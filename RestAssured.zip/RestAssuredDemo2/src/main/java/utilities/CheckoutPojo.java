package utilities;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CheckoutPojo {

	public String version;
    public String encoding;
    public CheckoutResponse checkoutResponse;
    
    public static class CheckoutResponse{

    	public CheckoutResult checkoutResult;
    	@JsonProperty("@xmlns")
    	private String xmlns;

    	@JsonProperty("@xmlns$xsd")
    	private String xmlnsxsd;

    	@JsonProperty("@xmlns$xsi")
    	private String xmlnsxsi;

    	}
	public static class CheckoutResult{

		@JsonProperty("@xsi$type")
		private String xsiType;

		private String acoustikItemID;
		private String assignmentID;
		private String expirationDate;
		public Status status;
		private String transactionID;
		}
	public static class Status{
		public String code;
		public String statusMessage;
		}
}