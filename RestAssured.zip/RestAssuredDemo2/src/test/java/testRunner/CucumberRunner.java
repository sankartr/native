package testRunner;

import java.io.IOException;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import utilities.TestReporting;


@RunWith(Cucumber.class)

@CucumberOptions(features = { "src/test/resources" }, glue = { "stepDefinitions" }, dryRun = false, 
		plugin = {"timeline:reports", "json:target/Results/cucumber.json", "pretty" },
		tags = "@POST",
		monochrome = true)

public class CucumberRunner {

	@BeforeClass
	public static void setUpBeforeClass() throws Throwable {
	
		System.out.println("Before class is initiated");
	}
	
	@AfterClass
	public static void afterClass() throws IOException {

		TestReporting.ReportingFormat();
		
	}
	
}
