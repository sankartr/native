package stepDefinitions;

import org.junit.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ProfileValidation {

	private static final String BaseURL = "https://uataxis360apim.azure-api.net/";
	private static final String Createprofile="kidszone/api/v1/libraries/BC4DE874-02FE-EC11-B47A-28187855E183/patrons/bf6abc03-c782-49d1-bbe9-52071ddf0221/profiles/create";
	private static final String GETProfile="kidszone/api/v1/libraries/BC4DE874-02FE-EC11-B47A-28187855E183/patrons/bf6abc03-c782-49d1-bbe9-52071ddf0221/profiles/16102445";
	private static final String UpdateProfile="kidszone/api/v1/libraries/BC4DE874-02FE-EC11-B47A-28187855E183/patrons/bf6abc03-c782-49d1-bbe9-52071ddf0221/profiles/16102445";
	private static Response response;

	@Given("user has given the base URI")
	public void user_has_given_the_base_URI() {
		RestAssured.baseURI = BaseURL;
	}
	@When("user calls create profile with post request method")
	public void user_calls_create_Profile_with_post_request_method() {
		response = RestAssured.given().log().all()
				  .header("Content-Type", "application/json")
				  .header("Ocp-Apim-Subscription-Key","7058c655dacc4e9f843297f96802e6ad")
				  .header("Authorization","Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJQYXRyb25JZCI6ImJmNmFiYzAzLWM3ODItNDlkMS1iYmU5LTUyMDcxZGRmMDIyMSIsIlVzZXJOYW1lIjoiQlRBdXRvIiwiTGlicmFyeUlkIjoiQkM0REU4NzQtMDJGRS1FQzExLUI0N0EtMjgxODc4NTVFMTgzIiwiVmVuZG9ySWQiOiJCb3VuZGxlc3NBcHBBUEkiLCJTZXNzaW9uSWQiOiI1NzdCMUZEQi0wQzVELUVFMTEtOTkzNy0wMDBEM0E0RTI4REUiLCJQcm9maWxlSWQiOiI0OTk1ODU3IiwiUHJvZmlsZVR5cGUiOiJBZHVsdCIsIklzUHJpbWFyeSI6IlRydWUiLCJTZWNvbmRhcnlQcm9maWxlcyI6IjQ5OTU4NTgsNDk5NTg1OSIsIm5iZiI6MTY5NTgwMjAzMCwiZXhwIjoxNjk5NjkwMDMwLCJpYXQiOjE2OTU4MDIwMzB9.FHJcZt8CM7k5qVfSDbUQ0Mn04HrSd0FSY139VODm6To")
				  .body(PayLoad.pay_load_post())
				  .when()
				  .post(Createprofile);
		
	}
	@Then("verify the response status code is valid with {string}")
	public void verify_the_API_call_is_success_with_status_code_is(String string) {
		String jsonString = response.asString();
		String profileID = JsonPath.from(jsonString).get("profileID");
		System.out.println("The profileId for this user is ------> " + profileID);
		System.out.println("*****Create Profile response is =====> " + response.prettyPrint());
		System.out.println("*****Create Profile response is =====> " + response.getStatusCode());
		Assert.assertEquals(200, response.getStatusCode());
	}
	@When("user want to retrive the profile information")
	public void user_want_to_get_list_of_users_information() {
		response = RestAssured
				   .given()
				   .header("Content-Type", "application/json")
				   .header("Ocp-Apim-Subscription-Key","7058c655dacc4e9f843297f96802e6ad")
				   .header("Authorization","Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJQYXRyb25JZCI6ImJmNmFiYzAzLWM3ODItNDlkMS1iYmU5LTUyMDcxZGRmMDIyMSIsIlVzZXJOYW1lIjoiQlRBdXRvIiwiTGlicmFyeUlkIjoiQkM0REU4NzQtMDJGRS1FQzExLUI0N0EtMjgxODc4NTVFMTgzIiwiVmVuZG9ySWQiOiJCb3VuZGxlc3NBcHBBUEkiLCJTZXNzaW9uSWQiOiI1NzdCMUZEQi0wQzVELUVFMTEtOTkzNy0wMDBEM0E0RTI4REUiLCJQcm9maWxlSWQiOiI0OTk1ODU3IiwiUHJvZmlsZVR5cGUiOiJBZHVsdCIsIklzUHJpbWFyeSI6IlRydWUiLCJTZWNvbmRhcnlQcm9maWxlcyI6IjQ5OTU4NTgsNDk5NTg1OSIsIm5iZiI6MTY5NTgwMjAzMCwiZXhwIjoxNjk5NjkwMDMwLCJpYXQiOjE2OTU4MDIwMzB9.FHJcZt8CM7k5qVfSDbUQ0Mn04HrSd0FSY139VODm6To")	  
				   .when()
				   .get(GETProfile);
	}
	@Then("verify the response status code is valid {string}")
	public void verify_the_response_status_code_with_a_list_of_requested_data_is_returned(String statusCode) {
		System.out.println("*****Get profile response is =====>" +response.getStatusCode());
		int Responsestatus = response.getStatusCode();
		Assert.assertEquals(200, Responsestatus);
				  
	}
	@When("user should be updated the displayName for the Created profile")
	public void user_should_be_updated_the_displayName_for_the_Created_profile() {
		RequestSpecification request = RestAssured.given()
									.header("Content-Type", "application/json")
									.header("Ocp-Apim-Subscription-Key","7058c655dacc4e9f843297f96802e6ad")
									.header("Authorization","Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJQYXRyb25JZCI6ImJmNmFiYzAzLWM3ODItNDlkMS1iYmU5LTUyMDcxZGRmMDIyMSIsIlVzZXJOYW1lIjoiQlRBdXRvIiwiTGlicmFyeUlkIjoiQkM0REU4NzQtMDJGRS1FQzExLUI0N0EtMjgxODc4NTVFMTgzIiwiVmVuZG9ySWQiOiJCb3VuZGxlc3NBcHBBUEkiLCJTZXNzaW9uSWQiOiI1NzdCMUZEQi0wQzVELUVFMTEtOTkzNy0wMDBEM0E0RTI4REUiLCJQcm9maWxlSWQiOiI0OTk1ODU3IiwiUHJvZmlsZVR5cGUiOiJBZHVsdCIsIklzUHJpbWFyeSI6IlRydWUiLCJTZWNvbmRhcnlQcm9maWxlcyI6IjQ5OTU4NTgsNDk5NTg1OSIsIm5iZiI6MTY5NTgwMjAzMCwiZXhwIjoxNjk5NjkwMDMwLCJpYXQiOjE2OTU4MDIwMzB9.FHJcZt8CM7k5qVfSDbUQ0Mn04HrSd0FSY139VODm6To");	  		   
		response = request
				  .body(PayLoad.pay_load_put())
				  .when()
				  .put(UpdateProfile);
		System.out.println("*****Updateprofile response is =====> " + response.asString());
	}
	@Then("verify user is able to get the updated displayName")
	public void verify_user_is_able_to_get_the_updated_Displayname() {
		response = RestAssured
				   .given()
				   .header("Content-Type", "application/json")
				   .header("Ocp-Apim-Subscription-Key","7058c655dacc4e9f843297f96802e6ad")
				   .header("Authorization","Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJQYXRyb25JZCI6ImJmNmFiYzAzLWM3ODItNDlkMS1iYmU5LTUyMDcxZGRmMDIyMSIsIlVzZXJOYW1lIjoiQlRBdXRvIiwiTGlicmFyeUlkIjoiQkM0REU4NzQtMDJGRS1FQzExLUI0N0EtMjgxODc4NTVFMTgzIiwiVmVuZG9ySWQiOiJCb3VuZGxlc3NBcHBBUEkiLCJTZXNzaW9uSWQiOiI1NzdCMUZEQi0wQzVELUVFMTEtOTkzNy0wMDBEM0E0RTI4REUiLCJQcm9maWxlSWQiOiI0OTk1ODU3IiwiUHJvZmlsZVR5cGUiOiJBZHVsdCIsIklzUHJpbWFyeSI6IlRydWUiLCJTZWNvbmRhcnlQcm9maWxlcyI6IjQ5OTU4NTgsNDk5NTg1OSIsIm5iZiI6MTY5NTgwMjAzMCwiZXhwIjoxNjk5NjkwMDMwLCJpYXQiOjE2OTU4MDIwMzB9.FHJcZt8CM7k5qVfSDbUQ0Mn04HrSd0FSY139VODm6To")	  
				   .when()
				   .get(GETProfile);
		String jsonString = response.asString();
		System.out.println("jsonString--"+jsonString);
		String displayName = JsonPath.from(jsonString).get("profileName");
		System.out.println("updated displayName========>"+displayName);
		
		
	}
}
