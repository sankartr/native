package stepDefinitions;

public class PayLoad {

	public static String pay_load_post() {
	      return "{\n"
	      		+ "  \"Isprimary\": \"0\",\n"
	      		+ "  \"DisplayName\": \"BTPatron879\",\n"
	      		+ "  \"profileTypeId\": \"2\",\n"
	      		+ "  \"displayCheckoutHistory\": \"Y\",\n"
	      		+ "  \"enableTracking\": \"N\",\n"
	      		+ "  \"profiletypeinfo\": \"1\",\n"
	      		+ "  \"PinStatus\": \"N\",\n"
	      		+ "  \"IsEmailEnabled\": \"N\",\n"
	      		+ "  \"sameAsAdultEmail\": \"N\",\n"
	      		+ "  \"email\": \"test@gmail.com\",\n"
	      		+ "  \"UniversalPINFlag\": true\n"
	      		+ "}";
	   }
	public static String pay_load_put()
	{
		return "{\n"
				+ "  \"profileID\": \"16102445\",\n"
				+ "  \"profileType\": \"Teen\",\n"
				+ "  \"profileTypeId\": 2,\n"
				+ "  \"displayName\": \"sankar\"\n"
				+ "  \n"
				+ "}";
	}

}
