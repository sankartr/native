package utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class Report {

	static Configuration config = new Configuration(new File(System.getProperty("user.dir") + "/target/Results"),
			"AutomationReport");
	
	public static void generateReport(String JsonFile)
	{
		config.addClassifications("Browser", "Chromium");
		config.addClassifications("Version", "98.0.4695.0");
		List<String> JsonFiles = new ArrayList<String>();
		JsonFiles.add(JsonFile);
		ReportBuilder report = new ReportBuilder(JsonFiles, config);
		report.generateReports();

	}
}
