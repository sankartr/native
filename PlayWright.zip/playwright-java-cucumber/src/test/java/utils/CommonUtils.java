package utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.BrowserType.LaunchOptions;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class CommonUtils {

	public static WebDriver driver = null;

	public Page configRead() throws IOException {
		Page page = null;
		Playwright playwright = Playwright.create();
		BrowserType chrome = playwright.chromium();
		Properties loadProperties = loadProperties();
		String getBrowser = loadProperties.getProperty("browser");
		BrowserList browserType = BrowserList.valueOf(getBrowser.toUpperCase());
		switch (browserType) {
		case CHROME:
			Browser chromeBrowser = chrome
					.launch(new BrowserType.LaunchOptions().setChannel("chrome").setHeadless(false));
			page = chromeBrowser.newPage();
			break;
		case FIREFOX:
			BrowserType fireFox = playwright.firefox();
			Browser firefoxBrowser = fireFox
					.launch(new BrowserType.LaunchOptions().setChannel("firefox").setHeadless(false));
			page = firefoxBrowser.newPage();
			break;
		case EDGE:
			Browser edgeBrowser = chrome
					.launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(false));
			page = edgeBrowser.newPage();
			break;
		case SAFARI:
			Browser safariBrowser = playwright.webkit().launch(new BrowserType.LaunchOptions().setHeadless(false));
			page = safariBrowser.newPage();
			break;
		case CHROMIUM:
			Browser chromiumBrowser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
			page = chromiumBrowser.newPage();
			break;
		}
		return page;

	}

	public static void jsClick(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, 15);
		WebElement webelement = wait.until(ExpectedConditions.visibilityOf(element));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', 'background: lightskyblue; border: 2px solid red;');",
				webelement);
		js.executeScript("arguments[0].setAttribute('style', arguments[1]);", webelement, "");
		js.executeScript("arguments[0].click();", webelement);
	}

	public Properties loadProperties() throws IOException {

		Properties props = new Properties();
		File file = new File(System.getProperty("user.dir") + "/src/test/resources/config/config.properties");
		FileReader fileInput = new FileReader(file);
		props.load(fileInput);
		return props;
	}

	public enum BrowserList {
		CHROME, FIREFOX, EDGE, SAFARI, CHROMIUM, IE, ANDROID, IOS
	}
}
