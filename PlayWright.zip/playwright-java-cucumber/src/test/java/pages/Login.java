package pages;

import com.microsoft.playwright.Page;
import utils.CommonUtils;

public class Login extends CommonUtils {

	Page page;
	String login_Button = "id=loginBtn";
	String login_Id = "id=LogOnModel_UserName";
	String login_password = "id=LogOnModel_Password";
	String search = "//input[@class='kz-searchTerm ng-untouched ng-pristine ng-valid']";
	String search_Button = "//button[@class='kz-searchButton']";
	String login_confirm = "id=loc_btnLogin";
	String HamburgerMenu = "id=loc_btnHamburgerMenu";
	String myShelf = "id=loc_linkMyShelf";
	String checkout = "id=loc_labelCheckouts";
	String filtericon = "id=loc_btnFilter";
	String eBook_filter = "id=loc_btnSelected eBook";
	String ickon="//figure[@class='ProfileButton_icon-account__ZXM7z']";
	String Email="//input[@class='email-input text-input']";
	String password="//input[@class='password-input text-input']";
	String submit="//button[@type='submit']";

	public String getLogin_Id() {
		return login_Id;
	}

	public String getLogin_password() {
		return login_password;
	}

	public String getSearch_Button() {
		return search_Button;
	}

	public Login(Page page) {
		this.page = page;
	}

	public void click_loginPage() {
		page.click(login_Button);
	}

	public void enterIdandPassword(String userName, String password) {
		page.fill(login_Id, userName);
		page.fill(login_password, password);
		page.click(login_confirm);
	}

	public void searchBooks(String books) {
		page.click(search);
		page.fill(search, books);
		page.click(search_Button);
	}

	public void navigatemyShelf() {
		page.click(HamburgerMenu);
		page.click(myShelf);
	}

	public void navigatetoCheckout() {
		page.click(checkout);

	}

	public void sortbyeBook() {
		page.click(filtericon);
		page.click(eBook_filter);
	}
	
	public void icon()
	{
		page.click(ickon);
	}
	
	public void login()
	{
		page.click(Email);
		page.fill(Email,"sankar");
		page.fill(password, "sksks");
		page.click(submit);
	}

}
