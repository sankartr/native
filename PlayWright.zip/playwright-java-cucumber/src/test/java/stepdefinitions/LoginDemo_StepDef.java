package stepdefinitions;

import java.util.Properties;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Login;
import utils.CommonUtils;

public class LoginDemo_StepDef extends CommonUtils {

	Login login;

	@Given("user launch the 'Magic Independent library' url$")
	public void user_launch_the_magic_independent_library_url() throws Throwable {
		Page page = configRead();
		page.setDefaultTimeout(5000000);
		page.navigate("https://simmer-b.kfc-digital.io/");
		login = new Login(page);
	}

	@When("user clicks on Login button {string} and {string}")
	public void user_clicks_on_login_button(String userName, String password) throws Throwable {
		login.click_loginPage();
		login.enterIdandPassword(userName, password);
	}

	@Then("user should see updated login screen$")
	public void user_should_see_updated_login_screen() throws Throwable {

	}

	@And("search the {string}")
	public void user_click_on_forgot_pin_cta(String books) throws Throwable {
		login.searchBooks(books);
	}
	@And("user navigate to myshelf")
    public void user_navigate_to_myshelf() throws Throwable {
		login.navigatemyShelf();
    }

    @And("user navigate to checkout")
    public void user_navigate_to_checkout() throws Throwable {
    	login.navigatetoCheckout();
    }

    @And("user should able to sort by ebook")
    public void user_should_able_to_sort_by_ebook() throws Throwable {
    	login.sortbyeBook();
    }
    @When("click the icon")
    public void click_icon()
    {
    	
    	login.icon();
    	login.login();
    }

}
