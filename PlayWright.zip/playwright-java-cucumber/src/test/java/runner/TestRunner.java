package runner;


import org.junit.After;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import stepdefinitions.LoginDemo_StepDef;
import utils.Report;


@RunWith(Cucumber.class)
@CucumberOptions( monochrome = true,
        features = "src/test/resources/features/",
        glue = {"stepdefinitions"},
        tags = "@Demo",
        plugin = {"pretty","junit:target/junitreport.xml","json:target/jsonreport.json","html:target/cucumber-reports"}
        
)
public class TestRunner {

	@AfterClass
	public static void afterTest() throws InterruptedException
	{
		Report.generateReport(System.getProperty("user.dir") + "/target/Results/cucumber.json");
	}
	 
}

