package pom.kidszone;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ISelect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class Tier2_TitlelistPage_VBookandVideo extends CommonActions {

	public Tier2_TitlelistPage_VBookandVideo(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	// ***************************Locators************************************************//

	@iOSXCUITFindBy(accessibility = "filter_cta")
	@AndroidFindBy(xpath = "//*[@resource-id='filter_cta']")
	private MobileElement video_Refiner;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@label='Publication date']")
	@AndroidFindBy(xpath = "//android.widget.RadioButton[contains(@content-desc,'Publication')]")
	private MobileElement filter_checkbox;
	
	@iOSXCUITFindBy(accessibility = "Sort By")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Sort By')]")
	private MobileElement video_Sort;
	
	@iOSXCUITFindBy(accessibility = "SORT_LIST_5")
	@AndroidFindBy(xpath = "//*[@resource-id='SORT_LIST_5']")
	private MobileElement view_Title;
	
	@iOSXCUITFindBy(accessibility = "Refiner_sortBy_toggle")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Sort By')]")
	private MobileElement view_Publishers;
	
	@iOSXCUITFindBy(accessibility = "Refiner_Age Level_toggle")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Age Level\"]")
	private MobileElement view_AgeRange;

	@iOSXCUITFindBy(accessibility = "Refiner_Language_toggle")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Language\"]")
	private MobileElement view_Language;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"item.listTestId1\"]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Publication')]")
	private MobileElement view_Publication_Date;
	
	@iOSXCUITFindBy(accessibility = "Refiner_search_cta")
	@AndroidFindBy(xpath = "//*[@resource-id='Refiner_search_cta']")
	private MobileElement search_CTA;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"item.listTestId_0\"]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Popularity')]")
	private MobileElement view_Popularity;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"item.listTestId2\"]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Relevance')]")
	private MobileElement view_Relevance;
	
	@iOSXCUITFindBy(accessibility = "Dummy_bottomDrawer")
	@AndroidFindBy(xpath = "//*[@resource-id='Dummy_bottomDrawer']")
	private MobileElement bottomDrawer;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'adp_card_image_card_VID')])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VID')])[1]")
	private MobileElement video_icon;
	
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'adp_card_image_card_VBK')])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VBK')])[1]")
	private MobileElement vBook_icon;
	
	@iOSXCUITFindBy(accessibility = "Dummy_play_ActionCTA")
	@AndroidFindBy(xpath = "//*[@resource-id='Dummy_play_ActionCTA']")
	private MobileElement play_ActionCTA;
	
	@iOSXCUITFindBy(accessibility = "secondaryButtonTestId")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"See dropdown, \"]")
	private MobileElement secondary_CTA;
	
	@iOSXCUITFindBy(accessibility = "Dummy_returnInBottomDrawer")
	@AndroidFindBy(xpath = "//*[@resource-id='Dummy_returnInBottomDrawer']")
	private MobileElement returnInBottomDrawer;
	
	@iOSXCUITFindBy(accessibility = "Dummy_renewInBottomDrawer")
	@AndroidFindBy(xpath = "//*[@resource-id='Dummy_renewInBottomDrawer']")
	private MobileElement renewInBottomDrawer;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Play')]")
	private MobileElement video_play_Button;
	
	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Checkout')]")
	private MobileElement video_checkout_Button;
	
	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='Dummy']")
	private MobileElement video_Button;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,\"adp_card_image_card_VID\")])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VID')])[1]")
	private MobileElement video_Title_card;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,\"adp_card_image_card_VBK\")])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VBK')])[1]")
	private MobileElement vBook_Title_card;
	
	@iOSXCUITFindBy(accessibility = "Series")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'AUTHOR')]")
	private MobileElement video_Author;

	@iOSXCUITFindBy(accessibility = "carAccordion_outer")
	@AndroidFindBy(xpath = "//*[@resource-id='carAccordion_outer']")
	private MobileElement sort_by;
	
	// ***********************Method********************************************************//

	
	public MobileElement getvideo_Refiner() {
		return video_Refiner;
	}
	
	public MobileElement getvideo_Sort() {
		return video_Sort;
	}
	
	public MobileElement getView_Title() {
		return view_Title;
	}
	
	public MobileElement getView_Publishers() {
		return view_Publishers;
	}
	
	public MobileElement getView_AgeRange() {
		return view_AgeRange;
	}
	
	public MobileElement getView_Language() {
		return view_Language;
	}
	
	public MobileElement getView_Publication_Date() {
		return view_Publication_Date;
	}
	
	public MobileElement getView_Popularity() {
		return view_Popularity;
	}
	
	public MobileElement getView_Relevance() {
		return view_Relevance;
	}

	public MobileElement getVideo_Author() {
		return video_Author;
	}

	public MobileElement getvideo_icon() {
		return video_icon;
	}
	
	public MobileElement getvBook_icon() {
		return vBook_icon;
	}
	
	public MobileElement verifyPlay_ActionCTA() {
		return play_ActionCTA;
	}
	
	public MobileElement verifySecondary_CTA() {
		return secondary_CTA;
	}
	
	public MobileElement verifyReturnInBottomDrawer() {
		return returnInBottomDrawer;
	}
	
	public MobileElement verifyRenewInBottomDrawer() {
		return renewInBottomDrawer;
	}
	
	public boolean verifyTier2Page() {
		boolean tier2Page = false;

		if (isElementPresent(video_Refiner)) {
			tier2Page = true;
		}
		return tier2Page;
	}

	public void expand_SorrtBy()
	{
		ClickOnMobileElement(sort_by);
	}
	public boolean verifyTier2page_ActionCTA()
	{
		boolean actionCTA = false;
		if(isElementPresent(video_play_Button))
		{
			actionCTA=true;
		}
		else if(isElementPresent(video_checkout_Button))
		{
			actionCTA=true;	
		}
		return actionCTA;
	}
	
	public void verifyNotStartedWatchingVideo()
	{
		boolean book=true;
		MobileElement findElement = (MobileElement) DriverManager.getDriver()
				.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
						+ ".scrollIntoView(new UiSelector().text(\"Play\"))"));
		if (isElementPresent(findElement)) {
			logger.info("Not started watching the checkedout video");
		} else {
			book = false;
			logger.info("Started watching the checkedout video");
		}
		
	}
	
	public void verifyStartedWatchingVideo()
	{
		boolean book=true;
		MobileElement findElement = (MobileElement) DriverManager.getDriver()
				.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
						+ ".scrollIntoView(new UiSelector().text(\"Play\"))"));
		if (isElementPresent(findElement)) {
			ClickOnMobileElement(findElement);
			logger.info("Started watching the checkedout video");
		} else {
			book = false;
			logger.info("Checkedout video not played");
		}
	}
	
	public void verifyPlay_ActionCTA_Video()
	{
		boolean book=true;
		MobileElement findElement = (MobileElement) DriverManager.getDriver()
				.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
						+ ".scrollIntoView(new UiSelector().text(\"Play\"))"));
		if (isElementPresent(findElement)) {
			logger.info("Play ActionCTA");
		} else {
			book = false;
			logger.info("Play ActionCTA - Not available");
		}
		
	}
	
	public void navigatetoRefine_section() {
		ClickOnMobileElement(video_Refiner);	
	}
	
	public void select_filter_checkbox() {
		if(isElementPresent(filter_checkbox)) {
			ClickOnMobileElement(filter_checkbox);
		}
	}
	
	public void select_SortBy_Publication() {
		ClickOnMobileElement(view_Publication_Date);	
	}	
	
	public void clickSearch_CTA() {
		ClickOnMobileElement(search_CTA);	
	}
	
	public void clickBottomDrawer() {
		ClickOnMobileElement(bottomDrawer);	
	}
	
	public void navigatetoVideodetail() {
		ClickOnMobileElement(video_Title_card);
	}
	
	public void navigatetoVbookdetail() {
		ClickOnMobileElement(vBook_Title_card);
	}

}
