package pom.kidszone;

import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class SetParentPin extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(SetParentPin.class);
	
	public SetParentPin(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

/************************ Locators *************************/

	@iOSXCUITFindBy(accessibility = "Profile Management PIN heading")
	@AndroidFindBy(xpath = "//*[@text='Profile Management PIN heading']")
	private MobileElement setParentPinPg_lbl_header;

	@iOSXCUITFindBy(accessibility = "Pin")
	@AndroidFindBy(xpath = "//*[@resource-id='PIN_INPUT']/android.view.ViewGroup")
	private List<MobileElement> setParentPin_txt_pin;

	@iOSXCUITFindBy(accessibility = "NUM_1_BTN")
	@AndroidFindBy(xpath = "//*[@resource-id='NUM_1_BTN']")
	private MobileElement setParentPin_NumpadKeyOne;
	
	@iOSXCUITFindBy(accessibility = "NUM_2_BTN")
	@AndroidFindBy(xpath = "//*[@resource-id='NUM_2_BTN']")
	private MobileElement setParentPin_NumpadKeyTwo;
	
	@iOSXCUITFindBy(accessibility = "loc_msgSnackbarFailed")
	@AndroidFindBy(xpath = "//*[@text='Pin mismatch']")
	private MobileElement setParentPin_lbl_wrongPin;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@text='Forgot PIN']")
	private MobileElement setParentPin_btn_forgotPin;

	@iOSXCUITFindBy(accessibility = "Done_button")
	@AndroidFindBy(xpath = "//*[@resource-id='Done_button']")
	private MobileElement setParentPin_btn_submit;
	
	@iOSXCUITFindBy(accessibility = "Profile Management PIN heading")
	@AndroidFindBy(xpath = "//*[@content-desc=\"Profile Management PIN heading, \"]")
	private MobileElement resetPin_lbl_header;

	@iOSXCUITFindBy(accessibility = "reset_button")
	@AndroidFindBy(xpath = "//*[@resource-id='reset_button']")
	private MobileElement resetPin_btn;
	
	@iOSXCUITFindBy(accessibility = "SECURITY_QUESTION_INPUT")
	@AndroidFindBy(xpath = "//*[@resource-id='SECURITY_QUESTION_INPUT']")
	private MobileElement resetPin_lbl_securityQuestion;

	@iOSXCUITFindBy(accessibility = "SECURITY_QUESTION_INPUT")
	@AndroidFindBy(xpath = "//*[@resource-id='SECURITY_QUESTION_INPUT']")
	private MobileElement resetPin_txt_securityQuestion;

	@iOSXCUITFindBy(accessibility = "FORGOT_PIN_ACTION")
	@AndroidFindBy(xpath = "//*[@resource-id='FORGOT_PIN_ACTION']")
	private MobileElement resetPin_btn_submit;
	
	@iOSXCUITFindBy(accessibility = "submit button")
	@AndroidFindBy(xpath = "//*[@resource-id='android:id/button1']")
	private MobileElement resetPin_btn_sucessOK;

	@iOSXCUITFindBy(accessibility = "alert_close")
	@AndroidFindBy(xpath = "//*[@resource-id='alert_close']")
	private MobileElement resetPin_btn_WrongSecAnsClose;
	
	public MobileElement getResetPin_btn_WrongSecAnsClose() {
		return resetPin_btn_WrongSecAnsClose;
	}

	public MobileElement getSetParentPinPg_lbl_header() {
		return setParentPinPg_lbl_header;
	}

	public List<MobileElement> getSetParentPin_txt_pin() {
		return setParentPin_txt_pin;
	}

	public MobileElement getSetParentPin_lbl_wrongPin() {
		return setParentPin_lbl_wrongPin;
	}

	public MobileElement getSetParentPin_btn_forgotPin() {
		return setParentPin_btn_forgotPin;
	}

	public MobileElement getSetParentPin_btn_submit() {
		return setParentPin_btn_submit;
	}

	public MobileElement getResetPin_btn() {
		return resetPin_btn;
	}

	public MobileElement getResetPin_txt_securityQuestion() {
		return resetPin_txt_securityQuestion;
	}

	public MobileElement getResetPin_btn_submit() {
		return resetPin_btn_submit;
	}
	
	public MobileElement getSetParentPin_NumpadKeyOne() {
		return setParentPin_NumpadKeyOne;
	}

	public MobileElement getSetParentPin_NumpadKeyTwo() {
		return setParentPin_NumpadKeyTwo;
	}

	public MobileElement getResetPin_lbl_header() {
		return resetPin_lbl_header;
	}

	public MobileElement getResetPin_lbl_securityQuestion() {
		return resetPin_lbl_securityQuestion;
	}

	public MobileElement getResetPin_btn_sucessOK() {
		return resetPin_btn_sucessOK;
	}


/********************Action methods*************************/
	
	public void parentPin() {
//		for (int i = 0; i < 4; i++) {
//			ClickOnMobileElement(setParentPin_NumpadKeyOne);
//			waitFor(2000);
//		}
			ClickOnMobileElement(setParentPin_NumpadKeyOne);
			ClickOnMobileElement(setParentPin_NumpadKeyOne);
			ClickOnMobileElement(setParentPin_NumpadKeyOne);
			ClickOnMobileElement(setParentPin_NumpadKeyOne);
			waitFor(2000);
			ClickOnMobileElement(setParentPin_btn_submit);
	}
	
	public void invalidparentPin() {
		for (int i = 0; i < 4; i++) {
			ClickOnMobileElement(setParentPin_NumpadKeyTwo);
		}
//			ClickOnMobileElement(setParentPin_btn_submit);
	}
	
	public void setParentPin() {
		for (int i = 0; i < 4; i++) {
			ClickOnMobileElement(setParentPin_NumpadKeyOne);
		}
	}
	
	public void confirmParentPin() {
//		for (int i = 0; i < 5; i++) {
//			waitFor(2000);
//			ClickOnMobileElement(setParentPin_NumpadKeyOne);
//		}
		ClickOnMobileElement(setParentPin_NumpadKeyOne);
		ClickOnMobileElement(setParentPin_NumpadKeyOne);
		ClickOnMobileElement(setParentPin_NumpadKeyOne);
		ClickOnMobileElement(setParentPin_NumpadKeyOne);
		waitFor(2000);
//		ClickOnMobileElement(setParentPin_btn_submit);
		
	}
	
	public void wrongParentPin() {	
		waitFor(2000);
		ClickOnMobileElement(setParentPin_NumpadKeyOne);
		ClickOnMobileElement(setParentPin_NumpadKeyTwo);
		ClickOnMobileElement(setParentPin_NumpadKeyOne);
		ClickOnMobileElement(setParentPin_NumpadKeyOne);
		ClickOnMobileElement(setParentPin_btn_submit);
		waitFor(2000);
	}

	public void securityAnsforResetPin(String answer) {
		ClickOnMobileElement(resetPin_txt_securityQuestion);
		SendKeysOnMobileElement(resetPin_txt_securityQuestion, answer);
		ClickOnMobileElement(resetPin_btn_submit);
	}
	
	public void resetPinClick() {
		ClickOnMobileElement(resetPin_btn);
		logger.info("Reset pin clicked");
	}
	
	public void popCloseAfterPinReset() {
		ClickOnMobileElement(resetPin_btn_WrongSecAnsClose);
		resetPin_txt_securityQuestion.clear();
		securityAnsforResetPin("red");
		setParentPin();
		confirmParentPin();
		try {
			ClickOnMobileElement(resetPin_btn_sucessOK);
		} catch (Exception e) {
			logger.info("Pin reset success");
		}	
	}
	
	public void multiTimeWrongPin() {
		for (int i = 1; i < 4; i++) {
			try {
				resetPinClick();
				break;
			} catch (Exception e) {
				logger.info("Reset pin not displayed on "+i+" attempt");
			}
			wrongParentPin();
			try {
				resetPinClick();
				break;
			} catch (Exception e) {
				logger.info("Reset pin not displayed on "+i+" attempt");
			}
		}
	}
	
}
