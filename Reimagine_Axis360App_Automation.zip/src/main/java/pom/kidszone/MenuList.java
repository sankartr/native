package pom.kidszone;

import java.util.List;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class MenuList extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(MenuList.class);

	public MenuList(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/**************************** Locators ****************************/

	@iOSXCUITFindBy(accessibility = "Empty list")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU_FLAT_LIST']//android.widget.TextView")
	private List<MobileElement> menuList_options;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"MENU_FLAT_LIST\"]/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU_FLAT_LIST']//android.widget.TextView")
	private List<MobileElement> menuList_options1;

	@iOSXCUITFindBy(accessibility = "My Library")
	@AndroidFindBy(xpath="//*[@text='Library']")
//	@AndroidFindBy(xpath="//*[@resource-id='MYLIBRARY']")
	private MobileElement menu_btn_footerlibrary;
	
	@iOSXCUITFindBy(accessibility = "MYLIBRARY")
	@AndroidFindBy(xpath="//*[@text='Library']")
//	@AndroidFindBy(xpath="//*[@resource-id='MYLIBRARY']")
	private MobileElement menu_btn_footerlibrary1;
	
	@iOSXCUITFindBy(accessibility = "Device_Preferences_Title")
	@AndroidFindBy(xpath = "//*[@resource-id='Device_Preferences_Title']")
	private MobileElement preferencePg_lbl_Header;

	@iOSXCUITFindBy(accessibility = "common_toolbar_title")
	@AndroidFindBy(id = "common_toolbar_title")
	private MobileElement preferencePg_lbl_Header1;

	@iOSXCUITFindBy(accessibility = "Menu")
	@AndroidFindBy(xpath = "//*[@resource-id='Checkbox_Auto_Play']")
	private MobileElement preferencePg_checkBox_AutoPlay;

	@iOSXCUITFindBy(accessibility = "Menu")
	@AndroidFindBy(xpath = "//*[@resource-id='Checkbox_Auto_Delete']")
	private MobileElement preferencePg_checkBox_AutoDelete;

	@iOSXCUITFindBy(accessibility = "Menu")
	@AndroidFindBy(xpath = "//*[@resource-id='Checkbox_Use_Cellular_Data']")
	private MobileElement preferencePg_checkBox_CellData;

	@iOSXCUITFindBy(accessibility = "Menu")
	@AndroidFindBy(xpath = "//*[@resource-id='Button_Save']")
	private MobileElement preferencePg_btn_Save;

	@iOSXCUITFindBy(accessibility = "Menu")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement preferencePg_btn_Back;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Help Title\"]")
	@AndroidFindBy(xpath = "//*[@text='Help']")
	private MobileElement helpPg_lbl_header;

	@iOSXCUITFindBy(accessibility = "Home")
	@AndroidFindBy(xpath = "//*[@text='General Help']")
	private MobileElement helpPg_lbl_header1;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Patron Support\"]")
	@AndroidFindBy(xpath = "//*[@text='Patron Support']")
	private MobileElement patSupportPg_lbl_header;

	@iOSXCUITFindBy(accessibility  = "Patron Support Title")
	@AndroidFindBy(xpath = "//*[@text='Patron Support']")
	private MobileElement patSupportPg_lbl_header1;
	
	@iOSXCUITFindBy(accessibility = "About us Title")
	@AndroidFindBy(xpath = "//*[@text='About Us']")
	private MobileElement aboutPg_lbl_header;

	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "(//*[@content-desc=\"Terms & Conditions Heading, \"])[1]")
	private MobileElement termsPg_lbl_header;

	@iOSXCUITFindBy(accessibility = "Menu")
	@AndroidFindBy(xpath = "(//*[@content-desc=\"Privacy Policy heading, \"])[1]")
	private MobileElement privacyPg_lbl_header;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeNavigationBar[@name='Terms and Conditions']")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement menu_txt_termsandconditions;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Privacy Policy\"]")
	@AndroidFindBy(xpath = "(//*[@text='Privacy Policy'])[1]")
	private MobileElement menu_txt_privacypolicy;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"txtTitle\"]")
	@AndroidFindBy(xpath = "//*[@text='Privacy Policy']")
	private MobileElement menu_txt_privacypolicy1;

	@iOSXCUITFindBy(accessibility = "MYLIBRARY")
	@AndroidFindBy(xpath = "//*[@text='Library']")
	private MobileElement menu_btn_mylibrary;

	@iOSXCUITFindBy(accessibility = "My Library")
	@AndroidFindBy(id = "txtTitle")
	private MobileElement menu_txt_mylibrary;

	@iOSXCUITFindBy(accessibility = "FEATURE_READING_PROGRAM_BUTTON_outer")
	@AndroidFindBy(xpath = "//*[@resource-id='FEATURE_READING_PROGRAM_TITLE']")
	private MobileElement menu_lbl_featuredprgHeader;
	
	@iOSXCUITFindBy(accessibility = "BROWSE")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'BROWSE')]")
	private MobileElement browse_Bottom_Navigation;

	@iOSXCUITFindBy(accessibility = "sort_Option")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[contains(@content-desc,'sort_Option')]")
	private MobileElement sort_Option;

	@iOSXCUITFindBy(accessibility = "REFINE_MODAL_SCREEN")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'REFINE_MODAL_SCREEN')]")
	private MobileElement results_No_Pills;
	@iOSXCUITFindBy(accessibility = "Sort By")
	@AndroidFindBy(xpath = "//*[contains(@text,'Sort By')]")
	private MobileElement sort_By;
	
	@iOSXCUITFindBy(accessibility = "SORT_LIST_0")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'SORT_LIST_0')]")
	private MobileElement sort_Added_Date;
	
	@iOSXCUITFindBy(accessibility = "SORT_LIST_1")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'SORT_LIST_1')]")
	private MobileElement sort_Author;
	
	@iOSXCUITFindBy(accessibility = "SORT_LIST_2")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'SORT_LIST_2')]")
	private MobileElement sort_Popularity;
	
	@iOSXCUITFindBy(accessibility = "Sort By")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'SORT_LIST_3')]")
	private MobileElement sort_Publication_Date;
	
	@iOSXCUITFindBy(accessibility = "SORT_LIST_4")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'SORT_LIST_4')]")
	private MobileElement sort_Return_Date;
	
	@iOSXCUITFindBy(accessibility = "SEARCH_BUTTON_TEST_ID")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'SEARCH_BUTTON_TEST_ID')]")
	private MobileElement search_Btn;
	
	@iOSXCUITFindBy(accessibility = "SORT_LIST_5")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'SORT_LIST_5')]")
	private MobileElement sort_Title;
	
	@iOSXCUITFindBy(accessibility = "RESULT_COUNT_TEST_ID")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'RESULT_COUNT_TEST_ID')]")
	private MobileElement search_Result;

	@iOSXCUITFindBy(accessibility = "intermediateScreen")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'intermediateScreen')]")
	private MobileElement intermediateScreen;

	@iOSXCUITFindBy(accessibility = "RESULT_COUNT_TEST_ID")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'RESULT_COUNT_TEST_ID')]")
	private MobileElement browse_Result_Page;

	@iOSXCUITFindBy(accessibility = "REFINE_ICON")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'REFINE_ICON')]")
	private MobileElement refiners_Option;
	@iOSXCUITFindBy(accessibility = "BROWSE_SUBJECT_LIST_ITEM_TEST_ID")
	@AndroidFindBy(xpath ="(//*[@resource-id = 'BROWSE_SUBJECT_LIST_ITEM_TEST_ID'])[1]")
	private MobileElement browse_Title;
	
	@iOSXCUITFindBy(accessibility = "CANCEL_BUTTON_TEST_ID")
	@AndroidFindBy(xpath ="//*[@resource-id = 'CANCEL_BUTTON_TEST_ID']")
	private MobileElement close_Refine;
	
	@iOSXCUITFindBy(accessibility = "REFINE_ICON")
	@AndroidFindBy(xpath ="//*[@resource-id = 'REFINE_ICON']")
	private MobileElement refineOption;

	@iOSXCUITFindBy(accessibility = "FEATURE_READING_PROGRAM_BUTTON_outer")
	@AndroidFindBy(xpath = "(//*[@resource-id='FEATURE_READING_PROGRAM_BUTTON']/following::android.view.ViewGroup/android.view.View)[1]")
	private MobileElement menu_lbl_featuredprogramtiltle;

	@iOSXCUITFindBy(accessibility = "FEATURE_READING_PROGRAM_BUTTON")
	@AndroidFindBy(xpath = "//*[@resource-id='FEATURE_READING_PROGRAM_BUTTON']")
	private MobileElement menu_btn_featuredprogramaccordin;

	@iOSXCUITFindBy(accessibility = "VIEW_PROGRAM_DETAILS")
	@AndroidFindBy(xpath = "//*[@resource-id='VIEW_PROGRAM_DETAILS']")
	private MobileElement menu_btn_featuredprgViewDetail;

	@iOSXCUITFindBy(accessibility = "FEATURE_READING_PROGRAM_TITLE")
	@AndroidFindBy(xpath = "//*[@resource-id='FEATURE_READING_PROGRAM_TITLE']")
	private MobileElement menu_txt_featuredprogrambanner;

	@iOSXCUITFindBy(accessibility = "SEARCH_TEXT_BOX")
	@AndroidFindBy(xpath = "//*[@resource-id='btnSearchMenu']")
	private MobileElement menu_txt_searchbar;

	@iOSXCUITFindBy(accessibility = "btnSearchMenu")
	@AndroidFindBy(id = "btnSearchMenu")
	private MobileElement menu_txt_searchbar1;
	
	@iOSXCUITFindBy(accessibility = "more_LIBRARY_ADVANCE_SEARCH_BUTTON")
	@AndroidFindBy(xpath = "//*[@resource-id='btnAdvancedSearchMenu']")
	private MobileElement menu_btn_advancesearch;

	@iOSXCUITFindBy(accessibility = "idnotavailable")
	@AndroidFindBy(id = "idnotavailable")
	private MobileElement menu_btn_searchclosebutton;

	@iOSXCUITFindBy(accessibility = "Preferences_Menu")
	@AndroidBy(id = "dummy")
	private MobileElement menu_lbl_preferences;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidBy(id = "dummy")
	private MobileElement menu_lbl_patronsupport;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Legal, button\"]")
	@AndroidBy(xpath = "//*[@text='Legal']")
	private MobileElement menu_btn_legal;

	@iOSXCUITFindBy(accessibility = "Terms & Conditions Menu")
	@AndroidFindBy(xpath = "//*[@text='Terms & Conditions']")
	private MobileElement terms_And_Condition;

	@iOSXCUITFindBy(accessibility = "Terms & Conditions Menu")
	@AndroidBy(xpath = "//*[@resource-id=\"Terms & Conditions\"]")
	private MobileElement menu_btn_termscondition1;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\" Privacy Policy, button\"]")
	@AndroidBy(xpath = "Privacy Policy Menu")
	private MobileElement menu_btn_privacypolicy;

	@iOSXCUITFindBy(accessibility = "Privacy Policy Menu")
	@AndroidBy(xpath = "(//*[@text='Privacy policy'])[1]")
	private MobileElement menu_btn_privacypolicy1;

	@iOSXCUITFindBy(accessibility = "Profiles Menu")
	@AndroidBy(id = "Profiles Menu")
	private MobileElement menu_btn_profile1;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Preferences, button\"]")
	@AndroidBy(id = "dummy")
	private MobileElement menu_btn_old_preferences;
	
	@iOSXCUITFindBy(accessibility = "Preferences")
	@AndroidBy(xpath = "//*[@resource-id='Preferences']")
	private MobileElement menu_btn_preferences;

	@iOSXCUITFindBy(accessibility = "Help_Menu")
	@AndroidBy(id = "Help_Menu")
	private MobileElement menu_btn_help;

	@iOSXCUITFindBy(accessibility = "About us Menu")
	@AndroidBy(xpath = "//*[@resource-id='About_us_Menu']")
	private MobileElement menu_btn_about;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"About, button\"]")
	@AndroidBy(xpath = "//*[@text='About Us']")
	private MobileElement menu_btn_about_old;
	
	@iOSXCUITFindBy(accessibility = "Patron Support Menu")
	@AndroidBy(xpath = "//*[@text='Patron Support']")
	private MobileElement menu_btn_patronsupport;

	@iOSXCUITFindBy(accessibility = "Patron Support Menu")
	@AndroidBy(xpath = "MyPrgHeader")
	private MobileElement myProgram_lbl_header;
	
	public MobileElement getMyProgram_lbl_header() {
		return myProgram_lbl_header;
	}

	public MobileElement getMenu_btn_featuredprgViewDetail() {
		return menu_btn_featuredprgViewDetail;
	}

	public MobileElement getMenu_lbl_featuredprgHeader() {
		return menu_lbl_featuredprgHeader;
	}
	
	public MobileElement getBrowse_Bottom_Navigation() {
		return browse_Bottom_Navigation;
	}
	
	public MobileElement getSort_Option() {
		return sort_Option;
	}

	public MobileElement getResults_No_Pills() {
		return results_No_Pills;
	}
	public MobileElement getSort_By() {
		return sort_By;
	}
	
	public MobileElement getAdded_Date() {
		return sort_Added_Date;
	}
	
	public MobileElement getSort_Author() {
		return sort_Author;
	}
	
	public MobileElement getPopularity() {
		return sort_Popularity;
	}
	
	public MobileElement getPublication_Date() {
		return sort_Publication_Date;
	}
	
	public MobileElement getReturn_Date() {
		return sort_Return_Date;
	}
	
	public MobileElement getTitle() {
		return sort_Title;
	}
	
	public MobileElement getSearchResult() {
		return search_Result;
	}

	public MobileElement getIntermediateScreen() {
		return intermediateScreen;
	}

	public MobileElement getBrowse_Result_Page() {
		return browse_Result_Page;
	}

	public MobileElement getRefiners_Option() {
		return refiners_Option;
	}
	public MobileElement getMenu_txt_privacypolicy1() {
		return menu_txt_privacypolicy1;
	}

	public MobileElement getMenu_lbl_patronsupport() {
		return menu_lbl_patronsupport;
	}

	public MobileElement getMenu_lbl_preferences() {
		return menu_lbl_preferences;
	}

	public MobileElement getMenu_btn_searchclosebutton() {
		return menu_btn_searchclosebutton;
	}

	public MobileElement getMenu_txt_searchbar() {
		return menu_txt_searchbar;
	}

	public MobileElement getPreferencePg_lbl_Header1() {
		return preferencePg_lbl_Header1;
	}

	public MobileElement getPreferencePg_btn_Back() {
		return preferencePg_btn_Back;
	}

	public MobileElement getHelpPg_lbl_header() {
		return helpPg_lbl_header;
	}

	public MobileElement getHelpPg_lbl_header1() {
		return helpPg_lbl_header1;
	}

	public MobileElement getPatSupportPg_lbl_header() {
		return patSupportPg_lbl_header;
	}

	public MobileElement getAboutPg_lbl_header() {
		return aboutPg_lbl_header;
	}

	public MobileElement getTermsPg_lbl_header() {
		return termsPg_lbl_header;
	}

	public MobileElement getMenu_btn_termsandconditions() {
		return terms_And_Condition;
	}

	public MobileElement getMenu_txt_termsandconditions() {
		return menu_txt_termsandconditions;
	}

	public MobileElement getMenu_btn_privacypolicy() {
		return menu_btn_privacypolicy;
	}

	public MobileElement getMenu_txt_privacypolicy() {
		return menu_txt_privacypolicy;
	}

	public MobileElement getMenu_btn_mylibrary() {
		return menu_btn_mylibrary;
	}

	public MobileElement getMenu_txt_mylibrary() {
		return menu_txt_mylibrary;
	}

	public MobileElement getMenu_lbl_featuredprogramtiltle() {
		return menu_lbl_featuredprogramtiltle;
	}

	public MobileElement getMenu_btn_featuredprogramaccordin() {
		return menu_btn_featuredprogramaccordin;
	}

	public MobileElement getMenu_txt_featuredprogrambanner() {
		return menu_txt_featuredprogrambanner;
	}

	public List<MobileElement> getMenuList_options() {
		return menuList_options;
	}

	public List<MobileElement> getMenuList_options1() {
		return menuList_options1;
	}

	public MobileElement getPreferencePg_lbl_Header() {
		return preferencePg_lbl_Header;
	}

	public MobileElement getPreferencePg_checkBox_AutoPlay() {
		return preferencePg_checkBox_AutoPlay;
	}

	public MobileElement getPreferencePg_checkBox_AutoDelete() {
		return preferencePg_checkBox_AutoDelete;
	}

	public MobileElement getPreferencePg_checkBox_CellData() {
		return preferencePg_checkBox_CellData;
	}

	public MobileElement getPreferencePg_btn_Save() {
		return preferencePg_btn_Save;
	}

	/************************** Action Methods **************************/

	public void clickpatronsupport() {
		ClickOnMobileElement(menu_lbl_patronsupport);
	}

	public void clickpreferences() {
		ClickOnMobileElement(menu_lbl_preferences);
	}

	public void menuListValidation() {
		logger.info("User able to see below options");
		try {
			for (int i = 0; i < menuList_options1.size() - 1; i++) {
				System.out.println(menuList_options.get(i).getText());
			}
		} catch (Exception e) {
			for (int i = 0; i < menuList_options.size() - 1; i++) {
				System.out.println(menuList_options.get(i).getText());
			}
		}
	}

	public Boolean profileOptDisplayCheck() {
		Boolean profileDisplay = true;
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			if (isElementPresent(menu_btn_profile1)) {
				profileDisplay = false;
			}

		} else if (System.getProperty("platform").equalsIgnoreCase("android")) {
			if (isElementPresent(login.getHome_btn_Logout())) {
				logger.info("adult user");
				for (int i = 0; i < menuList_options.size() - 1; i++) {
					logger.info("list : " + menuList_options.get(i).getText());
					if (menuList_options.get(i).getText().equalsIgnoreCase("Profiles")) {
						profileDisplay = false;
						logger.info("User able to see profile option inside menu list");
						break;
					}
				}
			} else {
				for (int i = 0; i < menuList_options1.size() - 1; i++) {
					logger.info("list : " + menuList_options1.get(i).getText());
					if (menuList_options1.get(i).getText().equalsIgnoreCase("Profiles")) {
						profileDisplay = false;
						logger.info("User able to see profile option inside menu list");
						break;
					}
				}
			}

			logger.info("User not able to see profile option inside menu list");
		}
		return profileDisplay;
	}

	public void clickonPreference() {
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			if (isElementPresent(menu_btn_old_preferences)) {
					ClickOnMobileElement(menu_btn_old_preferences);
			} else if (isElementPresent(menu_btn_preferences)) {
					ClickOnMobileElement(menu_btn_preferences);
				}
				
		}
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			if (isElementPresent(login.getLogo_btn_menu())) {
				
				for (int i = 0; i < menuList_options.size() - 1; i++) {
					System.out.println(menuList_options.get(i).getText()+ "Menu1");
					if (menuList_options.get(i).getText().equalsIgnoreCase("Preferences")) {
						ClickOnMobileElement(menuList_options.get(i));
						logger.info("Preference button clicked");
						break;
					}
				}
			} else if (isElementPresent(login.getLogo_btn_menu1())) {
				for (int i = 0; i < menuList_options1.size() - 1; i++) {
					System.out.println(menuList_options1.get(i).getText()+ "Menu2");
					if (menuList_options1.get(i).getText().equalsIgnoreCase("Preferences")) {
						ClickOnMobileElement(menuList_options1.get(i));
						logger.info("Preference button clicked");
						break;
					}
					
					
				}
			}
				else if (isElementPresent(login.getLogo_btn_menu2())) {
					for (int i = 0; i < menuList_options1.size() - 1; i++) {
						System.out.println(menuList_options1.get(i).getText()+ "Menu2");
						if (menuList_options1.get(i).getText().equalsIgnoreCase("Preferences")) {
							ClickOnMobileElement(menuList_options1.get(i));
							logger.info("Preference button clicked");
							break;
						}
			}
				}
		}
		
		
//			
//			if (isElementPresent(menu_btn_preferences)) {
//				ClickOnMobileElement(menu_btn_preferences);
//				logger.info("Preference button clicked");
//			}
		}
	
		

	public void clickprofileMenu() {
		if (isElementPresent(login.getLogo_btn_menu())) {
			for (int i = 0; i < menuList_options.size() - 1; i++) {
				if (menuList_options.get(i).getText().equalsIgnoreCase("Profile")) {
					ClickOnMobileElement(menuList_options.get(i));
					logger.info("Preference button clicked");
					break;
				}
			}
		} else if (isElementPresent(login.getLogo_btn_menu1())) {
			for (int i = 0; i < menuList_options1.size() - 1; i++) {
				if (menuList_options1.get(i).getText().equalsIgnoreCase("Profile")) {
					ClickOnMobileElement(menuList_options1.get(i));
					logger.info("Preference button clicked");
					break;
				}
			}
		}
	}

	public Boolean privacyPolicy() {
		Boolean privacyPolicy = false;
		if (isElementPresent(menu_txt_privacypolicy)) {
			privacyPolicy = true;
		} else if (isElementPresent(menu_txt_privacypolicy1)) {
			privacyPolicy = true;
		}
		return privacyPolicy;
	}

	public Boolean preferenceNavCheck() {
		Boolean prefNav = true;
		if (isElementPresent(preferencePg_lbl_Header)) {
			prefNav = true;
			logger.info("User is on kid/teen Profile Preference Page");
		} else if (isElementPresent(preferencePg_lbl_Header1)) {
			prefNav = true;
			logger.info("User is on Adult Profile Preference Page");
		}
		return prefNav;
	}

	public void clickonHelp() {

		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			if (isElementPresent(login.getLogo_btn_menu())) {
				// ClickOnMobileElement(menu_btn_preferences);
			} else if (isElementPresent(login.getLogo_btn_menu1())) {
				if (isElementPresent(menu_btn_help)) {
					ClickOnMobileElement(menu_btn_help);
				}
			}

		}
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			if (isElementPresent(login.getLogo_btn_menu())) {
				for (int i = 0; i < menuList_options.size() - 1; i++) {
					if (menuList_options.get(i).getText().equalsIgnoreCase("Help")) {
						ClickOnMobileElement(menuList_options.get(i));
						logger.info("Help button clicked");
						break;
					}
				}
			} else if (isElementPresent(login.getLogo_btn_menu1())) {
				for (int i = 0; i < menuList_options1.size() - 1; i++) {
					if (menuList_options1.get(i).getText().equalsIgnoreCase("Help")) {
						ClickOnMobileElement(menuList_options1.get(i));
						logger.info("Help button clicked");
						break;
					}
				}

			}
		}
	}

	public Boolean helpPgNavCheck() {
		Boolean helpNav = false;
		if (isElementPresent(helpPg_lbl_header)) {
			helpNav = true;
			logger.info("User is on kid/teen Profile Preference Page");
		} else if (isElementPresent(helpPg_lbl_header1)) {
			helpNav = true;
			logger.info("User is on Adult Profile Preference Page");
		}
		return helpNav;
	}

	public void clickonPatronSupprot() {
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			if (isElementPresent(login.getLogo_btn_menu())) {
				// ClickOnMobileElement(menu_btn_preferences);

			} else if (isElementPresent(login.getLogo_btn_menu1())) {
				if (isElementPresent(menu_btn_patronsupport)) {
					ClickOnMobileElement(menu_btn_patronsupport);
				}
			}

		}
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			if (isElementPresent(login.getLogo_btn_menu())) {
				for (int i = 0; i < menuList_options.size() - 1; i++) {
					if (menuList_options.get(i).getText().equalsIgnoreCase("Patron Support")) {
						ClickOnMobileElement(menuList_options.get(i));
						logger.info("Patron support button clicked");
						break;
					}
				}
			} else if (isElementPresent(login.getLogo_btn_menu1())) {
				for (int i = 0; i < menuList_options1.size() - 1; i++) {
					if (menuList_options1.get(i).getText().equalsIgnoreCase("Patron Support")) {
						ClickOnMobileElement(menuList_options1.get(i));
						logger.info("Patron support button clicked");
						break;
					}
				}
			}
		}
	}

	public Boolean patSupportPgNavCheck() {
		Boolean patSupportNav = false;
		if (isElementPresent(patSupportPg_lbl_header)) {
			patSupportNav = true;
			logger.info("User is on Patron support Page");
		} else if (isElementPresent(patSupportPg_lbl_header1)) {
			patSupportNav = true;
			logger.info("User is on Patron support Page");
		}
		return patSupportNav;
	}

	public void clickonRefiner() {
			ClickOnMobileElement(refiners_Option);
	}

	public void clickonAbout() {
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			if (isElementPresent(login.getLogo_btn_menu())) {
				 ClickOnMobileElement(menu_btn_about_old);

			} else if (isElementPresent(login.getLogo_btn_menu1())) {
				if (isElementPresent(menu_btn_about)) {
					ClickOnMobileElement(menu_btn_about);
				}
			}
		}
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			if (isElementPresent(login.getLogo_btn_menu())) {
				for (int i = 0; i < menuList_options.size() - 1; i++) {
					if (menuList_options.get(i).getText().contains("About")) {
						ClickOnMobileElement(menuList_options.get(i));
						logger.info("About us button clicked");
						break;
					}
				}
			} else if (isElementPresent(login.getLogo_btn_menu1())) {
				for (int i = 0; i < menuList_options1.size() - 1; i++) {
					if (menuList_options1.get(i).getText().contains("About")) {
						ClickOnMobileElement(menuList_options1.get(i));
						logger.info("About us button clicked");
						break;
					}
				}
			}
			else if (isElementPresent(login.getLogo_btn_menu2())) {
				for (int i = 0; i < menuList_options1.size() - 1; i++) {
					if (menuList_options1.get(i).getText().contains("About")) {
						ClickOnMobileElement(menuList_options1.get(i));
						logger.info("About us button clicked");
						break;
					}
				}
			}
		}
	}

	public Boolean aboutPgNavCheck() {
		Boolean aboutNav = true;
		if (isElementPresent(aboutPg_lbl_header)) {
			aboutNav = true;
			logger.info("User is on About us Page");
		}
		return aboutNav;
	}

	public void clickonTermsAndCondition() {
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {

			if (isElementPresent(terms_And_Condition)) {
				ClickOnMobileElement(terms_And_Condition);
			} else if (isElementPresent(menu_btn_termscondition1)) {
				ClickOnMobileElement(menu_btn_termscondition1);
			}
		}
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			if (isElementPresent(login.getLogo_btn_menu())) {
				System.out.println("Old ui is displayed");

				for (int i = 0; i < menuList_options.size() - 1; i++) {
					if (menuList_options.get(i).getText().equalsIgnoreCase("Terms & Conditions")) {
						ClickOnMobileElement(menuList_options.get(i));
						logger.info("Term and condition button clicked");
						break;
					}
				}
			} else if (isElementPresent(login.getLogo_btn_menu1())) {
				for (int i = 0; i < menuList_options1.size() - 1; i++) {
					if (menuList_options1.get(i).getText().equalsIgnoreCase("Terms & Conditions")) {
						ClickOnMobileElement(menuList_options1.get(i));
						logger.info("Term and condition button clicked");
						break;
					}
				}
			}
		}
	}

	public void signout() {
		
		logger.info("user logout from screen");
		if (System.getProperty("platform").equalsIgnoreCase("ios")) {
			if (isElementPresent(login.getHome_btn_Logout1())) {
				ClickOnMobileElement(login.getHome_btn_Logout1());
			} else if (isElementPresent(login.getHome_btn_Logout())) {
				ClickOnMobileElement(login.getHome_btn_Logout());
				if (isElementPresent(login.getHome_btn_Logout_Confirmation1())) {
					ClickOnMobileElement(login.getHome_btn_Logout_Confirmation1());
				} else if (isElementPresent(login.getHome_btn_Logout_Confirmation())) {
					ClickOnMobileElement(login.getHome_btn_Logout_Confirmation());
				}
			}
		}

		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			if (isElementPresent(login.getLogo_btn_menu())) {
				for (int i = 0; i < menuList_options.size() - 1; i++) {
					if (menuList_options.get(i).getText().equalsIgnoreCase("Sign Out")) {
						ClickOnMobileElement(menuList_options.get(i));
						logger.info("logout clicked");
						break;
					}
				}
			} else if (isElementPresent(login.getLogo_btn_menu1())) {
				ClickOnMobileElement(login.getHome_btn_Logout1());
				logger.info("logout clicked");
			}
		}

	}

	public Boolean termsAndConditionPgNavCheck() {
		Boolean termsNav = true;
		if (isElementPresent(termsPg_lbl_header)) {
			termsNav = true;
			logger.info("User is on terms and condition Page");
		}
		return termsNav;
	}

	public void clickonPrivacy() {
//		if (isElementPresent(login.getLogo_btn_menu())) {
//			for (int i = 0; i < menuList_options.size() - 1; i++) {
//				if (menuList_options.get(i).getText().equalsIgnoreCase("Legal")) {
//					ClickOnMobileElement(menuList_options.get(i));
//					ClickOnMobileElement(menu_btn_privacypolicy1);
//					logger.info("privacy policy button clicked");
//					break;
//				}
//			}
		if (isElementPresent(login.getLogo_btn_menu1())) {
			for (int i = 0; i < menuList_options1.size() - 1; i++) {
				if (menuList_options1.get(i).getText().equalsIgnoreCase("Privacy Policy")) {
					ClickOnMobileElement(menuList_options1.get(i));
					logger.info("privacy policy button clicked");
					break;
				}
			}
		}
	}
	

	public Boolean privacyPgNavCheck() {
		Boolean policyNav = false;
		if (isElementPresent(privacyPg_lbl_header)) {
			policyNav = true;
			logger.info("User is on Privacy policy Page");
		}
		return policyNav;
	}

//	public void signout() {
//		if (System.getProperty("platform").equalsIgnoreCase("ios")) {
//			if (isElementPresent(login.getHome_btn_Logout1())) {
//				ClickOnMobileElement(login.getHome_btn_Logout1());
//			} else if (isElementPresent(login.getHome_btn_Logout())) {
//				ClickOnMobileElement(login.getHome_btn_Logout());
//			}
//		}
//		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
//			if (isElementPresent(login.getLogo_btn_menu())) {
//				for (int i = 0; i < menuList_options.size() - 1; i++) {
//					if (menuList_options.get(i).getText().equalsIgnoreCase("Logout")) {
//						ClickOnMobileElement(menuList_options.get(i));
//						logger.info("logout clicked");
//						break;
//					}
//				}
//			} else if (isElementPresent(login.getLogo_btn_menu1())) {
//				ClickOnMobileElement(login.getHome_btn_Logout1());
//				logger.info("logout clicked");
//			}
//		}
//
//	}

	public void clicktermsand_conditionss() {
		ClickOnMobileElement(terms_And_Condition);
	}

	public void clickprivacypolicy() {
		if (isElementPresent(menu_btn_privacypolicy)) {
			ClickOnMobileElement(menu_btn_privacypolicy);
		} else if (isElementPresent(menu_btn_privacypolicy1)) {
			ClickOnMobileElement(menu_btn_privacypolicy1);
		}
	}

	public void clickMyLibrary() {
		login.handleNothankspopup();
		
		if (isElementPresent(menu_btn_footerlibrary)) {
			ClickOnMobileElement(menu_btn_footerlibrary);

		} else if (isElementPresent(menu_btn_footerlibrary1)) {
			ClickOnMobileElement(menu_btn_footerlibrary1);
		}
//		login.handleNothankspopup();
	}

	public void clickaccordion() {
		if(isElementPresent(menu_btn_featuredprogramaccordin))
		{
		ClickOnMobileElement(menu_btn_featuredprogramaccordin);
		if (isElementPresent(menu_btn_featuredprgViewDetail)) {
			logger.info("featured program is in expand state");
		} else {
			logger.info("featured program is in collapse state");
		}
		}
	}

	public void clickaccordionexpand() {
		if(isElementPresent(menu_btn_featuredprogramaccordin)) {
		ClickOnMobileElement(menu_btn_featuredprogramaccordin);
		}
	}

	public void initiatehomesearch(String searchtxt) {
		if(isElementPresent(menu_txt_searchbar))
		{
		ClickOnMobileElement(menu_txt_searchbar);
		SendKeysOnMobileElement(menu_txt_searchbar, searchtxt);
		}
		else if(isElementPresent(menu_txt_searchbar1))
		{
			ClickOnMobileElement(menu_txt_searchbar1);
			SendKeysOnMobileElement(menu_txt_searchbar1, searchtxt);
		}
	}

	public void clickadvancesearch() {
		if(isElementPresent(menu_btn_advancesearch)) {
		ClickOnMobileElement(menu_btn_advancesearch);
		}
	}

	public boolean checksearchcount() {
		boolean count = true;
		int totalCount = 0;
		if (isElementPresent(menu_txt_searchbar)) {
		//	totalCount = Integer.parseInt(menu_txt_searchbar.getText().trim());
			count =true;
		} else if (isElementPresent(menu_txt_searchbar1)) {
		//	totalCount = Integer.parseInt(menu_txt_searchbar1.getText().trim());
			count =true;
		}
		
		return count;
	}

	public void clicklegal() {
		if (isElementPresent(menu_btn_legal)) {
			ClickOnMobileElement(menu_btn_legal);
		}
	}

	public Boolean checkPatron() {
		Boolean patron = false;
		if (isElementPresent(menu_btn_patronsupport)) {
			patron = true;
		}
		return patron;
	}

	public void checkSeachbar(boolean b) {
		Boolean searchbar = false;
		if (isElementPresent(menu_txt_searchbar)) {
			searchbar = true;
		} else if (isElementPresent(menu_txt_searchbar1)) {
			searchbar = true;
		}
	}
	
	public void clickonFeaturedPrgViewDetails() {
		try {
			if(isElementPresent(menu_btn_featuredprgViewDetail)) {
			ClickOnMobileElement(menu_btn_featuredprgViewDetail);
			}
		} catch (Exception e) {
			try {
				ClickOnMobileElement(menu_btn_featuredprogramaccordin);
				ClickOnMobileElement(menu_btn_featuredprgViewDetail);
			} catch (Exception e2) {
				logger.info("Feature prg is not visible");
			}
		}
		
	}
	
	public void clickBrowse() {
			ClickOnMobileElement(browse_Bottom_Navigation);
	}
	
	public void clickBrowseTitle() {
			ClickOnMobileElement(browse_Title);
	}
	
	public void closeRefine() {
			ClickOnMobileElement(close_Refine);
	}
	
	public void clickSortOption() {
			ClickOnMobileElement(sort_Option);
	}
	
	public void clickReturn_Date() {
			ClickOnMobileElement(sort_Return_Date);
	}
	
	public void clickSearch() {
			ClickOnMobileElement(search_Btn);
	}
	
	public void navigatetoRefine() {
			ClickOnMobileElement(refineOption);
	}
}
