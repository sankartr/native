package pom.kidszone;

import com.reusableMethods.CommonActions;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import java.util.List;

public class MyShelf extends CommonActions {

	public MyShelf(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	/****************** Locators ******************/

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//android.view.View[@content-desc=\"My Shelf, \"]")
	private MobileElement myshelf_btn;

	@iOSXCUITFindBy(accessibility = "viewGridContainer0")
	@AndroidFindBy(xpath = "//*[@resource-id='Checkout_title_cover_image_test_id0']")
	private MobileElement checkedOutTitles;

	@iOSXCUITFindBy(accessibility = "secondaryButtonTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='secondaryButtonTestId']")
	private MobileElement secondaryCTA;

	@iOSXCUITFindBy(accessibility = "option1TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='option1TestId']")
	private MobileElement returnTitle;

	@iOSXCUITFindBy(accessibility = "option1TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='option1TestId']")
	private MobileElement returnEBook;

	@iOSXCUITFindBy(accessibility = "option0TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='option0TestId']")
	private MobileElement returnEAudio;

	@iOSXCUITFindBy(accessibility = "btnAlertOkay")
	@AndroidFindBy(xpath = "//*[@resource-id='btnAlertOkay']")
	private MobileElement alertOkBtn;

	@iOSXCUITFindBy(accessibility = "Filter_icon_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='Filter_icon_test_id']")
	private MobileElement filter_option;

	@iOSXCUITFindBy(accessibility = "FILTER_FOR_VIDEO")
	@AndroidFindBy(xpath = "//*[@resource-id='FILTER_FOR_VIDEO']")
	private MobileElement videos_option;

	@iOSXCUITFindBy(accessibility = "FILTER_FOR_VIDEOBOOK")
	@AndroidFindBy(xpath = "//*[@resource-id='FILTER_FOR_VIDEOBOOK']")
	private MobileElement vBook_option;

	@iOSXCUITFindBy(accessibility = "btnCheckout")
	@AndroidFindBy(xpath = "//*[@resource-id='btnCheckout']")
	private MobileElement checkout_CTA;

	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='Dummy']")
	private MobileElement video_action_CTA;

	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='Dummy']")
	private MobileElement vBook_action_CTA;

	@iOSXCUITFindBy(accessibility = "btnPurchaseRequest")
	@AndroidFindBy(xpath = "//*[@resource-id='btnPurchaseRequest']")
	private MobileElement recommendation_view;

	@iOSXCUITFindBy(accessibility = "btnCheckoutHistory")
	@AndroidFindBy(xpath = "//*[@resource-id='btnCheckoutHistory']")
	private MobileElement histroy_view;

	@iOSXCUITFindBy(accessibility = "btnCheckoutHistory")
	@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Remove\"])[1]")
	private MobileElement history_primaryCTA;

	@iOSXCUITFindBy(xpath = "(//*[contains(@label,'see all')])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@text,'See All')])[1]")
	private MobileElement seeAllCTA;

	@iOSXCUITFindBy(xpath = "//*[contains(@value,'Based on your interests')]")
	@AndroidFindBy(xpath = "//*[@content-desc=', Based on your interests ']")
	private MobileElement basedOnInterest_Title;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Edit')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Edit')]")
	private MobileElement editPreferences;

	@iOSXCUITFindBy(accessibility = "INTEREST_SURVEY_TOPICS1")
	@AndroidFindBy(xpath = "//*[@resource-id='INTEREST_SURVEY_TOPICS1']")
	private MobileElement selectReadingPreference;

	@iOSXCUITFindBy(accessibility = "INTEREST_SURVEY_SAVE")
	@AndroidFindBy(xpath = "//*[contains(@text,'Save Interests')]")
	private MobileElement readingPreferenceSave;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='btnHold']")
	private MobileElement myshelfHold;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='btnWishList']")
	private MobileElement myshelfwishlist;

	@iOSXCUITFindBy(xpath = "//*[@name='viewGridContainer0']")
	@AndroidFindBy(xpath = "//*[@name='viewGridContainer0']")
	private MobileElement wishlistTitle;

	@iOSXCUITFindBy(accessibility = "Checkout_title_cover_image_test_id0")
	@AndroidFindBy(xpath = "//*[@resource-id='Checkout_title_cover_image_test_id0']")
	private MobileElement getCheckedOutTitles;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='btnWishList']")
	private MobileElement myshelfDownloads;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='btnCheckoutHistory']")
	private MobileElement myshelfHistory;

	// ================================================================

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@resource-id='MYSHELF']")
	private MobileElement myShelf_lbl_header;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@resource-id='MYSHELF']")
	private MobileElement myShelf_lbl_footer;

	@iOSXCUITFindBy(accessibility = "iconTabMyStuff")
	@AndroidFindBy(xpath = "//*[@resource-id='iconTabMyStuff']")
	private MobileElement mystuff_lbl_footer;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@text='CURRENTLY CHECKED OUT']")
	private MobileElement myShelf_lbl_currentlyCheckoutHeader;

	@iOSXCUITFindBy(accessibility = "btnCheckout")
	@AndroidFindBy(xpath = "//*[@resource-id='btnCheckout']")
	private MobileElement myShelf_btn_checkout;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@text='dummy']")
	private MobileElement myShelf_lbl_checkout;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@text='dummy']")
	private MobileElement myShelf_btn_hold;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@text='dummy']")
	private MobileElement myShelf_lbl_hold;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@text='dummy']")
	private MobileElement myShelf_btn_wishlist;

	@iOSXCUITFindBy(accessibility = "My Stuff")
	@AndroidFindBy(xpath = "//*[@text='dummy']")
	private MobileElement mystuff_lbl;

	@iOSXCUITFindBy(accessibility = "FEATURE_CURATED_LIST_TITLE")
	@AndroidFindBy(xpath = "//*[@resource-id='FEATURE_CURATED_LIST_TITLE']")
	private MobileElement myShelf_lbl_FeaturedListTitle;

	@iOSXCUITFindBy(accessibility = "FEATURE_CURATED_LIST_TITLE")
	@AndroidFindBy(xpath = "//*[@resource-id='FEATURE_CURATED_LIST_TITLE']")
	private MobileElement myShelf_lbl_FeaturedListDesc;

	@iOSXCUITFindBy(accessibility = "FEATURE_CURATED_LIST_DESCRIPTION")
	@AndroidFindBy(xpath = "//*[@resource-id='FEATURE_CURATED_LIST_DESCRIPTION']")
	private List<MobileElement> myShelf_carousel_FeaturedList;

	@iOSXCUITFindBy(accessibility = "Featured List")
	@AndroidFindBy(xpath = "//*[@text='Featured List']")
	private MobileElement myShelf_lbl_FeaturedCuratedList1;

	@iOSXCUITFindBy(accessibility = "Featured List")
	@AndroidFindBy(xpath = "//*[@text='Featured List']")
	private MobileElement myShelf_lbl_FeaturedCuratedList2;

	@iOSXCUITFindBy(accessibility = "Featured List")
	@AndroidFindBy(xpath = "//*[@text='Featured List']")
	private MobileElement myShelf_lbl_FeaturedCuratedList3;

	@iOSXCUITFindBy(accessibility = "Featured List")
	@AndroidFindBy(xpath = "//*[@text='Featured List']")
	private MobileElement myShelf_lbl_FeaturedCuratedList4;

	@iOSXCUITFindBy(accessibility = "Featured List")
	@AndroidFindBy(xpath = "//*[@text='Featured List']")
	private List<MobileElement> myShelf_carousel_FeaturesList1;

	@iOSXCUITFindBy(accessibility = "Featured List")
	@AndroidFindBy(xpath = "//*[@text='Featured List']")
	private List<MobileElement> myShelf_carousel_FeaturesList2;

	@iOSXCUITFindBy(accessibility = "Featured List")
	@AndroidFindBy(xpath = "//*[@text='Featured List']")
	private List<MobileElement> myShelf_carousel_FeaturesList3;

	@iOSXCUITFindBy(accessibility = "Featured List")
	@AndroidFindBy(xpath = "//*[@text='Featured List']")
	private List<MobileElement> myShelf_carousel_FeaturesList4;

	@iOSXCUITFindBy(accessibility = "SeeAll")
	@AndroidFindBy(xpath = "//*[@text='SeeAll']")
	private List<MobileElement> myShelf_btn_SeeAll;

	@iOSXCUITFindBy(accessibility = "header")
	@AndroidFindBy(xpath = "//*[@text='header']")
	private MobileElement myShelf_lbl_ListingPageHeader;

	@iOSXCUITFindBy(accessibility = "txtMyProgramHeading")
	@AndroidFindBy(xpath = "//*[@text='Featured List']")
	private MobileElement myShelf_lbl_yourPrograms;

	@iOSXCUITFindBy(accessibility = "txtMyProgramHeading")
	@AndroidFindBy(xpath = "//*[@resource-id='txtMyProgramHeading']")
	private MobileElement myShelf_carousel_yourPrograms;

	@iOSXCUITFindBy(accessibility = "txtMyProgramHeading")
	@AndroidFindBy(xpath = "//*[@text='Featured List']")
	private MobileElement myPrgs_lbl_Header;

	@iOSXCUITFindBy(accessibility = "txtRecommendationInterestHeader")
	@AndroidFindBy(xpath = "//*[@text =txtRecommendationInterestHeader]")
	private MobileElement myPrgs_lbl_recommendedhdr;

	@iOSXCUITFindBy(accessibility = "//XCUIElementTypeOther[@name=\"recommendation_list_id_interest\"]/XCUIElementTypeScrollView/XCUIElementTypeOther")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement myPrgs_lbl_recommendedtitles;

	@iOSXCUITFindBy(accessibility = "txtRecommendationInterestHeader")
	@AndroidFindBy(xpath = "txtRecommendationInterestHeader")
	private MobileElement myPrgs_lbl_recommendedseeall;

	@iOSXCUITFindBy(accessibility = "checkout_title_test_id0")
	@AndroidFindBy(xpath = "//*[@resource-id='txtNoDataFound']")
	private MobileElement checkedout_titles_hdr;

	@iOSXCUITFindBy(accessibility = "CHECKEDOUT_LIST_LINK")
	@AndroidFindBy(id = "CHECKEDOUT_LIST_LINK")
	private MobileElement checkedout_seealltitles;

	@iOSXCUITFindBy(accessibility = "Image0 Image0")
	@AndroidFindBy(xpath = "//*[@text='CURRENTLY CHECKED OUT']")
	private MobileElement currently_checkout_titles;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Wishlist')]")
	@AndroidFindBy(xpath = "//*[@resource-id='btnWishList']")
	private MobileElement wishlist_View;

	@iOSXCUITFindBy(accessibility = "Wishlist")
	@AndroidFindBy(xpath = "//*[@resource-id='Wishlist']")
	private MobileElement wishlist_View_old;

	@iOSXCUITFindBy(accessibility = "btnCheckout")
	@AndroidFindBy(xpath = "//*[@resource-id='btnCheckout']")
	private MobileElement logo_txt_Checkout;

	@iOSXCUITFindBy(accessibility = "btnHold")
	@AndroidFindBy(xpath = "//*[@resource-id='btnHold']")
	private MobileElement logo_txt_Hold;

	//	HistoryView
	@iOSXCUITFindBy(accessibility = "btnCheckout")
	@AndroidFindBy(xpath = "//*[@resource-id='btnCheckout']")
	private MobileElement checkout_page;

	@iOSXCUITFindBy(accessibility = "btnHold")
	@AndroidFindBy(xpath = "//*[@resource-id='btnHold']")
	private MobileElement holds_page;

	@iOSXCUITFindBy(accessibility = "btnPurchaseRequest")
	@AndroidFindBy(xpath = "//*[@resource-id='btnPurchaseRequest']")
	private MobileElement purchase_page;

	@iOSXCUITFindBy(accessibility = "btnDownload")
	@AndroidFindBy(xpath = "//*[@resource-id='btnDownload']")
	private MobileElement download_page;

	@iOSXCUITFindBy(accessibility = "btnCheckoutHistory")
	@AndroidFindBy(xpath = "//*[@resource-id='btnCheckoutHistory']")
	private MobileElement history_page;

	@iOSXCUITFindBy(accessibility = "btnDownload")
	@AndroidFindBy(xpath = "//*[@resource-id='btnDownload']")
	private MobileElement download_view;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"WishlistPage\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='header_menu_options_test_id']")
	private MobileElement wishlist_page;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Checkouts Holds Wishlist Purchase Requests\"]/XCUIElementTypeOther")
	@AndroidFindBy(xpath = "//*[@class='android.widget.HorizontalScrollView']")
	private List<MobileElement> horizontal_view_list;

	@iOSXCUITFindBy(accessibility = "Search_text_icon_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='Search_text_icon_test_id']")
	private MobileElement searchMenu;

	@iOSXCUITFindBy(accessibility = "Mystuff_internal_search_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='Mystuff_internal_search_test_id']")
	private MobileElement searchtext;

	@iOSXCUITFindBy(accessibility = "Search_clear_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='Search_clear_test_id']")
	private MobileElement searchCloseIcon;

	@iOSXCUITFindBy(accessibility = "mystuffListView0")
	@AndroidFindBy(xpath = "//*[@resource-id='mystuffListView0']")
	private MobileElement title_list;

	@iOSXCUITFindBy(accessibility = "txtNoDataFound")
	@AndroidFindBy(xpath = "//*[@resource-id='txtNoDataFound']")
	private MobileElement no_titleFound;

	@iOSXCUITFindBy(xpath = "//*[contains(@label, 'Checkouts, book title count')]")
	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Checkouts, book title count')]/android.view.ViewGroup[2]/android.widget.TextView")
	private MobileElement checkoutPillsCount;
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='checkout_flat_list_test_id']//XCUIElementTypeButton")
	@AndroidFindBy(xpath = "//*[@resource-id='checkout_flat_list_test_id']//*[contains(@resource-id,'Checkout_title_cover_image_test_id')]")
	private List<MobileElement> checkoutTitlesCount;

	public MobileElement getNo_titleFound() {
		return no_titleFound;
	}

	public MobileElement gettitle_list() {
		return title_list;
	}

	public MobileElement getPurchase_page() {
		return purchase_page;
	}

	public MobileElement getDownload_page() {
		return download_page;
	}

	public MobileElement getHistory_page() {
		return history_page;
	}

	public MobileElement getDownload_view() {
		return download_view;
	}

	public void setHistroy_view(MobileElement histroy_view) {
		this.histroy_view = histroy_view;
	}

	public MobileElement getRecommendation_view() {
		return recommendation_view;
	}

	public MobileElement getSearchMenu() {
		return searchMenu;
	}

	public MobileElement getHolds_page() {
		return holds_page;
	}

	public MobileElement getWishlist_page() {
		return wishlist_page;
	}

	public MobileElement getCheckout_page() {
		return checkout_page;
	}

	public MobileElement getHistroy_view() {
		return histroy_view;
	}

	public MobileElement getLogo_txt_Checkout() {
		return logo_txt_Checkout;
	}

	public MobileElement getWishlist_View() {
		return wishlist_View;
	}

	public MobileElement getLogo_txt_Hold() {
		return logo_txt_Hold;
	}

	public MobileElement getCurrently_checkout_titles() {
		return currently_checkout_titles;
	}

	public MobileElement getCheckedout_titles_hdr() {
		return checkedout_titles_hdr;
	}

	public MobileElement getMyPrgs_lbl_recommendedseeall() {
		return myPrgs_lbl_recommendedseeall;
	}

	public MobileElement getMyPrgs_lbl_recommendedhdr() {
		return myPrgs_lbl_recommendedhdr;
	}

	public MobileElement getMyShelf_lbl_header() {
		return myShelf_lbl_header;
	}

	public MobileElement getMyShelf_lbl_FeaturedListTitle() {
		return myShelf_lbl_FeaturedListTitle;
	}

	public MobileElement getMyShelf_lbl_FeaturedCuratedList1() {
		return myShelf_lbl_FeaturedCuratedList1;
	}

	public MobileElement getMyShelf_btn_hold() {
		return myShelf_btn_hold;
	}

	public MobileElement getMyShelf_lbl_hold() {
		return holds_page;
	}

	public MobileElement getMyShelf_lbl_checkout() {
		return myShelf_lbl_checkout;
	}

	public MobileElement getMyShelf_btn_checkout() {
		return myShelf_btn_checkout;
	}

	public MobileElement getMyShelf_btn_wishlist() {
		return myShelf_btn_wishlist;
	}

	public MobileElement getmystuff_lbl() {
		return mystuff_lbl;
	}

	public MobileElement getMyShelf_lbl_footer() {
		return myShelf_lbl_footer;
	}

	public List<MobileElement> getMyShelf_carousel_FeaturesList1() {
		return myShelf_carousel_FeaturesList1;
	}

	public List<MobileElement> getMyShelf_carousel_FeaturesList2() {
		return myShelf_carousel_FeaturesList2;
	}

	public List<MobileElement> getMyShelf_carousel_FeaturesList3() {
		return myShelf_carousel_FeaturesList3;
	}

	public List<MobileElement> getMyShelf_carousel_FeaturesList4() {
		return myShelf_carousel_FeaturesList4;
	}

	public List<MobileElement> getMyShelf_btn_SeeAll() {
		return myShelf_btn_SeeAll;
	}

	public MobileElement getMyShelf_lbl_ListingPageHeader() {
		return myShelf_lbl_ListingPageHeader;
	}

	public MobileElement getMyShelf_lbl_yourPrograms() {
		return myShelf_lbl_yourPrograms;
	}

	public MobileElement getMyShelf_carousel_yourPrograms() {
		return myShelf_carousel_yourPrograms;
	}

	public MobileElement getMyShelf_lbl_currentlyCheckoutHeader() {
		return myShelf_lbl_currentlyCheckoutHeader;
	}

	public MobileElement getMyShelf_lbl_FeaturedCuratedList2() {
		return myShelf_lbl_FeaturedCuratedList2;
	}

	public MobileElement getMyShelf_lbl_FeaturedCuratedList3() {
		return myShelf_lbl_FeaturedCuratedList3;
	}

	public MobileElement getMyShelf_lbl_FeaturedCuratedList4() {
		return myShelf_lbl_FeaturedCuratedList4;
	}

	public MobileElement getMyPrgs_lbl_Header() {
		return myPrgs_lbl_Header;
	}

	public MobileElement getMyPrgs_lbl_recommendedtitles() {
		return myPrgs_lbl_recommendedtitles;
	}

	public MobileElement getCheckedout_seealltitles() {
		return checkedout_seealltitles;
	}

	/********************************** Methods **************************/

	public MobileElement checkVideo_action_CTA() {
		return video_action_CTA;
	}

	public MobileElement getHistory_primaryCTA() {
		return history_primaryCTA;
	}

	public MobileElement checkvBook_action_CTA() {
		return vBook_action_CTA;
	}

	public void clickMyShelf() {
		ClickOnMobileElement(myshelf_btn);
	}

	public void clickFilter_option() {
		ClickOnMobileElement(filter_option);
	}

	public void clickVideos_option() {
		ClickOnMobileElement(videos_option);
	}

	public void clickvBook_option() {
		ClickOnMobileElement(vBook_option);
	}

	public void clickCheckout_CTA() {
		ClickOnMobileElement(checkout_CTA);
	}

	public void clickrecommendation() {
		ClickOnMobileElement(recommendation_view);
	}

	public void clickhistory() {
		ClickOnMobileElement(histroy_view);
	}

	public void clickSeeAll() {
		for (int i = 0; i < 5; i++) {
			if (isElementPresent(seeAllCTA)) {
				break;
			} else {
				swipeDown();

			}
		}
		ClickOnMobileElement(seeAllCTA);
	}

	public MobileElement basedOnInterestTitle() {
		return basedOnInterest_Title;
	}

	public void clickEditPreferences() {
		ClickOnMobileElement(editPreferences);
	}

	public void clickReadingPreference() {
		ClickOnMobileElement(selectReadingPreference);
		ClickOnMobileElement(selectReadingPreference);
	}

	public void clickReadingInterestSaveBTN() {
		for (int i = 0; i < 7; i++) {
			if (isElementPresent(readingPreferenceSave)) {
				break;
			} else {
				swipeDown();
				swipeDown();
			}
		}
		ClickOnMobileElement(readingPreferenceSave);
	}

	public MobileElement readingInterestSeeAll() {
		return seeAllCTA;
	}

	public void clickmyShelfHoldBTN() {
		ClickOnMobileElement(myshelfHold);
	}

	public void clickwishlistBTN() {
		ClickOnMobileElement(myshelfwishlist);
	}

	public void clickdownloadsBTN() {
		ClickOnMobileElement(myshelfDownloads);
	}

	public void clickHistoryBTN() {
		ClickOnMobileElement(myshelfHistory);
	}

	public void clickMyself() {
		if (isElementPresent(myShelf_lbl_footer)) {
			ClickOnMobileElement(myShelf_lbl_footer);
		}
		waitFor(2000);
	}
	public void clickPurchaseHistory() {
		if (isElementPresent(purchase_page)) {
			ClickOnMobileElement(purchase_page);
		}
	}

	public void clickCheckout() {
		if (isElementPresent(myShelf_btn_checkout))
			ClickOnMobileElement(myShelf_btn_checkout);
	}

	public boolean featurelistTitleandDescValidation() {
		swipeDown();
		swipeDown();
		Boolean display = true;
		if (isElementPresent(myShelf_lbl_FeaturedListTitle) && isElementPresent(myShelf_lbl_FeaturedListDesc)) {
			logger.info("Feature list title and desc is displayed");
			display = true;
		} else if (isElementPresent(myShelf_lbl_FeaturedListTitle) || isElementPresent(myShelf_lbl_FeaturedListDesc)) {
			logger.info("Featured List title alone diaplyed");
			display = true;
		}
		return display;
	}

	public boolean featuredListCarouselValidation() {
		Boolean yourPrgs = true;
		if (isElementPresent(myShelf_lbl_FeaturedListDesc)) {
			yourPrgs = true;
		} else {
			logger.info("Title in list is not displayed");

		}
		return yourPrgs;
	}


	public void verifyCheckedOutTitles() {
		if (isElementPresent(currently_checkout_titles)) {
			logger.info("Checked out titles available");
		} else {
			logger.info("checked out titles not available");
		}
	}

	public void clickebook() {
		if (isElementPresent(currently_checkout_titles)) {
			ClickOnMobileElement(currently_checkout_titles);
		} else {
			logger.info("Checked out titles not available");
		}

	}

	public void clickaudiobook() {
		if (isElementPresent(currently_checkout_titles)) {
			ClickOnMobileElement(currently_checkout_titles);
		} else {
			logger.info("Checked out titles not available");
		}
	}

	public void checkseeAll() {
		if (isElementPresent(checkedout_seealltitles)) {
			logger.info("see all button available");
			ClickOnMobileElement(checkedout_seealltitles);
		} else {
			logger.info("see all button not available");
		}

	}

	public void clickholds() {
		ClickOnMobileElement(logo_txt_Hold);
	}

	public void clickwishlist() {
		ClickOnMobileElement(wishlist_View);
	}

	public void search(String title) {
		if (isElementPresent(searchMenu)) {
			ClickOnMobileElement(searchMenu);
			SendKeysOnMobileElement(searchtext, title);
			ClickOnMobileElement(searchCloseIcon);
		} else {
			logger.info("Please add more than three titles");
		}

	}

	public void clickdownload() {
		if (isElementPresent(download_view)) {
			ClickOnMobileElement(download_view);
			waitFor(1000);
			ClickOnMobileElement(download_view);
		} else {
			swipeScreen("RIGHT");
			ClickOnMobileElement(download_view);
			waitFor(1000);
			ClickOnMobileElement(download_view);
		}

	}

	public void horizzondalView() {
		horizontalSwipe(horizontal_view_list);
		horizontalSwipe(horizontal_view_list);
		if (isElementPresent(histroy_view)) {
			ClickOnMobileElement(histroy_view);
		}

	}
	public void clickrecommendedSeeAll() {
		if (isElementPresent(myPrgs_lbl_recommendedseeall)) {
			ClickOnMobileElement(myPrgs_lbl_recommendedseeall);
		}
	}

	public MobileElement getWishlistTitle(){return wishlistTitle;}

	public void tapCheckedOutTitles() {
		ClickOnMobileElement(checkedOutTitles);
	}

	public void tapOnSecondaryCTA(){
		ClickOnMobileElement(secondaryCTA);
	}

	public void tapReturnTitle() {
		ClickOnMobileElement(returnTitle);
	}

	public void returnEBook() {ClickOnMobileElement(returnEBook);}

	public void returnEAudio(){ClickOnMobileElement(returnEAudio);}

	public void tapOK(){
		ClickOnMobileElement(alertOkBtn);
	}

	public int getCheckoutPillsCount(){
		isElementPresent(checkoutPillsCount);
		int checkoutCount = Integer.parseInt(checkoutPillsCount.getText().replaceAll("[^0-9]", ""));
		return checkoutCount;
	}
	public int getCheckoutTitlesCount(){
		 return checkoutTitlesCount.size();
	}


}

