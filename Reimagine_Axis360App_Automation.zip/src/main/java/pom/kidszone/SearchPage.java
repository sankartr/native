package pom.kidszone;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.reusableMethods.CommonActions;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class SearchPage extends CommonActions {

    public SearchPage(AppiumDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

    /************************************
     * Locators
     ************************************************/

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Checkers Library TV')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Checkers Library TV')]")
    private MobileElement video_Colletion;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Videobooks')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Videobooks')]")
    private MobileElement vbook_Colletion;

    @iOSXCUITFindBy(accessibility = "txtVBooksCount")
    @AndroidFindBy(xpath = "//*[@resource-id='txtVBooksCount']")
    private MobileElement vbook_Category;

    @iOSXCUITFindBy(accessibility = "Collections_0")
    @AndroidFindBy(xpath = "//*[@resource-id='Collections_0']")
    private MobileElement collections_General;

    @iOSXCUITFindBy(accessibility = "Collections_2")
    @AndroidFindBy(xpath = "//*[@resource-id='Collections_2']")
    private MobileElement collections_WebResource;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Videobooks')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Videobooks')]")
    private MobileElement vBooks_Refiner;

    @iOSXCUITFindBy(accessibility = "viewGridContainer0")
    @AndroidFindBy(xpath = "//*[@resource-id='viewGridContainer0']")
    private MobileElement wishlistTitle;
    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Checkers Library TV')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Checkers Library TV')]")
    private MobileElement video_Refiner;

    @iOSXCUITFindBy(accessibility = "filter_cta")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_cta']")
    private MobileElement search_Refine_btn;

    @iOSXCUITFindBy(xpath = "(//*[@name='txtTitle'])[2]")
    @AndroidFindBy(xpath = "(//*[@name='txtTitle'])[2]")
    private MobileElement searchTitle;

    @iOSXCUITFindBy(accessibility = "loc_search_advance_search_refiner_icon")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_search_advance_search_refiner_icon']")
    private MobileElement refiner_Option;

    @iOSXCUITFindBy(accessibility = "wrap_inputBoxAdvanceSearch")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_inputBoxAdvanceSearch']")
    private MobileElement search_Input;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'loc_advance_search_search_btn')]")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_advance_search_search_btn']")
    private MobileElement search_btn;

    @iOSXCUITFindBy(accessibility = "loc_advance_search_search_btn")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_advance_search_search_btn']")
    private MobileElement clear_btn;

    @iOSXCUITFindBy(accessibility = "viewFeatureMenu")
    @AndroidFindBy(xpath = "//*[@resource-id='viewFeatureMenu']")
    private MobileElement viewFeatures_Menu;

    @iOSXCUITFindBy(accessibility = "third_party_header")
    @AndroidFindBy(xpath = "//*[@resource-id='third_party_header']")
    private MobileElement search_Result_Landing;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Videobooks heading')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Videobooks heading')]")
    private MobileElement vBook_Carousel_Landing;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Checkers Library TV heading')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Checkers Library TV heading')]")
    private MobileElement videos_Carousel_Landing;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(xpath = "//*[@resource-id='dummy']")
    private MobileElement other_Carousel_Landing;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Videobooks heading\"]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Videobooks heading')]")
    private MobileElement vbook_Expanded_Result;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Videosheading')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Videosheading')]")
    private MobileElement videos_Expanded_Result;

    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'adp_card_image_card_VBK')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VBK')])[1]")
    private MobileElement vbook_Cover_Image;

    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'adp_card_book_title')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_book_title')])[1]")
    private MobileElement vbook_Title;

    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'adp_card_checkout_cta')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_checkout_cta')])[1]")
    private MobileElement vbook_Checkout_CTA;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See All\"])[1]")
    @AndroidFindBy(xpath = "//*[contains(@text,'See All')]")
    private MobileElement ebooks_seeall;

    @iOSXCUITFindBy(xpath = "(//*[contains(@label,'eBook')])[2]")
    @AndroidFindBy(xpath = "(//*[contains(@content-desc,'BookTitle')])[1]")
    private MobileElement advancedSeachTitle;

    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'ABT_Title')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'ABT_Title_')])[1]")
    private MobileElement advanceEAudioTitle;

    @iOSXCUITFindBy(accessibility = "third_party_see_all_link_VBOOKS")
    @AndroidFindBy(xpath = "//android.view.View[@resource-id='third_party_see_all_link_VBOOKS']")
    private MobileElement vbooks_seeall;

    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
    private MobileElement back_btn;

    @iOSXCUITFindBy(accessibility = "txtNoDataFound")
    @AndroidFindBy(xpath = "//*[@resource-id='txtNoDataFound']")
    private MobileElement noDataTitle;
    @iOSXCUITFindBy(accessibility = "dummy_checkout_CTA")
    @AndroidFindBy(xpath = "//*[@resource-id='dummy_checkout_CTA']")
    private MobileElement checkout_CTA;

    @iOSXCUITFindBy(accessibility = "dummy_play_CTA")
    @AndroidFindBy(xpath = "//*[@resource-id='dummy_play_CTA']")
    private MobileElement play_CTA;

    @iOSXCUITFindBy(accessibility = "loc_search_advance_search_refiner_icon")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_cta']")
    private MobileElement search_Result;

    @iOSXCUITFindBy(accessibility = "filter_cta")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_cta']")
    private MobileElement refinerIcon;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_image_card_VBK')]")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_image_card_VBK')]")
    private MobileElement vBookTitle_Result;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeImage[@name=\"See Image, See Read ebook\"])[1]")
    @AndroidFindBy(xpath = "//*[@resource-id='dummy']")
    private MobileElement eBookTitle_card;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'adp_card_image_card_VBK')])[1]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Vbook')]")
    private MobileElement vBook_title_card2;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'adp_card_image_card_VID')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VID')])[1]")
    private MobileElement video_title_card;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_image_card_VBK')]")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_image_card_VBK')]")
    private MobileElement vBook_title_card;

    @iOSXCUITFindBy(accessibility = "Vbook ")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Vbook')]")
    private MobileElement eBookTitle_card_btnshare;

    @iOSXCUITFindBy(accessibility = "third_party_header")
    @AndroidFindBy(xpath = "//*[@resource-id=\"third_party_header\"]")
    private MobileElement titleHeaderInSearch;

    @iOSXCUITFindBy(accessibility = "loc_btnShare")
    @AndroidFindBy(xpath = "//android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup")
    private MobileElement titleResultInSearch;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Videobooks,(')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Videobooks (')]")
    private MobileElement vBookCategoryPills;

    @iOSXCUITFindBy(accessibility = "third_party_header_VBOOKS")
    @AndroidFindBy(xpath = "//*[@resource-id='third_party_header_VBOOKS']")
    private MobileElement vBookCategoryPills1;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Play')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Play')]")
    private MobileElement title_Details;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Resume')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Resume')]")
    private MobileElement title_resume;

    @iOSXCUITFindBy(accessibility = "third_party_header_")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Videosheading, ')]")
    private MobileElement videoCategoryPills;

    @iOSXCUITFindBy(accessibility = "third_party_header_VIDEOS")
    @AndroidFindBy(xpath = "//*[@resource-id='third_party_header_VIDEOS']")
    private MobileElement videoCategoryPills1;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"third_party_header\"]/parent::XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Results For')]")
    private MobileElement vBookandVideoSearchCategoryHeader;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_image_card_VBK')]")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_image_card_VBK')]")
    private List<MobileElement> vBookSearchTitleIcon;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_image_card_VID')]")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_image_card_VID')]")
    private List<MobileElement> videoSearchTitleIcon;

    @iOSXCUITFindBy(xpath = "//*[@value='Videosheading']/parent::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Videos heading, ')]/parent::android.view.ViewGroup//android.widget.Button")
    private MobileElement videoSeeAllSearchResultLink;

    @iOSXCUITFindBy(xpath = "//*[@value='VBooksheading']/parent::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'VBooks heading, ')]/parent::android.view.ViewGroup//android.widget.Button")
    private MobileElement vBookSeeAllSearchResultLink;

    @iOSXCUITFindBy(accessibility = "tier_2_txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='tier_2_txtTitle']")
    private MobileElement tier2Title;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"ItemCarousel\"]/XCUIElementTypeOther/XCUIElementTypeOther)[2]/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[@resource-id=\"ItemCarousel\"]/android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup")
    private MobileElement vBookandVideoSearchTitle;

    @iOSXCUITFindBy(accessibility = "tier_3_txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='tier_3_txtTitle']")
    private MobileElement tier3TextTitle;

    @iOSXCUITFindBy(accessibility = "Vbook ")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Vbook ')]")
    private MobileElement vBookTier3TitleIcon;

    @iOSXCUITFindBy(accessibility = "Video ")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Video ')]")
    private MobileElement videoTier3TitleIcon;

    @iOSXCUITFindBy(xpath = "//*[@name='SEARCH_TEXT_BOX']")
    @AndroidFindBy(xpath = "//*[@resource-id='SEARCH_TEXT_BOX']")
    private MobileElement search_txt_box;

    @iOSXCUITFindBy(xpath = "//*[@name='SEARCH_TEXT_BOX']")
    @AndroidFindBy(xpath = "//*[@resource-id='SEARCH_TEXT_BOX']")
    private MobileElement global_search_txt_box;

    @iOSXCUITFindBy(accessibility = "loc_inputBoxAdvanceSearch")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_inputBoxAdvanceSearch']")
    private MobileElement search_advanced_txt_box;

    @iOSXCUITFindBy(accessibility = "btnSearchMenu")
    @AndroidFindBy(xpath = "//*[@resource-id= 'btnSearchMenu']")
    private MobileElement search_txt_box1;

    @iOSXCUITFindBy(accessibility = "Search")
    @AndroidFindBy(xpath = "//*[@resource-id= 'Search']")
    private MobileElement old_search_txt_box;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeApplication[@name=\"Axis 360\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeScrollView/XCUIElementTypeOther[1]/XCUIElementTypeTextField")
    @AndroidFindBy(xpath = "//*[@resource-id= 'Search']")
    private MobileElement old_search_input_box;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"search icon\"]")
    @AndroidFindBy(xpath = "//*[@resource-id= 'Search']")
    private MobileElement old_search_icon;

    @iOSXCUITFindBy(accessibility = "loc_advance_search_search_btn") //(accessibility = "more_LIBRARY_ADVANCE_SEARCH_BUTTON")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_advance_search_search_btn']")
    private MobileElement btn_AdvancedSearchMenu;

    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'EBT_Title')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'EBT_Title')])[1]")
    private MobileElement title_cover;

    @iOSXCUITFindBy(accessibility = "MoreLikeThis")
    @AndroidFindBy(xpath = "//*[@content-desc='MoreLikeThis, ']")
    private MobileElement btn_moreLikethis;

    @iOSXCUITFindBy(accessibility = "RelatedItems")
    @AndroidFindBy(xpath = "//*[@content-desc='RelatedItems, ']")
    public MobileElement btn_RelatedItems;

    @iOSXCUITFindBy(xpath = "//*[@label='Other Titles Like This']")
    @AndroidFindBy(xpath = "//*[@content-desc='Other Titles Like This, ']")
    private MobileElement title_series;

    @iOSXCUITFindBy(accessibility = "loc_txtTitlesLikeThis")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_txtTitlesLikeThis']")
    private MobileElement title_likethis;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Checkers Library TV,(')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Checkers Library TV (')]")
    private MobileElement videos_Header;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Advanced Search')]")
    @AndroidFindBy(xpath = "//*[@content-desc='Advanced Search, ']")
    private MobileElement advance_serach_button;

    @iOSXCUITFindBy(accessibility = "Search")
    @AndroidFindBy(xpath = "//*[@content-desc='Search']")
    private MobileElement search_button;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@value=\"Type your search\"]")
    @AndroidFindBy(xpath = "//*[@text='Type your search']")
    private MobileElement search_textbox;

    @iOSXCUITFindBy(accessibility = "search icon")
    @AndroidFindBy(xpath = "//*[@content-desc='Search']")
    private MobileElement search_Icon;

    @iOSXCUITFindBy(accessibility = "RelatedItems")
    @AndroidFindBy(xpath = "//*[@content-desc='RelatedItems, ']")
    private MobileElement related_items;

    @iOSXCUITFindBy(accessibility = "Checkers Library TV heading")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Checkers Library TV heading, \"]")
    private MobileElement videos_SearchResults;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(xpath = "(//*[contains(@content-desc,'Results For')])[1]")
    private MobileElement searchResult;

    @iOSXCUITFindBy(xpath = "//*[@label='Resource Hub']")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Resource Hub radio,')]")
    private MobileElement resourceHub;

    @iOSXCUITFindBy(xpath = "//*[@label='Author']")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Author radio,')]")
    private MobileElement authorRadio;

    @iOSXCUITFindBy(xpath = "//*[@label='ISBN']")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'ISBN radio,')]")
    private MobileElement ISBNRadio;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Results')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Resource Hub')]")
    private MobileElement resourceHubResults;

    @iOSXCUITFindBy(xpath = "//*[@label='Web Resources']")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Web Resources radio,')]")
    private MobileElement webResources;

    @iOSXCUITFindBy(accessibility = "Title radio,")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Title radio,')]")
    private MobileElement titleRadio;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Results')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Web Resources')]")
    private MobileElement webResourcesResults;

    @iOSXCUITFindBy(xpath = "//*[@label='Newspapers & Magazines']")
    @AndroidFindBy(xpath = "//*[contains(@text,'Newspapers & Magazines')]")
    private MobileElement newspaperMagazine;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Results')]")
    @AndroidFindBy(xpath = "//*[@resource-id='third_party_header_PRESSRDR']")
    private MobileElement newspapersResults;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Magazine radio,')]")
    private MobileElement Magazine;

    @iOSXCUITFindBy(accessibility = "dummy")
    @AndroidFindBy(xpath = "dummy")
    private MobileElement magazineResults;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Results')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Results')]")
    private MobileElement ISBNResults;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Auto Kids Independent')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Auto Kids Independent')]")
    private MobileElement profile_Landing_Page;


    // =========================================================== 26/06/23


    public void click_All() {
        if (isElementPresent(all)) {
            ClickOnMobileElement(all);
        } else {

        }
    }

    public MobileElement getEBookCategory_pills() {
        return ebookcategory_pills;
    }

    public MobileElement getEContentCategory_pills() {
        return econtentcategory_pills;
    }

    public List<MobileElement> getWebsource_result() {
        return websource_result;
    }

    public List<MobileElement> pillsSelection_result() {
        return pillsSelectionresult;
    }

    public MobileElement getSearch_result_page() {
        return search_result_page;
    }

    public MobileElement getSubject_option2() {
        return subject_option2;
    }

    public MobileElement getSubject_option1() {
        return subject_option1;
    }

    public MobileElement getSubject_expand() {
        return subject_expand;
    }

    public MobileElement getRefineFilter_subject() {
        return refineFilter_subject;
    }

    public MobileElement getRefineFilter_sub_Category() {
        return refineFilter_sub_Category;
    }

    public MobileElement getRefineFilter_source() {
        return refineFilter_source;
    }

    public void setRefineFilter_source(MobileElement refineFilter_source) {
        this.refineFilter_source = refineFilter_source;
    }

    public MobileElement getSearch_txt_box1() {
        return search_txt_box1;
    }

    public MobileElement getSearch_clear() {
        return search_clear;
    }

    public MobileElement getRefiner_close() {
        return refiner_close;
    }

    public MobileElement getNo_resultFound() {
        return No_resultFound;
    }

    public MobileElement getWebsource_cardTitle() {
        return websource_cardTitle;
    }

    public MobileElement getExpand_search() {
        return expand_search;
    }

    public MobileElement getGeneral_Collections() {
        return general_Collections;
    }

    public MobileElement getAlwaysavilable_Collections() {
        return alwaysavilable_Collections;
    }

    public MobileElement getPurchase_Collections() {
        return purchase_Collections;
    }

    public MobileElement getNewspaper_Collections() {
        return newspaper_Collections;
    }

    public MobileElement getEbook_sucategory() {
        return ebook_sucategory;
    }

    public MobileElement geteAudio_sucategory() {
        return eAudio_sucategory;
    }

    public MobileElement getMultiSelectOptions() {
        return MultiSelectOptions;
    }

    public MobileElement getEbook_item() {
        return ebook_item;
    }

    public MobileElement getActivityresource_item() {
        return activityresource_item;
    }

    public MobileElement getWebresource_item() {
        return webresource_item;
    }

    public MobileElement getSearch_result() {
        return search_result;
    }

    public MobileElement getZeroSearchResult() {
        return ZeroSearchResult;
    }

    public MobileElement getOld_search_txt_box() {
        return Old_search_txt_box;
    }

    public MobileElement getEbook_Collection() {
        return Ebook_Collection;
    }

    public MobileElement getSearch_Sort() {
        return Search_Sort;
    }

    public MobileElement getAdvancedSearch_inputbox() {
        return AdvancedSearch_inputbox;
    }

    public MobileElement getAdvancedSearchBar() {
        return advanced_search_bar;
    }

    public MobileElement getClearCTA() {
        return ClearCTA;
    }

    public MobileElement getSearchCTA() {
        return SearchCTA_btn;
    }

    public MobileElement getSearchCTAInAdvancepopup() {
        return SearchCTA_btn;
    }

    public MobileElement getCancelIcon() {
        return CancelIcon;
    }

    public MobileElement getvideo_Collection() {
        return Video_Collection;
    }

    public MobileElement getRefine_Icon() {
        return Refine_Icon;
    }

    public MobileElement getRefine_All() {
        return Refine_All;
    }

    public MobileElement getWebResources() {
        return WebResources;
    }

    public MobileElement getStudySite() {
        return StudySite;
    }

    public MobileElement getBookCategory() {
        return BookCategory;
    }

    public MobileElement getAvailabilityCategory() {
        return AvailabilityCategory;
    }

    public MobileElement getCollectionsCategory() {
        return CollectionsCategory;
    }

    public MobileElement getSortBy() {
        return SortBy;
    }

    public MobileElement getebooks_Screen() {
        return ebooks_Screen;
    }

    public MobileElement getRefiners_Screen() {
        return Refiners_Screen;
    }

    public MobileElement getNewspapers_Magazines_lbl() {
        return Newspapers_Magazines_lbl;
    }

    public MobileElement getArticles_lbl() {
        return Articles_lbl;
    }

    public MobileElement getClear_icon() {
        return clear_icon;
    }

    public List<MobileElement> getSearchseeAll() {
        return searchseeAll;
    }

    public MobileElement getSearch_txt_box() {
        return search_txt_box;
    }

    public MobileElement getProfile_Landing_Page() {
        return profile_Landing_Page;
    }

    //========================================= 26/06/23


    @iOSXCUITFindBy(accessibility = "Type_2")
    @AndroidFindBy(xpath = "//*[@resource-id= 'Type_2']")
    private MobileElement select_TypeAuther;

    @iOSXCUITFindBy(accessibility = "more_LIBRARY_ADVANCE_SEARCH_BUTTON")
    @AndroidFindBy(xpath = "//*[@resource-id= 'more_LIBRARY_ADVANCE_SEARCH_BUTTON']")
    private MobileElement advanced_search_option;

    @iOSXCUITFindBy(accessibility = "wrap_inputBoxAdvanceSearch")
    @AndroidFindBy(xpath = "//*[@resource-id= 'wrap_inputBoxAdvanceSearch']")
    private MobileElement advanced_search_bar;

    @iOSXCUITFindBy(accessibility = "btnSearchMenu")
    @AndroidFindBy(xpath = "//*[@resource-id= 'btnSearchMenu']")
    private MobileElement advance_search_box1;

    @iOSXCUITFindBy(accessibility = "loc_advance_search_search_btn")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_advance_search_search_btn']")
    private MobileElement search_btn1;


    @iOSXCUITFindBy(accessibility = "loc_refiner_search_search_btn")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_refiner_search_search_btn']")
    private MobileElement search_button1;

    @iOSXCUITFindBy(accessibility = "viewFeatureMenu")
//	@AndroidFindBy(xpath = "//*[@resource-id= 'txtThirdPartyCount']")
    @AndroidFindBy(xpath = "//*[@resource-id='viewFeatureMenu']")
    private MobileElement search_result;

    @iOSXCUITFindBy(accessibility = "search_advance_search_page_theme_id")
    @AndroidFindBy(xpath = "//*[@resource-id= 'search_advance_search_page_theme_id']")
    private MobileElement search_result_page;

    @iOSXCUITFindBy(accessibility = "search_advance_search_page_theme_id")
    @AndroidFindBy(xpath = "//*[@resource-id= 'search_advance_search_page_theme_id']")
    private MobileElement ZeroSearchResult;

    @iOSXCUITFindBy(accessibility = "LIBRARY_ADVANCE_SEARCH_BUTTON")
    @AndroidFindBy(xpath = "//*[@resource-id= 'LIBRARY_ADVANCE_SEARCH_BUTTON']")
    private MobileElement search_LenseIcon;

    @iOSXCUITFindBy(accessibility = "btnAdvancedSearchMenu")
    @AndroidFindBy(xpath = "//*[@resource-id= 'btnAdvancedSearchMenu']")
    private MobileElement search_LenseIcon1;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'loc_search_advance_search_refiner_icon')]")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_search_advance_search_refiner_icon']")
    private MobileElement search_refiner_icon;

    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@resource-id= 'btnBackIcon']")
    private MobileElement backButton;

    @iOSXCUITFindBy(accessibility = "loc_search_advance_search_refiner_icon")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_search_advance_search_refiner_icon']")
    private MobileElement refineCTA;

    @iOSXCUITFindBy(accessibility = "item.listTestId1")
    @AndroidFindBy(xpath = "//*[@resource-id= 'item.listTestId1']")
    private MobileElement ebook_Format;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Availability')]")
    @AndroidFindBy(xpath = "//*[@resource-id= 'undefined_outer']")
    private MobileElement clickAvailability;

    @iOSXCUITFindBy(accessibility = "Selected option here_1")
    @AndroidFindBy(xpath = "//*[@resource-id= 'Selected option here_1']")
    private MobileElement availableNow;

    @iOSXCUITFindBy(accessibility = "Availability_0")
    @AndroidFindBy(xpath = "//*[@resource-id= 'Availability_0']")
    private MobileElement availableNowRadio;
    @iOSXCUITFindBy(accessibility = "Search")
    @AndroidFindBy(xpath = "//*[@resource-id= 'Search']")
    private MobileElement Old_search_txt_box;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'See All')]")
    @AndroidFindBy(xpath = "//*[@text='See All']")
    private List<MobileElement> searchseeAll;

    @iOSXCUITFindBy(accessibility = "loc_search_advance_search_refiner_icon")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_search_advance_search_refiner_icon']")
    private MobileElement refineFilter_icon;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Subject')]")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_btnRefinersExpandIcon0']")
    private MobileElement refineFilter_subject;


    @iOSXCUITFindBy(accessibility = "item.toggleTestId_outer")
    @AndroidFindBy(xpath = "//*[@resource-id= 'item.toggleTestId_outer']")
    private MobileElement refineFilter_toggle;


    @iOSXCUITFindBy(accessibility = "Sub-Category, option, Selected option here")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_btnRefinersExpandIcon1']")
    private MobileElement refineFilter_sub_Category;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Source')]")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_btnRefinersExpandIcon2']")
    private MobileElement refineFilter_source;


    @iOSXCUITFindBy(accessibility = "loc_refiner_search_clear_btn")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_refiner_search_clear_btn']")
    private MobileElement clear_icon;

    @iOSXCUITFindBy(accessibility = "item.listTestId1")
    @AndroidFindBy(xpath = "//*[@resource-id= 'item.listTestId1']")
    private MobileElement ebooks_Screen;

    @iOSXCUITFindBy(accessibility = "loc_search_advance_search_refiner_icon")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_search_advance_search_refiner_icon']")
    private MobileElement Refiners_Screen;

    @iOSXCUITFindBy(accessibility = "loc_search_advance_search_refiner_icon")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_search_advance_search_refiner_icon']")
    private MobileElement Refine_Icon;

    @iOSXCUITFindBy(accessibility = "item.listTestId_0")
    @AndroidFindBy(xpath = "//*[@resource-id= 'item.listTestId_0']")
    private MobileElement Refine_All;

    @iOSXCUITFindBy(accessibility = "item.listTestId_3")
    @AndroidFindBy(xpath = "//*[@resource-id= 'item.listTestId_3']")
    private MobileElement WebResources;

    @iOSXCUITFindBy(accessibility = "loc_btnRefinersExpandIcon0")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_btnRefinersExpandIcon0']")
    private MobileElement StudySite;

    @iOSXCUITFindBy(accessibility = "item.listTestId_1")
    @AndroidFindBy(xpath = "//*[@resource-id= 'item.listTestId_1']")
    private MobileElement BookCategory;

    @iOSXCUITFindBy(accessibility = "Sub-Category")
    @AndroidFindBy(xpath = "//*[@text= 'Sub-Category']")
    private MobileElement SubCategory;

    @iOSXCUITFindBy(accessibility = "txtRefineCategory_0")
    @AndroidFindBy(xpath = "//*[@resource-id= 'txtRefineCategory_0']")
    private MobileElement EBook;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])")
    @AndroidFindBy(xpath = "//*[@resource-id= 'txtEBookHeader']")
    public MobileElement ebookTitles;


    @iOSXCUITFindBy(accessibility = "txtFeatureMenuEbook")
    @AndroidFindBy(xpath = "//*[@resource-id= 'txtFeatureMenuEbook']")
    public MobileElement ebookPills;

    @iOSXCUITFindBy(accessibility = "txtLearningActivityCount")
    @AndroidFindBy(xpath = "//*[@resource-id= 'txtLearningActivityCount']")
    public MobileElement activityResourcePills;

    @iOSXCUITFindBy(accessibility = "btnSearchMenu")
    @AndroidFindBy(xpath = "//*[@resource-id='btnSearchMenu']")
    private MobileElement expand_result;

    @iOSXCUITFindBy(accessibility = "item.listTestId1")
    @AndroidFindBy(xpath = "//*[@resource-id='item.listTestId1']")
    private MobileElement ebook_item;

    @iOSXCUITFindBy(accessibility = "item.listTestId2")
    @AndroidFindBy(xpath = "//*[@resource-id='item.listTestId2']")
    private MobileElement activityresource_item;

    @iOSXCUITFindBy(accessibility = "item.listTestId2")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"Activity Resources, \"]")
    private MobileElement activityResourceRefiner;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Web Resources')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Web Resources')]")
    private MobileElement webresource_item;

    @iOSXCUITFindBy(accessibility = "btnAdvancedSearchMenu")
    @AndroidFindBy(xpath = "//*[@resource-id='btnAdvancedSearchMenu']")
    private MobileElement study_site;

    @iOSXCUITFindBy(accessibility = "btnAdvancedSearchMenu")
    @AndroidFindBy(xpath = "//*[@resource-id='btnAdvancedSearchMenu']")
    private MobileElement subcat_view;

    @iOSXCUITFindBy(accessibility = "btnAdvancedSearchMenu")
    @AndroidFindBy(xpath = "//*[@resource-id='btnAdvancedSearchMenu']")
    private MobileElement user_NotSeeRefiner;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Web Resources')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Web Resources')]")
    private MobileElement web_resource_lbl;

    @iOSXCUITFindBy(accessibility = "item.listTestId4")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"Newspapers & Magazines, \"]")
    private MobileElement newspaperRefiner;

    @iOSXCUITFindBy(accessibility = "REFINE")
    @AndroidFindBy(xpath = "//*[@text='REFINE']")
    private MobileElement refineText;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'txtFeatureMenuEbook')]")
    @AndroidFindBy(xpath = "//*[@resource-id='txtFeatureMenuEbook']")
    private MobileElement ebookcategory_pills;

    @iOSXCUITFindBy(accessibility = "txtFeatureMenuAudioBook")
    @AndroidFindBy(xpath = "//*[@resource-id='txtFeatureMenuAudioBook']")
    private MobileElement econtentcategory_pills;

    @iOSXCUITFindBy(accessibility = "btnAdvancedSearchMenu")
    @AndroidFindBy(xpath = "//*[@resource-id='btnAdvancedSearchMenu']")
    private MobileElement Newspapers_Magazines_lbl;

    @iOSXCUITFindBy(accessibility = "btnAdvancedSearchMenu")
    @AndroidFindBy(xpath = "//*[@resource-id='btnAdvancedSearchMenu']")
    private MobileElement Articles_lbl;

    @iOSXCUITFindBy(accessibility = "btnAdvancedSearchMenu")
    @AndroidFindBy(xpath = "//*[@resource-id='btnAdvancedSearchMenu']")
    private MobileElement Ebook_Collection;

    @iOSXCUITFindBy(accessibility = "btnAdvancedSearchMenu")
    @AndroidFindBy(xpath = "//*[@resource-id='btnAdvancedSearchMenu']")
    private MobileElement Video_Collection;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Sort')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Sort By,Heading, \"]")
    public MobileElement Search_Sort;

    @iOSXCUITFindBy(accessibility = "LIBRARY_ADVANCE_SEARCH_BUTTON")
    @AndroidFindBy(xpath = "//*[@resource-id='LIBRARY_ADVANCE_SEARCH_BUTTON']")
    private MobileElement searchIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[@resource-id='search_advance_search_page_theme_id']")
    private List<MobileElement> websource_result;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[1]")
    private List<MobileElement> pillsSelectionresult;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Search')]")
    @AndroidFindBy(xpath = "//*[@content-desc='Search, ']")
    private MobileElement searchIcon1;

    @iOSXCUITFindBy(accessibility = "wrap_inputBoxAdvanceSearch")
    @AndroidFindBy(xpath = "//*[@resource-id='wrap_inputBoxAdvanceSearch']")
    private MobileElement AdvanceSearch_input;

    @iOSXCUITFindBy(accessibility = "SEARCH_TEXT_BOX")
    @AndroidFindBy(xpath = "//*[@resource-id='SEARCH_TEXT_BOX']")
    private MobileElement AdvancedSearch_inputbox;

    @iOSXCUITFindBy(accessibility = "loc_advance_search_clear_btn")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_advance_search_clear_btn']")
    private MobileElement ClearCTA;

    @iOSXCUITFindBy(accessibility = "item.listTestId0")
    @AndroidFindBy(xpath = "//*[@resource-id='item.listTestId0']")
    private MobileElement all;

    @iOSXCUITFindBy(accessibility = "loc_refiner_search_close_btn")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_refiner_search_close_btn']")
    private MobileElement Cancel_Btn;

    @iOSXCUITFindBy(accessibility = "LIBRARY_ADVANCE_SEARCH_BUTTON")
    @AndroidFindBy(xpath = "//*[@resource-id='LIBRARY_ADVANCE_SEARCH_BUTTON']")
    private MobileElement SearchCTA;

    @iOSXCUITFindBy(accessibility = "loc_refiner_search_search_btn")
    @AndroidFindBy(xpath = "//*[@resource-id= 'loc_refiner_search_search_btn']")
    private MobileElement SearchCTA_btn;

    @iOSXCUITFindBy(accessibility = "loc_advance_search_close_btn")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_advance_search_close_btn']")
    private MobileElement CancelIcon;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Collections\"])[1]")
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Collections, collapsed, \"])[1]")
    private MobileElement Collections;

    @iOSXCUITFindBy(accessibility = "Collections_0")
    @AndroidFindBy(xpath = "//*[@resource-id='Collections_0']")
    private MobileElement general_Collections;

    @iOSXCUITFindBy(accessibility = "Collections_1")
    @AndroidFindBy(xpath = "(//android.widget.RadioButton[@content-desc=\"false, \"])[4]")
    private MobileElement alwaysavilable_Collections;

    @iOSXCUITFindBy(accessibility = "Collections_1")
    @AndroidFindBy(xpath = "//*[@resource-id='Collections_1']")
    private MobileElement purchase_Collections;

    @iOSXCUITFindBy(accessibility = "Collections_3")
    @AndroidFindBy(xpath = "//*[@resource-id='Collections_3']")
    private MobileElement studysite_Collections;

    @iOSXCUITFindBy(accessibility = "Collections_4")
    @AndroidFindBy(xpath = "//*[@resource-id='Collections_4']")
    private MobileElement newspaper_Collections;

    @iOSXCUITFindBy(accessibility = "loc_refiner_search_close_btn")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_refiner_search_close_btn']")
    private MobileElement refiner_close;

    @iOSXCUITFindBy(accessibility = "loc_refiner_search_close_btn")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Close, \"]")
    private MobileElement closeRefinerIcon;

    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
    private MobileElement navigation_back;

    @iOSXCUITFindBy(accessibility = "loc_refiner_search_search_btn")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_refiner_search_search_btn']")
    private MobileElement expand_search;

    @iOSXCUITFindBy(accessibility = "Sub-category")
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Sub-category, collapsed, \"])[2]")
    private MobileElement Sub_category;

    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
    private MobileElement clickBack_btn;

    @iOSXCUITFindBy(accessibility = "txtRefineCategory0")
    @AndroidFindBy(xpath = "//*[@resource-id='txtRefineCategory0']")
    private MobileElement ebook_sucategory;

    @iOSXCUITFindBy(accessibility = "txtRefineCategory1")
    @AndroidFindBy(xpath = "//*[@resource-id='txtRefineCategory1']")
    private MobileElement eAudio_sucategory;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"imgIsAudioBookundefined\"])[1]")
    @AndroidFindBy(xpath = "//*[@resource-id='imgIsAudioBookundefined']")
    private MobileElement websource_cardTitle;

    @iOSXCUITFindBy(accessibility = "Collections_0")
    @AndroidFindBy(xpath = "//*[@resource-id='Collections_0']")
    private MobileElement MultiSelectOptions;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "//*[@resource-id='Collections_0']")
    private MobileElement No_resultFound;

    @iOSXCUITFindBy(accessibility = "Availability")
    @AndroidFindBy(xpath = "//*[@text= 'Availability']")
    private MobileElement AvailabilityCategory;

    @iOSXCUITFindBy(accessibility = "item.listTestId_1")
    @AndroidFindBy(xpath = "//*[@text= 'Collections']")
    private MobileElement CollectionsCategory;

    @iOSXCUITFindBy(accessibility = "Sort By")
    @AndroidFindBy(xpath = "//*[@text= 'Sort By']")
    private MobileElement SortBy;

    @iOSXCUITFindBy(accessibility = "loc_refiner_search_clear_btn")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_refiner_search_clear_btn']")
    private MobileElement search_clear;

    @iOSXCUITFindBy(accessibility = "loc_btnRefinersExpandIcon0")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersExpandIcon0']")
    private MobileElement subject_expand;

    @iOSXCUITFindBy(accessibility = "(//XCUIElementTypeButton[@name=\"selectedSubjectOption\"])[2]")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersExpandIcon0']")
    private MobileElement subject_option2;


    @iOSXCUITFindBy(accessibility = "(//XCUIElementTypeButton[@name=\"selectedSubjectOption\"])[1]")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersExpandIcon0']")
    private MobileElement subject_option1;

    @iOSXCUITFindBy(accessibility = "more_LIBRARY_ADVANCE_SEARCH_BUTTON")
    @AndroidFindBy(xpath = "//*[@resource-id='more_LIBRARY_ADVANCE_SEARCH_BUTTON']")
    private MobileElement advanceSearch;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'Category')]/parent::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/*[contains(@label,'Newspapers & Magazines')]")
    @AndroidFindBy(xpath = "//android.widget.RadioButton[contains(@content-desc,'Newspapers & Magazine')]")
    private MobileElement newspapersAndMagazinesCollections;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'third_party_header')]")
    @AndroidFindBy(xpath = "(//*[@resource-id= 'third_party_header'])[1]")
    private MobileElement newspapersAndMagazinesHeader;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'third_party_see')]")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'third_party_see_all_link')]")
    private MobileElement newspaperAndMagzinesseeAllCTA;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'third_party_see')]")
    @AndroidFindBy(xpath = "//*[@resource-id= 'third_party_see_all_link']")
    private MobileElement newspaperAndMagzinesseeAllCTA1;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"third_party_header\"])[2]")
    @AndroidFindBy(xpath = "//*[@resource-id= 'ArticleCarousel']/android.widget.TextView")
    private MobileElement articlesHeader;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'ARTICLES')]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeLink")
    @AndroidFindBy(xpath = "//*[contains(@text,'ARTICLES')]/parent::android.view.ViewGroup/android.view.View")
    private MobileElement articlesseeAllCTA;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'third_party_see')]")
    @AndroidFindBy(xpath = "//*[@resource-id= 'third_party_see_all_link']")
    private MobileElement articlesseeAllCTA1;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Download')]")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Download\"]/parent::android.view.ViewGroup/parent::android.view.ViewGroup")
    private MobileElement newspaperAndMagzinesTitle;

    @iOSXCUITFindBy(accessibility = "third_party_header")
    @AndroidFindBy(xpath = "//*[@text= 'Articles']")
    private MobileElement newspaperAndMagzinesHeader;

    @iOSXCUITFindBy(accessibility = "item.listTestId_0")
    @AndroidFindBy(xpath = "//*[@resource-id= 'item.listTestId_0']")
    private MobileElement allRefinerOption;

    @iOSXCUITFindBy(accessibility = "item.listTestId_1")
    @AndroidFindBy(xpath = "//*[@resource-id= 'item.listTestId_1']")
    private MobileElement eBooksRefinerOption;

    @iOSXCUITFindBy(accessibility = "item.listTestId_2")
    @AndroidFindBy(xpath = "//*[@resource-id= 'item.listTestId_2']")
    private MobileElement activityResourcesRefinerOption;

    @iOSXCUITFindBy(accessibility = "item.listTestId_3")
    @AndroidFindBy(xpath = "//*[@resource-id= 'item.listTestId_3']")
    private MobileElement webResourcesRefinerOption;

    @iOSXCUITFindBy(accessibility = "item.listTestId_4")
    @AndroidFindBy(xpath = "//*[@resource-id= 'item.listTestId_4']")
    private MobileElement newspaperAndMaganizesRefinerOption;

    @iOSXCUITFindBy(xpath = "//*[@label = 'Requests for Library Purchase']")
    @AndroidFindBy(xpath = "//android.widget.RadioButton[@content-desc=\"Requests for Library Purchase, \"]")
    private MobileElement purchaseRequestCollections;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'All')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'All')]")
    private MobileElement generalCollections;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'eBooks')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'eBooks')]")
    private MobileElement eBooksCollections;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'eAudios')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'eAudios')]")
    private MobileElement eAudiosCollections;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Checkers Library')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Checkers Library')]")
    private MobileElement videoCollections;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Videobooks')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Videobooks')]")
    private MobileElement vbookCollections;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Resource Hub')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Resource Hub')]")
    private MobileElement resourceHubCollections;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Web Resources')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Web Resources')]")
    private MobileElement webResourceCollections;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Newspapers & Magazines')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Newspapers & Magazines')]")
    private MobileElement newspaperandMagzineCollections;

    @iOSXCUITFindBy(xpath = "//*[contains(@text,'The')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'The')]")
    private MobileElement respectiveKeyword;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'0 Results')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'0 Results')]")
    private MobileElement noResultVerbiage;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Suggest To Purchase')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Suggest To Purchase')]")
    private MobileElement viewSuggestToPurchase;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'REFINE')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'REFINE')]")
    private MobileElement refinePopup;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Available Now')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Available Now')]")
    private MobileElement selectedRefine;

    @iOSXCUITFindBy(accessibility = "loc_refiner_search_clear_btn")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_refiner_search_clear_btn')]")
    private MobileElement clearAllPill;

    @iOSXCUITFindBy(accessibility = "loc_refiner_search_close_btn")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'loc_refiner_search_close_btn')]")
    private MobileElement closeRefine;


//	@iOSXCUITFindBy(xpath = "//*[@label = 'Videos radio']")
//	@AndroidFindBy(xpath = "//android.widget.RadioButton[@content-desc=\"Videos radio, \"]/android.view.ViewGroup")
//	private MobileElement videosCollections;
//
//	@iOSXCUITFindBy(xpath = "//*[@label = 'vBooks radio']")
//	@AndroidFindBy(xpath = "//android.widget.RadioButton[@content-desc=\"vBooks radio, \"]/android.view.ViewGroup")
//	private MobileElement vBooksCollections;

    @iOSXCUITFindBy(xpath = "//*[@label = \"Always Available\"]")
    @AndroidFindBy(xpath = "//android.widget.RadioButton[@content-desc=\"Always Available, \"]")
    private MobileElement alwaysAvailableCollections;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"item.toggleTestId_outer\"]")
    @AndroidFindBy(xpath = "//*[@resource-id='item.toggleTestId']")
    private MobileElement categorySection;

    @iOSXCUITFindBy(accessibility = "Done")
    @AndroidFindBy(id = "//*[@resource-id='Done']")
    public MobileElement logo_btn_Done;

    @iOSXCUITFindBy(accessibility = "Search")
    @AndroidFindBy(id = "//*[@resource-id='Search']")
    public MobileElement searchKeyboard;


    public void clicktoggle() {
        ClickOnMobileElement(refineFilter_toggle);
    }

    public boolean search() {

        boolean search = false;
        if (isElementPresent(search_txt_box)) {
            return true;
        } else if (isElementPresent(old_search_txt_box)) {
            return true;
        }
        return search;
    }

    public void clickActivatityResource() {
        if (isElementPresent(activityresource_item)) {
            ClickOnMobileElement(activityresource_item);
        }
    }

    public void clickActivatityResourceRefiner() {
        ClickOnMobileElement(activityResourceRefiner);

    }

    public MobileElement checkEBookTitles() {
        return ebookTitles;

    }

    public MobileElement checkEBookPills() {
        return ebookPills;

    }

    public MobileElement checkActivityResourcePills() {
        return activityResourcePills;
    }

    public void clickCollection() {
        {
            ClickOnMobileElement(Collections);
        }
    }

    public void clickSearch_Button() {
        if (isElementPresent(SearchCTA)) {
            ClickOnMobileElement(SearchCTA);
        }
    }

    public void clickClearCTA() {
        ClickOnMobileElement(ClearCTA);
    }

    public void clickCancel() {
        ClickOnMobileElement(Cancel_Btn);
    }

    public void clickCancelIcon() {
        ClickOnMobileElement(CancelIcon);
    }


    public void clickCloseRefiner() {
        ClickOnMobileElement(closeRefinerIcon);
    }

    public void Expand_Subject() {
        ClickOnMobileElement(subject_expand);
    }

    public void clickWebresource() {
        ClickOnMobileElement(webresource_item);
    }

    public void clickebook() {
        if (isElementPresent(ebook_item)) {
            ClickOnMobileElement(ebook_item);
        }
    }

    public void navigateBack() {
        if (isElementPresent(navigation_back)) {
            ClickOnMobileElement(navigation_back);
        }
    }

    public void searchBar(String keyword) {
        if (isElementPresent(search_txt_box)) {
            ClickOnMobileElement(search_txt_box);
            SendKeysOnMobileElement(search_txt_box, keyword);
        } else if (isElementPresent(search_advanced_txt_box)) {
            ClickOnMobileElement(search_advanced_txt_box);
            SendKeysOnMobileElement(search_advanced_txt_box, keyword);
        }
        if (isElementPresent(search_button)) {
            ClickOnMobileElement(search_button);
        }
    }

    public void searchkeyWord(String keyword) {
        if (isElementPresent(search_advanced_txt_box)) {
            ClickOnMobileElement(search_advanced_txt_box);
            SendKeysOnMobileElement(search_advanced_txt_box, keyword);
        } else if (isElementPresent(search_txt_box)) {
            ClickOnMobileElement(search_txt_box);
            SendKeysOnMobileElement(search_txt_box, keyword);
        }
    }

    public void selectTypeAuther() {
        if (isElementPresent(select_TypeAuther)) {
            ClickOnMobileElement(select_TypeAuther);
        }
    }


    public void advancedSearchOption() {
        ClickOnMobileElement(advanced_search_option);
    }

    public void clickseeAll() {
        for (int i = 0; i < searchseeAll.size(); i++) {
            ClickOnMobileElement(searchseeAll.get(i));
            if (i == 2) {
                break;
            }

        }
    }

    public void clickSort() {
        ClickOnMobileElement(Search_Sort);
    }


    public void clickrefineFilter() {
        ClickOnMobileElement(refineFilter_icon);
    }

    public void clickSearchBox() {
        if (isElementPresent(search_btn)) {
            ClickOnMobileElement(search_btn);
        } else if (isElementPresent(search_btn1)) {
            ClickOnMobileElement(search_btn1);
        } else {
            ClickOnMobileElement(search_button1);
        }
    }

    public void clickSubCategory() {
        if (isElementPresent(SubCategory)) {
            ClickOnMobileElement(SubCategory);
        }
    }

    public void clickEBook() {
        if (isElementPresent(EBook)) {
            ClickOnMobileElement(EBook);
        }
    }

    public void clickEBookEAudio() {
        if (isElementPresent(BookCategory)) {
            ClickOnMobileElement(BookCategory);
        }
    }

    public void clickSearchCTA() {
        if (isElementPresent(SearchCTA_btn)) {
            ClickOnMobileElement(SearchCTA_btn);
        }
    }

    public MobileElement getSearch_box() {
        return search_txt_box;
    }

    public MobileElement getExpand_result() {
        return expand_result;
    }

    public MobileElement getStudy_site() {
        return study_site;
    }

    public MobileElement getSubCategory_view() {
        return subcat_view;
    }

    public MobileElement getUser_NotSeeRefiner() {
        return user_NotSeeRefiner;
    }

    public void selectcategorypills() {
        waitFor(5000);
        WaitForMobileElement(ebookcategory_pills);
        ClickOnMobileElement(ebookcategory_pills);
    }

    public void web_resources() {
        if (isElementPresent(web_resource_lbl)) {
            ClickOnMobileElement(web_resource_lbl);
        }
    }

    public MobileElement newspaperRefinerOption() {
        return newspaperRefiner;
    }

    public void clickPurchaseRequest() {
        ClickOnMobileElement(purchase_Collections);
    }

    public MobileElement getRefineText() {
        return refineText;
    }


    public void selecteook() {
        if (isElementPresent(ebooks_Screen)) {
            ClickOnMobileElement(ebooks_Screen);
        }
    }

    public void viewResult() {
        if (isElementPresent(expand_search)) {
            ClickOnMobileElement(expand_search);
        }
    }

    public void selectsubcategory() {
        if (isElementPresent(Sub_category)) {
            ClickOnMobileElement(Sub_category);
        }
    }


    public void clickAdvanceSearch() {
        ClickOnMobileElement(advanceSearch);
    }

    public MobileElement checkNewspapersAndMagazinesCollections() {
        return newspapersAndMagazinesCollections;
    }

    public void clickNewspapersAndMagazinesCollections() {
        ClickOnMobileElement(newspapersAndMagazinesCollections);
    }

    public void clickSearch() {
        if (isElementPresent(search_button)) {
            ClickOnMobileElement(search_button);
        }
    }


    public MobileElement verifyNewspapersAndMagazinesHeader() {
        return newspapersAndMagazinesHeader;
    }

    public void clickNewspaperAndMagzinesseeAllCTA() {
        if (isElementPresent(newspaperAndMagzinesseeAllCTA)) {
            ClickOnMobileElement(newspaperAndMagzinesseeAllCTA);
        } else {
            ClickOnMobileElement(newspaperAndMagzinesseeAllCTA1);
        }
    }

    public MobileElement verifyNewspaperAndMagzinesseeAllCTA() {
        return newspaperAndMagzinesseeAllCTA;
    }

    public MobileElement verifyNewspaperAndMagzinesseeAllCTA1() {
        return articlesseeAllCTA;
    }

    public MobileElement verifyArticlesHeader() {
        return articlesHeader;
    }

    public void clickArticlesseeAllCTA() {
        if (isElementPresent(articlesseeAllCTA)) {
            ClickOnMobileElement(articlesseeAllCTA);
        } else {
            ClickOnMobileElement(articlesseeAllCTA1);
        }
    }

    public MobileElement verifyArticlesseeAllCTA() {
        if (isElementPresent(articlesseeAllCTA)) {
            return articlesseeAllCTA;
        } else {
            return articlesseeAllCTA1;
        }
    }

    public MobileElement clickNewspaperAndMagzinesTitle() {
        return newspaperAndMagzinesTitle;
    }

    public MobileElement verifyNewspaperAndMagzinesListPage() {
        return newspaperAndMagzinesHeader;
    }

    public MobileElement checkGeneralCollections() {
        return newspapersAndMagazinesCollections;
    }

    public MobileElement verifyAllRefinerOption() {
        return allRefinerOption;
    }

    public MobileElement verifyEBooksRefinerOption() {
        return eBooksRefinerOption;
    }

    public MobileElement verifyActivityResourcesRefinerOption() {
        return activityResourcesRefinerOption;
    }

    public MobileElement verifyWebResourcesRefinerOption() {
        return webResourcesRefinerOption;
    }

    public MobileElement verifyNewspapersAndMaganizesRefinerOption() {
        return newspaperAndMaganizesRefinerOption;
    }

    public MobileElement verifyPurchaseRequestCollection() {
        return purchaseRequestCollections;
    }

    public MobileElement verifyGeneralCollection() {
        return generalCollections;
    }

    public MobileElement verifyeBooksCollections() {
        return eBooksCollections;
    }

    public MobileElement verifyeAudiosCollections() {
        return eAudiosCollections;
    }

    public MobileElement verifyResourceHubCollections() {
        return resourceHubCollections;
    }

    public MobileElement verifyWebResourceCollections() {
        return webResourceCollections;
    }

    public MobileElement verifyNewspaperAndMagzinesCollections() {
        return newspaperandMagzineCollections;
    }

    public MobileElement verifyRespectiveKeyword() {
        return respectiveKeyword;
    }

    public MobileElement verifyNoResultVerbiage() {
        return noResultVerbiage;
    }

    public MobileElement verifyViewSuggestToPurchase() {
        return viewSuggestToPurchase;
    }

    public MobileElement verifyRefinePopup() {
        return refinePopup;
    }

    public MobileElement verifySelectedRefine() {
        return selectedRefine;
    }

    public MobileElement verifyClearAllPill() {
        return clearAllPill;
    }

    public MobileElement verifyVideosCollections() {
        return videoCollections;
    }

    public MobileElement verifyvBooksCollections() {
        return vbookCollections;
    }

    public MobileElement verifyAlwaysAvailableCollection() {
        return alwaysAvailableCollections;
    }

    public void clickCategorSearch() {
        ClickOnMobileElement(SearchCTA_btn);
    }

    /************************************************************
     * Methods
     **************************/

    public MobileElement getVideos_SearchResults() {
        return videos_SearchResults;
    }

    public MobileElement getVideo_Colletion() {
        return video_Colletion;
    }

    public MobileElement getvBookCategoryPills() {
        return vBookCategoryPills;
    }

    public MobileElement getVideoCategoryPills() {
        return videoCategoryPills;
    }

    public MobileElement getTitle_resume() {
        return title_resume;
    }

    public MobileElement getCollections_WebResource() {
        return collections_WebResource;
    }

    public MobileElement getTitle_series() {
        return title_series;
    }

    public MobileElement getTitle_likethis() {
        return title_likethis;
    }

    public MobileElement getBtn_moreLikethis() {
        return btn_moreLikethis;
    }

    public MobileElement relatedItems() {
        return related_items;
    }

    public MobileElement getVbook_Colletion() {
        return vbook_Colletion;
    }

    public MobileElement getViewFeatures_Menu() {
        return viewFeatures_Menu;
    }

    public MobileElement getSearch_Result_Landing() {
        return search_Result_Landing;
    }

    public MobileElement getvBook_Carousel_Landing() {
        return vBook_Carousel_Landing;
    }

    public MobileElement getVideos_Carousel_Landing() {
        return videos_Carousel_Landing;
    }

    public MobileElement getOther_Carousel_Landing() {
        return other_Carousel_Landing;
    }

    public MobileElement getVbook_Expanded_Result() {
        return vbook_Expanded_Result;
    }

    public MobileElement getVideos_Expanded_Result() {
        return videos_Expanded_Result;
    }

    public MobileElement getVbook_Cover_Image() {
        return vbook_Cover_Image;
    }

    public MobileElement getVbook_Title() {
        return vbook_Title;
    }

    public MobileElement getVbook_Checkout_CTA() {
        return vbook_Checkout_CTA;
    }

    public MobileElement getSearch_Result() {
        return search_Result;
    }

    public MobileElement getvBookTitle_Result() {
        return vBookTitle_Result;
    }

    public MobileElement geteBookTitle_card_details() {
        return eBookTitle_card_btnshare;
    }

    public MobileElement getvideos_Header() {
        return videos_Header;
    }

    public void select_Videos() {
        ClickOnMobileElement(video_Colletion);
    }

    public void select_Collections_General() {
        ClickOnMobileElement(collections_General);
    }

    public void select_VBooks_Refiner() {
        ClickOnMobileElement(vBooks_Refiner);
    }

    public void select_Video_Refiner() {
        ClickOnMobileElement(video_Refiner);
    }

    public void select_vBooks() {
        ClickOnMobileElement(vbook_Colletion);
    }

    public void click_Search_btn() {
        ClickOnMobileElement(btn_AdvancedSearchMenu);
    }

    public MobileElement advance_search_btn() {
        return search_btn;
    }

    public MobileElement clear_btn() {
        return clear_btn;
    }

    public void click_Search_Refine_btn() {
        ClickOnMobileElement(search_Refine_btn);
    }

    public void click_Refiner_Option() {
        ClickOnMobileElement(refiner_Option);
    }

    public void selectVideoCollection() {
        ClickOnMobileElement(video_Colletion);
        if (isElementPresent(video_Colletion)) {
            ClickOnMobileElement(video_Colletion);
        }
    }

    public void selectVbookCollection() {
        ClickOnMobileElement(vbook_Colletion);
        if (isElementPresent(vbook_Colletion)) {
            ClickOnMobileElement(vbook_Colletion);
        }
    }

    public void clicksearchResultButton() {
        if (isElementPresent(clear_btn)) {
            ClickOnMobileElement(clear_btn);
            waitFor(2000);
        } else {
            ClickOnMobileElement(search_btn);
        }
    }

    public void clickSeeAll() {
        ClickOnMobileElement(ebooks_seeall);
    }

    public void click_vBook_SeeAll() {
        for (int i = 0; i < 5; i++) {
            if (isElementPresent(vbooks_seeall)) {
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(vbooks_seeall);
    }

    public void click_Back_btn() {
        ClickOnMobileElement(back_btn);
    }

    public void click_Checkout_CTA() {
        ClickOnMobileElement(checkout_CTA);
    }

    public void click_Play_CTA() {
        ClickOnMobileElement(play_CTA);
    }

    public void clickBookcard() {
        ClickOnMobileElement(eBookTitle_card);
    }

    public void clickvBook_title_card() {
        ClickOnMobileElement(vBook_title_card);
    }

    public void clickvideo_title_card() {
        ClickOnMobileElement(video_title_card);
    }

    public MobileElement checkTitleHeaderInSearch() {
        return titleHeaderInSearch;
    }

    public void clickTitleResultInSearch() {
        ClickOnMobileElement(titleResultInSearch);
    }

    public MobileElement checkvBookCategoryPills() {
        return vBookCategoryPills;
    }

    public MobileElement checkTitle_Details() {
        return title_Details;
    }

    public MobileElement checkvBookandVideoSearchCategoryHeader() {
        return vBookandVideoSearchCategoryHeader;
    }

    public List<MobileElement> checkvBookSearchTitleIcon() {
        return vBookSearchTitleIcon;
    }

    public void clickvBookSearchTitle() {

        ClickOnMobileElement(vBookSearchTitleIcon.get(0));
    }

    public MobileElement checkTier3TextTitle() {
        return tier3TextTitle;
    }

    public MobileElement checkvBookTier3TitleIcon() {
        return vBookTier3TitleIcon;
    }

    public MobileElement checkVideoCategoryPills() {
        if (isElementPresent(videoCategoryPills)) {
            return videoCategoryPills;
        } else {
            return videoCategoryPills1;
        }
    }

    public List<MobileElement> checkVideoSearchTitleIcon() {
        return videoSearchTitleIcon;
    }

    public MobileElement checkVideoTier3TitleIcon() {
        return videoTier3TitleIcon;
    }

    public void globalSearch(String keyword) {
        if (isElementPresent(global_search_txt_box)) {
            ClickOnMobileElement(global_search_txt_box);
            SendKeysOnMobileElement(global_search_txt_box, keyword);
        } else if (isElementPresent((search_txt_box))) {
            ClickOnMobileElement(search_txt_box);
            SendKeysOnMobileElement(search_txt_box, keyword);
        } else if (isElementPresent(search_advanced_txt_box)) {
            ClickOnMobileElement(search_advanced_txt_box);
            SendKeysOnMobileElement(search_advanced_txt_box, keyword);
        }

    }

    public void advanceSearch(String title) {
        ClickOnMobileElement(advanceSearch);
        ClickOnMobileElement(search_advanced_txt_box);
        SendKeysOnMobileElement(search_advanced_txt_box, title);

    }

    public void clickTitleCover() {
        ClickOnMobileElement(title_cover);
    }

    public boolean vbookResult() {
        boolean result = false;
        for (int i = 0; i < 3; i++) {
            if (isElementPresent(vBookCategoryPills)) {
                result = true;
                break;
            } else if (isElementPresent(vBookCategoryPills1)) {
                result = true;
                break;
            } else {
                swipeDown();
            }
        }
        return result;
    }

    public boolean videoResult() {
        boolean result = false;
        for (int i = 0; i < 3; i++) {
            if (isElementPresent(videoCategoryPills)) {
                result = true;
                break;
            } else if (isElementPresent(videoCategoryPills1)) {
                result = true;
                break;
            } else {
                swipeDown();
            }
        }
        return result;
    }

    public void clickVideoSearchTitle() {
        ClickOnMobileElement(videoSearchTitleIcon.get(0));

    }

    public void verifyVideoSearchResult() {
        for (int i = 0; i < 4; i++) {
            if (isElementPresent(vBookSeeAllSearchResultLink)) {
                break;
            } else if (isElementPresent(videoSeeAllSearchResultLink)) {
                ClickOnMobileElement(videoSeeAllSearchResultLink);
                waitFor(2000);
                Assert.assertEquals(isElementPresent(tier2Title), true);
                Assert.assertEquals(isElementPresent(refinerIcon), true);
                ClickOnMobileElement(back_btn);
                break;
            } else {
                swipeDown();
            }
        }
    }

    public void verifyvBookSearchResult() {
        for (int i = 0; i < 4; i++) {
            if (isElementPresent(vBookSeeAllSearchResultLink)) {
                ClickOnMobileElement(vBookSeeAllSearchResultLink);
                waitFor(2000);
                Assert.assertEquals(isElementPresent(tier2Title), true);
                Assert.assertEquals(isElementPresent(refinerIcon), true);
                ClickOnMobileElement(back_btn);
                break;
            } else {
                swipeDown();
            }
        }
    }

    public void search(String title) {

        ClickOnMobileElement(search_button);
        ClickOnMobileElement(search_textbox);
        SendKeysOnMobileElement(search_textbox, title);

    }

    public void searchButton() {
        ClickOnMobileElement(search_button);
    }

    public void searchIcon() {
        ClickOnMobileElement(search_Icon);
    }

    public void clickSearchIcon() {
        if (isElementPresent(search_btn)) {
            ClickOnMobileElement(search_btn);
        } else if (isElementPresent(searchIcon)) {
            ClickOnMobileElement(searchIcon);
        } else if (isElementPresent(searchIcon1)) {
            ClickOnMobileElement(searchIcon1);
        }
    }

    public void click_ebook_Format() {
        ClickOnMobileElement(ebook_Format);
    }

    public void clickClearAllPill() {
        ClickOnMobileElement(clearAllPill);
    }

    public void clickCloseRefine() {
        ClickOnMobileElement(closeRefine);
    }

    public void clickAvailability() {
        ClickOnMobileElement(clickAvailability);
    }

    public void selectAvailableNow() {
        ClickOnMobileElement(availableNow);
    }

    public void clickRefineCTA() {
        ClickOnMobileElement(refineCTA);
    }

    public void clickBackButton() {
        ClickOnMobileElement(backButton);
    }

    public void clickRefiner() {
        waitFor(3000);
        ClickOnMobileElement(search_refiner_icon);
    }

    public void closerefiner() {
        if (isElementPresent(refiner_close)) {
            ClickOnMobileElement(refiner_close);
        }
    }

    public void clickBack() {
        if (isElementPresent(clickBack_btn)) {
            ClickOnMobileElement(clickBack_btn);
        }
    }

    public void clickResourceHub() {
        ClickOnMobileElement(resourceHub);
        ClickOnMobileElement(resourceHub);
    }

    public MobileElement authorRadio() {
        return authorRadio;
    }

    public MobileElement ISBNRadio() {
        return ISBNRadio;
    }

    public MobileElement resourceHubResults() {
        return resourceHubResults;
    }

    public void clickWebResources() {
        ClickOnMobileElement(webResources);
        ClickOnMobileElement(webResources);
    }

    public MobileElement titleRadio() {
        return titleRadio;
    }

    public MobileElement webResourcesResults() {
        return webResourcesResults;
    }

    public void clickNewspaperMagazine() {
        ClickOnMobileElement(newspaperMagazine);
        ClickOnMobileElement(newspaperMagazine);
    }

    public MobileElement newspapersResults() {
        return newspapersResults;
    }

    public void clickMagazine() {
        ClickOnMobileElement(Magazine);
    }

    public MobileElement magazineResults() {
        return magazineResults;
    }

    public void clickISBNRadio() {
        ClickOnMobileElement(ISBNRadio);
    }

    public void ISBNSearch(String ISBN) {
        SendKeysOnMobileElement(search_txt_box, ISBN);
    }

    public MobileElement resourceHubRadio() {
        return resourceHub;
    }

    public MobileElement webResourcesRadio() {
        return webResources;
    }

    public MobileElement ISBNResults() {
        return ISBNResults;
    }

    public void authorSearch(String author) {
        SendKeysOnMobileElement(search_txt_box, author);
    }

    public void clickAuthorRadio() {
        ClickOnMobileElement(authorRadio);
        ClickOnMobileElement(authorRadio);
    }

    public void clickEbooksRadio() {
        ClickOnMobileElement(eBooksCollections);
    }

    public void clickEaudioRadio() {
        ClickOnMobileElement(eAudiosCollections);
    }

    public void clickVideoRadio() {
        ClickOnMobileElement(videoCollections);
    }

    public void clickVbookRadio() {
        ClickOnMobileElement(videoCollections);
    }

    public void clickIOSKeyboardDone() {

        if (System.getProperty("platform").equalsIgnoreCase("ios")) {
            ClickOnMobileElement(logo_btn_Done);
        }
    }

    public MobileElement iosKeyboardDone() {
        return logo_btn_Done;
    }

    public void clickSearchKeyboard() {
        ClickOnMobileElement(searchKeyboard);
    }

    public MobileElement selectSearchedTitle() { return advancedSeachTitle;}


    public MobileElement getNoDataTitle(){return noDataTitle;}

    public MobileElement selectEAudioTitle(){return advanceEAudioTitle;}

    public String geteBookTitle() {
        return searchTitle.getText();
    }

    public void tapWishlistTitle(){ClickOnMobileElement(wishlistTitle);}

    public void tapAvailableNowRadio(){
        swipeDown();
        ClickOnMobileElement(availableNowRadio);
    }
}
