package pom.kidszone;

import org.junit.Assert;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class LearningActivity extends CommonActions {
	
	TitleDetails details = new TitleDetails(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(TitleDetails.class);
	
	public LearningActivity(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	/*********************Locators***********************/

	@iOSXCUITFindBy(accessibility = "Learning Activities Heading, ")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtLearningResourceAndActivities']")
	private MobileElement LearningActivity_btn_learningActivityNavigation;
	
	@iOSXCUITFindBy(accessibility = "cardImageTestId")
	@AndroidFindBy(xpath = "(//*[@resource-id='cardImageTestId'])[1]")
	private MobileElement LearningActivityCard;
	
	@iOSXCUITFindBy(accessibility = "cardTestID")
	@AndroidFindBy(xpath = "//*[@resource-id='cardTestID']")
	private MobileElement LearningActivity_btn_learningActivityCard;

	@iOSXCUITFindBy(accessibility = "availableActivityTextTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='availableActivityTextTestId']")
	private MobileElement LearningActivity_txt_learningActivityTitle;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement LearningActivity_btn_backButton;
	
	/*********************148892***********************/

	@iOSXCUITFindBy(accessibility = "loc_txtNoOfTitlesLoaded")
	@AndroidFindBy(xpath = "//*[@resource-id='availableActivityTextTestId']")
	private MobileElement LearningActivity_txt_numberOfTitles;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersIcon']")
	private MobileElement LearningActivity_btn_refinersIcon;

	@iOSXCUITFindBy(accessibility = "loc_txtRefinersHeader")
	@AndroidFindBy(xpath = "//*[@text='REFINE']")
	private MobileElement LearningActivity_txt_refinersHeader;

	@iOSXCUITFindBy(accessibility = "There are no results matching your selection. Please modify your selection.")
	@AndroidFindBy(xpath = "//*[@text='There are no results matching your selection. Please modify your selection.']")
	private MobileElement LearningActivity_txt_noResultMsg;

	/*********************148893***********************/

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersSortExpandIcon")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"loc_txtSortBy, \"]")
	private MobileElement LearningActivity_txt_refinersSortSection;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersActivityExpandIcon")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"loc_txtActivityTypeText, \"]")
	private MobileElement LearningActivity_txt_refinersActivityTypeSection;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersAudienceExpandIcon")
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"loc_txtAudienceLevelText, \"]")
	private MobileElement LearningActivity_txt_refinersAudienceLevelSection;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersSortExpandIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersSortExpandIcon']")
	private MobileElement LearningActivity_btn_refinersSortExpandIcon;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersActivityExpandIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersActivityExpandIcon']")
	private MobileElement LearningActivity_btn_refinersActivityExpandIcon;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersAudienceExpandIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersAudienceExpandIcon']")
	private MobileElement LearningActivity_btn_refinersAudienceExpandIcon;
	
	@iOSXCUITFindBy(accessibility = "loc_btnRefinersSortCollapseIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersSortCollapseIcon']")
	private MobileElement LearningActivity_btn_refinersSortCollapseIcon;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersActivityCollapseIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersActivityCollapseIcon']")
	private MobileElement LearningActivity_btn_refinersActivityCollapseIcon;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersAudienceCollapseIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersAudienceCollapseIcon']")
	private MobileElement LearningActivity_btn_refinersAudienceCollapseIcon;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersViewResults")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersViewResults']")
	private MobileElement LearningActivity_btn_viewResultsCTA;

	@iOSXCUITFindBy(accessibility = "loc_btnClearRefiners")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnClearRefiners']")
	private MobileElement LearningActivity_btn_clearCTA;

	@iOSXCUITFindBy(accessibility = "loc_txtSortSelectedOption")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtSortSelectedOption']")
	private MobileElement LearningActivity_btn_selectedSort; //below Sort By text

	@iOSXCUITFindBy(accessibility = "loc_txtActivitySelectedOption")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtActivitySelectedOption']")
	private MobileElement LearningActivity_btn_selectedActivityType; //below Activity Type text

	@iOSXCUITFindBy(accessibility = "loc_txtAudienceSelectedOption")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtAudienceSelectedOption']")
	private MobileElement LearningActivity_btn_selectedAudienceLevel; //below Audience Level text

	/*********************148894***********************/

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"loc_btnSortOptions\"])[1]")
	@AndroidFindBy(xpath = "(//android.widget.ToggleButton[@content-desc=\"loc_btnSortOptions, \"])[1]/android.view.ViewGroup")
	private MobileElement LearningActivity_btn_sortOption;

	/*********************148895***********************/
	
	//@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"loc_btnAudienceLevelOptions\"])[2]")
	@iOSXCUITFindBy(accessibility = "Teen \"Checkbox checked")
	@AndroidFindBy(xpath = "//*[@resource-id='CheckBox-Teen']")
	private MobileElement LearningActivity_btn_audienceLvlOption;

	/*********************148896***********************/

	//@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"loc_btnActivityTypeOptions\"])[3]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Book Club Discussion Guide\"]/XCUIElementTypeOther")
	@AndroidFindBy(xpath = "//*[@resource-id='CheckBox-Book Club Discussion Guide']")
	private MobileElement LearningActivity_btn_activityTypeOption;

	@iOSXCUITFindBy(accessibility = "loc_btnSelectedOptionPills1")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnSelectedOptionPills1']")
	private MobileElement LearningActivity_btn_selectedRefinersPills;
	
	@iOSXCUITFindBy(accessibility = "loc_btnSelectedOptionPills2")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnSelectedOptionPills2']")
	private MobileElement LearningActivity_btn_selectedRefinersPills2;

	@iOSXCUITFindBy(accessibility = "loc_btnRemovePills1")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRemovePills1']")
	private MobileElement LearningActivity_btn_removeRefinersPills;

	@iOSXCUITFindBy(accessibility = "loc_btnClearAllOptionPills")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnClearAllOptionPills']")
	private MobileElement LearningActivity_btn_clearAllRefinersPills;

	@iOSXCUITFindBy(accessibility = "loc_btnCloseRefiners")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnCloseRefiners']") 
	private MobileElement LearningActivity_btn_closeRefiner;

	/*********************148897***********************/

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"loc_imgLACardCoverImage\"])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_imgLACardCoverImage']")
	private MobileElement LearningActivity_lbl_cardCoverImage;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"loc_txtLearningResourceName\"])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtLearningResourceName']")
	private MobileElement LearningActivity_lbl_cardTitle;

	@iOSXCUITFindBy(accessibility = "loc_txtLearningResourceType")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtLearningResourceType']")
	private MobileElement LearningActivity_lbl_cardTitleType;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"loc_txtLATitleMapped\"])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtLATitleMapped']")
	private MobileElement LearningActivity_lbl_cardTitleMapped;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"dummy\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='com.android.permissioncontroller:id/permission_deny_button']")
	private MobileElement LearningActivity_btn_allowAccessPhoto;

	@iOSXCUITFindBy(accessibility = "QLPDFItemViewControllerBarSearchRightButtonAccessibilityIdentifier")
	@AndroidFindBy(xpath = "//*[@resource-id='com.android.permissioncontroller:id/permission_allow_button']")
	private MobileElement LearningActivity_lbl_nativePDF;
	
	@iOSXCUITFindBy(accessibility = "QLOverlayDoneButtonAccessibilityIdentifier")
	@AndroidFindBy(xpath = "//*[@resource-id='com.android.permissioncontroller:id/permission_allow_button']")
	private MobileElement LearningActivity_btn_backFromPDF;
	
	@iOSXCUITFindBy(accessibility = "Back")
	@AndroidFindBy(xpath = "//*[@resource-id='com.android.permissioncontroller:id/permission_allow_button']")
	private MobileElement LearningActivity_btn_backFromPDF2;

	/*********************148899***********************/

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"loc_btnDownload\"])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnDownload']")
	private MobileElement LearningActivity_btn_download;

	@iOSXCUITFindBy(accessibility = "loc_btnPauseDownload")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnPauseDownload']")
	private MobileElement LearningActivity_btn_pauseDownload;

	@iOSXCUITFindBy(accessibility = "loc_btnStopDownload")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnStopDownload']")
	private MobileElement LearningActivity_btn_stopDownload;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Download Progress Bar\"])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='slideProgressTestID']")
	private MobileElement LearningActivity_btn_downloadProgressBar;
	
	@iOSXCUITFindBy(accessibility = "loc_btnDownloadProgress")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnDownloadProgress']")
	private MobileElement LearningActivity_btn_downloadProgressPercentage;
	
	/*********************124721***********************/
	
	@iOSXCUITFindBy(accessibility = "loc_txtLearningResourceAndActivities")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtLearningResourceAndActivities']")
	private MobileElement LearningActivity_lbl_learningResourceFa;
	
	@iOSXCUITFindBy(accessibility = "loc_txtLearningResourceAndActivities")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtLearningResourceDesc']")
	private MobileElement LearningActivity_lbl_learningResourceFaDesc;
	
	@iOSXCUITFindBy(accessibility = "loc_btnLearningCategories1TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnLearningCategories1TestId']")
	private MobileElement LearningActivity_btn_categories;
	
	@iOSXCUITFindBy(accessibility = "loc_btnLearningCategories2TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnLearningCategories2TestId']")
	private MobileElement LearningActivity_btn_categories1;
	
	@iOSXCUITFindBy(accessibility = "loc_btnLearningCategories3TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnLearningCategories3TestId']")
	private MobileElement LearningActivity_btn_categories2;
	
	@iOSXCUITFindBy(accessibility = "loc_btnLearningLearnMore")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnLearningLearnMore']")
	private MobileElement LearningActivity_btn_learnMore;
	
	@iOSXCUITFindBy(accessibility = "learningCardContent")
	@AndroidFindBy(xpath = "//*[@resource-id='availableActivityTextTestId']")
	private MobileElement LearningActivity_lbl_listingPage;

	@iOSXCUITFindBy(accessibility = "availableActivityTextTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='availableActivityTextTestId']")
	private MobileElement LearningActivity_lbl_learningTab;
	
	@iOSXCUITFindBy(accessibility = "learningActivityListTestID")
	@AndroidFindBy(xpath = "//*[@resource-id='learningActivityListTestID'")
	private MobileElement TitleDetails_lbl_learningResoucesCategories;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Learning Resources\"]")
	@AndroidFindBy(xpath = "//*[@text='Learning Resources']")
	private MobileElement LearningActivity_lbl_learningActivities;
	

	public MobileElement getRefinersIcon() {
		return LearningActivity_btn_refinersIcon;
	}
	
	public MobileElement getLearningActivityTitle() {
		return LearningActivity_txt_learningActivityTitle;
	}
	
	public MobileElement getLearningActivityList() {
		return LearningActivity_btn_learningActivityCard;
	}
	
	public MobileElement getLearningActivityCard() {
		return LearningActivity_btn_learningActivityCard;
	}
	
	public MobileElement getNoOfLearningActivity() {
		return LearningActivity_txt_numberOfTitles;
	}
	
	public MobileElement getRefinersScreenHeader() {
		return LearningActivity_txt_refinersHeader;
	}
	
	public MobileElement getSortSection() {
		return LearningActivity_txt_refinersSortSection;
	}
	
	public MobileElement getActivityTypeSection() {
		return LearningActivity_txt_refinersActivityTypeSection;
	}
	
	public MobileElement getAudienceLvlSection() {
		return LearningActivity_txt_refinersAudienceLevelSection;
	}
	
	public MobileElement getSelectedSort() {
		return LearningActivity_btn_selectedSort;
	}
	
	public MobileElement getSelectedActivityType() {
		return LearningActivity_btn_selectedActivityType;
	}
	
	public MobileElement getSelectedAudienceLvl() {
		return LearningActivity_btn_selectedAudienceLevel;
	}
	
	public MobileElement getSortOption() {
		return LearningActivity_btn_sortOption;
	}

	public MobileElement getLearningActivity_btn_refinersAudienceExpandIcon() {
		return LearningActivity_btn_refinersAudienceExpandIcon;
	}
	
	public MobileElement getActivityTypeOption() {
		return LearningActivity_btn_activityTypeOption;
	}

	public MobileElement getAudienceLvlOption() {
		return LearningActivity_btn_audienceLvlOption;
	}
	
	public MobileElement getActivityTypeExpandIcon() {
		return LearningActivity_btn_refinersActivityExpandIcon;
	}
	
	public MobileElement getAudienceLvlExpandIcon() {
		return LearningActivity_btn_refinersAudienceExpandIcon;
	}
	
	public MobileElement getClearCTA() {
		return LearningActivity_btn_clearCTA;
	}
	
	public MobileElement getCloseRefiners() {
		return LearningActivity_btn_closeRefiner;
	}
	
	public MobileElement getRefinersPills() {
		return LearningActivity_btn_selectedRefinersPills;
	}
	
	public MobileElement getRefinersPills2() {
		return LearningActivity_btn_selectedRefinersPills2;
	}
	
	public MobileElement getRefinersPillsRemover() {
		return LearningActivity_btn_removeRefinersPills;
	}
	
	public MobileElement getClearAllRefinersPills() {
		return LearningActivity_btn_clearAllRefinersPills;
	}
	
	public MobileElement getCardImageCover() {
		return LearningActivity_lbl_cardCoverImage;
	}

	public MobileElement getCardTitle() {
		return LearningActivity_lbl_cardTitle;
	}

	public MobileElement getCardTitleType() {
		return LearningActivity_lbl_cardTitleType;
	}

	public MobileElement getCardTitleMapped() {
		return LearningActivity_lbl_cardTitleMapped;
	}

	public MobileElement getDownloadButton() {
		return LearningActivity_btn_download;
	}

	public MobileElement getPauseButton() {
		return LearningActivity_btn_pauseDownload;
	}

	public MobileElement getStopButton() {
		return LearningActivity_btn_stopDownload;
	}

	public MobileElement getDownloadProgressBar() {
		return LearningActivity_btn_downloadProgressBar;
	}
	
	public MobileElement getDownloadProgressPercentage() {
		return LearningActivity_btn_downloadProgressPercentage;
	}

	public MobileElement getAllowAccessPhoto() { 
		return LearningActivity_btn_allowAccessPhoto;
	}

	public MobileElement getNativePDF() { 
		return LearningActivity_lbl_nativePDF;
	}
	
/*********************124721***********************/
	
	public MobileElement getLearningResourceFa() { 
		return LearningActivity_lbl_learningResourceFa;
	}
	
	public void getLearningResourceFaDesc() {
		for (int i = 0; i <= 4; i++) {
			if (isElementPresent(LearningActivity_lbl_learningResourceFaDesc)) {
				break;
			} else {
				swipeDown();
			}
		}
	}
	
	public MobileElement getCategories() { 
		return LearningActivity_btn_categories;
	}
	
	public MobileElement getLearnMoreButton() { 
		return LearningActivity_btn_learnMore;
	}
	
	public MobileElement getListingPage() { 
		return LearningActivity_lbl_listingPage;
	}
	
	public MobileElement getLearningActivityCategory() { 
		return LearningActivity_btn_learningActivityNavigation;
	}
	
	public MobileElement getLearningTab() { 
		return LearningActivity_lbl_learningTab;
	}

	public MobileElement getLearningActivity() { 
		return LearningActivity_lbl_learningActivities;
	}

	/*********************Action***********************/

	public Boolean scrollAndTapOnLANavigation(){
		Boolean la = true;
			waitFor(3000);
			for(int i=0;i<10;i++) {
				if(isElementPresent(LearningActivityCard)) {
					swipeDown();
					break;
				}
				else{
					swipeDown();
				}
			}
			ClickOnMobileElement(LearningActivityCard);
		return la;
	}
	
	public void tapOnLACard() {
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			ClickOnMobileElement(LearningActivity_btn_allowAccessPhoto);
		}	
		else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			Assert.assertEquals(LearningActivity_lbl_nativePDF.isDisplayed(), true);
			if (isElementPresent(LearningActivity_btn_backFromPDF)) {
				ClickOnMobileElement(LearningActivity_btn_backFromPDF);
				}
			else if (isElementPresent(LearningActivity_btn_backFromPDF2)) {
				ClickOnMobileElement(LearningActivity_btn_backFromPDF2);
			}
		}
	}

	public String verifyNoOfLearningActivity(){
		String title = LearningActivity_txt_numberOfTitles.getText();
		System.out.println("No of Learning Activity displayed : " + title);
		return title;
	}

	public void tapOnRefinersIcon(){
		ClickOnMobileElement(LearningActivity_btn_refinersIcon);
	}

	public void tapOnRefinersExpandIcon(){
		swipeUp();
		ClickOnMobileElement(LearningActivity_btn_refinersSortExpandIcon);
		ClickOnMobileElement(LearningActivity_btn_refinersActivityExpandIcon);
		scrollToViewResults();
	}
	
	public void tapOnRefinersCollapseIcon(){
		swipeUp();
		ClickOnMobileElement(LearningActivity_btn_refinersSortCollapseIcon);
		ClickOnMobileElement(LearningActivity_btn_refinersActivityCollapseIcon);
		scrollToViewResults();
		ClickOnMobileElement(LearningActivity_btn_refinersAudienceCollapseIcon);
	}
	
	public void tapOnExpandCollapseIcon() {
		try {
			tapOnRefinersExpandIcon();
		}
		catch (Exception e) {
			tapOnRefinersCollapseIcon();
		}
	}

	public Boolean scrollToViewResults(){
		Boolean viewResults = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"View Results\"))"));
			if (isElementPresent(findElement)) {
				logger.info("View Results is available");
			} else {
				viewResults = false;
				logger.info("View Results is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
		}
		return viewResults;
	}
	

	public void tapOnViewResultsButton(){
		scrollToViewResults();
		ClickOnMobileElement(LearningActivity_btn_viewResultsCTA);
	}

	public void tapOnClearButton(){
		scrollToViewResults();
		ClickOnMobileElement(LearningActivity_btn_clearCTA);
	}

	public void tapOnSortOption(){
		ClickOnMobileElement(LearningActivity_btn_sortOption);
	}
	
	public void tapOnActivityOption(){
		ClickOnMobileElement(LearningActivity_btn_activityTypeOption);
	}
	
	public void tapOnAudienceOption(){
		ClickOnMobileElement(LearningActivity_btn_audienceLvlOption);
	}
	
	public Boolean scrollToLearningResourceFunActivities() {		
		Boolean categories = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(5000);
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"Activity\"))"));
			if (isElementPresent(findElement)) {
				logger.info("Learning activity is available");
			} else {
				categories = false;
				logger.info("Learning activity is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(1000);
			swipeDown();
			swipeDown();
			ClickOnMobileElement(LearningActivity_btn_learningActivityNavigation);
			}
		return categories;
	}
	
	public void getCategory() {
		isElementPresent(LearningActivity_btn_categories);
	}
	
	public void tapOnCategory() {
		scrollToLearningResourceFunActivities();
		try {
			ClickOnMobileElement(LearningActivity_btn_categories);
			} 
		catch (Exception e)  {
			logger.info("user should not be able to view Learn More Button");
		    }
		
	}
	
	public void getLearnMore() {
		scrollToLearningResourceFunActivities();
		try {
			if(isElementPresent(LearningActivity_btn_learnMore)) {
				logger.info("user should be able to view Learn More Button");
			}
			} 
		catch (Exception e)  {
			logger.info("user should not be able to view Learn More Button");
		    }
	}
	
	public void tapOnLearnMore(){
		try {
			getLearnMore();
			ClickOnMobileElement(LearningActivity_btn_learnMore);
			ClickOnMobileElement(details.getBackButton());
			} 
		catch (Exception e)  {
			logger.info("user should not be able to view Learn More Button");
		    }
	}
	
	public Boolean scrollToCloseRefiners() {
		Boolean close = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"REFINE\"))"));
			if (isElementPresent(findElement)) {
				logger.info("REFINE is available");
			} else {
				close = false;
				logger.info("REFINE is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			swipeUp();
			swipeUp();
		}
		return close;
		
	}
	
	
	
}
