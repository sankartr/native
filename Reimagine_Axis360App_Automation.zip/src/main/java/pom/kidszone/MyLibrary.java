package pom.kidszone;

import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.*;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class MyLibrary extends CommonActions {

    public MyLibrary(AppiumDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

    /****************** Locators ******************/

    @iOSXCUITFindBy(accessibility = "LIBRARY_FILTER_FORMAT")
    @AndroidFindBy(xpath = "//*[@resource-id='LIBRARY_FILTER_FORMAT']")
    private MobileElement Format_Dropdown;

    @iOSXCUITFindBy(accessibility = "Availability")
    @AndroidFindBy(xpath = "//*[@text='Availability']")
    public MobileElement lib_Availability;

    @iOSXCUITFindBy(accessibility = "more options")
    @AndroidFindBy(xpath = "//*[@resource-id='more options']")
    public MobileElement menuOption;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'ABT_Title_')])[2]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'ABT_Title_')])[2]")
	public MobileElement eAudioTitle;

	@iOSXCUITFindBy(xpath = "(//*[contains(@name,'EBT_Title')])[2]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'EBT_Title')])[2]")
	public MobileElement eBookTitle;

    @iOSXCUITFindBy(accessibility = "avail_now_option_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='avail_now_option_test_id']")
    public MobileElement lib_Available_option;

    // @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,'adp_card_image_card_VID')])[1]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"ItemCarousel\"]//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VID')])[1]")
    private MobileElement video_title_card;

    @iOSXCUITFindBy(accessibility = "filter_eBook_option_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_eBook_option_test_id']")
    private MobileElement eBook_DropDown;

    @iOSXCUITFindBy(accessibility = "filter_eAudio_option_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_eAudio_option_test_id']")
    private MobileElement eAudio__DropDown;

    @iOSXCUITFindBy(accessibility = "filter_vBook_option_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_vBook_option_test_id']")
    private MobileElement vBook_BottomDrawer;

    @iOSXCUITFindBy(accessibility = "filter_eBook_option_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_eBook_option_test_id']")
    private MobileElement eBook_BottomDrawer;

    @iOSXCUITFindBy(accessibility = "filter_eAudio_option_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_eAudio_option_test_id']")
    private MobileElement eAudio_BottomDrawer;

    @iOSXCUITFindBy(accessibility = "filter_vBook_option_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_vBook_option_test_id']")
    private MobileElement vBook_BottomDrawer_selected;

    @iOSXCUITFindBy(accessibility = "filter_video_option_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_video_option_test_id']")
    private MobileElement video_BottomDrawer;

    @iOSXCUITFindBy(accessibility = "filter_video_option_test_id")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_video_option_test_id']")
    private MobileElement video_BottomDrawer_selected;

    @iOSXCUITFindBy(xpath = "(//*[@name='third_party_see_all_link_VBOOKS'])[1]")
    @AndroidFindBy(xpath = "(//*[@resource-id='third_party_see_all_link_VBOOKS'])[1]")
    private MobileElement vBook_Carousel_title;

    @iOSXCUITFindBy(xpath = "//*[@label='Popular Videobooks see all']")
    @AndroidFindBy(xpath = "(//*[@resource-id='Popular Videobooks see all'])")
    private MobileElement vBook_Carousel_title1;

    @iOSXCUITFindBy(accessibility = "header_title")
    @AndroidFindBy(xpath = "//*[@resource-id='header_title']")
    private MobileElement eAudio_Carousel;
    @iOSXCUITFindBy(xpath = "//*[@name ='WidgetsCarousel']//*[@name='third_party_header_VBOOKS']")
    @AndroidFindBy(xpath = "//*[@resource-id='WidgetsCarousel']//*[@resource-id='third_party_header_VBOOKS']")
    private MobileElement vBook_Widget_Carousel_title;

    @iOSXCUITFindBy(xpath = "//*[@label='Checkers Library TV see all']")
    @AndroidFindBy(xpath = "//*[@content-desc='Checkers Library TV see all, ']")
    private MobileElement checkersLibraryTVSeeAll;

    @iOSXCUITFindBy(xpath = "//*[@label='Videobooks see all']")
    @AndroidFindBy(xpath = "//*[@content-desc='Videobooks see all, ']")
    private MobileElement videoBooksSeeAll;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'e Book')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'e Book')]")
    private MobileElement eBook_Carousel_title;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Audio Book')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Audio Book')]")
    private MobileElement eAudio_Carousel_title;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'eBook/Video/Vbook')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'eBook/Video/Vbook')]")
    private MobileElement checkout_limit;
    @iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_image_card_VBK')]")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_image_card_VBK')]")
    private MobileElement vBook_Titles;

    @iOSXCUITFindBy(accessibility = "ItemCarousel")
    @AndroidFindBy(xpath = "//*[@resource-id='ItemCarousel']")
    private MobileElement videoItemCarouselInTier1;

    // @iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_image_card_VID')]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name='ItemCarousel'])[1]/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeScrollView/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Videos')]")
    private MobileElement video_Titles;

    // @iOSXCUITFindBy(xpath = "(//*[contains(@name,'adp_card_category_card')])[1]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='CategoryCarousel']//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_category_card')])[1]")
    private MobileElement vBook_Diff_Publishers;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='CategoryCarousel']//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
    // @iOSXCUITFindBy(xpath = "(//*[contains(@name,'adp_card_category_card')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_category_card')])[1]")
    private MobileElement videos_Diff_Publishers;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"third_party_header_VIDEOS\"])[1]")
    @AndroidFindBy(xpath = "(//*[@resource-id='third_party_header_VIDEOS'])[1]")
    private MobileElement Video_Carousel_title;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"FEATURE_CURATED_LIST_TITLE\"])[1]")
    @AndroidFindBy(xpath = "(//*[@resource-id='FEATURE_CURATED_LIST_TITLE'])[1]")
    private MobileElement eBook_Carousel;

    @iOSXCUITFindBy(accessibility = "txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
    private MobileElement eBook_Title_Details;

    @iOSXCUITFindBy(accessibility = "tier_3_txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='tier_3_txtTitle']")
    private MobileElement Video_Title_Details;

    @iOSXCUITFindBy(accessibility = "txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
    private MobileElement vBook_Title_Details;
    @iOSXCUITFindBy(accessibility = "ratingCTATestId")
    @AndroidFindBy(xpath = "//*[@resource-id='ratingCTATestId']")
    private MobileElement eBook_Star_Rating;

    @iOSXCUITFindBy(accessibility = "loc_txtRatingOptionFive")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_txtRatingOptionFive']")
    private MobileElement eBook_5Star_Rating;
    @iOSXCUITFindBy(accessibility = "averageRatingTestId")
    @AndroidFindBy(xpath = "//*[@resource-id='averageRatingTestId']")
    private MobileElement eBook_Star_Rating_Count;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Reviews')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'Reviews')]")
    private MobileElement eBook_Reviews;

    @iOSXCUITFindBy(accessibility = "loc_txtDetailsCountReview")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_txtDetailsCountReview']")
    private MobileElement eBook_Reviews_Count;

    @iOSXCUITFindBy(accessibility = "loc_btnDetailsWriteReview")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_btnDetailsWriteReview']")
    private MobileElement eBook_First_Review;

    @iOSXCUITFindBy(accessibility = "loc_txtReviewField")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_txtReviewField']")
    private MobileElement eBook_Review_Field;
    @iOSXCUITFindBy(xpath = "//*[contains(@label,'How many stars would you like to rate')]")
    @AndroidFindBy(xpath = "//*[contains(@text,'How many stars would you like to rate')]")
    private MobileElement eBook_Star_RatingWindow;

    @iOSXCUITFindBy(xpath = "//*[@name ='WidgetsCarousel']//*[@name='third_party_header_VIDEOS']")
    @AndroidFindBy(xpath = "//*[@resource-id='WidgetsCarousel']//*[@resource-id='third_party_header_VIDEOS']")
    private MobileElement Video_Widget_Carousel_title;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"third_party_see_all_link_VBOOKS\"])[2]")
    @AndroidFindBy(xpath = "(//*[@resource-id='third_party_header_VIDEOS'])[1]")
    private MobileElement Vbook_Widget_Carousel_title;

    @iOSXCUITFindBy(accessibility = "tier_1_txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id=\"tier_1_txtTitle\"]")
    private MobileElement Tier1_listing_page;

    // @iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_image_card_VID')]")
    // @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'Vertical scroll bar, 2 pages']/preceding-sibling::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"CategoryCarousel\"]//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Video')]")
    private MobileElement video_titles_page;

    @iOSXCUITFindBy(accessibility = "Dummy_video_primary_CTA")
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Play\"])[1]")
    private MobileElement video_primary_CTA;

    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'adp_card_image_card_Newspaper')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_Newspaper')])[1]")
    private MobileElement Newspaper_tier3_detail_page;

    @iOSXCUITFindBy(accessibility = "Dummy_tier3_primary_CTA")
    @AndroidFindBy(xpath = "//*[@text='Dummy_tier3_primary_CTA']")
    private MobileElement tier3_primary_CTA;

    @iOSXCUITFindBy(accessibility = "Dummy_tier3_secondary_CTA")
    @AndroidFindBy(xpath = "//*[@text='Drop_down']")
    private MobileElement tier3_secondary_CTA;

    @iOSXCUITFindBy(accessibility = "view_wishlist")
    @AndroidFindBy(xpath = "//*[@text='view_wishlist']")
    private MobileElement view_wishlist;

    @iOSXCUITFindBy(accessibility = "view_hold")
    @AndroidFindBy(xpath = "//*[@text='view_hold']")
    private MobileElement view_hold;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'adp_card_image_card_VBK')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Vbook')]/parent::android.view.ViewGroup/parent::android.view.ViewGroup")
    private MobileElement vBookCoverImage;

    @iOSXCUITFindBy(accessibility = "Dummy_coverImage")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Video')]/parent::android.view.ViewGroup/parent::android.view.ViewGroup")
    private MobileElement videoCoverImage;

    // @iOSXCUITFindBy(xpath = "//*[contains(@id,'adp_card_image_card_VBK')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='ItemCarousel']//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'adp_card_image_card_VBK')]")
    private MobileElement vBook_title;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='ItemCarousel']//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[@resource-id='adp_vbk_card_title_text_bottom']")
    private MobileElement firstVBook;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"third_party_see_all_link_VBOOKS\"]/parent::XCUIElementTypeOther/parent::XCUIElementTypeStaticText/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther)[1]")
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Checkout\"])[1]")
    private MobileElement primary_CTA1;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"third_party_see_all_link_VIDEOS\"]/parent::XCUIElementTypeOther/parent::XCUIElementTypeStaticText/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther)[1]")
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Play\"])[1]")
    private MobileElement primary_CTA2;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"third_party_see_all_link_VBOOKS\"]/parent::XCUIElementTypeOther/parent::XCUIElementTypeStaticText/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther)[1]")
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Resume\"])[1]")
    private MobileElement primary_CTA3;

    @iOSXCUITFindBy(accessibility = "adp_card_title_details_author")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc='AUTHOR']")
    private MobileElement tier3_details_page;

    @iOSXCUITFindBy(accessibility = "Dummy_tier3_PrimaryCTA_Checkout")
    @AndroidFindBy(xpath = "//*[@text='Dummy_tier3_PrimaryCTA_Checkout']")
    private MobileElement tier3_PrimaryCTA_Checkout;

    @iOSXCUITFindBy(accessibility = "Dummy_tier3_PrimaryCTA_Checkout")
    @AndroidFindBy(xpath = "//*[@text='Dummy_tier3_PrimaryCTA_Checkout']")
    private MobileElement tier3_SecondaryCTA;

    // @iOSXCUITFindBy(xpath = "(//*[contains(@name,'adp_card_category_card')])[1]")

    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'third_party_see_all_link_VIDEOS')])[2]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'third_party_see_all_link_VIDEOS')])[2]")
    private MobileElement popularVideosSeeAll;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='CategoryCarousel']//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_category_card')])[1]")
    private MobileElement video_Publisher;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='WidgetsCarousel']//XCUIElementTypeStaticText[@name='third_party_header_VBOOKS']")
    @AndroidFindBy(xpath = "//*[@resource-id='WidgetsCarousel']//*[@resource-id='third_party_header_VBOOKS']")
    private MobileElement vBook_Publisher;

    // @iOSXCUITFindBy(xpath = "(//*[contains(@name,'adp_card_image_card_VBK')])[1]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='ItemCarousel']//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VBK')])[1]")
    private MobileElement vBook_title_card;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'third_party_see_all_link_VIDEOS')]")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'third_party_see_all_link_VIDEOS')]")
    private MobileElement video_Carousel_SeeAll;

    @iOSXCUITFindBy(accessibility = "Dummy_Video_Carousel_name")
    @AndroidFindBy(xpath = "//*[@resource-id='Dummy_Video_Carousel_name']")
    private MobileElement video_Carousel_Format;

    @iOSXCUITFindBy(accessibility = "tier_3_txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id=\"tier_3_txtTitle\"]")
    private MobileElement tier3Title;

    @iOSXCUITFindBy(accessibility = "txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
    private MobileElement vBookTier3TitleIcon;

    @iOSXCUITFindBy(accessibility = "txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
    private MobileElement videoTier3TitleIcon;

    @iOSXCUITFindBy(accessibility = "txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='WidgetsCarousel']")
    private MobileElement vBookWidget;

    @iOSXCUITFindBy(accessibility = "txtTitle")
    @AndroidFindBy(xpath = "//*[@resource-id='WidgetsCarousel']")
    private MobileElement videoWidget;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"third_party_see_all_link_PRESSRDR\"])[1]")
    @AndroidFindBy(xpath = "(//*[@resource-id='adp_card_title_text_bottom'])[1]")
    private MobileElement firstMagazine;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"third_party_see_all_link_PRESSRDR\"])[1]")
    @AndroidFindBy(xpath = "(//*[@resource-id='third_party_see_all_link_PRESSRDR'])[1]")
    private MobileElement newPaperMagazineTitleCard;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"third_party_see_all_link_PRESSRDR\"])[1]")
    @AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_PRESSRDR']")
    private MobileElement newPaperMagazineSeeAll;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"third_party_see_all_link_PRESSRDR\"])[1]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='adp_card_title_text_bottom']")
    private MobileElement newPaperMagazineTitleTxtBottom;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"third_party_see_all_link_PRESSRDR\"])[1]")
    @AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_PRESSRDR']")
    private MobileElement newPaperMagazineSearchSeeAll;

    @iOSXCUITFindBy(accessibility = "filter_cta")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Refiner.button.')]")
    private MobileElement tier2newPaperMagazineRefiner;

    @iOSXCUITFindBy(accessibility = "filter_cta")
    @AndroidFindBy(xpath = "//*[@resource-id='filter_cta']")
    private MobileElement tier2newPaperMagazineSearchRefiner;

    @iOSXCUITFindBy(accessibility = "viewCheckoutHistory")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Display Checkout History')]")
    private MobileElement displayCheckoutHistory;

    @iOSXCUITFindBy(accessibility = "viewCheckoutHistory")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Display Checkout History Checkbox')]")
    private MobileElement displayCheckoutHistoryCheckbox;

    @iOSXCUITFindBy(accessibility = "ALERT_TITLE")
    @AndroidFindBy(xpath = "//*[@resource-id='ALERT_TITLE']")
    private MobileElement displayCheckoutPopupText;

    @iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
    @AndroidFindBy(xpath = "//*[@resource-id='ALERT_MESSAGE']")
    private MobileElement displayCheckoutPopupContent;

    @iOSXCUITFindBy(accessibility = "history_disabled_alert_yes")
    @AndroidFindBy(xpath = "//*[@text='Disable']")
    private MobileElement displayCheckoutPopupDisable;

    @iOSXCUITFindBy(accessibility = "history_disabled_alert_no")
    @AndroidFindBy(xpath = "//*[@text='Cancel']")
    private MobileElement displayCheckoutPopupCancel;

    @iOSXCUITFindBy(accessibility = "Preferences")
    @AndroidFindBy(xpath = "//*[@resource-id='Preferences']")
    private MobileElement menuListPreferences;

    @iOSXCUITFindBy(accessibility = "deRegisterDevice")
    @AndroidFindBy(xpath = "//*[@resource-id='deRegisterDevice']")
    private MobileElement deregisterDevice;

    @iOSXCUITFindBy(xpath = "//*[@label='Deregister']")
    @AndroidFindBy(xpath = "//*[@text='Deregister']")
    private MobileElement deregisterPopupYes;

    @iOSXCUITFindBy(accessibility = "parentail_disabled_alert_no")
    @AndroidFindBy(xpath = "//*[@text='No']")
    private MobileElement deregisterPopupNo;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Preferences')]")
    @AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
    private MobileElement devicePreferencesHeading;

    @iOSXCUITFindBy(accessibility = "Format")
    @AndroidFindBy(xpath = "//*[@text='Format']")
    private MobileElement libFormatHeading;

    @iOSXCUITFindBy(accessibility = "FEATURE_CURATED_LIST_LINK")
    @AndroidFindBy(xpath = "//*[@resource-id='FEATURE_CURATED_LIST_LINK']")
    private MobileElement ebookFeatureSeeAll;

    @iOSXCUITFindBy(accessibility = "Publications heading")
    @AndroidFindBy(xpath = "//*[@resource-id='Publications heading']")
    private MobileElement publicationsSectionInTier2Screen;

    @iOSXCUITFindBy(xpath = "//*[contains(@label,'Newspapers Heading')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Newspapers Heading')]")
    private MobileElement newspaperSectionInTier2Screen;

    @iOSXCUITFindBy(accessibility = "Magazines heading")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Magazines Heading, \"]")
    private MobileElement magazineSectionInTier2Screen;

    @iOSXCUITFindBy(accessibility = "BROWSE")
    @AndroidFindBy(xpath = "//*[@resource-id='BROWSE']")
    private MobileElement libraryBrowse;

    @iOSXCUITFindBy(accessibility = "//*[@label='Young Adult Fiction']")
    @AndroidFindBy(xpath = "//*[@text='Young Adult Fiction']")
    private MobileElement browseYoungAdultFiction;

    @iOSXCUITFindBy(accessibility = "REFINE_ICON")
    @AndroidFindBy(xpath = "//*[@resource-id='REFINE_ICON']")
    private MobileElement browseRefinerBTN;

    @iOSXCUITFindBy(accessibility = "SORT_LIST_TOGGLE_outer")
    @AndroidFindBy(xpath = "//*[@resource-id='SORT_LIST_TOGGLE_outer']")
    private MobileElement sortByRefiner;

    @iOSXCUITFindBy(accessibility = "Menu")
    @AndroidFindBy(xpath = "//*[@resource-id='MENU']")
    private MobileElement menuBottom;

    @iOSXCUITFindBy(accessibility = "more_LIBRARY_ADVANCE_SEARCH_BUTTON")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Advanced Search, \"]/android.widget.TextView")
    private MobileElement advancedSearch;

    @iOSXCUITFindBy(accessibility = "more_LIBRARY_ADVANCE_SEARCH_BUTTON")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'LIBRARY_ADVANCE_SEARCH_BUTTON')]")
    private MobileElement advancedSearchLib;


    // ==================================================================


    @iOSXCUITFindBy(accessibility = "My Library")
    @AndroidFindBy(xpath = "//*[@resource-id='MYLIBRARY']")
    private MobileElement menu_btn_footerlibrary;

    @iOSXCUITFindBy(accessibility = "MYLIBRARY")
    @AndroidFindBy(xpath = "//*[@text='Library']")
    private MobileElement menu_btn_footerlibrary1;

    @iOSXCUITFindBy(accessibility = "header")
    @AndroidFindBy(id = "header")
    private MobileElement myLib_lbl_Header;

    @iOSXCUITFindBy(accessibility = "header_title")
    @AndroidFindBy(xpath = "//*[@text='Always Available']")
    private MobileElement myLib_lbl_alwaysAvlHeader;

    @iOSXCUITFindBy(accessibility = "description")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[2]/android.widget.TextView")
    private MobileElement myLib_lbl_alwaysAvlDesc;

    @iOSXCUITFindBy(accessibility = "MyLibrary")
    @AndroidFindBy(xpath = "//*[@text='ALWAYS AVAILABLE']/following::android.widget.HorizontalScrollView[1]/android.view.ViewGroup/android.view.ViewGroup")
    private List<MobileElement> myLib_title_alwaysAvlTitleList;

    @iOSXCUITFindBy(accessibility = "link")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"SEE ALL Always Available\"]")
    private MobileElement myLib_btn_alwaysavlViewAll;

    @iOSXCUITFindBy(accessibility = "header_title")
    @AndroidFindBy(id = "pageNotDeliverec")
    private MobileElement myLib_lbl_alwaysAvlListingPgHeader;

    @iOSXCUITFindBy(accessibility = "FEATURE_READING_PROGRAM_TITLE")
    @AndroidFindBy(xpath = "//*[@resource-id='FEATURE_READING_PROGRAM_TITLE']")
    private MobileElement myLib_lbl_FeatureTitle;

    @iOSXCUITFindBy(accessibility = "View_My_Interests")
    @AndroidFindBy(xpath = "//*[@resource-id='View_My_Interests']")
    private MobileElement mylib_lbl_interestSurvey;

    @iOSXCUITFindBy(accessibility = "link")
    @AndroidFindBy(xpath = "//*[@resource-id='link']")
    private MobileElement Feature_curated_seeall;

    @iOSXCUITFindBy(accessibility = "MENU_ITEM_NEW")
    @AndroidFindBy(xpath = "//*[@resource-id='MENU_ITEM_NEW']")
    private MobileElement mylib_btn_newQuickAccess;

    @iOSXCUITFindBy(accessibility = "MENU_ITEM_TRENDING")
    @AndroidFindBy(xpath = "//*[@resource-id='MENU_ITEM_TRENDING']")
    private MobileElement mylib_btn_trendingQuickAccess;

    @iOSXCUITFindBy(accessibility = "MENU_ITEM_SURPRISE_ME")
    @AndroidFindBy(xpath = "//*[@resource-id='MENU_ITEM_SURPRISE_ME']")
    private MobileElement mylib_btn_surpriseMeQuickAccess;

    @iOSXCUITFindBy(accessibility = "MYSHELF")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'MYSHELF')]")
    private MobileElement myshelf;

    @iOSXCUITFindBy(accessibility = "MYLIBRARY")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'MYLIBRARY')]")
    private MobileElement library;

    @iOSXCUITFindBy(accessibility = "BROWSE")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'BROWSE')]")
    private MobileElement browse;
    @iOSXCUITFindBy(accessibility = "PROGRAMS")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'PROGRAMS')]")
    private MobileElement programs;
    @iOSXCUITFindBy(accessibility = "MENU")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'MENU')]")
    private MobileElement menu;
    @iOSXCUITFindBy(xpath = "(//*[contains(@name,'third_party_see_all_link_PRESSRDR')])[1]")
    @AndroidFindBy(xpath = "//*[@resource-id='third_party_see_all_link_PRESSRDR']")
    private MobileElement thirdparty_SeeAlllink;

    @iOSXCUITFindBy(accessibility = "REFINE_ICON")
    @AndroidFindBy(xpath = "//*[@resource-id='REFINE_ICON']")
    private MobileElement browseRefiner;

    @iOSXCUITFindBy(accessibility = "loc_btnLearningLearnMore")
    @AndroidFindBy(xpath = "//*[@resource-id='loc_btnLearningLearnMore']")
    private MobileElement learningMore;

    @iOSXCUITFindBy(accessibility = "availableActivityTextTestId")
    @AndroidFindBy(xpath = "//*[@resource-id='availableActivityTextTestId']")
    private MobileElement header_learnMore;

    @iOSXCUITFindBy(accessibility = "btnBackIcon")
    @AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
    private MobileElement profile_icon;

    @iOSXCUITFindBy(xpath = "(//*[contains(@id,'EBT_Title')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'EBT_Title')])[1]")
    private MobileElement eBook_title;

    @iOSXCUITFindBy(accessibility = "Details")
    @AndroidFindBy(xpath = "//*[@resource-id='Details']")
    private MobileElement eBook_Details;
    @iOSXCUITFindBy(xpath = "(//*[contains(@id,'ABT_Title')])[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'ABT_Title')])[1]")
    private MobileElement eAudio_title;

    // @iOSXCUITFindBy(xpath = "(//*[contains(@id,'adp_card_image_card_VID')])[1]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='Vertical scroll bar, 2 pages']/preceding-sibling::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'adp_card_image_card_VID')])[1]")
    private MobileElement Video_title;

    @iOSXCUITFindBy(accessibility = "Boundless Logo")
    @AndroidFindBy(xpath = "//*[@resource-id='Boundless Logo']")
    private MobileElement boundlessLogo;

    @iOSXCUITFindBy(accessibility = "book_of_the_section")
    @AndroidFindBy(xpath = "//*[@resource-id='book_of_the_section']")
    private MobileElement bookOfMonthWidget;

    @iOSXCUITFindBy(accessibility = "book_of_the_month_header")
    @AndroidFindBy(xpath = "//*[@resource-id='book_of_the_month_header']")
    private MobileElement bookOfMonthHeading;

    @iOSXCUITFindBy(accessibility = "book_of_the_month_author")
    @AndroidFindBy(xpath = "//*[@resource-id='book_of_the_month_author']")
    private MobileElement bookOfMonthDescription;

    @iOSXCUITFindBy(xpath = "(//*[@name='stack_title_touch_test_id'])[1]")
    @AndroidFindBy(xpath = "(//*[@resource-id='stack_title_touch_test_id'])[1]")
    private MobileElement bookOfMonthTitle;

    @iOSXCUITFindBy(xpath = "//*[contains(@name,'Search')]")
    @AndroidFindBy(xpath = "//*[contains(@resource-id,'Search')]")
    private MobileElement titleDetailsPage;

    @iOSXCUITFindBy(xpath = "//*[@name='stack_title_touch_test_id']")
    @AndroidFindBy(xpath = "//*[@resource-id='stack_title_touch_test_id']")
    private List<MobileElement> bookOfTheMonthTitlesList;

    @iOSXCUITFindBy(xpath = "//*[@name='loc_btnWishlist']")
    @AndroidFindBy(xpath = "dummy")
    private MobileElement wishlistCta;

    @iOSXCUITFindBy(xpath = "//*[@name='loc_btnShare']")
    @AndroidFindBy(xpath = "dummy")
    private MobileElement shareCTA;

    ////////////////////***********Implemention*******************

    public MobileElement getHeader_learnMore() {
        return header_learnMore;
    }

    public MobileElement getThirdparty_SeeAlllink() {
        return thirdparty_SeeAlllink;
    }

    public MobileElement getMyshelf() {
        return myshelf;
    }

    public MobileElement getLibrary() {
        return library;
    }

    public MobileElement getBrowse() {
        return browse;
    }

    public MobileElement getPrograms() {
        return programs;
    }

    public MobileElement getMenu() {
        return menu;
    }

    public MobileElement getMyLib_btn_alwaysavlViewAll() {
        return myLib_btn_alwaysavlViewAll;
    }

    public MobileElement getMylib_btn_newQuickAccess() {
        return mylib_btn_newQuickAccess;
    }

    public MobileElement getMylib_btn_trendingQuickAccess() {
        return mylib_btn_trendingQuickAccess;
    }

    public MobileElement getMylib_btn_surpriseMeQuickAccess() {
        return mylib_btn_surpriseMeQuickAccess;
    }

    public MobileElement getMylib_lbl_interestSurvey() {
        return mylib_lbl_interestSurvey;
    }

    public MobileElement getMyLib_lbl_FeatureTitle() {
        return myLib_lbl_FeatureTitle;
    }

    public void clickCheckersLibraryTVSeeAll() {
        for (int i = 0; i <= 10; i++) {
            if (isElementPresent(checkersLibraryTVSeeAll)) {
                break;
            } else {
                swipeDown();
                swipeDown();
            }
        }
        ClickOnMobileElement(checkersLibraryTVSeeAll);
    }

public void clickVideoBooksSeeAll(){
    for (int i = 0; i <= 30; i++) {
        if (isElementPresent(videoBooksSeeAll)) {
            break;
        } else {
            swipeDown();
        }
    }
    ClickOnMobileElement(videoBooksSeeAll);
}

    public MobileElement getMenu_btn_footerlibrary() {
        return menu_btn_footerlibrary;
    }

    public MobileElement getMyLib_lbl_alwaysAvlHeader() {
        return myLib_lbl_alwaysAvlHeader;
    }

    public MobileElement getMyLib_lbl_Header() {
        return myLib_lbl_Header;
    }

    public MobileElement getMyLib_lbl_alwaysAvlDesc() {
        return myLib_lbl_alwaysAvlDesc;
    }

    public List<MobileElement> getMyLib_title_alwaysAvlTitleList() {
        return myLib_title_alwaysAvlTitleList;
    }

    public MobileElement getMyLib_lbl_alwaysAvlListingPgHeader() {
        return myLib_lbl_alwaysAvlListingPgHeader;
    }

    public MobileElement getMenu_btn_footerlibrary1() {
        return menu_btn_footerlibrary1;
    }

    /********************************** Methods **************************/


    public MobileElement check_eBook_DropDown() {
        return eBook_DropDown;
    }

    public MobileElement geteAudio_Carousel_title() {
        return eAudio_Carousel_title;
    }

    public MobileElement geteBook_Carousel_title() {
        return eBook_Carousel_title;
    }

    public MobileElement check_eAudio__DropDown() {
        return eAudio__DropDown;
    }

    public MobileElement check_vBook_BottomDrawer() {
        return vBook_BottomDrawer;
    }

    public MobileElement check_Video_BottomDrawer() {
        return video_BottomDrawer;
    }

    public MobileElement getPopularVideosSeeAll(){return popularVideosSeeAll;}

    public MobileElement video_Publisher() {
        return video_Publisher;
    }

    public MobileElement vBook_Publisher() {
        return vBook_Publisher;
    }

    public MobileElement video_Carousel_SeeAll() {
        return video_Carousel_SeeAll;
    }

    public MobileElement video_Carousel_Format() {
        return video_Carousel_Format;
    }

    public MobileElement Video_Carousel() {
        return Video_Carousel_title;
    }

    public MobileElement eBook_Carousel() {
        return eBook_Carousel;
    }

    public MobileElement eBook_Title_Details() {
        return eBook_Title_Details;
    }

    public MobileElement get_Video_Title_Details() {
        return Video_Title_Details;
    }
    public MobileElement get_vBook_Title_Details() {
        return vBook_Title_Details;
    }
    public MobileElement get_eBook_Star_Rating() {
        return eBook_Star_Rating;
    }

    public MobileElement get_eBook_Star_Rating_Count() {
        return eBook_Star_Rating_Count;
    }

    public MobileElement eBook_Reviews() {
        return eBook_Reviews;
    }

    public MobileElement eBook_Reviews_Count() {
        return eBook_Reviews_Count;
    }

    public MobileElement eBook_First_Review() {
        return eBook_First_Review;
    }

    public MobileElement eBook_Star_RatingWindow() {
        return eBook_Star_RatingWindow;
    }

    public MobileElement Video_Widget_Carousel() {
        return Video_Widget_Carousel_title;
    }

    public MobileElement Vbook_Widget_Carousel() {
        return Vbook_Widget_Carousel_title;
    }

    public MobileElement vBook_Carousel() {
        return vBook_Carousel_title;
    }

    public MobileElement vBook_Carousel1() {
        return vBook_Carousel_title1;
    }

    public MobileElement vBook_Diff_Publishers() {
        return vBook_Diff_Publishers;
    }

    public MobileElement eAudio_Carousel() {
        return eAudio_Carousel;
    }

    public MobileElement vBook_Widget_Carousel() {
        return vBook_Widget_Carousel_title;
    }

    public MobileElement Video_Titles() {
        return video_Titles;
    }

    public MobileElement getCheckout_limit() {
        return checkout_limit;
    }

    public MobileElement vBook_Titles() {
        return vBook_Titles;
    }

    public MobileElement checkVideoItemCarouselInTier1() {
        return videoItemCarouselInTier1;
    }

    public MobileElement check_vBook_Diff_Publishers() {
        return vBook_Diff_Publishers;
    }

    public void clickvBookPublisher() {
        ClickOnMobileElement(vBook_Diff_Publishers);
    }

    public MobileElement check_videos_Diff_Publishers() {
        return videos_Diff_Publishers;
    }

    public MobileElement Tier1_listing_page() {
        return Tier1_listing_page;
    }

    public MobileElement video_titles_page() {
        return video_titles_page;
    }

    public MobileElement video_primary_CTA() {
        return video_primary_CTA;
    }

    public MobileElement tier3_detail_page() {
        return Newspaper_tier3_detail_page;
    }

    public MobileElement tier3_primary_CTA() {
        return tier3_primary_CTA;
    }

    public MobileElement tier3_secondary_CTA() {
        return tier3_secondary_CTA;
    }

    public MobileElement view_wishlist() {
        return view_wishlist;
    }

    public MobileElement view_hold() {
        return view_hold;
    }

    public MobileElement checkvBookCoverImage() {
        return vBookCoverImage;
    }

    public MobileElement checkVideoCoverImage() {
        return videoCoverImage;
    }

    public MobileElement check_vBook_title() {
        return vBook_title;
    }

    public MobileElement getFirstVBook(){return firstVBook;}

    public MobileElement checkPrimary_CTA1() {
        return primary_CTA1;
    }

    public MobileElement checkPrimary_CTA2() {
        return primary_CTA2;
    }

    public MobileElement checkPrimary_CTA3() {
        return primary_CTA3;
    }

    public MobileElement check_Tier3_details_page() {
        return tier3_details_page;
    }

    public MobileElement check_Tier3_PrimaryCTA_Checkout() {
        return tier3_PrimaryCTA_Checkout;
    }

    public MobileElement check_Tier3_SecondaryCTA() {
        return tier3_SecondaryCTA;
    }

    public MobileElement displayCheckoutPopupText() {
        return displayCheckoutPopupText;
    }

    public MobileElement displayCheckoutPopupContent() {
        return displayCheckoutPopupContent;
    }

    public MobileElement displayCheckoutPopupDisable() {
        return displayCheckoutPopupDisable;
    }

    public MobileElement displayCheckoutPopupCancel() {
        return displayCheckoutPopupCancel;
    }

    public void clickFormat_Dropdown() {
        ClickOnMobileElement(Format_Dropdown);
    }

    public void clickAvailabilityDropDown() {
        ClickOnMobileElement(lib_Availability);
    }

    public void clickAvailableOption() {
        ClickOnMobileElement(lib_Available_option);
    }

    public void click_eBook_Star_Rating() {
        ClickOnMobileElement(eBook_Star_Rating);
    }

    public void click_eBook_Review() {
        ClickOnMobileElement(eBook_First_Review);
    }
    public void enter_eBook_Review() {
        waitFor(2000);
        ClickOnMobileElement(eBook_Review_Field);
        SendKeysOnMobileElement(eBook_Review_Field, "My Review");
        hideMobileKeyboard();
    }

    public void click_eBook_5StarRating() {
        ClickOnMobileElement(eBook_5Star_Rating);
    }

    public void navigatetoLearnMore() {
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(learningMore)) {
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(learningMore);
    }

    public void naivatetoTier3Page() {
        ClickOnMobileElement(Newspaper_tier3_detail_page);
    }

    public void click_video_title_card() {
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(video_title_card)) {
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(video_title_card);
    }

    public void click_eBook_BottomDrawer() {
        if (isElementPresent(eBook_BottomDrawer)) {
            ClickOnMobileElement(eBook_BottomDrawer);
        }
    }

    public void click_vBook_BottomDrawer() {
        if (isElementPresent(vBook_BottomDrawer)) {
            ClickOnMobileElement(vBook_BottomDrawer);
        } else {
            ClickOnMobileElement(vBook_BottomDrawer_selected);
        }
    }

    public void click_eAudio_BootomDrawer() {
        ClickOnMobileElement(eAudio__DropDown);
    }

    public void click_Video_BottomDrawer() {
        if (isElementPresent(video_BottomDrawer)) {
            ClickOnMobileElement(video_BottomDrawer);
        } else {
            ClickOnMobileElement(video_BottomDrawer_selected);
        }
    }

    public void click_video_publisher() {
        ClickOnMobileElement(video_Publisher);
    }

    public void click_vBook_title_card() {
        waitFor(2000);
        ClickOnMobileElement(vBook_title_card);
    }

    public MobileElement verifyTier3Title() {
        return tier3Title;
    }

    public MobileElement verifyvBookTier3TitleIcon() {
        return vBookTier3TitleIcon;
    }

    public MobileElement verifyVideoTier3TitleIcon() {
        return videoTier3TitleIcon;
    }

    public MobileElement verifyvBookWidget() {
        return vBookWidget;
    }

    public MobileElement verifyVideoWidget() {
        return videoWidget;
    }

    public MobileElement display_Checkout_History() {
        return displayCheckoutHistory;

    }

    public void navigatetoLibraryPage() {
        if (isElementPresent(eBook_Carousel_title)) {
            ClickOnMobileElement(eBook_Carousel_title);
        }

    }

    public void clickNewsPaperMagazine() {
        for (int i = 0; i <= 6; i++) {
            if (isElementPresent(firstMagazine)) {
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(newPaperMagazineTitleCard);
    }

    public void clickNewsPaperMagazineSeeAll() {
        for (int i = 0; i <= 9; i++) {
            if (isElementPresent(newPaperMagazineSeeAll)) {
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(newPaperMagazineSeeAll);
    }

    public void clickNewsPaperMagazineSearchSeeAll() {
        for (int i = 0; i <= 6; i++) {
            if (isElementPresent(newPaperMagazineSearchSeeAll)) {
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(newPaperMagazineSearchSeeAll);
    }

    public void clickNewsPaperMagazineRefiner() {
        ClickOnMobileElement(tier2newPaperMagazineRefiner);
    }

    public void clickNewsPaperMagazineSearchRefiner() {
        ClickOnMobileElement(tier2newPaperMagazineSearchRefiner);
    }

    public void displayCheckoutHistory() {
        for (int i = 0; i <= 4; i++) {
            if (isElementPresent(displayCheckoutHistory)) {
                break;
            } else {
                swipeDown();
            }
        }
    }

    public void clickDisplayCheckoutHistoryCheckbox() {
        ClickOnMobileElement(displayCheckoutHistoryCheckbox);
    }

    public void clickPreferences() {
        ClickOnMobileElement(menuListPreferences);
    }

    public void clickDeregisterDevice() {
        ClickOnMobileElement(deregisterDevice);
    }

    public MobileElement deregisterDevice() {
        return deregisterDevice;

    }

    public MobileElement deregisterWarningPopupContent() {
        return displayCheckoutPopupContent;
    }

    public MobileElement deregisterWarningPopupYes() {
        return deregisterPopupYes;
    }

    public MobileElement deregisterWarningPopupNo() {
        return deregisterPopupNo;
    }

    public void clickDeregisterPopupYes() {
        ClickOnMobileElement(deregisterPopupYes);
    }

    public void clickDeregisterPopupNo() {
        ClickOnMobileElement(deregisterPopupNo);
    }

    public MobileElement devicePreferencesHeading() {
        return devicePreferencesHeading;
    }

    public MobileElement libFormat() {
        return libFormatHeading;
    }

    public void clickEbookSeeAll() {
        ClickOnMobileElement(ebookFeatureSeeAll);
    }

    public MobileElement verifyPublicationsSectionInTier2Screen() {
        return publicationsSectionInTier2Screen;
    }

    public MobileElement verifyNewspaperSectionInTier2Screen() {
        return newspaperSectionInTier2Screen;
    }

    public MobileElement verifyMagazineSectionInTier2Screen() {
        return magazineSectionInTier2Screen;
    }

    public void clickLibraryBrowse() {
        ClickOnMobileElement(libraryBrowse);
    }

    public void clickBrowseYoungAdultFiction() {
        for (int i = 0; i <= 6; i++) {
            if (isElementPresent(browseYoungAdultFiction)) {
                break;
            } else {
                swipeDown();
            }
        }
        ClickOnMobileElement(browseYoungAdultFiction);
    }

    public void clickRefiner() {
        ClickOnMobileElement(browseRefinerBTN);
    }

    public void clickSortBy() {
        ClickOnMobileElement(sortByRefiner);
    }

    public void clickMenuBottom() {
        ClickOnMobileElement(menuBottom);
    }

	public void clickeAudioTitle() {
		for(int i=0;i<5;i++) {
			if(isElementPresent(eAudioTitle)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		ClickOnMobileElement(eAudioTitle);
	}

	public void clickeBookTitle() {
		for(int i=0;i<5;i++) {
			if(isElementPresent(eBookTitle)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		ClickOnMobileElement(eBookTitle);
	}

    public void clickMenuOption() {
        ClickOnMobileElement(menuOption);
    }

    public void clickMylibrary() {
        if (isElementPresent(menu_btn_footerlibrary)) {
            ClickOnMobileElement(menu_btn_footerlibrary);

        } else if (isElementPresent(menu_btn_footerlibrary1)) {
            ClickOnMobileElement(menu_btn_footerlibrary1);
        }
    }

    public boolean alwaysAvailablecheck() {
        boolean alwaysAvailable = false;
        if (isElementPresent(myLib_lbl_alwaysAvlHeader)) {
            alwaysAvailable = true;
        }
        return alwaysAvailable;
    }


    public void clickOnalwaysAvlViewAll() {
        if (isElementPresent(myLib_btn_alwaysavlViewAll)) {
            ClickOnMobileElement(myLib_btn_alwaysavlViewAll);
        }
    }

    public void clickInterestsurvey() {
        ClickOnMobileElement(mylib_lbl_interestSurvey);
    }

    public void clickseeAll() {
        swipeDown();
        if (isElementPresent(Feature_curated_seeall)) {
            ClickOnMobileElement(Feature_curated_seeall);
        }

    }

    public void clickAdvancedSearch() {
        ClickOnMobileElement(advancedSearch);
        ClickOnMobileElement(advancedSearch);
    }

    public boolean verifyMenuOption() {
        boolean eAudioTitle = false;
        for (int i = 0; i < 15; i++) {
            if (isElementPresent(menuOption)) {
                eAudioTitle = true;
                break;
            } else {
                waitFor(1000);
            }
        }
        return eAudioTitle;
    }

    public void click_seeAll_thirdParty() {
        ClickOnMobileElement(thirdparty_SeeAlllink);
    }

    public void clickRefinerBTN() {
        ClickOnMobileElement(browseRefiner);
    }

    public void clik_profileIcon() {
        ClickOnMobileElement(profile_icon);
    }

    public void click_eBook_title() {
        ClickOnMobileElement(eBook_title);
    }

    public MobileElement eBook_title() {
        return eBook_title;
    }

    public void click_eAudio_title() {
        ClickOnMobileElement(eAudio_title);
    }

    public MobileElement get_eAudio_title() {
        return eAudio_title;
    }

    public void click_Video_title() {
        ClickOnMobileElement(Video_title);
    }

    public MobileElement get_Video_title() {
        return Video_title;
    }
    public void click_vBook_title() {
        ClickOnMobileElement(vBook_title);
    }

    public MobileElement get_vBook_title() {
        return vBook_title;
    }
    public MobileElement boundlessLogoNew() {
        return boundlessLogo;
    }

    public MobileElement bookOfTheMonthWidget() {
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(bookOfMonthWidget)) {
                break;
            } else {
                swipeDown();
            }
        }
        return bookOfMonthWidget;
    }

    public MobileElement bookOfTheMonthText() {
        return bookOfMonthWidget;
    }

    public MobileElement bookOfTheMonthDesc() {
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(bookOfMonthDescription)) {
                break;
            } else {
                swipeDown();
            }
        }
        return bookOfMonthDescription;
    }

    public void clickBookOfTheMonthTitle() {
        ClickOnMobileElement(bookOfMonthTitle);
    }

    public MobileElement titleDetailsPage() {
        return titleDetailsPage;
    }

    public List<MobileElement> bookOfTheMonthTitleList() {
        return bookOfTheMonthTitlesList;
    }

    public MobileElement wishlistCTATier3() {
        return wishlistCta;
    }

    public MobileElement shareCTATier3() {
        return shareCTA;
    }

    public MobileElement advancedSearchLib() {
        return advancedSearchLib;
    }

    public MobileElement featuredseeallThirdparty() {
        return newPaperMagazineSeeAll;
    }

}
