package pom.kidszone;

import org.apache.commons.compress.archivers.sevenz.CLI;
import org.apache.tools.ant.taskdefs.WaitFor;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class BoundlessLogo extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());


	public BoundlessLogo(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@iOSXCUITFindBy(accessibility="txtTitle")
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='txtTitle']")
	public MobileElement home_header_libraryName;

	@iOSXCUITFindBy(accessibility="Search")
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Search\"]/parent::android.widget.RelativeLayout/android.widget.TextView")
	public MobileElement home_header_libraryName_old;

	@iOSXCUITFindBy(accessibility="Profiles")
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='Profiles']")
	public MobileElement menu_profiles;

	@iOSXCUITFindBy(accessibility="Profiles_Menu")
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='Profiles_Menu']")
	public MobileElement menu_profiles_new;

	@iOSXCUITFindBy(xpath="//XCUIElementTypeOther[@name=\"Profiles, button\"]")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Profiles']")
	public MobileElement menu_profiles_old;

	@iOSXCUITFindBy(accessibility="user_profile_title")
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='user_profile_title']")
	public MobileElement profiles_header;

	@iOSXCUITFindBy(accessibility="listItemProfileListRow2")
	@AndroidFindBy(xpath = "//android.widget.Button[contains(@content-desc,'Teen, ')]/android.widget.TextView[2]")
	public MobileElement profliles_teen_option;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeImage")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_screen']/android.widget.ImageView")
	public MobileElement boundless_logo_ProfilesScreen;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeImage")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_screen']/following-sibling::android.widget.ImageView")
	public MobileElement boundless_logo_ProfilesTypeScreen;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeImage")
	@AndroidFindBy(xpath = "//android.widget.ScrollView[@resource-id='MENU_FLAT_LIST']/following-sibling::android.widget.ImageView")
	public MobileElement boundless_logo_MenuScreen;

	@iOSXCUITFindBy(accessibility="btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	public MobileElement profiles_btn_Back;

	@iOSXCUITFindBy(accessibility="Sign_out_Menu")
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id='Sign_out_Menu']")
	public MobileElement menu_signOut;

	@iOSXCUITFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Logout, button\"]")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Logout']")
	public MobileElement menu_logOut;

	@iOSXCUITFindBy(accessibility="SIGNOUT_YES")
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id='SIGNOUT_YES']")
	public MobileElement signOut_btn_Yes;

	@iOSXCUITFindBy(xpath ="//XCUIElementTypeButton[@name=\"Yes\"]")
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id='android:id/button1']")
	public MobileElement logout_btn_Yes;

	@iOSXCUITFindBy(accessibility="loc_btnSignin")
	@AndroidFindBy(xpath = "(//*[@text = \"Sign In\"])[2]")
	public MobileElement signIn_text;

	@iOSXCUITFindBy(accessibility="loc_btnSignin")
	@AndroidFindBy(xpath = "//*[@text = \"Log in\"]")
	public MobileElement login_text;
	
	@iOSXCUITFindBy(accessibility="listItemProfileListRow2")
	@AndroidFindBy(xpath = "//android.widget.Button[contains(@content-desc,'Kid')]")
	public MobileElement profliles_kid_option;

	@iOSXCUITFindBy(accessibility="user_profile_add_avatar")
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id='user_profile_add_avatar']")
	public MobileElement profiles_addIcon_option;

	@iOSXCUITFindBy(accessibility="txtProfileTypesTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileTypesTitle']")
	public MobileElement addProflile_Screen;

	@iOSXCUITFindBy(accessibility="btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	public MobileElement back_btn_addProfile_screen;

	@iOSXCUITFindBy(accessibility="txtTitle")
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='txtTitle']")
	public MobileElement menu_header;

	@iOSXCUITFindBy(accessibility="Search")
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Search\"]/parent::android.widget.RelativeLayout/android.widget.TextView")
	public MobileElement menu_header_old;

	@iOSXCUITFindBy(xpath="//XCUIElementTypeScrollView/XCUIElementTypeOther[4]/XCUIElementTypeTextField")
	@AndroidFindBy(id = "com.bt.mdd.qa:id/fetv_lib_id")
	public MobileElement libraryId_txt_libId;

	@iOSXCUITFindBy(xpath="//XCUIElementTypeButton[@name=\"Login\"]")
	@AndroidFindBy(id = "com.bt.mdd.qa:id/btn_login")
	public MobileElement login_btn_libId;

	public boolean verifyLibraryHeader() {
		boolean match = false;
		waitFor(500);
		try {
			if (isElementPresent(home_header_libraryName)) {
				logger.info("User verified the library header");
				match = true;
			} else if (isElementPresent(home_header_libraryName_old)) {
				logger.info("User verified the library header");
				match = true;

			}

		} catch (Exception e) {
			logger.severe("Error while verifing profiles header : " + e.getMessage());
			match = false;
		}

		return match;

	}

	public boolean clickProfiles() {
		boolean match = false;
		try {
//			WaitForMobileElement(menu_profiles);
			if (isElementPresent(menu_profiles)) {
				ClickOnMobileElement(menu_profiles);
				logger.info("User clicked profiles");
				match = true;
			} else if (isElementPresent(menu_profiles_old)) {
				ClickOnMobileElement(menu_profiles_old);
				logger.info("User clicked profiles");
				match = true;
			} else if (isElementPresent(menu_profiles_new)) {
				ClickOnMobileElement(menu_profiles_new);
				logger.info("User clicked profiles");
				match = true;
			}

		} catch (Exception e) {
			logger.severe("Error while clicking profiles : " + e.getMessage());
			match = false;
		}
		return match;
	}

	public boolean verifyProfilesHeader() {
		boolean match;
		try {
			isElementPresent(profiles_header);
			logger.info("profile header verified");
			match = true;
		} catch (Exception e) {
			logger.severe("Error while verifing profiles header: " + e.getMessage());
			match = false;
		}
		return match;
	}

	public boolean verifyboundlessLogo() {
		boolean match;
		try {
			if (isElementPresent(boundless_logo_ProfilesScreen)) {
				logger.info("verified boundless logo on profiles screen ");
			} else if (isElementPresent(boundless_logo_ProfilesTypeScreen)) {
				logger.info("verified boundless logo on profile Type screen");
			} else if (isElementPresent(boundless_logo_MenuScreen)) {
				logger.info("verified boundless logo on menu screen");
			}
			match = true;
		} catch (Exception e) {
			logger.severe("Error while verifing boundless Logo on screen: " + e.getMessage());
			match = false;
		}
		return match;
	}

	public boolean clickBacktoMenu() {
		boolean match;
		try {
			if (isElementPresent(profiles_btn_Back)) {
				ClickOnMobileElement(profiles_btn_Back);
				logger.info("Clicked Back to menu button from profiles screen");
			}
			match = true;
		} catch (Exception e) {
			logger.severe("Error while Back to menu button from profiles screen" + e.getMessage());
			match = false;
		}
		return match;

	}

	public boolean clickSignOutAndYesOption() {
		boolean match;
		try {
			if (isElementPresent(menu_signOut)) {
				ClickOnMobileElement(menu_signOut);
				logger.info("Clicked sign out button");
			}

			if (isElementPresent(menu_logOut)) {
				ClickOnMobileElement(menu_logOut);
				logger.info("Clicked log out button");
			}

			match = true;
		} catch (Exception e) {
			logger.severe("Error while Sign out Yes button : " + e.getMessage());
			match = false;
		}
		return match;

	}

	public boolean clickSignOutPopUpYes() {
		boolean match = false;
		try {

			if (isElementPresent(signOut_btn_Yes)) {
				ClickOnMobileElement(signOut_btn_Yes);
				logger.info("Clicked sign out Yes button");
			}

			if (isElementPresent(logout_btn_Yes)) {
				ClickOnMobileElement(logout_btn_Yes);
				logger.info("Clicked logout out button");
			}

			match = true;
		} catch (Exception e) {
			logger.severe("Error while clicking Alert yes  : " + e.getMessage());
			match = false;
		}
		return match;
	}

	public boolean verifySingPage() {
		boolean match = false;
		try {

			if (isElementPresent(signIn_text)) {
				logger.info("verified sign in button");
				match = true;
			}

			if (isElementPresent(login_text)) {
				logger.info("verified Log in button");
				match = true;
			}

		} catch (Exception e) {
			logger.severe("Error while verifing sign in page : " + e.getMessage());
			match = false;
		}

		return match;
	}

	public boolean clickTeenProfile() {
		boolean match;
		try {
			if (isElementPresent(profliles_teen_option)) {
				ClickOnMobileElement(profliles_teen_option);
				login.handleNothankspopup();
				logger.info("Clicked Teen profile button");
			}
			match = true;
		} catch (Exception e) {
			logger.severe("Error while clicking Teen profile: " + e.getMessage());
			match = false;
		}
		return match;
	}

	public boolean clickKidProfile() {
		boolean match;
		try {
			if (isElementPresent(profliles_kid_option)) {
				ClickOnMobileElement(profliles_kid_option);
				login.handleNothankspopup();
				logger.info("Clicked Kid profile button");
			}
			match = true;
		} catch (Exception e) {
			logger.severe("Error while clicking Kid profile: " + e.getMessage());
			match = false;
		}
		return match;
	}

	public void infoExistingAxisApplicationTheme() {

		logger.info("Checking Application Theme");

	}

	public void infoBoundlessLogText() {

		logger.info("As per the lastest comment as adult user should able to view the new boundless logo");

	}

	public void verifingTheme() {

		logger.info("Checking Theme");

	}

	public boolean clickProfliePulsIcon() {
		boolean match;
		try {
			if (isElementPresent(profiles_addIcon_option)) {
				ClickOnMobileElement(profiles_addIcon_option);
				login.handleNothankspopup();
				logger.info("Clicked Add profile button");
			}
			match = true;
		} catch (Exception e) {
			logger.severe("Error while clicking Add profile: " + e.getMessage());
			match = false;
		}
		return match;
	}

	public boolean verifyAddProfileScreen() {
		boolean match = false;
		try {
			if (isElementPresent(addProflile_Screen)) {
				match = true;
			}

			logger.info("verified add profile screen");
		} catch (Exception e) {
			logger.severe("Error while verifing add profile screen: " + e.getMessage());
			match = false;
		}
		return match;
	}

	public boolean clickBackButtonfromAddProfile() {
		boolean match;
		try {
			if (isElementPresent(back_btn_addProfile_screen)) {
				ClickOnMobileElement(back_btn_addProfile_screen);
				logger.info("Clicked back button from add profile screen");
			}
			match = true;
		} catch (Exception e) {
			logger.severe("Error while back button from add profile screen: " + e.getMessage());
			match = false;
		}
		return match;
	}

	public boolean verifyAddMenuScreen() {
		boolean match = false;
		waitFor(200);
		try {
			if (isElementPresent(menu_header)) {
				match = true;
			} else if (isElementPresent(menu_header_old)) {
				match = true;
			}

			logger.info("verified add menu screen");
		} catch (Exception e) {
			logger.severe("Error while verifing menu screen: " + e.getMessage());
			match = false;
		}
		return match;
	}

	public boolean enterLibraryId(String libId) {
		boolean match = false;
		try {
			ClickOnMobileElement(libraryId_txt_libId);
			SendKeysOnMobileElement(libraryId_txt_libId, libId);
			match = true;
			logger.info("Entered Library ID");
		} catch (Exception e) {
			logger.severe("Error while Entering Library ID: " + e.getMessage());
			match = false;
		}
		return match;
	}

	public boolean clickLogInBtn() {
		boolean match = false;
		try {
			if (isElementPresent(login_btn_libId)) {
				ClickOnMobileElement(login_btn_libId);
				match = true;
				logger.info("Clicked Login Button");
			}
		} catch (Exception e) {
			logger.severe("Error while Clicking Login Button: " + e.getMessage());
			match = false;
		}
		return match;

	}
}
