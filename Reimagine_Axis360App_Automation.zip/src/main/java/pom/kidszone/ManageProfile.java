package pom.kidszone;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class ManageProfile extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(ManageProfile.class);
	// public String username;
	public ThreadLocal<String> username = ThreadLocal.withInitial(() -> "");
	public ManageProfile(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/************************ Locators *************************/

	@iOSXCUITFindBy(accessibility = "user_profile_right_menu")
	// @AndroidFindBy(id = "Edit Profile")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_right_menu']")
	public MobileElement manageProf_btn_Edit;

	@iOSXCUITFindBy(accessibility = "user_profile_add_avatar")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_add_avatar']")
	private MobileElement manageProf_btn_add;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow0")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_avatar_image0']")
	private List<MobileElement> manageProf_icon_profile;

	@iOSXCUITFindBy(accessibility = "txtProfileListName0")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListName0']")
	public List<MobileElement> manageProf_lbl_profName;

	@iOSXCUITFindBy(accessibility = "txtProfileListName1")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListName1']")
	public List<MobileElement> manageProf_lbl_profName1;

	@iOSXCUITFindBy(accessibility = "txtProfileListName2")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListName2']")
	public List<MobileElement> manageProf_lbl_profName2;

	@iOSXCUITFindBy(accessibility = "txtProfileListName3")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListName3']")
	public List<MobileElement> manageProf_lbl_profName3;

	@iOSXCUITFindBy(accessibility = "txtProfileListName4")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListName4']")
	public List<MobileElement> manageProf_lbl_profName4;

	@iOSXCUITFindBy(accessibility = "txtProfileListType0")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileListType0']")
	public List<MobileElement> manageProf_lbl_profType;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow0")
	@AndroidFindBy(xpath = "//*[@resource-id='imgUserListIcon0']")
	public List<MobileElement> manageProf_icon_edit;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement manageProf_lbl_header;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public MobileElement manageProf_lbl_desc;

	@iOSXCUITFindBy(accessibility = "btnLandingPageDisplay")
	@AndroidFindBy(xpath = "//*[@resource-id='btnLandingPageDisplay']/android.widget.CheckBox")
	public MobileElement manageProf_lbl_setmyshelf;

	@iOSXCUITFindBy(accessibility = "txtProfileTypesTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileTypesTitle']")
	private MobileElement addprofile_lbl_desc;

	@iOSXCUITFindBy(accessibility = "profile_teen_type_title")
	@AndroidFindBy(xpath = "//*[@resource-id='profile_teen_type_title']")
	private MobileElement addprofile_btn_AdultProf;

	@iOSXCUITFindBy(accessibility = "profile_teen_type")
	@AndroidFindBy(xpath = "//*[@resource-id='profile_teen_type_title']")
	private MobileElement addprofile_btn_teenProf;

	@iOSXCUITFindBy(accessibility = "profile_child_type")
	@AndroidFindBy(xpath = "//*[@resource-id='profile_child_type_title']")
	private MobileElement addprofile_btn_kidProf;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	private MobileElement addprofile_txt_userName;

	@iOSXCUITFindBy(accessibility = "wrap_display_name")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_display_name']")
	private MobileElement addprofile_txt_disPlayName;

	@iOSXCUITFindBy(accessibility = "edit_profile_email")
	@AndroidFindBy(xpath = "//*[@resource-id='edit_profile_email']")
	private MobileElement addprofile_txt_email;

	@iOSXCUITFindBy(accessibility = "btnSelectAvatar")
	@AndroidFindBy(xpath = "//*[@resource-id='btnSelectAvatar']")
	public MobileElement addprofile_btn_selectAvatar;

	@iOSXCUITFindBy(accessibility = "btnDone")
	@AndroidFindBy(xpath = "//*[@resource-id='btnDone']")
	private MobileElement addprofile_btn_done;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"change_image\"])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='avatar_view']")
	public List<MobileElement> addprofile_avatarImageList;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"change_image\"])[1]")
	@AndroidFindBy(xpath = "(//*[@resource-id='avatar_view'])[4]")
	public MobileElement addprofile_avatarImage;

	@iOSXCUITFindBy(accessibility = "btnAddProfileNo")
	@AndroidFindBy(xpath = "//*[@resource-id='btnAddProfileNo']")
	private MobileElement addprofile_btn_successPopYes;

	@iOSXCUITFindBy(accessibility = "edit_profile_delete_profilen")
	@AndroidFindBy(xpath = "//*[@resource-id='edit_profile_delete_profilen']")
	private MobileElement editprofile_btn_deltProfile;

	@iOSXCUITFindBy(accessibility = "edit_profile_checkout_limit")
	@AndroidFindBy(xpath = "//*[@resource-id='edit_profile_checkout_limit']")
	private MobileElement editprofile_lbl_checkoutLimit;

	@iOSXCUITFindBy(accessibility = "edit_profile_hold_limit")
	@AndroidFindBy(xpath = "//*[@resource-id='edit_profile_hold_limit']")
	private MobileElement editprofile_lbl_holdLimit;

	@iOSXCUITFindBy(accessibility = "edit_profile_recommendation_limit")
	@AndroidFindBy(xpath = "//*[@resource-id='edit_profile_recommendation_limit']")
	private MobileElement editprofile_lbl_recomLimit;

	@iOSXCUITFindBy(accessibility = "txtLibraryName")
	@AndroidFindBy(xpath = "//*[@resource-id='txtLibraryName']")
	private MobileElement editprofile_lbl_LibName;

	@iOSXCUITFindBy(accessibility = "edit_profile_avatar")
	@AndroidFindBy(xpath = "//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup")
	public List<MobileElement> editprofile_avatar;

	@iOSXCUITFindBy(accessibility = "imgPencilIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='imgPencilIcon']")
	public MobileElement editprofile_icon_editavatar;

	@iOSXCUITFindBy(accessibility = "wrap_edit_profile_name")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_edit_profile_name']")
	private MobileElement editprofile_displayName;

	@iOSXCUITFindBy(accessibility = "edit_profile_avatar")
	@AndroidFindBy(xpath = "//*[@resource-id='edit_profile_avatar']")
	private MobileElement editprofile_btn_close;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement profileIcon;

	@iOSXCUITFindBy(accessibility = "txtCheckoutHistory")
	@AndroidFindBy(xpath = "//*[@resource-id='txtCheckoutHistory']")
	private MobileElement editprofile_checkoutHistory;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='edit_profile_dropdown']")
	public MobileElement editprofile_profiledropdown;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(id = "dummy")
	public List<MobileElement> editprofile_profileOptions;

	@iOSXCUITFindBy(accessibility = "edit_profile_save")
	@AndroidFindBy(xpath = "//*[@resource-id='edit_profile_save']")
	public MobileElement editprofile_btn_save;

	@iOSXCUITFindBy(accessibility = "btnYes")
	@AndroidFindBy(xpath = "//*[@resource-id='btnYes']")
	public MobileElement deleteprofile_btn_popYes;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='btnNo']")
	public MobileElement deleteprofile_btn_popNo;

	@iOSXCUITFindBy(accessibility = "user_profile_title")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_list']//android.view.ViewGroup[contains(@resource-id,'listItemUserProfileList')]")
	// @AndroidFindBy(id = "user_profile_title")
	public List<MobileElement> manageProf_lbl_Profile;

	@iOSXCUITFindBy(accessibility = "listItemUserProfileList6")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList6']")
	private MobileElement manageProf_lbl_MaxuserNotifi;

	@iOSXCUITFindBy(accessibility = "listItemUserProfileList0")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList0']")
	private MobileElement profile_txt_profile1; 
	
	@iOSXCUITFindBy(accessibility = "listItemUserProfileList1")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList1']")
	private MobileElement profile_txt_profile2;
	
	@iOSXCUITFindBy(accessibility = "listItemUserProfileList2")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList2']")
	private MobileElement profile_txt_profile3;
	
	@iOSXCUITFindBy(accessibility = "listItemUserProfileList3")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList3']")
	private MobileElement profile_txt_profile4;

	@iOSXCUITFindBy(accessibility = "listItemUserProfileList4")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList4']")
	private MobileElement profile_txt_profile5;

	@iOSXCUITFindBy(accessibility = "profile_saved")
	@AndroidFindBy(xpath = "//*[@resource-id='profile_saved']")
	public MobileElement profile_txt_detailssaveconfirm;

	public MobileElement getEditprofile_btn_deltProfile() {
		return editprofile_btn_deltProfile;
	}

	public MobileElement getManageProf_lbl_setmyshelf() {
		return manageProf_lbl_setmyshelf;
	}

	public MobileElement getManageProf_lbl_MaxuserNotifi() {
		return manageProf_lbl_MaxuserNotifi;
	}

	public MobileElement getAddprofile_txt_userName() {
		return addprofile_txt_userName;
	}

	public MobileElement getAddprofile_txt_email() {
		return addprofile_txt_email;
	}

	public MobileElement getManageProf_btn_add() {
		return manageProf_btn_add;
	}

	public MobileElement getEditprofile_displayName() {
		return editprofile_displayName;
	}

	public MobileElement getEditprofile_lbl_checkoutLimit() {
		return editprofile_lbl_checkoutLimit;
	}

	public MobileElement getEditprofile_lbl_holdLimit() {
		return editprofile_lbl_holdLimit;
	}

	public MobileElement getEditprofile_lbl_recomLimit() {
		return editprofile_lbl_recomLimit;
	}

	public MobileElement getEditprofile_lbl_LibName() {
		return editprofile_lbl_LibName;
	}

	public MobileElement getEditprofile_btn_close() {
		return editprofile_btn_close;
	}

	public MobileElement getEditprofile_checkoutHistory() {
		return editprofile_checkoutHistory;
	}

	public List<MobileElement> getManageProf_lbl_Profile() {
		return manageProf_lbl_Profile;
	}

	public MobileElement getAddprofile_lbl_desc() {
		return addprofile_lbl_desc;
	}

	public MobileElement getAddprofile_btn_AdultProf() {
		return addprofile_btn_AdultProf;
	}

	public MobileElement getAddprofile_btn_teenProf() {
		return addprofile_btn_teenProf;
	}

	public MobileElement getAddprofile_btn_kidProf() {
		return addprofile_btn_kidProf;
	}

	/*************************** Action methods **********************************/

	public Boolean manageprofielScreenNav() {
		Boolean prfilePage = false;
		if (manageProf_lbl_Profile.size() != 0) {
			prfilePage = true;
			logger.info("User is on profilepage");
		}
		System.out.println(prfilePage);
		return prfilePage;
	}

	public void selectProf() {
		ClickOnMobileElement(manageProf_icon_profile.get(0));
	}

	public void editBtnClick() {

			ClickOnMobileElement(manageProf_btn_Edit);

	}

	public Boolean editIconCheck() {
		Boolean iconSize = true;
		int profileSize = manageProf_icon_profile.size();
		int editIconSize = manageProf_icon_edit.size();
		if (profileSize == editIconSize) {
			logger.info("User is able to editIcon for all the profiles");
		} else {
			iconSize = false;
			logger.info("User is not able to editIcon for all the profiles");
		}
		return iconSize;
	}

	public void penIconClick() {
		ClickOnMobileElement(manageProf_icon_edit.get(0));
		// try {
		// for (int i = 0; i < manageProf_lbl_profType.size()-1; i++) {
		// if (manageProf_lbl_profType.get(i).getText().equalsIgnoreCase("Kid")) {
		// ClickOnMobileElement(manageProf_lbl_profName.get(i));
		// logger.info("clicked on kid profile to edit");
		// break;
		// }else if (manageProf_lbl_profType.get(i).getText().equalsIgnoreCase("Teen"))
		// {
		// ClickOnMobileElement(manageProf_lbl_profName.get(i));
		// logger.info("clicked on Teen profile to edit");
		// break;
		// }
		// }
		// }catch (Exception e) {
		// logger.info("User dont have kid or teen profile hence editing adult
		// profile");
		// for (int i = 0; i < manageProf_lbl_profType.size()-1; i++) {
		// if (manageProf_lbl_profType.get(i).getText().equalsIgnoreCase("Adult")) {
		// ClickOnMobileElement(manageProf_lbl_profName.get(i));
		// break;
		// }
		// }
		// }
	}

	public Boolean profDtlPgNav() {
		Boolean profavatar = false;
		if (editprofile_avatar.size() != 0) {
			profavatar = true;
			logger.info("User is on the Manage prof screen");
		}
		return profavatar;
	}

	public void profDisplayCheck() {
		if (manageProf_icon_profile.size() != 0 && manageProf_icon_profile.size() <= 5) {
			for (int i = 0; i <= manageProf_icon_profile.size() - 1; i++) {
				logger.info("displayed profiles : " + manageProf_icon_profile.get(i));
			}
		} else if (manageProf_icon_profile.size() == 0) {
			Assert.assertTrue(manageProf_lbl_header.isDisplayed());
			Assert.assertTrue(manageProf_lbl_desc.isDisplayed());
			logger.info("User is on the manage profile screen but no profiles displayed");
		}
	}

	public void clickOnAddCTA() {
		if (manageProf_lbl_profName.size() < 5) {
			ClickOnMobileElement(manageProf_btn_add);
		} else if (manageProf_lbl_profName.size() == 5) {
			deleteProfile();
			ClickOnMobileElement(manageProf_btn_add);
		}
	}

	public void selectProfType(String profType) {
		if (profType.equalsIgnoreCase("Adult")) {
			ClickOnMobileElement(addprofile_btn_AdultProf);
		} else if (profType.equalsIgnoreCase("Teen")) {
			ClickOnMobileElement(addprofile_btn_teenProf);
		} else if (profType.equalsIgnoreCase("Kid")) {
			ClickOnMobileElement(addprofile_btn_kidProf);
		}
	}

	public String enterProfDetail() {
		ClickOnMobileElement(addprofile_txt_disPlayName);
		SendKeysOnMobileElement(addprofile_txt_disPlayName, "BTAuto" + RandomStringGenerate());
		username.set(addprofile_txt_disPlayName.getText());
		swipeDown();
		ClickOnMobileElement(addprofile_btn_selectAvatar);
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			if (isElementPresent(addprofile_btn_selectAvatar)) {
				ClickOnMobileElement(addprofile_btn_selectAvatar);
				ClickOnMobileElement(addprofile_avatarImage);

			}
		}
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {

			ClickOnMobileElement(addprofile_avatarImageList.get(0));
		}
		return username.get();
	}

	public void doneBtnClick() {
		ClickOnMobileElement(addprofile_btn_done);
//		ClickOnMobileElement(addprofile_btn_successPopYes);
	}

	public Boolean createdProfDisplayCheck() {
		Boolean disPlay = false;
		if (username.get().contains(manageProf_lbl_profName.get(0).getText())) {
			disPlay = true;
			logger.info("User able to see the created prof");
		} else if (username.get().contains(manageProf_lbl_profName1.get(0).getText())) {
			disPlay = true;
			logger.info("User able to see the created prof");
		} else if (username.get().contains(manageProf_lbl_profName2.get(0).getText())) {
			disPlay = true;
			logger.info("User able to see the created prof");
		} else if (username.get().contains(manageProf_lbl_profName3.get(0).getText())) {
			disPlay = true;
			logger.info("User able to see the created prof");
		} else if (username.get().contains(manageProf_lbl_profName4.get(0).getText())) {
			disPlay = true;
			logger.info("User able to see the created prof");
		}
		return disPlay;
	}

	public void addProfile(String profType) {
		if (manageProf_lbl_profName.size() < 5) {
			ClickOnMobileElement(manageProf_btn_add);
			if (profType.equalsIgnoreCase("Adult")) {
				ClickOnMobileElement(addprofile_btn_AdultProf);
			} else if (profType.equalsIgnoreCase("Teen")) {
				ClickOnMobileElement(addprofile_btn_teenProf);
			} else if (profType.equalsIgnoreCase("Kid")) {
				ClickOnMobileElement(addprofile_btn_kidProf);
			}
			SendKeysOnMobileElement(addprofile_txt_userName, "username");
			ClickOnMobileElement(addprofile_btn_selectAvatar);
			ClickOnMobileElement(addprofile_avatarImageList.get(0));
			ClickOnMobileElement(addprofile_btn_done);
			ClickOnMobileElement(addprofile_btn_successPopYes);
		} else if (manageProf_lbl_profName.size() == 5) {
			deleteProfile();
			ClickOnMobileElement(manageProf_btn_add);
			if (profType.equalsIgnoreCase("Adult")) {
				ClickOnMobileElement(addprofile_btn_AdultProf);
			} else if (profType.equalsIgnoreCase("Teen")) {
				ClickOnMobileElement(addprofile_btn_teenProf);
			} else if (profType.equalsIgnoreCase("Kid")) {
				ClickOnMobileElement(addprofile_btn_kidProf);
			}
			SendKeysOnMobileElement(addprofile_txt_userName, "username");
			ClickOnMobileElement(addprofile_btn_selectAvatar);
			ClickOnMobileElement(addprofile_avatarImageList.get(0));
			ClickOnMobileElement(addprofile_btn_done);
			ClickOnMobileElement(addprofile_btn_successPopYes);
		}
	}

	public void deleteProfile() {
		int beforeDelete = manageProf_lbl_profName.size();
		ClickOnMobileElement(manageProf_btn_Edit);
		for (int i = manageProf_lbl_profName.size(); i > 0; i--) {
			if (manageProf_lbl_profType.get(i).getText().equalsIgnoreCase("Kid")
					|| manageProf_lbl_profType.get(i).getText().equalsIgnoreCase("Teen"))
				ClickOnMobileElement(manageProf_icon_profile.get(i));
			swipeDown();
			ClickOnMobileElement(editprofile_btn_deltProfile);
			ClickOnMobileElement(deleteprofile_btn_popYes);
			break;
		}
		int afterDelete = manageProf_lbl_profName.size();
		if (beforeDelete != afterDelete) {
			logger.info("user deleted Profile successfully");
		}
	}

	public void editProfile() {
		for (int i = manageProf_lbl_profName.size(); i > 0; i--) {
			ClickOnMobileElement(manageProf_lbl_Profile.get(i));
			swipeDown();
			ClickOnMobileElement(editprofile_profiledropdown);
			ClickOnMobileElement(editprofile_profileOptions.get(1));
			ClickOnMobileElement(editprofile_btn_save);
			break;
		}
	}

	public void kidprofileSelection() {
		
		ClickOnMobileElement(profile_txt_profile3);

//		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
//			if (isElementPresent(profile_txt_profile2) && profile_txt_profile2.getText().contains("Kid")) {
//				ClickOnMobileElement(profile_txt_profile2);
//			} else if (isElementPresent(profile_txt_profile3) && profile_txt_profile3.getText().contains("Kid")) {
//				ClickOnMobileElement(profile_txt_profile3);
//			} else if (isElementPresent(profile_txt_profile4) && profile_txt_profile4.getText().contains("Kid")) {
//				ClickOnMobileElement(profile_txt_profile4);
//			} else if (isElementPresent(profile_txt_profile5) && profile_txt_profile5.getText().contains("Kid")) {
//				ClickOnMobileElement(profile_txt_profile5);
//			}
//		}
//		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
//			if (isElementPresent(profile_txt_profile2)
//					&& profile_txt_profile2.getAttribute("text").contains("Kid")) {
//				ClickOnMobileElement(profile_txt_profile2);
//			} else if (isElementPresent(profile_txt_profile3)
//					&& profile_txt_profile3.getAttribute("text").contains("Kid")) {
//				ClickOnMobileElement(profile_txt_profile3);
//			} else if (isElementPresent(profile_txt_profile4)
//					&& profile_txt_profile4.getAttribute("text").contains("Kid")) {
//				ClickOnMobileElement(profile_txt_profile4);
//			} else if (isElementPresent(profile_txt_profile5)
//					&& profile_txt_profile5.getAttribute("text").contains("Kid")) {
//				ClickOnMobileElement(profile_txt_profile5);
//			}
//		}
	}

	public void teenprofileSelection() {
//		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
//		MobileElement mobelement = (MobileElement) exwait.until(ExpectedConditions.visibilityOf(profile_txt_profile2));
//		mobelement.click();
		
		ClickOnMobileElement(profile_txt_profile2);

//		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
//			if (isElementPresent(profile_txt_profile2) && profile_txt_profile2.getText().contains("Teen")) {
//				ClickOnMobileElement(profile_txt_profile2);
//			} else if (isElementPresent(profile_txt_profile3) && profile_txt_profile3.getText().contains("Teen")) {
//				ClickOnMobileElement(profile_txt_profile3);
//			} else if (isElementPresent(profile_txt_profile4) && profile_txt_profile4.getText().contains("Teen")) {
//				ClickOnMobileElement(profile_txt_profile4);
//			} else if (isElementPresent(profile_txt_profile5) && profile_txt_profile5.getText().contains("Teen")) {
//				ClickOnMobileElement(profile_txt_profile5);
//			}
//		}
//		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
//			if (isElementPresent(profile_txt_profile2)
//					&& profile_txt_profile2.getAttribute("text").contains("Teen")) {
//				ClickOnMobileElement(profile_txt_profile2);
//			} else if (isElementPresent(profile_txt_profile3)
//					&& profile_txt_profile3.getAttribute("text").contains("Teen")) {
//				ClickOnMobileElement(profile_txt_profile3);
//			} else if (isElementPresent(profile_txt_profile4)
//					&& profile_txt_profile4.getAttribute("text").contains("Teen")) {
//				ClickOnMobileElement(profile_txt_profile4);
//			} else if (isElementPresent(profile_txt_profile5)
//					&& profile_txt_profile5.getAttribute("text").contains("Teen")) {
//				ClickOnMobileElement(profile_txt_profile5);
//			}
//		}
	}

	public void adultprofileSelection() {
//		WebDriverWait exwait = new WebDriverWait(DriverManager.getDriver(), 25);
//		MobileElement mobelement = (MobileElement) exwait.until(ExpectedConditions.visibilityOf(profile_txt_profile1));
//		mobelement.click();
				ClickOnMobileElement(profile_txt_profile1);
//		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
//			if (isElementPresent(profile_txt_profile2) && profile_txt_profile2.getText().contains("Adult")) {
//				ClickOnMobileElement(profile_txt_profile2);
//			} else if (isElementPresent(profile_txt_profile3) && profile_txt_profile3.getText().contains("Adult")) {
//				ClickOnMobileElement(profile_txt_profile3);
//			} else if (isElementPresent(profile_txt_profile4) && profile_txt_profile4.getText().contains("Adult")) {
//				ClickOnMobileElement(profile_txt_profile4);
//			} else if (isElementPresent(profile_txt_profile5) && profile_txt_profile5.getText().contains("Adult")) {
//				ClickOnMobileElement(profile_txt_profile5);
//			}
//		}
//		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
//			if (isElementPresent(profile_txt_profile2)
//					&& profile_txt_profile2.getAttribute("text").contains("Adult")) {
//				ClickOnMobileElement(profile_txt_profile2);
//			} else if (isElementPresent(profile_txt_profile3)
//					&& profile_txt_profile3.getAttribute("text").contains("Adult")) {
//				ClickOnMobileElement(profile_txt_profile3);
//			} else if (isElementPresent(profile_txt_profile4)
//					&& profile_txt_profile4.getAttribute("text").contains("Adult")) {
//				ClickOnMobileElement(profile_txt_profile4);
//			} else if (isElementPresent(profile_txt_profile5)
//					&& profile_txt_profile5.getAttribute("text").contains("Adult")) {
//				ClickOnMobileElement(profile_txt_profile5);
//			}
//		}
	}

	public void createProfWithUploadImage() {
		SendKeysOnMobileElement(addprofile_txt_userName, "demoName");
		SendKeysOnMobileElement(addprofile_txt_email, "demoName@gmail.com");
	}

	public void createProfWithSelectDefaultImage() {
		SendKeysOnMobileElement(addprofile_txt_userName, "demoName");
		SendKeysOnMobileElement(addprofile_txt_email, "demoName@gmail.com");
		ClickOnMobileElement(addprofile_btn_selectAvatar);
		ClickOnMobileElement(addprofile_avatarImageList.get(0));
	}

	public void addProfilevalidation() {
		try {
			ClickOnMobileElement(manageProf_btn_add);
		} catch (Exception e) {
			logger.info("Add button is not displayed");
		}
	}

	public void clickProfileImage() {
		
			ClickOnMobileElement(profileIcon);

//		} else if(isElementPresent(editprofile_btn_close)) {
//			ClickOnMobileElement(editprofile_btn_close);
//			logger.info("Profile Image not Displayed");
//		}
//	ClickOnMobileElement(editprofile_btn_close);

	}

	public void updateAvatar() {
		if (isElementPresent(editprofile_icon_editavatar)) {
			ClickOnMobileElement(editprofile_icon_editavatar);
		}
		if (isElementPresent(addprofile_avatarImage)) {
			ClickOnMobileElement(addprofile_avatarImage);
		}
	}

	public void saveUpdatedAvatar() {
		swipeDown();
		swipeDown();
		if (isElementPresent(addprofile_avatarImage)) {
			ClickOnMobileElement(editprofile_btn_save);
		}
		if (isElementPresent(profile_txt_detailssaveconfirm)) {
			ClickOnMobileElement(profile_txt_detailssaveconfirm);
		}
	}

	public void myshelfHandle(boolean enable) {
		swipeDown();
		if (isElementPresent(manageProf_lbl_setmyshelf)) {
			if (enable) {
				ClickOnMobileElement(manageProf_lbl_setmyshelf);
			} else {
				ClickOnMobileElement(manageProf_lbl_setmyshelf);
			}
		}
	}
	
	public void displayName() {
		SendKeysOnMobileElement(editprofile_displayName, "Adult_two");
	}
}
