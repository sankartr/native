package pom.kidszone;

import org.junit.Assert;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class ProfilePage extends CommonActions {

	public ProfilePage(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public static final Logger logger = LoggerFactory.getLogger(ProfilePage.class);

	@iOSXCUITFindBy(accessibility = "txtProfileTypesTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='profile_adult_type']")
	public MobileElement profile_txt_add;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow4")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow4']")
	public MobileElement profile_txt_profile5;

	@iOSXCUITFindBy(accessibility = "user_profile_right_menu")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_right_menu']")
	public MobileElement profile_txt_editProfile;

	@iOSXCUITFindBy(accessibility = "Profiles_Menu")
	@AndroidFindBy(xpath = "//*[@resource-id='Profiles_Menu']")
	private MobileElement menuList_profile1;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Profiles, button\"]")
	@AndroidFindBy(xpath = "(//android.widget.TextView[@content-desc=\"Legal\"])[1]")
	private MobileElement menuList_profile;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow0")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow0']")
	private MobileElement profile_txt_profile1;
	
	@iOSXCUITFindBy(accessibility = "SEARCH_TEXT_BOX")
	@AndroidFindBy(xpath = "//*[@resource-id='SEARCH_TEXT_BOX']")
	private MobileElement searchbar;
	
	@iOSXCUITFindBy(accessibility = "LIBRARY_ADVANCE_SEARCH_BUTTON")
	@AndroidFindBy(xpath = "//*[@resource-id='LIBRARY_ADVANCE_SEARCH_BUTTON']")
	private MobileElement search_btn;

	@iOSXCUITFindBy(accessibility = "user_profile_right_menu")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_right_menu']")
	private MobileElement edit_Option;

	@iOSXCUITFindBy(accessibility = "btnYes")
	@AndroidFindBy(xpath = "//*[@resource-id='btnYes']")
	private MobileElement profile_Delete_Ok;
	
	@iOSXCUITFindBy(accessibility = "listItemProfileListRow1")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow1']")
	private MobileElement editPenIcon_FirstTeen;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow0")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow0']")
	private MobileElement editPenIcon_Adult;

	@iOSXCUITFindBy(accessibility = "close_icon")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'close_icon')]")
	private MobileElement clickClose_Btn;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'btnBackIcon')]")
	private MobileElement prof_PIN_Close_Btn;
	
	@iOSXCUITFindBy(accessibility = "ok_button")
	@AndroidFindBy(xpath = "//*[@resource-id='ok_button']")
	private MobileElement alert_Close_Btn;
	
	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement clickBack_Btn;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'Kid')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Kid')]")
	private MobileElement editPenIcon_FirstKid;
	
	@iOSXCUITFindBy(accessibility = "user_profile_add_avatar")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_add_avatar']")
	private MobileElement clickAdd_Profile;

	@iOSXCUITFindBy(accessibility = "btnNo")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'btnNo')]")
	private MobileElement delete_Cancel;
	
	@iOSXCUITFindBy(accessibility = "txtDeleteProfile")
	@AndroidFindBy(xpath = "//*[@resource-id='txtDeleteProfile']")
	private MobileElement delete_Profile;

	@iOSXCUITFindBy(accessibility = "NUM_1_BTN")
	@AndroidFindBy(xpath = "//*[@resource-id='NUM_1_BTN']")
	private MobileElement profile_pin1;

	@iOSXCUITFindBy(accessibility = "NUM_2_BTN")
	@AndroidFindBy(xpath = "//*[@resource-id='NUM_2_BTN']")
	private MobileElement profile_pin2;

	@iOSXCUITFindBy(accessibility = "NUM_3_BTN")
	@AndroidFindBy(xpath = "//*[@resource-id='NUM_3_BTN']")
	private MobileElement profile_pin3;

	@iOSXCUITFindBy(accessibility = "NUM_4_BTN")
	@AndroidFindBy(xpath = "//*[@resource-id='NUM_4_BTN']")
	private MobileElement profile_pin4;

	@iOSXCUITFindBy(accessibility = "Done_button")
	@AndroidFindBy(xpath = "//*[@resource-id='Done_button']")
	private MobileElement profile_pin_submit;

	@iOSXCUITFindBy(accessibility = "btnYes")
	@AndroidFindBy(xpath = "//*[@resource-id='btnYes']")
	private MobileElement delete_Profile_Ok;

	@iOSXCUITFindBy(accessibility = "listItemUserProfileList1")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList1']")
	private MobileElement profile_txt_profile2;

	@iOSXCUITFindBy(accessibility = "listItemUserProfileList2")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemUserProfileList2']")
	private MobileElement profile_txt_profile3;
	
	@iOSXCUITFindBy(xpath = "(//*[@name='btnEmailNotifications'])[3]")
	@AndroidFindBy(xpath = "//*[@resource-id='checkbox_seven']")
	private MobileElement enable_Pin_Checkbox;
	
	@iOSXCUITFindBy(accessibility = "edit_profile_save")
	@AndroidFindBy(xpath = "//*[@resource-id='edit_profile_save']")
	private MobileElement clickSave_Button;
	
	@iOSXCUITFindBy(accessibility = "edit_profile_delete_profilen")
	@AndroidFindBy(xpath = "//*[@resource-id='edit_profile_delete_profilen']")
	private MobileElement profile_txt_deleteprofile;

	@iOSXCUITFindBy(accessibility = "btnYes")
	@AndroidFindBy(xpath = "//*[@resource-id='btnYes']")
	public MobileElement profile_txt_deleteconfirm;

	@iOSXCUITFindBy(accessibility = "txtProfileTypesSubTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileTypesSubTitle']")
	private MobileElement addprofile_lbl_desc;
	
	@iOSXCUITFindBy(accessibility = "Create a Profile PIN")
    @AndroidFindBy(xpath = "//*[@text='Create a Profile PIN']")
    public MobileElement create_Profile_PIN;
	
	@iOSXCUITFindBy(accessibility = "ALERT_TITLE")
    @AndroidFindBy(xpath = "//*[@text='Please add an email to enable your profile PIN']")
    public MobileElement email_Popup_Alert;
	
	@iOSXCUITFindBy(accessibility = "Confirm Profile PIN")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Confirm Profile PIN')]")
    public MobileElement confirm_Profile_PIN;
	
	@iOSXCUITFindBy(accessibility = "Enter Profile PIN")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Enter Profile PIN')]")
    public MobileElement profile_Management_PIN;
	
	@iOSXCUITFindBy(accessibility = "btnYes")
    @AndroidFindBy(xpath = "//*[@resource-id='btnYes']")
    public MobileElement okDeleteBtn;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Cancel')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Cancel')]")
    public MobileElement Cancel;
	
	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Leave Page')]")
    @AndroidFindBy(xpath = "//*[contains(@content-desc,'Leave Page')]")
    public MobileElement leave_page;

	@iOSXCUITFindBy(accessibility = "INTEREST_SURVEY_CHECKBOX-TEXT-checkboxOne")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Checkbox Adult')]")
	private MobileElement viewMyInterestAgeLevel;

	@iOSXCUITFindBy(accessibility = "INTEREST_SURVEY_CHECKBOX-TEXT-checkboxTwo")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Checkbox Teen')]")
	private MobileElement viewMyInterestAgeLevelTeen;


	public void clickCancelCTA()
	{
		ClickOnMobileElement(Cancel);
	}
	
	public void leavePage()
	{
		ClickOnMobileElement(leave_page);
	}
	
	public void checkprofileCount() {
		if (isElementPresent(profile_txt_profile5)) {
			logger.info("Already 5 profile avilable");
			WaitForMobileElement(profile_txt_editProfile);
			ClickOnMobileElement(profile_txt_editProfile);
			if (isElementPresent(profile_txt_profile2) && !profile_txt_profile2.getText().contains("Adult")) {
				ClickOnMobileElement(profile_txt_profile2);
			} else if (isElementPresent(profile_txt_profile2) && !profile_txt_profile2.getText().contains("Adult")) {
				ClickOnMobileElement(profile_txt_profile2);
			} else if (isElementPresent(profile_txt_profile3) && !profile_txt_profile3.getText().contains("Adult")) {
				ClickOnMobileElement(profile_txt_profile3);
			}
			if (System.getProperty("platform").equalsIgnoreCase("Android")) {
				MobileElement upcomingPrg = (MobileElement) DriverManager.getDriver()
						.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"

								+ ".scrollIntoView(new UiSelector().text(\"View My Interests\"))"));
			}
			for (int i = 0; i < 4; i++) {
				if (isElementPresent(profile_txt_deleteprofile)) {
					break;
				} else {
					swipeDown();
				}
			}
			ClickOnMobileElement(profile_txt_deleteprofile);
			ClickOnMobileElement(profile_txt_deleteconfirm);
		} else {
			logger.info("create more profile up to 5");
		}
	}

	public void addProfileCta() {
		checkprofileCount();
		swipeDown();
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(profile_txt_add)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(profile_txt_add);
	}

	public MobileElement getAddprofile_lbl_desc() {
		return addprofile_lbl_desc;
	}

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement profileIcon;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"edit_profile_screen\"]/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther[3]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton")
	@AndroidFindBy(xpath = "//*[@resource-id='close_icon']")
	private MobileElement profileIcon_close;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"viewTitleHistory\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='viewTitleHistory']")
	private MobileElement Checkout_Available;

	@iOSXCUITFindBy(accessibility = "viewTitleHistory")
	@AndroidFindBy(xpath = "//*[@resource-id='viewTitleHistory']//android.widget.CheckBox")
	private MobileElement clickCheckoutAvailableCheckBox;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"btnEmailNotifications\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='checkbox_five']")
	private MobileElement email_Notification;

	@iOSXCUITFindBy(accessibility = "viewCheckoutHistory")
	@AndroidFindBy(xpath = "//*[@resource-id='checkbox_two']")
	private MobileElement checkout_history;

	@iOSXCUITFindBy(accessibility = "btnInsightAndBadgesDisplay")
	@AndroidFindBy(xpath = "//*[@resource-id='checkbox_three']")
	private MobileElement insight_Badges;

	@iOSXCUITFindBy(accessibility = "btnLandingPageDisplay")
	@AndroidFindBy(xpath = "//*[@resource-id='btnLandingPageDisplay']")
	private MobileElement myshelf_homePage;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"viewTitleHistory\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitleHistory']")
	private MobileElement checkout_available_txt;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"viewTitleHistory\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='viewTitleHistory']")
	private MobileElement checkout_available_txt1;

	@iOSXCUITFindBy(accessibility = "edit_profile_save")
	@AndroidFindBy(xpath = "//*[@resource-id='edit_profile_save']")
	private MobileElement edit_profile_Save;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"btnLandingPageDisplay\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='txtLandingPageDisplay']")
	private MobileElement set_myshelf_txt;

	@iOSXCUITFindBy(accessibility = "view_toggle")
	@AndroidFindBy(xpath = "//*[@resource-id='view_toggle']")
	private MobileElement view_toggle;
	
	@iOSXCUITFindBy(accessibility = "parentail_disabled_alert_yes")
	@AndroidFindBy(xpath = "//*[@resource-id='parentail_disabled_alert_yes']")
	private MobileElement click_Alert_Yes;
	
	@iOSXCUITFindBy(accessibility = "NUM_1_BTN")
	@AndroidFindBy(xpath = "//*[@resource-id='NUM_1_BTN']")
	private MobileElement enterNewPIN1;
	
	@iOSXCUITFindBy(accessibility = "NUM_2_BTN")
	@AndroidFindBy(xpath = "//*[@resource-id='NUM_2_BTN']")
	private MobileElement enterNewPIN2;
	
	@iOSXCUITFindBy(accessibility = "NUM_3_BTN")
	@AndroidFindBy(xpath = "//*[@resource-id='NUM_3_BTN']")
	private MobileElement enterNewPIN3;
	
	@iOSXCUITFindBy(accessibility = "NUM_4_BTN")
	@AndroidFindBy(xpath = "//*[@resource-id='NUM_4_BTN']")
	private MobileElement enterNewPIN4;

	@iOSXCUITFindBy(accessibility = "Enable Profile PIN")
	@AndroidFindBy(xpath = "//*[@resource-id='view_toggle']")
	private MobileElement Enable_PIN;

	@iOSXCUITFindBy(accessibility = "Enable My Profile PIN")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Enable My Profile PIN')]")
	private MobileElement Enable_PIN_Text;


	@iOSXCUITFindBy(accessibility = "view_toggle")
	@AndroidFindBy(xpath = "//*[@resource-id='view_toggle']")
	private MobileElement Enable_PIN_Toggle;

	@iOSXCUITFindBy(accessibility = "user_profile_right_menu")
	@AndroidFindBy(xpath = "//*[@text='Profiles']")
	private MobileElement profile_Page;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow0")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow0']")
	private MobileElement adult_Profile_Edit_Icon;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow1")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow1']")
	private MobileElement teen_Profile_Edit_Icon;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow1")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow1']")
	private MobileElement teen_Profile;

	@iOSXCUITFindBy(accessibility = "listItemProfileListRow2")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow2']")
	private MobileElement Kid_Profile;

	@iOSXCUITFindBy(accessibility = "user_profile_right_menu")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_right_menu']")
	private MobileElement profile_Cancel_Option;

	@iOSXCUITFindBy(accessibility = "My Profile Heading")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'My Profile')]")
	private MobileElement profile_Details;
	
	@iOSXCUITFindBy(accessibility = "loc_edit_profile_email")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_edit_profile_email']")
	private MobileElement edit_profile_email;

	@iOSXCUITFindBy(accessibility = "Email notifications will be sent to this email address")
	@AndroidFindBy(xpath = "//*[@text='Email notifications will be sent to this email address']")
	private MobileElement edit_profile_email_notification;
	
	@iOSXCUITFindBy(accessibility = "btnToolTip")
	@AndroidFindBy(xpath = "//*[@resource-id='imgToolTip']")
	private MobileElement edit_email_tool_tip;

	@iOSXCUITFindBy(accessibility = "Enter a Valid Email")
	@AndroidFindBy(xpath = "//*[@text='Enter a Valid Email']")
	private MobileElement invalid_email_msg;

	@iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
	@AndroidFindBy(xpath = "//*[@text='Please add an email to enable your Profile PIN']")
	private MobileElement enable_notification_popup;

	@iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
	@AndroidFindBy(xpath = "//*[@text='The Primary Profile must enter an email address in their profile to enable a Profile PIN']")
	private MobileElement enable_notification_popup1;

	@iOSXCUITFindBy(accessibility = "ok_button")
	@AndroidFindBy(xpath = "//*[@resource-id='ok_button']")
	private MobileElement enable_notification_popup_close;

	@iOSXCUITFindBy(accessibility = "btnTeenEmailAddress")
	@AndroidFindBy(xpath = "//*[@resource-id='checkbox_six']")
	private MobileElement add_sameEmail;
	
	@iOSXCUITFindBy(accessibility = "Done_button")
	@AndroidFindBy(xpath = "//*[@resource-id='Done_button']")
	private MobileElement click_Disable_CTA;

	@iOSXCUITFindBy(accessibility = "NUM_1_BTN")
	@AndroidFindBy(xpath = "//*[@resource-id='NUM_1_BTN']")
	private MobileElement setParentPin_NumpadKeyOne;

	@iOSXCUITFindBy(accessibility = "Done_button")
	@AndroidFindBy(xpath = "//*[@resource-id='Done_button']")
	private MobileElement setParentPin_btn_submit;

	@iOSXCUITFindBy(accessibility = "user_profile_right_menu")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_right_menu']")
	public MobileElement edit_profile;

	@iOSXCUITFindBy(accessibility = "FORGOT_PIN_BUTTON")
	@AndroidFindBy(xpath = "//*[contains(@text,'Two more attempts left')]")
	private MobileElement profile_UnabletoDelete_Msg;

	@iOSXCUITFindBy(accessibility = "ALERT_TITLE")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'ALERT_TITLE')]")
	private MobileElement delete_Profile_Msg;

	@iOSXCUITFindBy(accessibility = "deleted")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'deleted')]")
	private MobileElement profile_Deleted_Msg;

	@iOSXCUITFindBy(accessibility = "user_profile_title")
	@AndroidFindBy(xpath = "//*[@content-desc='Profiles Heading, ']")
	private MobileElement ProfilesHeader;

	@iOSXCUITFindBy(accessibility = "user_profile_add_avatar")
	@AndroidFindBy(xpath = "//*[@content-desc='Add Profile, ']")
	private MobileElement AddProfile;
	
	@iOSXCUITFindBy(accessibility = "user_profile_right_menu")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	private MobileElement manage_profile_page;
	
	@iOSXCUITFindBy(accessibility = "txtProfileTypesTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtProfileTypesTitle']")
	private MobileElement add_profile_page;
	
	@iOSXCUITFindBy(accessibility = "profile_teen_type")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Add a teen. 12 to 18, \"]/android.view.ViewGroup/android.widget.TextView[2]")
	private MobileElement verbiage_teen;
	
	@iOSXCUITFindBy(accessibility = "profile_child_type")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Add a kid. 0 to 11, \"]/android.view.ViewGroup/android.widget.TextView[2]")
	private MobileElement verbiage_kid;
	
	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	private MobileElement profile_details_page;
	
	@iOSXCUITFindBy(accessibility = "FORGOT_PIN_BUTTON")
	@AndroidFindBy(xpath = "//*[@text='PIN not valid. Please try again.']")
	private MobileElement wrong_PIN_Failure;
	
	@iOSXCUITFindBy(accessibility = "view_toggle")
	@AndroidFindBy(xpath = "//*[@resource-id='view_toggle']")
	private MobileElement toggle_on_button;
	
	@iOSXCUITFindBy(accessibility = "ALERT_TITLE")
	@AndroidFindBy(xpath = "//*[@resource-id='ALERT_TITLE']")
	private MobileElement disable_profile_pin_alert;
	
	@iOSXCUITFindBy(accessibility = "Disable Profile PIN")
	@AndroidFindBy(xpath = "//*[@content-desc='Disable Profile PIN, ']")
	private MobileElement disable_Profile_PIN;
	
	@iOSXCUITFindBy(accessibility = "Profile Type")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'Profile Type')]")
	private MobileElement profile_type;
	
	@iOSXCUITFindBy(accessibility = "loc_edit_profile_email")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_edit_profile_email']")
	private MobileElement adultMailId;

	@iOSXCUITFindBy(accessibility = "user_profile_right_menu")
	@AndroidFindBy(xpath = "//*[@resource-id='user_profile_right_menu']")
	private MobileElement EditProfileCTA;
	
	@iOSXCUITFindBy(accessibility = "txtDeleteProfile")
	@AndroidFindBy(xpath = "//*[@resource-id='txtDeleteProfile']")
	private MobileElement cancel_Boundless;
	
	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	private MobileElement profile_List_Screen;
	
	@iOSXCUITFindBy(accessibility = "txtDeleteProfile")
	@AndroidFindBy(xpath = "//*[@resource-id='txtDeleteProfile']")
	private MobileElement delete__Profile;
	
	@iOSXCUITFindBy(accessibility = "loc_txtLogo")
	@AndroidFindBy(xpath = "//*[@content-desc='logo']")
	private MobileElement boundless_lib;
	
	@iOSXCUITFindBy(accessibility = "FORGOT_PIN_BUTTON")
	@AndroidFindBy(xpath = "//*[@text=\"Forgot PIN\"]")
	private MobileElement forgotPin;

	@iOSXCUITFindBy(accessibility = "FORGOT_PIN_BUTTON")
	@AndroidFindBy(xpath = "//*[@text='PIN not valid. Please try again.']")
	private MobileElement forgotPinErrorMessage;

	@iOSXCUITFindBy(accessibility = "FORGOT_PIN_BUTTON")
	@AndroidFindBy(xpath = "//*[@resource-id='FORGOT_PIN_BUTTON']")
	private MobileElement forgotPin1;
	
	@iOSXCUITFindBy(accessibility = "Reset Profile PIN heading")
	@AndroidFindBy(xpath = "//*[@content-desc='Reset Profile PIN heading, ']")
	private MobileElement resetProfilePin;
	
	@iOSXCUITFindBy(accessibility = "Reset Profile PIN heading")
	@AndroidFindBy(xpath = "//*[@text='Send email']")
	private MobileElement sendEmail;

	@iOSXCUITFindBy(accessibility = "The PINs you entered do not match. Please retry.")
	@AndroidFindBy(xpath = "//*[@text='The PINs you entered do not match. Please retry.']")
	private MobileElement pinNotMatch;
	
	@iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
	@AndroidFindBy(xpath = "//*[@resource-id='ALERT_MESSAGE']")
	private MobileElement deleteWarningMsg;
	
	@iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
	@AndroidFindBy(xpath = "//*[@resource-id='ALERT_MESSAGE']")
	private MobileElement deleteWarningMsgTeen;
	
	@iOSXCUITFindBy(accessibility = "View_My_Interests")
	@AndroidFindBy(xpath = "//*[@resource-id='View_My_Interests']")
	private MobileElement viewMyInterest;

	@iOSXCUITFindBy(accessibility = "profile_adult_type")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'profile_adult_type')])[1]")
	private MobileElement addAnAdult;
	
	@iOSXCUITFindBy(accessibility = "listItemProfileListRow3")
	@AndroidFindBy(xpath = "//*[@resource-id='listItemProfileListRow3']")
	private MobileElement adult_Profile_two;
	
	public MobileElement PIN_Not_Match() {
        return pinNotMatch;
    }

	public MobileElement create_Profile_PIN() {
        return create_Profile_PIN;
    }
	
	public MobileElement email_Popup_Alert() {
        return email_Popup_Alert;
    }
	
	public MobileElement confirm_Profile_PIN() {
        return confirm_Profile_PIN;
    }
	
	public MobileElement profile_Management_PIN() {
        return profile_Management_PIN;
    }
	
	public MobileElement boundless_lib() {
		return boundless_lib;
	}

	public MobileElement delete__Profile() {
		return delete__Profile;
	}

	public MobileElement cancel_Boundless() {
		return cancel_Boundless;
	}

	public MobileElement profile_List_Screen() {
		return profile_List_Screen;
	}
	
	public MobileElement getProfileIcon() {
		return profileIcon;
	}

	public MobileElement getEdit_profile_email() {
		return edit_profile_email;
	}
	
	public MobileElement getEnable_notification_popup() {
		return enable_notification_popup;
	}
	
	public MobileElement getEnable_notification_teen_popup() {
		return enable_notification_popup;
	}

	public MobileElement getEnable_notification_popup1() {
		return enable_notification_popup1;
	}

	public MobileElement getInvalid_email_msg() {
		return invalid_email_msg;
	}

	public MobileElement getEnable_PIN() {
		return Enable_PIN;
	}

	public MobileElement getEnablePINText() {
		for (int i = 0; i < 5; i++) {
			if (isElementPresent(Enable_PIN_Text)) {
				break;
			} else {
				swipeDown();
			}
		}
		return Enable_PIN_Text;
	}

	public MobileElement getProfile_Page() {
		return profile_Page;
	}

	public MobileElement getAdult_Profile_Edit_Icon() {
		return adult_Profile_Edit_Icon;
	}

	public MobileElement getTeen_Profile_Edit_Icon() {
		return teen_Profile_Edit_Icon;
	}

	public MobileElement getProfile_Cancel_Option() {
		return profile_Cancel_Option;
	}

	public MobileElement getProfile_Details() {
		return profile_Details;
	}

	public MobileElement getProfile_UnabletoDelete_Msg() {
		return profile_UnabletoDelete_Msg;
	}

	public MobileElement getDelete_Profile_Msg() {
		return delete_Profile_Msg;
	}

	public MobileElement getProfile_Deleted_Msg() {
		return profile_Deleted_Msg;
	}

	public MobileElement getCheckout_Available() {
		for(int i =0;i<5;i++) {
			if (isElementPresent(Checkout_Available)) {
				break;
			} else {
				swipeDown();
			}
		}
		return Checkout_Available;
	}

	public MobileElement getMyshelf_homePage() {
		for (int i = 0; i < 5; i++) {
			if (isElementPresent(myshelf_homePage)) {
				break;
			} else {
				swipeDown();
			}
		}
		return myshelf_homePage;
	}

	public void clickMenuProfile() {

		if (isElementPresent(menuList_profile)) {

			ClickOnMobileElement(menuList_profile);
		}
		if (isElementPresent(menuList_profile1)) {
			ClickOnMobileElement(menuList_profile1);
		}

	}

	public void clickEdit_Option() {
		WaitForMobileElement(edit_Option);
		ClickOnMobileElement(edit_Option);
	}

	public void clickProfile_Delete_Ok() {
		ClickOnMobileElement(profile_Delete_Ok);
	}

	public void clickEditPenIcon_FirstTeen() {
		ClickOnMobileElement(editPenIcon_FirstTeen);
	}

	public void clickEditPenIcon_Adult() {
		WaitForMobileElement(editPenIcon_Adult);
		ClickOnMobileElement(editPenIcon_Adult);
	}

	public void clickClose_Btn() {
		if (isElementPresent(clickClose_Btn)) {
			ClickOnMobileElement(clickClose_Btn);
		} else {
			ClickOnMobileElement(clickBack_Btn);
		}
	}

	public void click_Prof_PIN_Close_Btn() {
		WaitForMobileElement(prof_PIN_Close_Btn);
		ClickOnMobileElement(prof_PIN_Close_Btn);
	}
	public void clickAlert_Close_Btn() {
		ClickOnMobileElement(alert_Close_Btn);
	}
	
	public void clickBack_Btn() {
		ClickOnMobileElement(clickBack_Btn);
	}
	
	public void clickEditPenIcon_FirstKid() {
		ClickOnMobileElement(editPenIcon_FirstKid);
	}

	public void clickAdd_Profile() {
		ClickOnMobileElement(clickAdd_Profile);
	}
	
	public void clickDelete_Cancel() {
		ClickOnMobileElement(delete_Cancel);
	}

	public void clickDelete_Profile() {
		 for(int i =0;i<5;i++) {
	            if(isElementPresent(delete_Profile)) {
	                break;
	            }
	            else {
	                swipeDown();
	            }
	        }
		ClickOnMobileElement(delete_Profile);
		waitFor(1000);

	}

	public void provideInvalid_Pin_DeleteProfile() {
		ClickOnMobileElement(profile_pin2);
		waitFor(1000);
		ClickOnMobileElement(profile_pin2);
		waitFor(1000);
		ClickOnMobileElement(profile_pin3);
		waitFor(1000);
		ClickOnMobileElement(profile_pin4);
		waitFor(1000);
		ClickOnMobileElement(profile_pin_submit);
	}

	public void provideValid_Pin_DeleteProfile() {
		ClickOnMobileElement(profile_pin1);
		waitFor(1000);
		ClickOnMobileElement(profile_pin2);
		waitFor(1000);
		ClickOnMobileElement(profile_pin3);
		waitFor(1000);
		ClickOnMobileElement(profile_pin4);
		waitFor(1000);
		ClickOnMobileElement(profile_pin_submit);
	}

	public void clickDelete_Profile_Ok() {
		ClickOnMobileElement(delete_Profile_Ok);
	}

	public void adultProfileSelection() {
		ClickOnMobileElement(profile_txt_profile1);
	}

	public void searchTitleHold() {
		ClickOnMobileElement(searchbar);
		SendKeysOnMobileElement(searchbar, "Five Little Bunnies");
		ClickOnMobileElement(search_btn);
	}
	
	public void teenprofileSelection() {
		WaitForMobileElement(profile_txt_profile2);
		ClickOnMobileElement(profile_txt_profile2);
	}

	public void kidprofileSelection() {
		WaitForMobileElement(profile_txt_profile3);
		ClickOnMobileElement(profile_txt_profile3);
	}
	
	public void click_EnablePIN_Checkbox() {
		for (int i = 0; i < 3; i++) {
			if (isElementPresent(enable_Pin_Checkbox)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(enable_Pin_Checkbox);
	}
	
	public void click_EnablePIN_toggle() {
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(Enable_PIN_Toggle)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(Enable_PIN_Toggle);
	}

	public void clickSave_Button() {
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(clickSave_Button)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(clickSave_Button);
	}
	
	public void navigateProfileDetail() {
		ClickOnMobileElement(profileIcon);
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(edit_profile_Save)) {
				break;
			} else {
				swipeDown();
			}
		}
	}

	public void closeProfile() {
		ClickOnMobileElement(profileIcon_close);
	}

	public boolean checkcheckoutVerbiage(String text) {
		boolean result = false;
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			String actualText = checkout_available_txt.getAttribute("label");
			if (actualText.contains(text)) {
				result = true;
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			result = false;
			if (checkout_available_txt.getText().contains(text)) {
				result = true;
				System.out.println("idud");
			}
		}
		return result;
	}

	public boolean checkMyshelfVerbiage(String text) {

		boolean result = false;
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			String actualText = set_myshelf_txt.getAttribute("label");
			if (actualText.contains(text)) {
				result = true;
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			String actualText = set_myshelf_txt.getText();
			if (actualText.contains(text)) {
				result = true;
			}
		}
		return result;

	}

	public void save_profile() {
		ClickOnMobileElement(edit_profile_Save);
	}

	public void checkUncheck() {

		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			if (Checkout_Available.getAttribute("label").equalsIgnoreCase("Checkbox  Unselected")) {
				ClickOnMobileElement(Checkout_Available);
				logger.info("Checked chekout available");
			} else {
				ClickOnMobileElement(Checkout_Available);
				logger.info("UnChecked chekout available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			if (Checkout_Available.getAttribute("content-desc").equalsIgnoreCase("Auto checkout available holdsCheckbox  Unselected, ")) {
				ClickOnMobileElement(Checkout_Available);
				logger.info("Checked chekout available");
			} else {
				ClickOnMobileElement(Checkout_Available);
				logger.info("UnChecked chekout available");
			}
		}

	}

	public boolean checkEditAccess() {

		boolean edit = false;
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			if (Checkout_Available.getAttribute("label").contains("Auto checkout available")) {
				edit = true;
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("Android")) {
//			System.out.println("ooo----" + checkout_available_txt.getAttribute("content-desc"));

			if (checkout_available_txt1.getAttribute("enabled").contains("false")) {
				edit = true;
			}
		}
		return edit;

	}

	public void enablePIN() {
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(view_toggle)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(view_toggle);
	}
	
	public void disablePIN() {
		ClickOnMobileElement(view_toggle);
	}
	
	public void click_Alert_Yes() {
		ClickOnMobileElement(click_Alert_Yes);
	}
	
	public void enterNewPIN() {
		ClickOnMobileElement(enterNewPIN1);
		ClickOnMobileElement(enterNewPIN2);
		ClickOnMobileElement(enterNewPIN3);
		ClickOnMobileElement(enterNewPIN4);
	}
	
	public void confirmNewPIN() {
		ClickOnMobileElement(enterNewPIN1);
		ClickOnMobileElement(enterNewPIN2);
		ClickOnMobileElement(enterNewPIN3);
		ClickOnMobileElement(enterNewPIN4);
	}
	
	public void confirmWrongPIN() {
		ClickOnMobileElement(enterNewPIN1);
		ClickOnMobileElement(enterNewPIN1);
		ClickOnMobileElement(enterNewPIN2);
		ClickOnMobileElement(enterNewPIN2);
	}
	
	public void clickEmailNotification() {
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(email_Notification)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(email_Notification);
//		if (isElementPresent(enable_notification_popup_close)){
//			ClickOnMobileElement(enable_notification_popup_close);
//		}
	}

	public void editEmail(String mailId) {
		ClickOnMobileElement(edit_profile_email);
		edit_profile_email.clear();
		SendKeysOnMobileElement(edit_profile_email, mailId);
//		waitFor(2000);
		hideMobileKeyboard();
//		DriverManager.getDriver().navigate().back();
		
//		ClickOnMobileElement(edit_email_tool_tip);
		//ClickOnMobileElement(edit_profile_email_notification);
	}

	public void addsameEmail() {
		ClickOnMobileElement(add_sameEmail);
	}
	
	public void click_Disable_CTA() {
		ClickOnMobileElement(click_Disable_CTA);
	}

	public MobileElement Disable_CTA() {
		return click_Disable_CTA;
	}
	
	public void parentPin() {
		for (int i = 0; i < 4; i++) {
			ClickOnMobileElement(setParentPin_NumpadKeyOne);
		}
		ClickOnMobileElement(setParentPin_btn_submit);
	}

	public void clickManageProfile() {
		ClickOnMobileElement(edit_profile);
	}

	public MobileElement editProfileCTA() {
		return EditProfileCTA;
	}

	public MobileElement addProfile() {
		return AddProfile;
	}
	
	public MobileElement manage_profile_page() {
		return manage_profile_page;
	}
	
	public MobileElement add_profile_page() {
		return add_profile_page;
	}
	
	public MobileElement verbiage_teen() {
		return verbiage_teen;
	}
	
	public MobileElement verbiage_kid() {
		return verbiage_kid;
	}
	
	public MobileElement profile_details_page() {
		return profile_details_page;
	}
	
	public MobileElement wrong_PIN_Failure() {
		return wrong_PIN_Failure;
	}
	
	public MobileElement toggle_on_button() {
		return toggle_on_button;
	}
	
	public MobileElement disable_profile_pin_alert() {
		return disable_profile_pin_alert;
	}
	
	public MobileElement disable_Profile_PIN() {
		return disable_Profile_PIN;
	}
	
	public MobileElement profile_type() {
		return profile_type;
	}
	
	public MobileElement adultMailId() {
		return adultMailId;
	}
	
	public MobileElement profilesHeader() {
		return ProfilesHeader;
	}
	
	public void clickCancel() {
		ClickOnMobileElement(enable_notification_popup_close);
	}
	
	public void clickForgotPin() {
		ClickOnMobileElement(forgotPin);
	}
	
	public MobileElement resetProfilePinTxt() {
		return resetProfilePin;
	}
	
	public MobileElement sendEmail() {
		return sendEmail;
	}
	
	public void clickSendEmail() {
		ClickOnMobileElement(sendEmail);
	}
	
	public void commonPIN() {
		ClickOnMobileElement(enterNewPIN1);
		ClickOnMobileElement(enterNewPIN1);
		ClickOnMobileElement(enterNewPIN1);
		ClickOnMobileElement(enterNewPIN1);
	}
	
	public void clickProfile() {
		ClickOnMobileElement(profileIcon);
	}
	
	public MobileElement forgotPin() {
		return forgotPin;
	}

	public MobileElement checkForgotPinErrorMessage() {
		return forgotPinErrorMessage;
	}


	public MobileElement checkForgotPin() {
		return forgotPin1;
	}

	public void selectTeenProfile() {
		ClickOnMobileElement(teen_Profile);
	}

	public void selectKidProfile() {
		ClickOnMobileElement(Kid_Profile);
	}
	
	public void okDeleteBtnClick() {
		if(isElementPresent(okDeleteBtn)) {
			ClickOnMobileElement(okDeleteBtn);
		}
	}
	
	public MobileElement deleteWarningMsg() {
		return deleteWarningMsg;
	}
	
	public MobileElement deleteWarningMsgteen() {
		return deleteWarningMsgTeen;
	}
	
	public void clickViewMyInterest() {
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(viewMyInterest)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(viewMyInterest);
	}
	
	public void clickAdult() {
		ClickOnMobileElement(viewMyInterestAgeLevel);
	}
	
	
	public void clickAddProfile() {
		ClickOnMobileElement(profile_txt_add);
	}
	
	public MobileElement addProfileIcon() {
		return profile_txt_add;
	}
	
	public MobileElement addAnAdult() {
		return addAnAdult;
	}
	
	public void clickAddAnAdult() {
		ClickOnMobileElement(addAnAdult);
	}
	
	public void navigateProfileSave() {
		for (int i = 0; i < 4; i++) {
			if (isElementPresent(clickSave_Button)) {
				break;
			} else {
				swipeDown();
			}
		}
		ClickOnMobileElement(clickSave_Button);
	}
	
	public MobileElement adultProfileTwo() {
		return adult_Profile_two;
	}
	
	public void click_AdultProfileTwo() {
		ClickOnMobileElement(adult_Profile_two);
	}
	
	public void selectProfile(String profile)
	
	{
		if(profile.contains("Teen"))
		{
			ClickOnMobileElement(verbiage_teen);
		}else if(profile.contains("Kid"))
		{
			ClickOnMobileElement(verbiage_kid);
		}
	}
	public void clickTeen() {
		for (int i = 0; i <7; i++) {
			if (isElementPresent(viewMyInterestAgeLevelTeen)) {
				break;
			} else {
				swipeDown();
			}
			ClickOnMobileElement(viewMyInterestAgeLevelTeen);
		}

	}
	
	
}
