package pom.kidszone;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.junit.Assert;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class TitleDetails extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	MyShelf myshelf = new MyShelf(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(TitleDetails.class);

	public TitleDetails(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/********************* Locators ***********************/

	@iOSXCUITFindBy(xpath = "(//*[contains(@label,'E book')])[1]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[1]")
	private MobileElement titledetails_btn_titleCardEbook;


	@iOSXCUITFindBy(xpath = "(//*[contains(@name,'EBT_Title')])[2]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'EBT_Title')])[2]")
	private MobileElement Featured;
	@iOSXCUITFindBy(xpath = "(//*[contains(@name,'EBT_Title')])[2]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'EBT_Title')])[2]")
	private MobileElement titledetails_btn_titleCardEbook12;
	
	@iOSXCUITFindBy(xpath = "(//*[contains(@name,'EBT_Title')])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'EBT_Title')])[1]")
	public MobileElement titled_btn_titleCardEbook;

	@iOSXCUITFindBy(accessibility = "View Program Details")
	@AndroidFindBy(xpath = "//*[@text='View Program Details']")
	private MobileElement ebook_view_prm;

	@iOSXCUITFindBy(accessibility = "Foundations 2 Book")
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Foundations 2 Book, \"]")
	private MobileElement ebook_title;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Image_Cover\"])[3]")
	@AndroidFindBy(xpath = "//android.view.ViewGroup/android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup/android.view.ViewGroup[1]")
	private MobileElement ebook_title1;

	@iOSXCUITFindBy(accessibility = "Cold Fusion Book")
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Cold Fusion Book, \"]")
	private MobileElement ebook_title2;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Details\"])[2]" )
	@AndroidFindBy(xpath = "//*[@resource-id = 'Details']")
	private MobileElement Click_Details;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[4]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[2]")
	private MobileElement titledetails_btn_titleCardEbook1; // download

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[31]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[4]/android.widget.ImageView")
	private MobileElement titledetails_btn_titleCardEbook2; // read now

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[33]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[1]")
	private MobileElement titledetails_btn_titleCardEbook3; // place hold

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[33]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[8]")
	private MobileElement titledetails_btn_titleCardEbook4; // suspend hold

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeImage[@name=\"See Image, See Read ebook\"])3]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[3]")
	private MobileElement titledetails_btn_titleCardEbook5; // remove hold

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeImage[@name=\"See Image, See Read ebook\"])[8]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[8]/android.widget.ImageView")
	private MobileElement titledetails_btn_titleCardEbook6; // limit checkout

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'ABT_Title')]")
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'ABT_Title')])[1]")
	private MobileElement titledetails_btn_titleCardAudioBook; // checkout

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Audio Book\"])[7]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Audio Book, \"])[5]")
	private MobileElement titledetails_btn_titleCardAudioBook1; // download

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[31]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Audio Book, \"])[8]/android.widget.ImageView")
	private MobileElement titledetails_btn_titleCardAudioBook2; // listen now

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Read ebook\"])[83]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[2]")
	private MobileElement titledetails_btn_titleCardAudioBook3; // place hold

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Audio Book\"])[3]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Audio Book, \"])[3]")
	private MobileElement titledetails_btn_titleCardAudioBook4; // suspend hold

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Audio Book\"])[6]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Audio Book, \"])[2]")
	private MobileElement titledetails_btn_titleCardAudioBook5; // remove hold

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Audio Book\"])[6]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Read ebook, \"])[8]/android.widget.ImageView")
	private MobileElement titledetails_btn_titleCardAudioBook6; // limit checkout

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement titleDetails_btn_BackButton;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"txtTitle\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	private MobileElement titleDetails_lbl_title;

	@iOSXCUITFindBy(accessibility = "txtSubTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtSubTitle']")
	private MobileElement titleDetails_lbl_subtitle;

	// @iOSXCUITFindBy(xpath = "(//*[@name=\"loc_txtImageCoverBook\"])[2]")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeLink[@name=\"loc_lnkAuthor\"])[2]/preceding-sibling::XCUIElementTypeOther/XCUIElementTypeOther")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtImageCoverBook']")
	private MobileElement titleDetails_lbl_imageCover;

	@iOSXCUITFindBy(accessibility = "loc_txtImageCoverBook")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtImageCoverBook']")
	private MobileElement titleDetails_lbl_defaultimageCover;

	@iOSXCUITFindBy(accessibility = "loc_txtEbookFormatIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtEbookFormatIcon']")
	private MobileElement titleDetails_lbl_ebookFormatIcon;

	@iOSXCUITFindBy(accessibility = "cardIconTestID")
	@AndroidFindBy(xpath = "//*[@resource-id='cardIconTestID']")
	private MobileElement titleDetails_lbl_audioBookFormatIcon;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"detailsContentAUTHORTestId\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentAUTHORTestId']")
	private MobileElement titleDetails_lbl_authorName;

	@iOSXCUITFindBy(xpath = "(//*[contains(@name,'AUTHOR')])[2]")
	@AndroidFindBy(xpath = "//*[@resource-id='link_AUTHOR']")
	private MobileElement titleDetails_btn_authorName;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"search_advance_search_page_theme_id\"]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
	@AndroidFindBy(xpath = "//*[@resource-id='search_advance_search_page_theme_id']")
	private MobileElement titleDetails_lbl_AuthorSearchResultScreen;

	@iOSXCUITFindBy(accessibility = "loc_btnWishlist")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnWishlist']")
	private MobileElement titleDetails_btn_WishlistIcon;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Success! As You Wish has been added to your Wishlist.\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='message_snackbar_view']")
	private MobileElement titleDetails_lbl_ToastMessageAddWishlist;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Success! You have removed As You Wish from your Wishlist.\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='message_snackbar_view']")
	private MobileElement titleDetails_lbl_ToastMessageRemoveWishlist;

	@iOSXCUITFindBy(accessibility = "message_snackbar_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='message_snackbar_test_id']")
	private MobileElement titleDetails_lbl_WishlistCloseToastMessage;

	@iOSXCUITFindBy(accessibility = "loc_btnShare")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnShare']")
	private MobileElement titleDetails_btn_ShareCTA;

	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement shareCloseIcon;

	@iOSXCUITFindBy(accessibility = "loc_btnCheckout")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnCheckout']")
	private MobileElement titleDetails_btn_PrimaryCTA;

	@iOSXCUITFindBy(accessibility = "secondaryButtonTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='secondaryButtonTestId']")
	private MobileElement titleDetails_btn_SecondaryCTA;

	@iOSXCUITFindBy(accessibility = "primaryButtonTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='primaryButtonTestId']")
	private MobileElement titleDetails_btn_PrimaryCTA1;

	@iOSXCUITFindBy(accessibility = "Download_handler_test_id0")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'Download_handler_test_id0')]")
	private MobileElement ActiveHoldbtn;

	@iOSXCUITFindBy(accessibility = "cuntinue_reading_book_title")
	@AndroidFindBy(xpath = "//*[@resource-id='cuntinue_reading_book_title']")
	private MobileElement library_btn_titleReadingProgress;

	@iOSXCUITFindBy(accessibility = "readingProgressID")
	@AndroidFindBy(xpath = "//*[@resource-id='readingProgressID']")
	private MobileElement titleDetails_lbl_titleReadingProgress;

	@iOSXCUITFindBy(accessibility = "LIBRARY_AVAILABILITY")
	@AndroidFindBy(xpath = "//*[@resource-id='LIBRARY_AVAILABILITY']")
	private MobileElement availabilityDropdown;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"avail_now_option_test_id\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='avail_now_option_test_id']")
	private MobileElement availableOption;

	@iOSXCUITFindBy(accessibility = "LIBRARY_FILTER_FORMAT")
	@AndroidFindBy(xpath = "//*[@resource-id='LIBRARY_FILTER_FORMAT']")
	private MobileElement formatDropDown;

	@iOSXCUITFindBy(accessibility = "filter_eBook_option_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='filter_eBook_option_test_id']")
	private MobileElement eBookOption;

	@iOSXCUITFindBy(accessibility = "filter_eAudio_option_test_id")
	@AndroidFindBy(xpath = "//*[@resource-id='filter_eAudio_option_test_id']")
	private MobileElement eAudioOption;

	@iOSXCUITFindBy(accessibility = "loc_txtSynopsis")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtSynopsis']")
	private MobileElement titleDetails_lbl_Synopsis;

	@iOSXCUITFindBy(accessibility = "loc_lnkSeeMore")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_lnkSeeMore']")
	private MobileElement titleDetails_btn_ViewAllCTA;

	@iOSXCUITFindBy(accessibility = "MoreLikeThis")
	@AndroidFindBy(xpath = "//*[@resource-id='MoreLikeThis']")
	private MobileElement titleDetails_btn_moreLikethisTab;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"MoreLikeThis\"])[1]")
	@AndroidFindBy(xpath = "(//XCUIElementTypeOther[@name=\"MoreLikeThis\"])[1]")
	private MobileElement moreLikeThisTab;


	@iOSXCUITFindBy(accessibility = "loc_txtTitlesLikeThis")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtTitlesLikeThis']")
	private MobileElement titleDetails_lbl_recommendation;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Titles in Series\"]")
	@AndroidFindBy(xpath = "//*[@text='Titles in Series']")
	private MobileElement titleDetails_lbl_titleSeries;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"See Image, See Audio Book\"])[1]")
	@AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc=\"See Image, See Audio Book, \"])[1]/android.widget.ImageView")
	private MobileElement titleDetails_lbl_titleSeriesCard;

	@iOSXCUITFindBy(accessibility = "loc_btnRelatedItemsTab")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRelatedItemsTab']")
	private MobileElement titleDetails_btn_relatedItemTab;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Learning Resources\"]")
	@AndroidFindBy(xpath = "//*[@text='Learning Resources']")
	private MobileElement titleDetails_lbl_learningActivities;

	@iOSXCUITFindBy(accessibility = "Details")
	@AndroidFindBy(xpath = "//*[@resource-id='Details']")
	private MobileElement titleDetails_lbl_detailsTab;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'AUTHOR')]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentAUTHORTestId']")
	private MobileElement detailsTab_lbl_author;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"detailsContentNARRATORTestId\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentNARRATORTestId']")
	private MobileElement detailsTab_lbl_narrator;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"detailsContentSERIESTestId\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentSERIESTestId']")
	private MobileElement detailsTab_lbl_series;

	@iOSXCUITFindBy(accessibility = "link_SERIES")
	@AndroidFindBy(xpath = "//*[@resource-id='link_SERIES']")
	private MobileElement detailsTab_btn_seriesCTA;

	@iOSXCUITFindBy(xpath = "(//*[@name=\"CURATED_LIST_LINK\"])[1]")
	@AndroidFindBy(xpath = "(//*[@resource-id='CURATED_LIST_LINK'])[1]")
	private MobileElement eBookSeeAllCuratedList;

	@iOSXCUITFindBy(accessibility = "search_advance_search_page_theme_id")
	@AndroidFindBy(xpath = "//*[@resource-id='search_advance_search_page_theme_id']")
	private MobileElement detailsTab_lbl_seriesListScreen;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name='FORMAT eBook'])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentFORMATTestId']")
	private MobileElement detailsTab_lbl_Format;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'LANGUAGE')]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentLANGUAGETestId']")
	private MobileElement detailsTab_lbl_Language;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'PUBLISHER')]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentPUBLISHERTestId']")
	private MobileElement detailsTab_lbl_Publisher;

	@iOSXCUITFindBy(xpath = "(//*[contains(@name,'PUBLISH DATE')])[2]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentPUBLISHDATETestId']")
	private MobileElement detailsTab_lbl_PublishDate;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'ISBN')]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentISBNTestId']")
	private MobileElement detailsTab_lbl_ISBN;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"detailsContentAUDIENCETestId\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentAUDIENCETestId']")
	private MobileElement detailsTab_lbl_Audience;

	@iOSXCUITFindBy(accessibility = "loc_btnDetailsWriteReview")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnDetailsWriteReview']")
	private MobileElement detailsTab_btn_WriteReview;

	/********************* 146956 ***********************/

	@iOSXCUITFindBy(accessibility = "loc_txtAvailableCopies")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtAvailableCopies']")
	private MobileElement titleDetails_lbl_availableCopy;

	/********************* 146957 ***********************/

	@iOSXCUITFindBy(accessibility = "detailsContentPATRONSONHOLDTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentPATRONONHOLDTestId']")
	private MobileElement detaislTab_lbl_countPatronOnHold;

	/********************* 146958 ***********************/

	@iOSXCUITFindBy(accessibility = "infoButtonTestId")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"See You are in Line, \"]")
	private MobileElement detailsTab_lbl_patronOnHoldPositionName;

	@iOSXCUITFindBy(accessibility = "infoButtonTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='infoButtonTestId']")
	private MobileElement detailsTab_btn_holdPositionToolTip;

	@iOSXCUITFindBy(accessibility = "Close")
	@AndroidFindBy(xpath = "//*[@resource-id='Close']")
	private MobileElement detailsTab_txt_toolTipVerbiage;

	@iOSXCUITFindBy(accessibility = "Close")
	@AndroidFindBy(xpath = "//*[@resource-id='Close']")
	private MobileElement detailsTab_txt_toolTipVerbiageClose;

	/********************* 146959 ***********************/

	@iOSXCUITFindBy(accessibility = "subjectBtn_Fiction")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"See Young Adult Fiction SUBJECT, \"]/android.view.ViewGroup/android.view.ViewGroup/android.widget.TextView")
	private MobileElement btn_lvl1Subject;

	@iOSXCUITFindBy(accessibility = "subjectBtn_Juvenile Nonfiction")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"See Music,Nature SUBJECT, \"]/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.TextView")
	private MobileElement btn_lvl2Subject;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"loc_txtDetailsSubject\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtDetailsSubject']")
	private MobileElement detailsTab_subjectText;

	/********************* 146960 ***********************/

	@iOSXCUITFindBy(accessibility = "detailsContentNARRATORTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentNARRATORTestId']")
	private MobileElement titleDetails_lbl_narratorName;

	@iOSXCUITFindBy(accessibility = "link_NARRATOR")
	@AndroidFindBy(xpath = "//*[@resource-id='link_NARRATOR']")
	private MobileElement titleDetails_btn_narratorName;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"search_advance_search_page_theme_id\"]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
	@AndroidFindBy(xpath = "//*[@resource-id='search_advance_search_page_theme_id']")
	private MobileElement titleDetails_lbl_NarratorSearchResultScreen;

	/********************* 146961 ***********************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"detailsContentEDITIONTestId \"]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentEDITIONTestId']")
	private MobileElement detailsTab_lbl_edition;

	/********************* 146963 ***********************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"detailsContentLENGTHTestId\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentLENGTHTestId']")
	private MobileElement detailsTab_lbl_length;

	/********************* 146964 ***********************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"detailsContentATTRIBUTETestId\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentATTRIBUTETestId']")
	private MobileElement detailsTab_lbl_Attribute;

	/********************* 146965 ***********************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"detailsContentLENGTHTestId\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentLENGTHTestId']")
	private MobileElement detailsTab_lbl_noOfPagesAttribute;

	/********************* 146966 ***********************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"detailsContentDOWNLOADSIZETestId\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentDOWNLOADSIZETestId']")
	private MobileElement detailsTab_lbl_titleFileSize;

	/********************* 146967 ***********************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"No recommended books available.\"]")
	@AndroidFindBy(xpath = "//*[@text='No recommended books available.']")
	private MobileElement moreLikeThisTab_lbl_noRecommendationText;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"recommendation_list_id_interest\"])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRecommendedTitleCard']")
	private MobileElement moreLikeThisTab_btn_recommendedTitleCard;

	/********************* 146977 ***********************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"title_details_page_test_id\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='title_details_page_test_id']")
	private MobileElement titledetails_container;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"KidsZone New York Library Title Description for headline announcement see\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='FEATURE_CURATED_LIST_CONTAINER']")
	private MobileElement titledetails_container2;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='recommendedTitle0012458580TestId']")
	private MobileElement library_swipe_container;

	/********************* 148838 ***********************/

	@iOSXCUITFindBy(accessibility = "testIdQuickFormat")
	@AndroidFindBy(xpath = "//*[@resource-id='testIdQuickFormat']")
	private MobileElement quickInfo_TitleFormatIcon;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Teen\"]")
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[5]/android.view.ViewGroup[1]/android.view.ViewGroup[2]/android.widget.TextView")
	private MobileElement quickInfo_profileIcon;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"15+\"]")
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[5]/android.view.ViewGroup[1]/android.view.ViewGroup[2]/android.view.ViewGroup")
	private MobileElement quickInfo_ageIcon;

	@iOSXCUITFindBy(accessibility = "loc_txtLang")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtLang']")
	private MobileElement quickInfo_languageIcon;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\\\"totalPageTestId\\\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='totalPageTestId']")
	private MobileElement quickInfo_noOfPages;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'LENGTH')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'LENGTH')]")
	private MobileElement quickInfo_duration;

	@iOSXCUITFindBy(accessibility = "loc_txtDuration")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"loc_txtDuration, \"]/android.widget.TextView")
	private MobileElement quickInfo_durationContent;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'LENGTH')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'LENGTH')]")
	private MobileElement audioLenght;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'FORMAT')]")
	@AndroidFindBy(xpath = "//*[contains(@content-desc,'FORMAT')]")
	private MobileElement audioFormat;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"loc_txtTextToSpeech\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtTextToSpeech']")
	private MobileElement quickInfo_textToSpeech;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement quickInfo_eReadAlong;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"loc_txtReleaseDate\"])[1]")
	@AndroidFindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"loc_txtReleaseDate, \"])[1]/android.widget.TextView")
	private MobileElement quickInfo_subjectText;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"loc_txtReleaseDate\"])[2]")
	@AndroidFindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"loc_txtReleaseDate, \"])[2]/android.widget.TextView")
	private MobileElement quickInfo_releaseDate;

	/********************* 146947 ***********************/

	@iOSXCUITFindBy(accessibility = "loc_btnRemoveHoldDrawer")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRemoveHoldDrawer']")
	private MobileElement Drawer_RemoveHold;

	@iOSXCUITFindBy(accessibility = "loc_btnWishlistDrawer")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnWishlistDrawer']")
	private MobileElement Drawer_Wishlist;

	@iOSXCUITFindBy(accessibility = "loc_btnShareTitleDrawer")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnShareTitleDrawer']")
	private MobileElement Drawer_ShareTitle;

	@iOSXCUITFindBy(accessibility = "emptySpaceCloseAreaTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='emptySpaceCloseAreaTestId']")
	private MobileElement Drawer_emptySpaceCloseArea;

	/********************* 162631 ***********************/

	@iOSXCUITFindBy(accessibility = "primaryButtonTextTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='primaryButtonTestId']")
	private MobileElement titleDetails_btn_downloadTitle;

	@iOSXCUITFindBy(accessibility = "slideProgressID")
	@AndroidFindBy(xpath = "//*[@resource-id='slideProgressID']")
	private MobileElement titleDetails_btn_downloadProgressBar;

	@iOSXCUITFindBy(accessibility = "Read Online")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"Read Online, \"]")
	private MobileElement titleDetails_btn_readOnline;

	@iOSXCUITFindBy(accessibility = "loc_btnContinueReadOnline")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnContinueReadOnline']")
	private MobileElement titleDetails_btn_continueReadOnline;

	@iOSXCUITFindBy(accessibility = "option2TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='option2TestId']")
	private MobileElement titleDetails_btn_renew;

	@iOSXCUITFindBy(accessibility = "option1TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='option1TestId']")
	private MobileElement titleDetails_btn_return;

	@iOSXCUITFindBy(accessibility = "loc_txtReturnPopUpConfirmation")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtReturnPopUpConfirmation']")
	private MobileElement titleDetails_btn_returnConfirmation;

	@iOSXCUITFindBy(accessibility = "loc_txtRenewPopUpConfirmation")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtRenewPopUpConfirmation']")
	private MobileElement titleDetails_btn_renewConfirmation;

	@iOSXCUITFindBy(accessibility = "option1TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='option1TestId']")
	private MobileElement titleDetails_btn_removeDownload;

	@iOSXCUITFindBy(accessibility = "ALERT_TITLE")
	@AndroidFindBy(xpath = "//*[@resource-id='ALERT_TITLE']")
	private MobileElement titleDetails_msg_removeDownload;

	@iOSXCUITFindBy(accessibility = "yesButtonConfirmPopUpAlertCTATestId")
	@AndroidFindBy(xpath = "//*[@resource-id='yesButtonConfirmPopUpAlertCTATestId']")
	private MobileElement titleDetails_btn_removeDownloadYesConf;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Removing the title will delete the download from your device. Are you sure you want to Remove?']\"]")
	@AndroidFindBy(xpath = "//*[@text='Removing the title will delete the download from your device. Are you sure you want to Remove?']")
	private MobileElement titleDetails_lbl_removeConfirmationMsg;

	@iOSXCUITFindBy(accessibility = "reading-area")
	@AndroidFindBy(xpath = "//*[@resource-id='reading-area']")
	private MobileElement titleDetails_lbl_pdfOnlinePage;

	@iOSXCUITFindBy(xpath = "page01")
	@AndroidFindBy(xpath = "//android.widget.RelativeLayout/android.widget.ImageView")
	private MobileElement titleDetails_lbl_playerOnlinePage;

	/********************* 159581 ***********************/

	@iOSXCUITFindBy(accessibility = "btnPurchaseRequest")
	@AndroidFindBy(xpath = "//*[@resource-id='btnPurchaseRequest']")
	private MobileElement myShelf_btn_purchaseReqFilter;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Purchase RequestsPage\"]")
	@AndroidFindBy(xpath = "//*[@text='PURCHASE REQUESTS']")
	private MobileElement myShelf_lbl_purchaseReqResultScreen;

	@iOSXCUITFindBy(accessibility = "mystuffListView2")
	@AndroidFindBy(xpath = "//*[@resource-id='mystuffListView0']")
	private MobileElement myShelf_lbl_purchaseReqBookList;

	@iOSXCUITFindBy(accessibility = "Cancel Request")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"Cancel Request, \"]/android.widget.TextView")
	private MobileElement myShelf_btn_cancelReqDrawer;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Your purchase request has been sent to the library for consideration.\"]")
	@AndroidFindBy(xpath = "//*[@text='Your purchase request has been sent to the library for consideration.']")
	private MobileElement myShelf_lbl_purchaseReqSuccessMsg;

	/********************* 159582 ***********************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"The library has reached its daily checkout limit.  Please add items to your Wishlist and return later to check out.\"]")
	@AndroidFindBy(xpath = "//*[@text='The library has reached its daily checkout limit.  Please add items to your Wishlist and return later to check out.']")
	private MobileElement titleDetails_lbl_checkoutLimitMsg;

	/********************* 160258 ***********************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Your checkout could not be completed. Please try again.\"]")
	@AndroidFindBy(xpath = "//*[@text='Your checkout could not be completed. Please try again.']")
	private MobileElement titleDetails_lbl_checkoutFailMsg;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Title could not be added to Wishlist. Please try again.\"]")
	@AndroidFindBy(xpath = "//*[@text='Title could not be added to Wishlist. Please try again.']")
	private MobileElement titleDetails_lbl_wishlistFailMsg;

	@iOSXCUITFindBy(accessibility = "option0TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='option0TestId']")
	private MobileElement titleDetails_btn_listenNow;

	@iOSXCUITFindBy(accessibility = "option0TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='option0TestId']")
	private MobileElement titleDetails_btn_readNow;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"We're having trouble retrieving your title.  If this issue continues, please Remove the title and re-download.\"]")
	@AndroidFindBy(xpath = "//*[@text='We're having trouble retrieving your title.  If this issue continues, please Remove the title and re-download.']")
	private MobileElement titleDetails_lbl_readAndListenNowFailMsg;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Your download could not be completed. Please try again.\"]")
	@AndroidFindBy(xpath = "//*[@text='Your download could not be completed. Please try again.']")
	private MobileElement titleDetails_lbl_downloadFailMsg;

	@iOSXCUITFindBy(accessibility = "yesButtonConfirmPopUpAlertCTATestId")
	@AndroidFindBy(xpath = "//*[@resource-id='yesButtonConfirmPopUpAlertCTATestId']")
	private MobileElement titleDetails_btn_removeYesConfirmation;

	@iOSXCUITFindBy(accessibility = "noButtonConfirmPopUpAlertCTATestId")
	@AndroidFindBy(xpath = "//*[@resource-id='noButtonConfirmPopUpAlertCTATestId']")
	private MobileElement titleDetails_btn_removeNoConfirmation;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"The title could not be removed. Please try again.\"]")
	@AndroidFindBy(xpath = "//*[@text='The title could not be removed. Please try again.']")
	private MobileElement titleDetails_btn_removeFailMsg;

	@iOSXCUITFindBy(accessibility = "downloadPlayID")
	@AndroidFindBy(xpath = "//*[@resource-id='downloadPlayID']")
	private MobileElement titleDetails_btn_pauseDownloadTitle;

	@iOSXCUITFindBy(accessibility = "//XCUIElementTypeOther[@name=\"\"]")
	@AndroidFindBy(xpath = "//*[@text='']")
	private MobileElement titleDetails_btn_pauseDownloadFailMsg;

	@iOSXCUITFindBy(accessibility = "resetDownloadCountID")
	@AndroidFindBy(xpath = "//*[@resource-id='resetDownloadCountID']")
	private MobileElement titleDetails_btn_cancelDownloadTitle;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"\"]")
	@AndroidFindBy(xpath = "//*[@text='']")
	private MobileElement titleDetails_btn_cancelDownloadFailMsg;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Title was not returned. Please try again.\"]")
	@AndroidFindBy(xpath = "//*[@text='Title was not returned. Please try again.']")
	private MobileElement titleDetails_lbl_returnFailMsg;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Title was not renewed. Please try again.\"]")
	@AndroidFindBy(xpath = "//*[@text='Title was not renewed. Please try again.']")
	private MobileElement titleDetails_lbl_renewFailMsg;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"loc_btnCheckout\"]")
	@AndroidFindBy(xpath = "//*[@text='Place Hold']")
	private MobileElement titleDetails_btn_placeOnHold;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Hold was not completed. Please try again.\"]")
	@AndroidFindBy(xpath = "//*[@text='Hold was not completed. Please try again.']")
	private MobileElement titleDetails_lbl_placeOnHoldFailMsg;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Your hold was not removed. Please try again.\"]")
	@AndroidFindBy(xpath = "//*[@text='Your hold was not removed. Please try again.']")
	private MobileElement titleDetails_lbl_removeHoldFailMsg;

	@iOSXCUITFindBy(accessibility = "option0TestId")
	@AndroidFindBy(xpath = "//*[@resource-id='option0TestId']")
	private MobileElement titleDetails_btn_suspendHold;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Suspend hold was not completed. Please try again.\"]")
	@AndroidFindBy(xpath = "//*[@text='Suspend hold was not completed. Please try again.']")
	private MobileElement titleDetails_lbl_suspendHoldFailMsg;

	@iOSXCUITFindBy(accessibility = "primaryButtonTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='primaryButtonTestId']")
	private MobileElement titleDetails_btn_reactivateHold;

	@iOSXCUITFindBy(accessibility = "primaryButtonTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='primaryButtonTestId']")
	private MobileElement titleDetails_btn_removeHold;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Reactivation of hold did not complete. Please try again.\"]")
	@AndroidFindBy(xpath = "//*[@text='Reactivation of hold did not complete. Please try again.']")
	private MobileElement titleDetails_lbl_reactivateHoldFailMsg;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Title was not removed from Wishlist. Please try again.\"]")
	@AndroidFindBy(xpath = "//*[@text='Title was not removed from Wishlist. Please try again.']")
	private MobileElement titleDetails_lbl_removeWishlistFailMsg;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Your purchase request has been sent to the library for consideration.\"]")
	@AndroidFindBy(xpath = "//*[@text='Your purchase request has been sent to the library for consideration.']")
	private MobileElement titleDetails_lbl_purchaseReqSuccessMsg;

	@iOSXCUITFindBy(accessibility = "loc_btnCheckout")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnCheckout']")
	private MobileElement titleDetails_btn_cancelPurchaseReq;

	@iOSXCUITFindBy(accessibility = "loc_btnCheckout")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnCheckout']")
	private MobileElement purchaseRequestButton;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Cancellation of your purchase request was not completed. Please try again.\"]")
	@AndroidFindBy(xpath = "//*[@text='Cancellation of your purchase request was not completed. Please try again.']")
	private MobileElement titleDetails_lbl_purchaseReqCancelFailMsg;

	/********************* 164678 ***********************/

	@iOSXCUITFindBy(accessibility = "loc_imgLACardCoverImage")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_imgLACardCoverImage']")
	private MobileElement titleDetails_lbl_LACoverImage;

	@iOSXCUITFindBy(accessibility = "loc_txtLearningResourceName")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtLearningResourceName']")
	private MobileElement titleDetails_lbl_LATitle;

	@iOSXCUITFindBy(accessibility = "loc_txtLearningResourceType")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtLearningResourceType']")
	private MobileElement titleDetails_lbl_LAType;

	@iOSXCUITFindBy(accessibility = "cardTestID")
	@AndroidFindBy(xpath = "//*[@resource-id='cardTestID']")
	private MobileElement titleDetails_btn_LACard;

	@iOSXCUITFindBy(accessibility = "loc_btnDownload]")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnDownload']")
	private MobileElement titleDetails_btn_LADownload;

	@iOSXCUITFindBy(accessibility = "loc_btnPauseDownload")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnPauseDownload']")
	private MobileElement titleDetails_btn_LAPauseDownload;

	@iOSXCUITFindBy(accessibility = "loc_btnResumeDownload")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnResumeDownload']")
	private MobileElement titleDetails_btn_LAResumeDownload;

	@iOSXCUITFindBy(accessibility = "loc_btnStopDownload")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnStopDownload']")
	private MobileElement titleDetails_btn_LAStopDownload;

	@iOSXCUITFindBy(accessibility = "slideProgressTestID")
	@AndroidFindBy(xpath = "//*[@resource-id='slideProgressTestID']")
	private MobileElement titleDetails_btn_LADownloadProgressBar;

	/********************* 160319 ***********************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"See You are in Line\"]")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"See You are in Line, \"]/android.widget.TextView") // loc_txtEstimatedWaitTime
	private MobileElement titleDetails_lbl_estimateWaitTimeEbook;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"See You are in Line\"]")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"See You are in Line, \"]/android.widget.TextView") // loc_txtEstimatedWaitTime
	private MobileElement titleDetails_lbl_estimateWaitTimeAudioBook;

	/********************* 166291 ***********************/

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'AUDIENCE')]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentAUDIENCETestId']")
	private MobileElement titleDetails_lbl_audienceText;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'AGE RANGE')]")
	@AndroidFindBy(xpath = "//*[@resource-id='detailsContentAGERANGETestId']")
	private MobileElement titleDetails_lbl_ageLevel;

	@iOSXCUITFindBy(accessibility = "link_AUDIENCE")
	@AndroidFindBy(xpath = "//*[@resource-id='link_AUDIENCE']")
	private MobileElement titleDetails_lbl_audienceValue;

	@iOSXCUITFindBy(accessibility = "link_AGE RANGE")
	@AndroidFindBy(xpath = "//*[@resource-id='link_AGE RANGE']")
	private MobileElement titleDetails_lbl_ageValue;

	@iOSXCUITFindBy(accessibility = "loc_txtAudience loc_txtAge")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"loc_txtAudience loc_txtAge\"]")
	private MobileElement quickInfo_lbl_audienceText;

	@iOSXCUITFindBy(accessibility = "loc_txtAge")
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"loc_txtAge, \"]")
	private MobileElement quickInfo_lbl_ageLevel;

	/********************* 163362 ***********************/

	@iOSXCUITFindBy(accessibility = "updateEmailPopupCloseButtonTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='updateEmailPopupCloseButtonTestId']")
	private MobileElement titleDetails_btn_closeUpdateEmail;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Update Your Email\"]")
	@AndroidFindBy(xpath = "//*[@text='Update Your Email']")
	private MobileElement updateEmail_txt_notificationPopup;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Please enter a valid email address that can be used to notify you when the title is available for checkout.\"]")
	@AndroidFindBy(xpath = "//*[@text='Please enter a valid email address that can be used to notify you when the title is available for checkout.']")
	private MobileElement updateEmail_txt_shortDescription;

	@iOSXCUITFindBy(accessibility = "loc_txtDetailsCountReview")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtDetailsCountReview']")
	private MobileElement reviews_list;

	@iOSXCUITFindBy(accessibility = "loc_btnDetailsWriteReview")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnDetailsWriteReview']")
	private MobileElement write_review;

	@iOSXCUITFindBy(accessibility = "updateEmailPopupEmailInputTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='updateEmailPopupEmailInputTestId']")
	private MobileElement updateEmail_txt_emailAddress;

	@iOSXCUITFindBy(accessibility = "updateEmailPopupConfirmEmailInputTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='updateEmailPopupConfirmEmailInputTestId']")
	private MobileElement updateEmail_txt_confirmEmailAddress;

	@iOSXCUITFindBy(accessibility = "updateEmailPopupSubmitButtonTestId")
	@AndroidFindBy(xpath = "//*[@resource-id='updateEmailPopupSubmitButtonTestId']")
	private MobileElement updateEmail_btn_okButton;

	@iOSXCUITFindBy(accessibility = "Invalid Format")
	@AndroidFindBy(xpath = "//*[@text='Please Enter Valid Email Address']")
	private MobileElement updateEmail_txt_invalidEmailErrorMessage;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Email Addresses Do Not Match\"]")
	@AndroidFindBy(xpath = "//*[@text='Please Enter Valid Confirm Email Address']")
	private MobileElement updateEmail_txt_notMatchEmailErrorMessage;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "(//android.view.View[@content-desc=\"See All, \"])[2]/android.view.View")
	private MobileElement seeAllTeenChevronIcon;

	@iOSXCUITFindBy(accessibility = "LIBRARY_FILTER_FORMAT")
	@AndroidFindBy(xpath = "//*[@resource-id='LIBRARY_FILTER_FORMAT']")
	private MobileElement libraryFilterFolmat;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"eAudio, \"]")
	private MobileElement libraryFilterAudioBook;

	@iOSXCUITFindBy(xpath = "message_snackbar_view")
	@AndroidFindBy(xpath = "//*[@resource-id='message_snackbar_view']")
	private MobileElement toastMessageUpdateEmail;

	@iOSXCUITFindBy(accessibility = "btnHold")
	@AndroidFindBy(xpath = "//*[@resource-id='btnHold']")
	private MobileElement myShelf_btn_holdsFilter;

	@iOSXCUITFindBy(accessibility = "mystuffListView0")
	@AndroidFindBy(xpath = "//*[@resource-id='mystuffListView0']")
	private MobileElement myShelf_lbl_holdsBookList;

	@iOSXCUITFindBy(accessibility = "btnAlertOkay")
	@AndroidFindBy(xpath = "//*[@resource-id='btnAlertOkay']")
	public MobileElement returnConfirmation;

	@iOSXCUITFindBy(xpath = "(//*[@name='Details'])[2]")
	@AndroidFindBy(xpath = "//*[@text='Details']")
	public MobileElement detailsTab;

	@iOSXCUITFindBy(accessibility = "loc_txtLearningResourceDesc")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_txtLearningResourceDesc']")
	public MobileElement resourceDesc;

	@iOSXCUITFindBy(accessibility = "loc_btnLearningLearnMore")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnLearningLearnMore']")
	public MobileElement resourceSeeAll;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersIcon']")
	public MobileElement resourceRefine;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersSortExpandIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnRefinersSortExpandIcon']")
	public MobileElement resourceFilterSortby;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersActivityExpandIcon")
	@AndroidFindBy(xpath = "//*[@resource-id = 'loc_btnRefinersActivityExpandIcon']")
	public MobileElement resourceFilterType;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersAudienceExpandIcon")
	@AndroidFindBy(xpath = "//*[@resource-id = 'loc_btnRefinersAudienceExpandIcon']")
	public MobileElement resourceFilterAudience;

	@iOSXCUITFindBy(accessibility = "Linked Title,Radio Button selected")
	@AndroidFindBy(xpath = "//*[contains(@content-desc, 'Linked Title, selected')]")
	public MobileElement resourceFilterLinkedtitle;

	@iOSXCUITFindBy(accessibility = "CheckBox-All")
	@AndroidFindBy(xpath = "//*[@resource-id = 'CheckBox-All']")
	public MobileElement resourceFilterTypeAll;

	@iOSXCUITFindBy(accessibility = "CheckBox-Educator Guides")
	@AndroidFindBy(xpath = "//*[@resource-id = 'CheckBox-Educator Guides']")
	public MobileElement resourceFilterEducatorGuides;

	@iOSXCUITFindBy(accessibility = "CheckBox-Activities")
	@AndroidFindBy(xpath = "//*[@resource-id = 'CheckBox-Activities']")
	public MobileElement resourceFilterActivities;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Teen')]")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'Teen')]")
	public MobileElement resourceFilterAudienceTeen;

	@iOSXCUITFindBy(accessibility = "loc_btnRefinersViewResults")
	@AndroidFindBy(xpath = "//*[@resource-id = 'loc_btnRefinersViewResults']")
	public MobileElement resourceFilterSearch;

	@iOSXCUITFindBy(accessibility = "loc_btnClearRefiners")
	@AndroidFindBy(xpath = "//*[@resource-id = 'loc_btnClearRefiners']")
	public MobileElement resourceFilterReset;

	@iOSXCUITFindBy(xpath = "(//*[contains(@label,'Activities')])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@name,'Activities')])[1]")
	public MobileElement resourcePillActivities;

	@iOSXCUITFindBy(xpath = "(//*[contains(@label,'Educator Guides')])[1]")
	@AndroidFindBy(xpath = "(//*[contains(@name,'Educator Guides')])[1]")
	public MobileElement resourcePillEducator;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Teen')]")
	@AndroidFindBy(xpath = "//*[contains(@name,'Teen')]")
	public MobileElement resourcePillTeen;

	@iOSXCUITFindBy(xpath = "//*[contains(@label,'Clear All Button')]")
	@AndroidFindBy(xpath = "//*[contains(@name,'Clear All Button')]")
	public MobileElement resourcePillClearAll;

	@iOSXCUITFindBy(xpath = "(//*[@name='ratingCTATestId'])[1]")
	@AndroidFindBy(xpath = "(//*[@name='ratingCTATestId'])[1]")
	private MobileElement starRating;

	@iOSXCUITFindBy(xpath = "(//*[@name='Chrome'])[1]")
	@AndroidFindBy(xpath = "(//*[@name='Chrome'])[1]")
	private MobileElement shareChromeOption;

	@iOSXCUITFindBy(xpath = "(//*[@name='Messages'])[1]")
	@AndroidFindBy(xpath = "(//*[@name='Messages'])[1]")
	private MobileElement messagesShareOption;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement alternateFormats;

	@iOSXCUITFindBy(xpath = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement LearningResources;

	@iOSXCUITFindBy(accessibility = "banner")
	@AndroidFindBy(xpath = "//*[@resource-id='app-navbar']")
	private MobileElement readerBanner;

	@iOSXCUITFindBy(accessibility = "close player")
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Close']")
	private MobileElement eAudioReader;

	@iOSXCUITFindBy(accessibility = "Back Button")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBack']")
	private MobileElement readerBackBtn;

	public MobileElement gettitleDetails_lbl_title() {
		return titleDetails_lbl_title;
	}

	public MobileElement getsubtitle() {
		return titleDetails_lbl_subtitle;
	}

	public MobileElement getebookFormatIcon() {
		return titleDetails_lbl_ebookFormatIcon;
	}

	public MobileElement getaudiobookFormatIcon() {
		return titleDetails_lbl_audioBookFormatIcon;
	}

	public MobileElement getimageCover() {
		return titleDetails_lbl_imageCover;
	}

	public MobileElement getdefaultimageCover() {
		return titleDetails_lbl_defaultimageCover;
	}

	public MobileElement getWishlist() {
		return titleDetails_btn_WishlistIcon;
	}

	public MobileElement getToastMessageRemoveWishlist() {
		return titleDetails_lbl_ToastMessageRemoveWishlist;
	}

	public MobileElement getToastMessageAddWishlist() {
		return titleDetails_lbl_ToastMessageAddWishlist;
	}

	public MobileElement getShareCTA() {
		return titleDetails_btn_ShareCTA;
	}

	public MobileElement getCheckoutCTA() {
		return titleDetails_btn_PrimaryCTA;
	}

	public MobileElement getSecondaryDropdownCTA() {
		return titleDetails_btn_SecondaryCTA;
	}

	public void clickSecondaryDropdownCTA() {
		ClickOnMobileElement(titleDetails_btn_SecondaryCTA);
	}

	public MobileElement gettitleDetails_lbl_titleReadingProgress() {
		return titleDetails_lbl_titleReadingProgress;

	}

	public MobileElement getSynopsis() {
		return titleDetails_lbl_Synopsis;

	}

	public MobileElement getViewAllCTA() {
		return titleDetails_btn_ViewAllCTA;

	}

	public MobileElement getdetailsTab() {
		return titleDetails_lbl_detailsTab;
	}

	public MobileElement getRecommendation() {
		return titleDetails_lbl_recommendation;
	}

	public MobileElement getLearningActivities() {
		return titleDetails_lbl_learningActivities;
	}

	public MobileElement getWriteReviewDetailsTab() {
		return detailsTab_btn_WriteReview;
	}

	public MobileElement getAuthorDetailsTab() {
		return detailsTab_lbl_author;
	}

	public MobileElement getAuthorName() {
		return titleDetails_lbl_authorName;
	}

	public MobileElement getAuthorNameCTA() {
		return titleDetails_btn_authorName;
	}

	public MobileElement getAuthorSearchResultScreen() {
		return titleDetails_lbl_AuthorSearchResultScreen;
	}

	public MobileElement getSeriesDetailsTab() {
		return detailsTab_lbl_series;
	}

	public MobileElement getSeriesName() {
		return detailsTab_btn_seriesCTA;
	}

	public MobileElement getFormatDetailsTab() {
		return detailsTab_lbl_Format;
	}

	public MobileElement getLanguageDetailsTab() {
		return detailsTab_lbl_Language;

	}

	public MobileElement getPublisherDetailsTab() {
		return detailsTab_lbl_Publisher;

	}

	public MobileElement getPublishDateDetails() {
		return detailsTab_lbl_PublishDate;

	}

	public MobileElement getISBNDetailsTab() {
		return detailsTab_lbl_ISBN;

	}

	public MobileElement getAvailableCopy() {
		return titleDetails_lbl_availableCopy;
	}

	public MobileElement getPatronOnHold() {
		return detaislTab_lbl_countPatronOnHold;
	}

	public MobileElement getHoldPosition() {
		return detailsTab_lbl_patronOnHoldPositionName;
	}

	public MobileElement getHoldPositionToolTip() {
		return detailsTab_btn_holdPositionToolTip;
	}

	public MobileElement getToolTipVerbiage() {
		return detailsTab_txt_toolTipVerbiage;
	}

	public MobileElement getToolTipVerbiageClose() {
		return detailsTab_txt_toolTipVerbiageClose;
	}

	public MobileElement getSubjectDetails() {
		return detailsTab_subjectText;
	}

	public MobileElement getLevelOneSubject() {
		return btn_lvl1Subject;
	}

	public MobileElement getLevelTwoSubject() {
		return btn_lvl2Subject;
	}

	public MobileElement getNarratorName() {
		return titleDetails_lbl_narratorName;
	}

	public MobileElement getNarratorNameCTA() {
		return titleDetails_btn_narratorName;
	}

	public MobileElement getNarratorSearchResultScreen() {
		return titleDetails_lbl_NarratorSearchResultScreen;
	}

	public MobileElement getEdition() {
		return detailsTab_lbl_edition;
	}

	public MobileElement getLength() {
		return detailsTab_lbl_length;
	}

	public MobileElement getAttribute() {
		return detailsTab_lbl_Attribute;
	}

	public MobileElement getNoOfPageAttribute() {
		return detailsTab_lbl_noOfPagesAttribute;
	}

	public MobileElement getTitleFileSize() {
		return detailsTab_lbl_titleFileSize;
	}

	public MobileElement getNoRecommendationText() {
		return moreLikeThisTab_lbl_noRecommendationText;
	}

	public MobileElement getRecommendationTitleCard() {
		return moreLikeThisTab_btn_recommendedTitleCard;
	}

	public MobileElement getTitleFormatIcon() {
		return quickInfo_TitleFormatIcon;
	}

	public MobileElement getDuration() {
		return quickInfo_duration;
	}

	public MobileElement getProfileIcon() {
		return quickInfo_profileIcon;
	}

	public MobileElement getAgeIcon() {
		return quickInfo_ageIcon;
	}

	public MobileElement getLanguageIcon() {
		return quickInfo_languageIcon;
	}

	public MobileElement getNoOfPages() {
		return quickInfo_noOfPages;
	}

	public MobileElement getTextToSpeech() {
		return quickInfo_textToSpeech;
	}

	public MobileElement geteReadAlong() {
		return quickInfo_eReadAlong;
	}

	public MobileElement getSubjectText() {
		return quickInfo_subjectText;
	}

	public MobileElement getReleaseDate() {
		return quickInfo_releaseDate;
	}

	public MobileElement getBackButton() {
		return titleDetails_btn_BackButton;
	}

	public MobileElement getTitleSeries() {
		return titleDetails_lbl_titleSeries;
	}

	public MobileElement getTitleSeriesCard() {
		return titleDetails_lbl_titleSeriesCard;
	}

	public MobileElement getDownloadTitle() {
		return titleDetails_btn_downloadTitle;
	}

	public MobileElement getDownloadProgressBar() {
		return titleDetails_btn_downloadProgressBar;
	}

	public MobileElement getContinueRead() {
		return titleDetails_btn_continueReadOnline;
	}

	public MobileElement getShareTitle() {
		return Drawer_ShareTitle;
	}

	public MobileElement getRenewBtn() {
		return titleDetails_btn_renew;
	}

	public MobileElement getReturnBtn() {
		return titleDetails_btn_return;
	}

	public MobileElement checkReadOnlineBtn() {
		return titleDetails_btn_readOnline;
	}

	public MobileElement clickReturnConfirmation() {
		return returnConfirmation;
	}

	public MobileElement getReturnConfirmation() {
		return titleDetails_btn_returnConfirmation;
	}

	public MobileElement getRenewConfirmation() {
		return titleDetails_btn_renewConfirmation;
	}

	public MobileElement getRemoveDownload() {
		return titleDetails_btn_removeDownload;
	}

	public MobileElement getRemoveConfirmation() {
		return titleDetails_lbl_removeConfirmationMsg;
	}

	public MobileElement getCheckoutFailMsg() {
		return titleDetails_lbl_checkoutFailMsg;
	}

	public MobileElement getWishlistFailMsg() {
		return titleDetails_lbl_wishlistFailMsg;
	}

	public MobileElement getListenNowBtn() {
		return titleDetails_btn_listenNow;
	}

	public MobileElement getReadNowBtn() {
		return titleDetails_btn_readNow;
	}

	public MobileElement getReadNowFailMsg() {
		return titleDetails_lbl_readAndListenNowFailMsg;
	}

	public MobileElement getDownloadFailMsg() {
		return titleDetails_lbl_downloadFailMsg;
	}

	public MobileElement getRemoveConfirmationMsg() {
		return titleDetails_lbl_removeConfirmationMsg;
	}

	public MobileElement getRemoveYesConfirmation() {
		return titleDetails_btn_removeYesConfirmation;
	}

	public MobileElement getRemoveNoConfirmation() {
		return titleDetails_btn_removeNoConfirmation;
	}

	public MobileElement getRemoveFailMsg() {
		return titleDetails_btn_removeFailMsg;
	}

	public MobileElement getPauseDownload() {
		return titleDetails_btn_pauseDownloadTitle;
	}

	public MobileElement getPauseDownloadFailMsg() {
		return titleDetails_btn_pauseDownloadFailMsg;
	}

	public MobileElement getCancelDownload() {
		return titleDetails_btn_cancelDownloadTitle;
	}

	public MobileElement getCancelDownloadFailMsg() {
		return titleDetails_btn_cancelDownloadFailMsg;
	}

	public MobileElement getReturnFailMsg() {
		return titleDetails_lbl_returnFailMsg;
	}

	public MobileElement getRenewFailMsg() {
		return titleDetails_lbl_renewFailMsg;
	}

	public MobileElement getPlaceOnHoldBtn() {
		return titleDetails_btn_placeOnHold;
	}

	public MobileElement getPlaceOnHoldFailMsg() {
		return titleDetails_lbl_placeOnHoldFailMsg;
	}

	public MobileElement getRemoveHoldBtnDrawer() {
		return Drawer_RemoveHold;
	}

	public MobileElement getRemoveHoldFailMsg() {
		return titleDetails_lbl_removeHoldFailMsg;
	}

	public MobileElement getSuspendHoldBtn() {
		return titleDetails_btn_suspendHold;
	}

	public void clickSuspendHoldBtn() {
		ClickOnMobileElement(titleDetails_btn_suspendHold);
	}

	public MobileElement getSuspendHoldFailMsg() {
		return titleDetails_lbl_suspendHoldFailMsg;
	}

	public MobileElement getReactivateHoldBtn() {
		return titleDetails_btn_reactivateHold;
	}

	public MobileElement getRemoveHoldBtn() {
		return titleDetails_btn_removeHold;
	}

	public MobileElement getReactivateHoldFailMsg() {
		return titleDetails_lbl_reactivateHoldFailMsg;
	}

	public MobileElement getRemoveWishlistFailMsg() {
		return titleDetails_lbl_removeWishlistFailMsg;
	}

	public MobileElement getPurchaseReqSuccessMsg() {
		return titleDetails_lbl_purchaseReqSuccessMsg;
	}

	public MobileElement getCancelPurchaseReqBtn() {
		return titleDetails_btn_cancelPurchaseReq;
	}

	public void clickPurchaseRequest() {
		ClickOnMobileElement(purchaseRequestButton);
	}

	public MobileElement getPurchaseReqCancelFailMsg() {
		return titleDetails_lbl_purchaseReqCancelFailMsg;
	}

	public MobileElement getLACoverImage() {
		return titleDetails_lbl_LACoverImage;
	}

	public MobileElement getLATitle() {
		return titleDetails_lbl_LATitle;
	}

	public MobileElement getLAType() {
		return titleDetails_lbl_LAType;
	}

	public MobileElement getLACard() {
		return titleDetails_btn_LACard;
	}

	public MobileElement getLADownload() {
		return titleDetails_btn_LADownload;
	}

	public MobileElement getLAStopDownload() {
		return titleDetails_btn_LAStopDownload;
	}

	public MobileElement getEstimateWaitTimeAudioBook() {
		return titleDetails_lbl_estimateWaitTimeAudioBook;
	}

	public MobileElement getAudienceText() {
		return titleDetails_lbl_audienceText;
	}

	public MobileElement getAgeRangeText() {
		return titleDetails_lbl_ageLevel;
	}

	public MobileElement getAudienceValue() {
		return titleDetails_lbl_audienceValue;
	}

	public MobileElement getAgeRangeValue() {
		return titleDetails_lbl_ageValue;
	}

	public MobileElement getButtonCloseUpdateEmail() {
		return titleDetails_btn_closeUpdateEmail;
	}

	public MobileElement getButtonCloseWishListToastMassage() {
		return titleDetails_lbl_WishlistCloseToastMessage;
	}

	public MobileElement getNotificationPopup() {
		return updateEmail_txt_notificationPopup;
	}

	public MobileElement getShortDescription() {
		return updateEmail_txt_shortDescription;
	}

	public MobileElement getReviews() {
		return reviews_list;
	}

	public MobileElement getWriteReview() {
		return write_review;
	}

	public MobileElement getEmailAddress() {
		return updateEmail_txt_emailAddress;
	}

	public MobileElement getConfirmEmailAddress() {
		return updateEmail_txt_confirmEmailAddress;
	}

	public MobileElement getOkButton() {
		return updateEmail_btn_okButton;
	}

	public MobileElement getDrawerWishlist() {
		return Drawer_Wishlist;
	}

	public MobileElement getTitleDetailsReadingProgress() {
		return titleDetails_lbl_titleReadingProgress;
	}

	public MobileElement getPurchaseReqFilter() {
		return myShelf_btn_purchaseReqFilter;
	}

	public MobileElement getPurchaseReqResultScreen() {
		return myShelf_lbl_purchaseReqResultScreen;
	}

	public MobileElement getCancelReqDrawer() {
		return myShelf_btn_cancelReqDrawer;
	}

	public MobileElement getRemoveDownloadConfPopup() {
		return titleDetails_msg_removeDownload;
	}

	public MobileElement getRemoveDownloadYesConf() {
		return titleDetails_btn_removeDownloadYesConf;
	}

	public MobileElement getHoldsFilter() {
		return myShelf_btn_holdsFilter;
	}

	public MobileElement getHoldsBookList() {
		return myShelf_lbl_holdsBookList;
	}

	public MobileElement getCloseUpdateEmail() {
		return titleDetails_btn_closeUpdateEmail;
	}

	/********************* Actions ***********************/

	public MobileElement scrollToEbook() {

		return titledetails_btn_titleCardEbook12;
	}

	public void scrollAndTapeBook1() {
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(8000);
			swipeDown();
			waitFor(1000);
			swipeDown();
			waitFor(1000);
			swipeDown();
			waitFor(1000);
			swipeDown();
			waitFor(1000);
			swipeDown();
			waitFor(1000);
			swipeDown();
			waitFor(1000);
			ClickOnMobileElement(titledetails_btn_titleCardEbook);
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(8000);
			swipeDown();
			waitFor(1000);
			swipeDown();
			swipeDown();
			waitFor(1000);
			swipeDown();
			swipeDown();
			waitFor(1000);
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardEbook);
		}
	}

	public void scrollAndTapeBook() {
		if (isElementPresent(ebook_view_prm)) {
			ClickOnMobileElement(ebook_view_prm);
		}

		if (isElementPresent(ebook_title)) {
			ClickOnMobileElement(ebook_title);
			logger.info("eBook is available");
		} else {
			logger.info("eBook is not available");
		}
	}

	public void scrollAndTapeBooknotrated() {
		if (isElementPresent(ebook_view_prm)) {
			ClickOnMobileElement(ebook_view_prm);
		}
		waitFor(5000);

		if (isElementPresent(ebook_title1)) {
			ClickOnMobileElement(ebook_title1);
			logger.info("eBook is not rated");
		} else {
			logger.info("eBook is not available");
		}
	}

	public void scrollAndTapeBookhasreview() {
		if (isElementPresent(ebook_view_prm)) {
			ClickOnMobileElement(ebook_view_prm);
		}

		if (isElementPresent(ebook_title2)) {
			ClickOnMobileElement(ebook_title2);
			logger.info("eBook has review");
		} else {
			logger.info("eBook has no review");
		}
	}

	public void clickDetailstab() {
		waitFor(5000);
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"Details\"))"));
			if (isElementPresent(Click_Details)) {
				ClickOnMobileElement(Click_Details);
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("ios")) {
			swipeDown();
			swipeDown();
//			swipeDown();
//			swipeDown();
			if (isElementPresent(Click_Details)) {
				ClickOnMobileElement(Click_Details);
			}
		}
	}

	public Boolean scrollAndTapAudioBook() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(5000);
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"SEP21 LIST\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardAudioBook);
				logger.info("Audio Book is available");
			} else {
				book = false;
				logger.info("Audio Book is not available");
			}

		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(10000);
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardAudioBook);
		}
		return book;
	}

	public void scrollAndTapToolTip() throws Exception {
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(5000);
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"ENG\"))"));
		} else {
			swipeUp();
			swipeUp();
		}
	}

	public Boolean scrollAndTapeBookWithCheckout() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"CURATED LIST12\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardEbook);
				logger.info("eBook is available");
			} else {
				book = false;
				logger.info("eBook is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardEbook);
		}
		return book;
	}

	public Boolean scrollAndTapAudioBookWithCheckout() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"NON-FICTION\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardAudioBook);
				logger.info("Audio Book is available");
			} else {
				book = false;
				logger.info("Audio Book is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardAudioBook);
		}
		return book;
	}

	public void clickAudioTitle() {
		ClickOnMobileElement(titledetails_btn_titleCardAudioBook);
	}

	public Boolean scrollAndTapeBookWithReadNow() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"TEENS\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardEbook1);
				logger.info("eBook is available");
			} else {
				book = false;
				logger.info("eBook is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardEbook1);
		}
		return book;
	}

	public Boolean scrollAndTapAudioBookWithListenNow() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"NON-FICTION\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardAudioBook1);
				logger.info("Audio Book is available");
			} else {
				book = false;
				logger.info("Audio Book is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardAudioBook1);
		}
		return book;
	}

	public Boolean scrollAndTapeBookWithDownload() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"TEENS\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardEbook2);
				logger.info("eBook is available");
			} else {
				book = false;
				logger.info("eBook is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardEbook2);
		}
		return book;
	}

	public Boolean scrollAndTapAudioBookWithDownload() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"NON-FICTION\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardAudioBook2);
				logger.info("Audio Book is available");
			} else {
				book = false;
				logger.info("Audio Book is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardAudioBook2);
		}
		return book;
	}

	public Boolean scrollAndTapeBookWithPlaceHold() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"CHILDREN\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardEbook3);
				logger.info("eBook is available");
			} else {
				book = false;
				logger.info("eBook is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardEbook3);
		}
		return book;
	}

	public Boolean scrollAndTapAudioBookWithPlaceHold() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"CHILDREN\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardAudioBook3);
				logger.info("Audio Book is available");
			} else {
				book = false;
				logger.info("Audio Book is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardAudioBook3);
		}
		return book;
	}

	public Boolean scrollAndTapeBookWithSuspendHold() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"CURATED SEP30\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardEbook4);
				logger.info("eBook is available");
			} else {
				book = false;
				logger.info("eBook is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardEbook4);
		}
		return book;
	}

	public Boolean scrollAndTapAudioBookWithSuspendHold() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"CURATED SEP30\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardAudioBook4);
				logger.info("Audio Book is available");
			} else {
				book = false;
				logger.info("Audio Book is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardAudioBook4);
		}
		return book;
	}

	public Boolean scrollAndTapeBookWithActivateHold() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"TEENS\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardEbook5);
				logger.info("eBook is available");
			} else {
				book = false;
				logger.info("eBook is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardEbook5);
		}
		return book;
	}

	public Boolean scrollAndTapAudioBookWithActivateHold() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"NON-FICTION\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardAudioBook5);
				logger.info("Audio Book is available");
			} else {
				book = false;
				logger.info("Audio Book is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardAudioBook5);
		}
		return book;
	}

	public Boolean scrollAndTapeBookWithRemoveHold() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"LIST - ADULT\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardEbook5);
				logger.info("eBook is available");
			} else {
				book = false;
				logger.info("eBook is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardEbook5);
		}
		return book;
	}

	public Boolean scrollAndTapAudioBookWithRemoveHold() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"TEENS\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardAudioBook5);
				logger.info("Audio Book is available");
			} else {
				book = false;
				logger.info("Audio Book is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			ClickOnMobileElement(titledetails_btn_titleCardAudioBook5);
		}
		return book;
	}

	public Boolean scrollAndTapeBookWithLimit() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(5000);
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"TEENS\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardEbook6);
				logger.info("eBook is available");
			} else {
				book = false;
				logger.info("eBook is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			if (isElementPresent(titledetails_btn_titleCardEbook6)) {
				ClickOnMobileElement(titledetails_btn_titleCardEbook6);
			} else if (isElementPresent(titledetails_btn_titleCardEbook1)) {
				ClickOnMobileElement(titledetails_btn_titleCardEbook1);
			} else if (isElementPresent(titledetails_btn_titleCardEbook2)) {
				ClickOnMobileElement(titledetails_btn_titleCardEbook2);
			} else {
				book = false;
				logger.info("eBook is not available");
			}
		}
		return book;
	}

	public Boolean scrollAndTapAudioBookWithLimit() throws Exception {
		Boolean book = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			waitFor(5000);
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"TEENS\"))"));
			if (isElementPresent(findElement)) {
				ClickOnMobileElement(titledetails_btn_titleCardEbook6);
				logger.info("Audio Book is available");
			} else {
				book = false;
				logger.info("Audio Book is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			swipeDown();
			swipeDown();
			swipeDown();
			if (isElementPresent(titledetails_btn_titleCardAudioBook6)) {
				ClickOnMobileElement(titledetails_btn_titleCardAudioBook6);
			} else if (isElementPresent(titledetails_btn_titleCardAudioBook2)) {
				ClickOnMobileElement(titledetails_btn_titleCardAudioBook2);
			} else if (isElementPresent(titledetails_btn_titleCardAudioBook3)) {
				ClickOnMobileElement(titledetails_btn_titleCardAudioBook3);
			} else {
				book = false;
				logger.info("eBook is not available");
			}
		}
		return book;
	}

	public void verifyWishlist() {
		if (isElementPresent(titleDetails_btn_WishlistIcon)) {
			logger.info("user should be able to view Wishlist");
		} else {
			logger.info("user should not be able to view wishlist");
		}
	}

	public void ClickWishlist() {
		try {
			ClickOnMobileElement(titleDetails_btn_WishlistIcon);
		} catch (Exception e) {
			logger.info("Wishlist icon is not displayed");
		}
	}

	public void verifyAddMessageWishlist() {
		if (isElementPresent(titleDetails_lbl_ToastMessageAddWishlist)) {
			logger.info(
					"User should be able to view the confirmation toast message for adding title from the wishlist");
		} else {
			logger.info(
					"User should not be able to view the confirmation toast message for adding title from the wishlist");
		}
	}

	public void verifyRemoveMessageWishlist() {
		if (isElementPresent(titleDetails_lbl_ToastMessageRemoveWishlist)) {
			logger.info(
					"user should be able to view the confirmation toast message for removing title from the wishlist");
		} else {
			logger.info(
					"user should not be able to view the confirmation toast message for removing title from the wishlist");
		}
	}

	public void verifyShare() {
		if (isElementPresent(titleDetails_btn_ShareCTA)) {
			logger.info("user should be able to view share icon");
		} else {
			logger.info("user should not be able to view share icon");
		}
	}

	public void Clickshare() {
		try {
			ClickOnMobileElement(titleDetails_btn_ShareCTA);
			//swipeDown();
		} catch (Exception e) {
			logger.info("Share icon is not displayed");
		}
	}

	public void clickHoldTitle() {
		ClickOnMobileElement(titled_btn_titleCardEbook);
	}

	public void clickshareCloseIcon() {
//		if (isElementPresent(shareCloseIcon)) {
//			ClickOnMobileElement(shareCloseIcon);
//		}
		swipeUp();
	}

	public void getPrimaryCTA() {
		try {
			if (isElementPresent(titleDetails_btn_PrimaryCTA)) {
				logger.info("Primary CTA is displayed");
			} else if (isElementPresent(titleDetails_btn_PrimaryCTA1)) {
				logger.info("Primary CTA is displayed");
			}
		} catch (Exception e) {
			logger.info("Primary CTA is not displayed");
		}
	}

	public void clickActivateHold() {
		ClickOnMobileElement(ActiveHoldbtn);
	}

	public void clickRemoveHold() {
		ClickOnMobileElement(titleDetails_btn_PrimaryCTA1);
	}

	public String verifyCopiesLabelIsDisplayed() {
		String label = titleDetails_lbl_availableCopy.getText();
		System.out.println("Copy text displayed : " + label);
		return label;
	}

	public String verifyTitleIsDisplayed() {
		String title = titleDetails_lbl_title.getText();
		System.out.println("Book title displayed : " + title);
		return title;
	}

	public Boolean scrollToDetailsTab() {
		Boolean detailsTab = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"Details\"))"));
			if (isElementPresent(findElement)) {
				logger.info("Details tab is available");
			} else {
				detailsTab = false;
				logger.info("Details tab is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			swipeDown();
			swipeDown();
			if (isElementPresent(titleDetails_lbl_detailsTab)) {
				logger.info("Details tab is available");
			}
		}
		return detailsTab;
	}

	public void tapDetailsTab() {
		scrollToDetailsTab();
		ClickOnMobileElement(titleDetails_lbl_detailsTab);
	}

	public void tapDetailsSection() {
		ClickOnMobileElement(titleDetails_lbl_detailsTab);
	}

	public void tapOnRelatedItemsTab() {
		try {
			if (isElementPresent(titleDetails_btn_relatedItemTab)) {
				ClickOnMobileElement(titleDetails_btn_relatedItemTab);
			}
		} catch (Exception e) {
			logger.info("Related Items tab is not displayed");
		}
	}

	public void verifyNarratorName() {
		try {
			if (isElementPresent(detailsTab_lbl_narrator)) {
				logger.info("Narrator name is displayed");
			}
		} catch (Exception e) {
			logger.info("Narrator name is not displayed");
		}
	}

	public void verifySeriesIsDisplayed() {
		try {
			if (isElementPresent(detailsTab_lbl_series)) {
				logger.info("Series is displayed");
			}
		} catch (Exception e) {
			logger.info("Series is not displayed");
		}
	}

	public void verifyLengthIsDisplayed() {
		try {
			if (isElementPresent(detailsTab_lbl_length)) {
				logger.info("Length is displayed");
			}
		} catch (Exception e) {
			logger.info("Length is not displayed");
		}
	}

	public void verifyEditionIsDisplayed() {
		try {
			scrollToSubject();
			if (isElementPresent(detailsTab_lbl_edition)) {
				logger.info("Edition is displayed");
			}
		} catch (Exception e) {
			logger.info("Edition is not displayed");
		}
	}

	public void verifyAttributeIsDisplayed() {
		try {
			scrollToSubject();
			if (isElementPresent(detailsTab_lbl_Attribute)) {
				logger.info("Attribute is displayed");
			}
		} catch (Exception e) {
			logger.info("Attribute is not displayed");
		}
	}

	public void verifyAudienceIsDisplayed() {
		try {
			scrollToSubject();
			if (isElementPresent(detailsTab_lbl_Audience)) {
				logger.info("Audience is displayed");
			}
		} catch (Exception e) {
			logger.info("Audience is not displayed");
		}
	}

	public void verifyToolTipIsDisplayed() {
		try {
			if (isElementPresent(detailsTab_btn_holdPositionToolTip)) {
				logger.info("Tool tip is displayed");
			}
		} catch (Exception e) {

			logger.info("Tool tip is not displayed");

		}
	}

	public void tapToolTip() {
		try {
			ClickOnMobileElement(detailsTab_btn_holdPositionToolTip);
		} catch (Exception e) {
			logger.info("Tool tip button is not displayed");
		}
	}

	public void verifyToolTipVerbiageIsDisplayed() {
		try {
			ClickOnMobileElement(detailsTab_txt_toolTipVerbiage);
		} catch (Exception e) {
			logger.info("Tooltip Verbiage is not displayed");
		}
	}

	public Boolean scrollToPublisher() {
		Boolean publisher = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"PUBLISHER\"))"));
			if (isElementPresent(findElement)) {
				logger.info("Publisher is available");
			} else {
				publisher = false;
				logger.info("Publisher is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			swipeDown();
			if (isElementPresent(detailsTab_lbl_Publisher)) {
				logger.info("Publisher is available");
			}
		}
		return publisher;

	}

	public Boolean scrollToSubject() {
		Boolean subject = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"SUBJECT\"))"));
			if (isElementPresent(findElement)) {
				logger.info("Subject is available");
			} else {
				subject = false;
				logger.info("Subject is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			swipeDown();
			if (isElementPresent(detailsTab_subjectText)) {
				logger.info("Subject is available");
			}
		}
		return subject;

	}

	public String verifyDurationFormat() {
		String duration = quickInfo_durationContent.getText();
		System.out.println("Duration format : " + duration);
		return duration;
	}

	public MobileElement checkAudioLength() {
		return audioLenght;
	}

	public MobileElement checkAudioFronat() {
		return audioFormat;
	}

	public void verifyRecommendedTitle() {
		if (isElementPresent(moreLikeThisTab_btn_recommendedTitleCard)) {
			logger.info("Title recommendation is displayed");
		} else if (isElementPresent(moreLikeThisTab_lbl_noRecommendationText)) {
			logger.info("No Recommendation text is displayed");
		}
	}

	public void swipeLeftCard() {
		swipeleft(titledetails_container);
	}

	public void swipeRightCard() {
		swiperight(titledetails_container);
	}

	public void swipeRightFirstCard() {
		swiperight(titledetails_container);
		swiperight(titledetails_container);
		swiperight(titledetails_container);
	}

	public void swipeLeftLastCard() {
		swipeleft(titledetails_container);
		swipeleft(titledetails_container);
		swipeleft(titledetails_container);
	}

	public void swiperight(MobileElement e) {
		Dimension dimension = DriverManager.getDriver().manage().window().getSize();
		int scrollStart = (int) (dimension.getWidth() * 0.4);
		int scrollEnd = (int) (dimension.getWidth() * 0.8);
		int y = (int) (dimension.getHeight() / 2);
		new TouchAction((PerformsTouchActions) DriverManager.getDriver()).press(PointOption.point(scrollStart, y))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(scrollEnd, y))
				.release().perform();
	}

	public Boolean scrollToSynopsis() {
		Boolean synopsis = true;
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			MobileElement findElement = (MobileElement) DriverManager.getDriver()
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
							+ ".scrollIntoView(new UiSelector().text(\"Synopsis\"))"));
			if (isElementPresent(findElement)) {
				logger.info("Synopsis is available");
			} else {
				synopsis = false;
				logger.info("Synopsis is not available");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			swipeDown();
			swipeDown();
			if (isElementPresent(titleDetails_lbl_Synopsis)) {
				logger.info("Synopsis is available");
			}
		}
		return synopsis;
	}

	public void verifySynopsis() {
		try {
			scrollToSynopsis();
		} catch (Exception e) {
			logger.info("Synopsis is not available");
		}
	}

	public Boolean verifySeeMore() {
		Boolean book = true;
		if (isElementPresent(titleDetails_btn_ViewAllCTA)) {
			ClickOnMobileElement(titleDetails_btn_ViewAllCTA);
			logger.info("user should be able to view 'View all' cta to view complete synopsis");
		} else {
			book = false;
			logger.info("View all cta is not available");
		}
		return book;
	}

	public Boolean ClickSeeMore() {
		Boolean book = true;
		if (isElementPresent(titleDetails_btn_ViewAllCTA)) {
			ClickOnMobileElement(titleDetails_btn_ViewAllCTA);
			logger.info("user should be able to click on 'See More' cta to view complete synopsis");
		} else {
			book = false;
			logger.info("See More button is not displayed");
		}
		return book;
	}

	public String verifyAgeLevelContent() {
		String label = quickInfo_lbl_ageLevel.getText();
		System.out.println("Age Level text displayed : " + label);
		return label;
	}

	public String verifyAudienceTextIsDisplayed() {
		String label = quickInfo_lbl_audienceText.getText();
		System.out.println("Audience text displayed : " + label);
		return label;
	}

	public void getSecondaryCTA() {
		try {
			if (isElementPresent(titleDetails_btn_WishlistIcon) && (isElementPresent(titleDetails_btn_ShareCTA))) {
				logger.info("Wishlist and Share button is displayed");
			} else if (isElementPresent(titleDetails_btn_SecondaryCTA)) {
				logger.info("Dropdown button is displayed");
			}
		} catch (Exception e) {
			logger.info("Secondary Action is not displayed");
		}
	}

	public void clickPlaceHold() {
		if (isElementPresent(titleDetails_btn_PrimaryCTA1)) {
			ClickOnMobileElement(titleDetails_btn_PrimaryCTA1);
		} else {
			ClickOnMobileElement(purchaseRequestButton);
			ClickOnMobileElement(titleDetails_btn_PrimaryCTA1);

		}

	}

	public void clickWishList() {
		try {
			ClickOnMobileElement(titleDetails_btn_WishlistIcon);
		} catch (Exception e) {
			logger.info("Wishlist button is not displayed");
		}
	}

	public void verifyQuickInfoTextToSpeech() {
		waitFor(2000);
		swipeDown();
		try {
			if (isElementPresent(quickInfo_textToSpeech)) {
				logger.info("Text to speech is displayed");
			}
		} catch (Exception e) {

			logger.info("Text to speech is not displayed");

		}
	}

	public void clickCloseUpdateEmail() {
		ClickOnMobileElement(titleDetails_btn_closeUpdateEmail);
	}

	public void closeToastMessageWishList() {
		try {
			ClickOnMobileElement(titleDetails_lbl_WishlistCloseToastMessage);
		} catch (Exception e) {
			logger.info("Close Button Wishlist Toast Message is not displayed");
		}
	}

	public void getShareCTAButton() {
		try {
			isElementPresent(titleDetails_btn_ShareCTA);

		} catch (Exception e) {
			logger.info("share CTA button is not displayed");
		}
	}

	public void getPurchaseReqBookList() {
		try {
			isElementPresent(myShelf_lbl_purchaseReqBookList);

		} catch (Exception e) {
			logger.info("purchase request book is displayed");
		}
	}

	public void clickPurchaseReqBookList() {
		try {
			ClickOnMobileElement(myShelf_lbl_purchaseReqBookList);

		} catch (Exception e) {
			logger.info("purchase request book is not displayed");
		}
	}

	public void getCheckoutFail() {
		try {
			isElementPresent(titleDetails_lbl_checkoutFailMsg);
		} catch (Exception e) {
			logger.info("Checkout fail is not displayed");
		}
	}

	public void getWishlistFail() {
		try {
			if (isElementPresent(titleDetails_lbl_wishlistFailMsg)) {
			}
		} catch (Exception e) {
			logger.info("wishlish fail is not displayed");
		}
	}

	public void getDownloadButton() {
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			try {
				if (isElementPresent(titleDetails_btn_PrimaryCTA)) {
					ClickOnMobileElement(titleDetails_btn_PrimaryCTA);
					WaitForMobileElement(titleDetails_btn_pauseDownloadTitle);
//					ClickOnMobileElement(titleDetails_btn_pauseDownloadTitle);
					ClickOnMobileElement(titleDetails_btn_cancelDownloadTitle);
//		        	if(isElementPresent(titleDetails_lbl_pdfOnlinePage)) {
//		        		waitFor(5000);
//		        	}
//		        	else {
//		        		isElementPresent(titleDetails_lbl_playerOnlinePage);
//		        		waitFor(5000);
//		        	}
				} else {
					ClickOnMobileElement(titleDetails_btn_downloadTitle);
					waitFor(15000);
					if (isElementPresent(titleDetails_lbl_pdfOnlinePage)) {
						waitFor(5000);
						androidKeyBack();
					} else {
						isElementPresent(titleDetails_lbl_playerOnlinePage);
						waitFor(5000);
						androidKeyBack();
					}
				}
			} catch (Exception e) {
				logger.info("Download button is not displayed");
			}
		} else if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			waitFor(5000);
			try {
				if (isElementPresent(titleDetails_btn_PrimaryCTA)) {
					ClickOnMobileElement(titleDetails_btn_PrimaryCTA);
					WaitForMobileElement(titleDetails_btn_cancelDownloadTitle);
					ClickOnMobileElement(titleDetails_btn_pauseDownloadTitle);
					ClickOnMobileElement(titleDetails_btn_cancelDownloadTitle);
//		        	if(isElementPresent(titleDetails_lbl_pdfOnlinePage)) {
//		        		waitFor(5000);
//		        	}
//		        	else {
//		        		isElementPresent(titleDetails_lbl_playerOnlinePage);
//		        		waitFor(5000);
//		        	}
				} else {
					ClickOnMobileElement(titleDetails_btn_downloadTitle);
					waitFor(15000);
					if (isElementPresent(titleDetails_lbl_pdfOnlinePage)) {
						waitFor(5000);
					} else {
						isElementPresent(titleDetails_lbl_playerOnlinePage);
						waitFor(5000);
					}
				}
			} catch (Exception e) {
				logger.info("Download button is not displayed");
			}
		}

	}

	public void getPatronOnHoldSection() {
		try {
			if (isElementPresent(detaislTab_lbl_countPatronOnHold)) {
				logger.info("Patron on hold is displayed");
			}
		} catch (Exception e) {
			logger.info("Patron on hold is not displayed");
		}
	}

	public void getEstimateWaitTime() {
		try {
			if (isElementPresent(titleDetails_lbl_estimateWaitTimeEbook)) {
				ClickOnMobileElement(detailsTab_btn_holdPositionToolTip);
				ClickOnMobileElement(detailsTab_txt_toolTipVerbiageClose);
				ClickOnMobileElement(getBackButton());
			}
		} catch (Exception e) {
			logger.info("Estimate wait time is not displayed");
		}
	}

	public void getSeriesListScreen() {
		try {
			if (isElementPresent(detailsTab_lbl_seriesListScreen)) {
				ClickOnMobileElement(getBackButton());
			}
		} catch (Exception e) {
			logger.info("Series list screen is not displayed");
		}
	}

	public void getReturnRenewShareButton() {
		try {
			if (isElementPresent(getSecondaryDropdownCTA())) {
				ClickOnMobileElement(getSecondaryDropdownCTA());
				isElementPresent(getReturnBtn());
//				isElementPresent(getRenewBtn());
				isElementPresent(getShareTitle());
				ClickOnMobileElement(Drawer_emptySpaceCloseArea);
			}
		} catch (Exception e) {
			logger.info("Return Renew Share are not displayed");
		}
	}

	public void getLADownloadProgressBar() {
		try {
			if (isElementPresent(titleDetails_btn_LADownloadProgressBar)) {
				logger.info("Progress Bar is displayed");
			}
		} catch (Exception e) {
			logger.info("Progress Bar is not displayed");
		}
	}

	public void getLAPauseDownload() {
		try {
			if (isElementPresent(titleDetails_btn_LAPauseDownload)) {
				logger.info("Pause Button is displayed");
			}
		} catch (Exception e) {
			logger.info("Pause Button is not displayed");
		}
	}

	public void getLAResumeDownload() {
		try {
			if (isElementPresent(titleDetails_btn_LAResumeDownload)) {
				logger.info("Resume Button is displayed");
			}
		} catch (Exception e) {
			logger.info("Resume Button is not displayed");
		}
	}

	public void getCheckoutLimitMsg() {
		try {
			if (isElementPresent(titleDetails_lbl_checkoutLimitMsg)) {
				logger.info("Checkout Limit Message is displayed");
			}
		} catch (Exception e) {
			logger.info("Checkout Limit Message is not displayed");
		}
	}

	public void clickOnAuthorName() {
		try {
			if (isElementPresent(titleDetails_btn_authorName)) {
				ClickOnMobileElement(titleDetails_btn_authorName);
				waitFor(5000);
			}
		} catch (Exception e) {
			logger.info("Author Name is not displayed");
		}
	}

	public void clickOnNarratorName() {
		try {
			if (isElementPresent(titleDetails_btn_narratorName)) {
				ClickOnMobileElement(titleDetails_btn_narratorName);
				waitFor(5000);
			}
		} catch (Exception e) {
			logger.info("Narrator Name is not displayed");
		}
	}

	public void getAudienceQuickText() {
		try {
			if (isElementPresent(quickInfo_lbl_audienceText)) {
				logger.info("Audience in QuickInfo not displayed");
			}
		} catch (Exception e) {
			logger.info("Audience in QuickInfo is not displayed");
		}
	}

	public void getAgeRangeQuickText() {
		try {
			if (isElementPresent(quickInfo_lbl_ageLevel)) {
				logger.info("Age in QuickInfo not displayed");
			}
		} catch (Exception e) {
			logger.info("Age in QuickInfo is not displayed");
		}
	}

	public void getReadOnline() {
		try {
			if (isElementPresent(titleDetails_btn_readOnline)) {
				ClickOnMobileElement(titleDetails_btn_readOnline);
				if (isElementPresent(titleDetails_lbl_pdfOnlinePage)) {
					waitFor(5000);
					androidKeyBack();
				}
			}
		} catch (Exception e) {
			logger.info("Read Now button is not displayed");
		}
	}

	public void findTheAudioBook() {
		ClickOnMobileElement(libraryFilterFolmat);
		ClickOnMobileElement(libraryFilterAudioBook);
		waitFor(10000);
	}

	public void enterValidEmailUpdate(String validemail) {
		ClickOnMobileElement(updateEmail_txt_emailAddress);
		SendKeysOnMobileElement(updateEmail_txt_emailAddress, validemail);
	}

	public void enterInvalidEmailUpdate(String invalidemail) {
		ClickOnMobileElement(updateEmail_txt_emailAddress);
		SendKeysOnMobileElement(updateEmail_txt_emailAddress, invalidemail);
	}

	public void enterValidConfirmEmailUpdate(String validemail) {
		ClickOnMobileElement(updateEmail_txt_confirmEmailAddress);
		SendKeysOnMobileElement(updateEmail_txt_confirmEmailAddress, validemail);
		hideMobileKeyboard();
	}

	public void enterInvalidConfirmEmailUpdate(String invalidemail) {
		ClickOnMobileElement(updateEmail_txt_confirmEmailAddress);
		SendKeysOnMobileElement(updateEmail_txt_confirmEmailAddress, invalidemail);
		hideMobileKeyboard();
	}

	public void getInvalidErrorMessage() {
		try {
			if (isElementPresent(updateEmail_txt_invalidEmailErrorMessage)) {
			}
		} catch (Exception e) {
			logger.info("Invalid Address Error Message is not displayed");
		}
	}

	public void getNotMatchErrorMessage() {
		try {
			if (isElementPresent(updateEmail_txt_notMatchEmailErrorMessage)) {
			}
		} catch (Exception e) {
			logger.info("Not Match Address Error Message is not displayed");
		}
	}

	public void getToastMessageUpdateSuccess() {
		try {
			if (isElementPresent(toastMessageUpdateEmail)) {
				logger.info("Success Update Email Toast Message is displayed");
			}
		} catch (Exception e) {
			logger.info("Success Update Email Toast Message is not displayed");
		}
	}

	public void tapBookWithRemoveHold() {
		waitFor(5000);
		myshelf.clickMyself();
		ClickOnMobileElement(getHoldsFilter());
		clickHoldsBookList();
	}

	public void clickHoldsBookList() {
		try {
			ClickOnMobileElement(getHoldsBookList());

		} catch (Exception e) {
			logger.info("holds book listis not displayed");
		}
	}

	public void getmoreLikethisTab() {
		try {
			isElementPresent(titleDetails_btn_moreLikethisTab);
			logger.info("More Like This tab is displayed");
		} catch (Exception e) {
			logger.info("More Like This tab not displayed");
		}
	}

	public void verifyMoreLikeThisTab(){
		for(int i=0;i<8;i++) {
			if(isElementPresent(moreLikeThisTab)) {
				swipeDown();
				break;
			}
			else {
				swipeDown();
			}
		}
		ClickOnMobileElement(moreLikeThisTab);


	}
	public  void verifyTitleInThisSeries(){
		try {
			isElementPresent(titleDetails_lbl_recommendation);
		}
		catch (NoSuchElementException e){
			logger.info("No recommened titles availabe");
		}
	}

	public void verifyOtherTitlesLikeThis(){
		try {
			isElementPresent(titleDetails_lbl_recommendation);
		}
		catch (NoSuchElementException e){
			logger.info("No recommened titles availabe");
		}
	}

	public void getRelatedItemTab() {
		try {
			isElementPresent(titleDetails_btn_relatedItemTab);
			logger.info("Related Items tab is displayed");
		} catch (Exception e) {
			logger.info("Related Items tab is not displayed");
		}
	}

	public void getLibraryReadingProgress() {
		try {
			if (isElementPresent(library_btn_titleReadingProgress)) {
				ClickOnMobileElement(library_btn_titleReadingProgress);
				waitFor(5000);
				isElementPresent(titleDetails_lbl_titleReadingProgress);
			}
		} catch (Exception e) {
			logger.info("Reading Progress is not displayed");
		}
	}

	public void selectAvailableNowTitles() {
		ClickOnMobileElement(availabilityDropdown);
		ClickOnMobileElement(availableOption);
	}

	public void selecteBookTitles() {
		ClickOnMobileElement(formatDropDown);
		ClickOnMobileElement(eBookOption);
	}

	public void selecteAudioTitles() {
		ClickOnMobileElement(formatDropDown);
		ClickOnMobileElement(eAudioOption);
	}

	public void clickEbbook() {
		for(int i=0;i<12;i++)
		{
			if(isElementPresent(Featured))
			{
				swipeDown();
				break;
			}else
			{
				swipeDown();
			}
		}
		ClickOnMobileElement(scrollToEbook());
	}
	
	
//		for (int i = 0; i < 6; i++) {
//			if (isElementPresent(scrollToEbook().get(0))) {
//				ClickOnMobileElement(scrollToEbook().get(0));
//				break;
//			} else {
//				swipeDown();
//			}
//		}

	public void scrollToAuthor() {
		for(int i=0;i<5;i++)
		{
			if(isElementPresent(detailsTab_lbl_Format))
			{
				swipeDown();
				break;
			}else {
		
	}
}
	}

	public void clickSeeAllEBookCuratedList() {
		for(int i=0;i<8;i++) {
			if(isElementPresent(eBookSeeAllCuratedList)) {
				swipeDown();
				break;
			}
			else {
				swipeDown();
			}
		}
		ClickOnMobileElement(eBookSeeAllCuratedList);
	}

	public MobileElement detailsTab() {
		return detailsTab;
	}
	public void clickDetailsTab(){

	}

	public MobileElement resoruceDesc() {
		return resourceDesc;
	}

	public MobileElement resourceHubSeeAll() {
		return resourceSeeAll;
	}

	public void scrollToResourceHubSeeall() {
		for (int i = 0; i < 5; i++) {
			if (isElementPresent(resourceSeeAll)) {
				break;
			} else {
				swipeDown();
			}
		}
	}

	public void clickResourceHubSeeAll() {
		swipeDown();
		ClickOnMobileElement(resourceSeeAll);
	}

	public MobileElement resourceHubRefine() {
		return resourceRefine;
	}

	public void clickResourceHubRefine() {
		ClickOnMobileElement(resourceRefine);
	}

	public MobileElement resourceFilterSortby() {
		return resourceFilterSortby;
	}

	public MobileElement resourceFilterType() {
		return resourceFilterType;
	}

	public MobileElement resourceFilterAudience() {
		return resourceFilterAudience;
	}

	public void clickResourceFilterSortby() {
		ClickOnMobileElement(resourceFilterSortby);
	}

	public void clickResourceFilterType() {
		ClickOnMobileElement(resourceFilterType);
	}

	public void clickResourceFilterAudience() {
		ClickOnMobileElement(resourceFilterAudience);
	}

	public MobileElement resourceFilterLinkedtitlee() {
		return resourceFilterLinkedtitle;
	}

	public void clickResourceFilterTypeAll() {
		ClickOnMobileElement(resourceFilterTypeAll);
	}

	public void clickResourceFilterTypeEducator() {
		ClickOnMobileElement(resourceFilterEducatorGuides);
	}

	public void clickResourceFilterAudienceTeen() {
		ClickOnMobileElement(resourceFilterAudienceTeen);
	}

	public void clickResourceFilterSearch() {
		ClickOnMobileElement(resourceFilterSearch);
	}

	public void clickResourceFilterReset() {
		ClickOnMobileElement(resourceFilterReset);
	}

	public void clickResourceFilterTypeActivities() {
		ClickOnMobileElement(resourceFilterActivities);
	}

	public MobileElement resourcePillActivities() {
		return resourcePillActivities;
	}

	public MobileElement resourcePillEducator() {
		return resourcePillEducator;
	}

	public MobileElement resourcePillTeen() {
		return resourcePillTeen;
	}

	public MobileElement resourcePillClearAll() {
		return resourcePillClearAll;
	}

	public void clickResourcePillClearAll() {
		ClickOnMobileElement(resourcePillClearAll);
	}

	public MobileElement verifystarRating(){
		Assert.assertTrue(isElementPresent(starRating));
		return starRating;
	}

	public MobileElement verifyShareChromeOption(){
		isElementPresent(shareChromeOption);
		return shareChromeOption;
	}

	public MobileElement verifyMessagesShareOption(){
		isElementPresent(messagesShareOption);
		return messagesShareOption;
	}

	public void verifyAlternateFormats() {
		try {
        isElementPresent(alternateFormats);
		}catch (NoSuchElementException e){
			logger.info("Alternate formats not available for this title");
		}
	}

	public void verifyLearningResources() {
		try {
			isElementPresent(LearningResources);
		}catch (NoSuchElementException e){
			logger.info("Learning Resources not availabe for this title");
		}
	}
	public MobileElement getReaderBanner(){return readerBanner;}

	public MobileElement getReaderBackBtn(){
		return readerBackBtn;
	}

	public MobileElement getEAdudioReader(){return eAudioReader;}

	public void closeAudioReader(){ClickOnMobileElement(eAudioReader);}
}
	
