package pom.kidszone;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class SelectLibrary extends CommonActions {

    public static final Logger logger = LoggerFactory.getLogger(SelectLibrary.class);

	public SelectLibrary(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@AndroidFindBy(id = "search_field")
	public MobileElement selectlibrary_inp_searchfield;

	@AndroidFindBy(id = "find_your_lib")
	public MobileElement selectlibrary_txt_searchfield;

	@AndroidFindBy(id = "search_imgvw")
	public MobileElement selectlibrary_icon_search;

	@AndroidFindBy(id = "error_text_view")
	public MobileElement selectlibrary_txt_searchresultmessage;

	@AndroidFindBy(id = "values_text_vw")
	public MobileElement selectlibrary_txt_listoflibrary;

	public String search_feield() {
		String librarypage = selectlibrary_txt_searchfield.getText();
		// Assert.assertTrue(librarypage, true);
		return librarypage;
	}

	public void enter_invalidCharacters(String invalidcharacters) {
		SendKeysOnMobileElementList(selectlibrary_inp_searchfield, invalidcharacters);	
	}

	public void enter_search() {
		try {
			ClickOnMobileElement(selectlibrary_icon_search);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	

	public void enter_branchLibrary(String branchlibrary) {
		try {
			SendKeysOnMobileElementList(selectlibrary_inp_searchfield, branchlibrary);
		} catch (Exception e) {
			e.printStackTrace();
		}
		enter_search();
		waitFor(2000);
	}

}
