package pom.kidszone;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.reusableMethods.CommonActions;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class MyProgram extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	public MyProgram(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);

	}

	@iOSXCUITFindBy(accessibility = "PROGRAMS")
	@AndroidFindBy(xpath = "//*[@resource-id='PROGRAMS']")
	private MobileElement navigation_bottommenu_programs;

	@iOSXCUITFindBy(accessibility = "Programs")
	@AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"Programs\"]")
	private MobileElement navigation_bottommenu_programs1;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeLink[@name=\"myProgram\"]")
	@AndroidFindBy(xpath = "//*[@content-desc='My Programs']")
	private MobileElement my_Programs_hdr;

	@iOSXCUITFindBy(accessibility = "myProgram")
	@AndroidFindBy(xpath = "//*[@resource-id ='myProgram']")
	private MobileElement my_Programs_hdr_old;

	@iOSXCUITFindBy(accessibility = "noReadingProgramLable")
	@AndroidFindBy(xpath = "//*[@resource-id='noReadingProgramLable']")
	private MobileElement no_reading_programs;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"No Reading Programs Yet\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='openProgramNoReadingProgram']")
	private MobileElement no_reading_programs1;

	@iOSXCUITFindBy(accessibility = "All Programs")
	@AndroidFindBy(xpath = "//*[@resource-id ='All Programs']")
	private MobileElement open_programs_hdr;

	@iOSXCUITFindBy(accessibility = "openProgram")
	@AndroidFindBy(xpath = "//*[@resource-id ='openProgram']")
	private MobileElement open_programs_hdr_old;
	
	@iOSXCUITFindBy(accessibility = "onGoingProgramList0")
	@AndroidFindBy(xpath = "//*[@resource-id='onGoingProgramList0']")
	private MobileElement program_name;

	@iOSXCUITFindBy(accessibility = "START DATE")
	@AndroidFindBy(xpath = "//*[@resource-id='start_date']")
	private MobileElement program_details_startdate;

	@iOSXCUITFindBy(accessibility = "onGoingProgramList")
	@AndroidFindBy(xpath = "//*[@resource-id='onGoingProgramList']")
	private MobileElement Ongoing_prg;

	@iOSXCUITFindBy(accessibility = "activeProgramList0")
	@AndroidFindBy(xpath = "//*[@resource-id='activeProgramList0']")
	private MobileElement active_program_hdr;

	@iOSXCUITFindBy(accessibility = "END DATE")
	@AndroidFindBy(xpath = "//*[@resource-id='end_date']")
	private MobileElement program_details_enddate;

	@iOSXCUITFindBy(accessibility = "ok_button")
	@AndroidFindBy(xpath = "//*[@resource-id='ok_button']")
	public MobileElement confirm_ok;

	@iOSXCUITFindBy(xpath = "//*[@label='Yes']")
	@AndroidFindBy(xpath = "//*[@text='Yes']")
	public MobileElement confirm_Button;

	@iOSXCUITFindBy(accessibility = "cancel_button")
	@AndroidFindBy(xpath = "//*[@resource-id='cancel_button']")
	private MobileElement confirm_cancel;

	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='noReadingProgram']")
	private MobileElement MyProgramNoReadingProgram;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "(//*[@resource-id='programTitle'])[1]")
	private MobileElement Upcoming_program_name_hdr;

	@iOSXCUITFindBy(accessibility = "Join Program")
	@AndroidFindBy(xpath = "//*[@resource-id='Join Program']")
	private MobileElement join_Program;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"end date\"])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='endDate']")
	private MobileElement program_end_date;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"start date\"])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='startDate']")
	private MobileElement program_start_date;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"In the Red Corner Book, \"]")
	private MobileElement Upcoming_program_name;

	@iOSXCUITFindBy(accessibility = "join_program")
	@AndroidFindBy(xpath = "//*[@resource-id='join_program']")
	private MobileElement join_program;
	
	@iOSXCUITFindBy(accessibility = "join_program")
	@AndroidFindBy(xpath = "//*[@resource-id='join_program']")
	private MobileElement remove_program;

	@iOSXCUITFindBy(accessibility = "onGoingProgramList0")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'onGoingProgramList0')]")
	private MobileElement onGoingProgramList;
	
	@iOSXCUITFindBy(accessibility = "Dummy")
	@AndroidFindBy(xpath = "//*[@resource-id='openProgramNoReadingProgram']")
	private MobileElement openProgramNoReadingProgram;

	@iOSXCUITFindBy(accessibility = "start_date")
	@AndroidFindBy(xpath = "//*[@resource-id='start_date']")
	private MobileElement open_prg_startDate;

	@iOSXCUITFindBy(accessibility = "end_date")
	@AndroidFindBy(xpath = "//*[@resource-id='end_date']")
	private MobileElement open_prg_endDate;

	@iOSXCUITFindBy(accessibility = "reading_list_title")
	@AndroidFindBy(xpath = "//*[@resource-id='reading_list_title']")
	private MobileElement reading_list_title;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Image_Cover\"])[2]")
	@AndroidFindBy(xpath = "//android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup")
	private MobileElement book_title_Details;

	@iOSXCUITFindBy(accessibility = "ALERT_MESSAGE")
	@AndroidFindBy(xpath = "//*[@resource-id='ALERT_MESSAGE']")
	private MobileElement confirm_alert_msg;

	@iOSXCUITFindBy(accessibility = "Started Button")
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Started Button, \"]")
	private MobileElement Started_button;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"progress bar\"])[1]")
	@AndroidFindBy(xpath = "//*[@resource-id='Program_type']")
	private MobileElement prg_progress_bar;

	@iOSXCUITFindBy(accessibility = "upcomingProgramList")
	@AndroidFindBy(xpath = "//*[@resource-id='upcomingProgramList']")
	private MobileElement upcomming_prg_list;

	@iOSXCUITFindBy(accessibility = "onGoingProgramList0")
	@AndroidFindBy(xpath = "//*[@resource-id='onGoingProgramList0']")
	private MobileElement ongoing_prg_list_prg;
	
	@iOSXCUITFindBy(accessibility = "upcomingProgramList0")
	@AndroidFindBy(xpath = "//*[@resource-id='upcomingProgramList0']")
	private MobileElement upcomming_prg_list_prg;

	@iOSXCUITFindBy(accessibility = "activeProgramList0")
	@AndroidFindBy(xpath = "//*[@resource-id='activeProgramList0']")
	private MobileElement active_prg_list_prg;

	@iOSXCUITFindBy(accessibility = "SeeAll_Button")
	@AndroidFindBy(xpath = "//*[@resource-id='SeeAll_Button']")
	private MobileElement seeAll_btn;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Leave Program\"]")
	@AndroidFindBy(xpath = "//*[@resource-id='message_snackbar_view']")
	private MobileElement leave_confirm_msg;
	
	@iOSXCUITFindBy(accessibility = "loc_btnWishlist")
	@AndroidFindBy(xpath = "//*[@resource-id='loc_btnWishlist']")
	private MobileElement primary_btn;
	
	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement back_CTA;
	
	public MobileElement getonGoingProgramList() {
		return onGoingProgramList;
	}
	
	public MobileElement getPrimary_btn() {
		return primary_btn;
	}


	public MobileElement getSeeAll_btn() {
		return seeAll_btn;
	}

	public MobileElement getActive_prg_list_prg() {
		return active_prg_list_prg;
	}

	public MobileElement getProgress_bar() {
		return prg_progress_bar;
	}

	public MobileElement getStarted_button() {
		return Started_button;
	}
	
	public MobileElement getConfirm_ok() {
		return confirm_ok;
	}
	public MobileElement getConfirm_cancel() {
		return confirm_cancel;
	}

	public MobileElement getReading_list_title() {
		return reading_list_title;
	}

	public MobileElement getOpen_prg_startDate() {
		return open_prg_startDate;
	}

	public MobileElement getOpen_prg_endDate() {
		return open_prg_endDate;
	}

	public MobileElement getUpcoming_program_name() {
		return Upcoming_program_name;
	}

	public MobileElement getProgram_start_date() {
		return program_start_date;
	}

	public MobileElement getProgram_end_date() {
		return program_end_date;
	}

	public MobileElement getJoin_program() {
		return join_program;
	}

	public MobileElement getUpcoming_program_name_hdr() {
		return Upcoming_program_name_hdr;
	}

	public MobileElement getProgram_name() {
		return program_name;
	}

	public MobileElement getNo_reading_programs() {
		return no_reading_programs;
	}

	public MobileElement getjoin_program() {
		return join_program;
	}

	public MobileElement getConfirm_alert_msg() {
		return confirm_alert_msg;
	}

	public MobileElement getOngoing_prg() {
		return Ongoing_prg;
	}

	public MobileElement getopenProgramNoReadingProgram() {
		return openProgramNoReadingProgram;
	}

	public MobileElement getMyProgramNoReadingProgram() {
		return MyProgramNoReadingProgram;
	}

	public MobileElement getActive_program_hdr() {
		return active_program_hdr;
	}

	public MobileElement getProgram_details_startdate() {
		return program_details_startdate;
	}

	public MobileElement getProgram_details_enddate() {
		return program_details_enddate;
	}

	public MobileElement getNo_reading_programs1() {
		return no_reading_programs1;
	}

	public void bookTitleDetails() {
		if (isElementPresent(book_title_Details)) {
			ClickOnMobileElement(book_title_Details);
		}
	}

	public void start_joinProgram() {
		if (isElementPresent(Started_button)) {
			ClickOnMobileElement(Started_button);
		}
	}

	public void navigateBackCTA()
	{
		if (isElementPresent(back_CTA)) {
			ClickOnMobileElement(back_CTA);
		}
	}
	
	public void ClickOnprogram()
	{
		if (isElementPresent(onGoingProgramList)) {
			ClickOnMobileElement(onGoingProgramList);
		}
	}
	public void clikMenuProgram() {
		if (isElementPresent(navigation_bottommenu_programs)) {
			ClickOnMobileElement(navigation_bottommenu_programs);
		} else {
			ClickOnMobileElement(navigation_bottommenu_programs1);
		}
	}

	public void clickmyProgram() {
		if (isElementPresent(my_Programs_hdr)) {
			ClickOnMobileElement(my_Programs_hdr);
		} else if (isElementPresent(my_Programs_hdr_old)) {
			ClickOnMobileElement(my_Programs_hdr_old);
		}
	}

	public void clickOpenProgram() {

		if(isElementPresent(open_programs_hdr_old))
		{
			ClickOnMobileElement(open_programs_hdr_old);
		}if(isElementPresent(active_program_hdr))
		{
		ClickOnMobileElement(active_program_hdr);
		}
	}

	public void clickActiveProgram()
	{
		ClickOnMobileElement(active_program_hdr);
	}

	public void navigateprgDetails() {
		if (isElementPresent(program_name)) {
			ClickOnMobileElement(program_name);
		}
		if(isElementPresent(upcomming_prg_list_prg))
		{
			ClickOnMobileElement(upcomming_prg_list_prg);
		}
		if(isElementPresent(ongoing_prg_list_prg))
		{
			ClickOnMobileElement(ongoing_prg_list_prg);
		}
		if (isElementPresent(active_program_hdr)) {
			ClickOnMobileElement(active_program_hdr);
		}

	}

	public void cancel_join_prg() {
		if (isElementPresent(confirm_cancel)) {
			ClickOnMobileElement(confirm_cancel);
		}
	}

	public void join_prg() {
		if(isElementPresent(confirm_ok))
		{
			ClickOnMobileElement(confirm_ok);
		}
	}

	public void ViewOpenprgDetails() {
		Upcoming_program_name_hdr.isDisplayed();

	}

	public void navigateJoin_program() {
		ClickOnMobileElement(join_program);
	}

	public void Clickjoin_program() {
		ClickOnMobileElement(join_program);
		if (isElementPresent(confirm_ok)) {
			ClickOnMobileElement(confirm_ok);
		}

	}

	public void confirmOK()
	{
		if(isElementPresent(confirm_Button)) {
			ClickOnMobileElement(confirm_Button);
		}

	}


	public boolean leaveconfirmMsg()
	{
		boolean confirmMsg=false;
		if(isElementPresent(leave_confirm_msg))
		{
			confirmMsg=true;
		}
		return confirmMsg;
	}
	public void Viewjoin_program() {
		ClickOnMobileElement(join_program);
	}

	public void ViewOpenprgname() {
		Upcoming_program_name.isDisplayed();

	}

	public void navigateupcommingPrg() {
		ScrollTo("scroll", "down", upcomming_prg_list);

	}

	public void navigateupcomingPrg() {
		ClickOnMobileElement(upcomming_prg_list_prg);
	}

	public void clickLeavePrg() {
		ClickOnMobileElement(remove_program);
		if (isElementPresent(confirm_ok)) {
			ClickOnMobileElement(confirm_ok);
		}
	}

	public void navigateactiveProgram() {
			ClickOnMobileElement(active_prg_list_prg);
	}

	

}
