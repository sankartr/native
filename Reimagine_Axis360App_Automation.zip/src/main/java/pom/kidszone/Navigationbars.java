package pom.kidszone;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.reusableMethods.CommonActions;
import com.utilities.ExcelReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class Navigationbars extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	public Navigationbars(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/******************* Locators **********************/

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label,'Menu')]")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU']")
	private MobileElement navigation_menu_librarymenu;

	@iOSXCUITFindBy(accessibility = "btnSearchMenu")
	@AndroidFindBy(xpath = "(//android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ImageView)[1]")
	private MobileElement navigation_icon_search;

	@iOSXCUITFindBy(accessibility = "btnAdvancedSearchMenu")
	@AndroidFindBy(xpath = "//*[@resource-id='btnAdvancedSearchMenu']")
	private MobileElement navigation_icon_Advancesearch;

	@iOSXCUITFindBy(accessibility = "btnSearchMenu")
	@AndroidFindBy(xpath = "//*[@resource-id='btnSearchMenu']")
	private MobileElement navigation_txt_searchBox;
	
	@iOSXCUITFindBy(accessibility = "SEARCH_TEXT_BOX")
	@AndroidFindBy(xpath = "//*[@resource-id='SEARCH_TEXT_BOX']")
	private MobileElement navigation_txt_library_searchBox;
	
	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private List<MobileElement> navigation_suggestion_Advancesearchlistofsuggestion;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "//*[@text='Close']")
	private MobileElement navigation_MyprofileCloseCta;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_close_AdvancesearchCloseCta;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_navHome_homepage;

	@iOSXCUITFindBy(accessibility = "dummy")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_bottomNavigation_navigationbar;

	@iOSXCUITFindBy(accessibility = "MENU_FLAT_LIST")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_topNavigation_navigationbar;
	
	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtTitle']")
	private MobileElement navigation_txt_Libraryname;

	@iOSXCUITFindBy(accessibility = "MYSHELF")
	@AndroidFindBy(xpath = "//*[@resource-id='MYSHELF']")
	private MobileElement navigation_bottommenu_myshelf;

	@iOSXCUITFindBy(accessibility = "txtHeaderCard")
	@AndroidFindBy(xpath = "//*[@text='GOALS & INSIGHTS']")
	private MobileElement navigation_navMyshelf_myshelfscreen;
	
	@iOSXCUITFindBy(accessibility = "MYLIBRARY")
	@AndroidFindBy(xpath = "//*[@resource-id='MYLIBRARY']")
	private MobileElement navigation_bottommenu_Library;
	
	@iOSXCUITFindBy(accessibility = "SEARCH_TEXT_BOX")
	@AndroidFindBy(xpath = "//*[@resource-id='SEARCH_TEXT_BOX']")
	private MobileElement navigation_navLib_libscreen;

	@iOSXCUITFindBy(accessibility = "BROWSE")
	@AndroidFindBy(xpath = "//*[@resource-id='BROWSE']")
	private MobileElement navigation_bottommenu_Browse;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Browse\"]")
	@AndroidFindBy(xpath = "(//*[@text='Browse'])[1]")
	private MobileElement navigation_navBrowse;

	@iOSXCUITFindBy(accessibility = "PROGRAMS")
	@AndroidFindBy(xpath = "//*[@resource-id='PROGRAMS']")
	private MobileElement navigation_bottommenu_programs;
	
	@iOSXCUITFindBy(accessibility = "My Programs")
	@AndroidFindBy(xpath = "(//*[@text='My Programs")
	private MobileElement navigation_navPrograms;

	@iOSXCUITFindBy(accessibility = "MENU")
	@AndroidFindBy(xpath = "//*[@resource-id='MENU']")
	private MobileElement navigation_bottommenu_menu;

	@iOSXCUITFindBy(accessibility = "txtTitle")
	@AndroidFindBy(xpath = "//*[@text='© 2022 Baker & Taylor']")
	private MobileElement navigation_navMenu_Menuscreen;
	
	@iOSXCUITFindBy(accessibility = "btnBackIcon")
	@AndroidFindBy(xpath = "//*[@resource-id='btnBackIcon']")
	private MobileElement navigation_img_avatarimg;

	@iOSXCUITFindBy(accessibility = "txtLibraryName")
	@AndroidFindBy(xpath = "//*[@resource-id='txtLibraryName']")
	private MobileElement myProfile_lbl_libName;

	@iOSXCUITFindBy(accessibility = "txtRightMenuTitle")
	@AndroidFindBy(xpath = "//*[@resource-id='txtRightMenuTitle']")
	private MobileElement navigation_icon_notification;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"txtRightMenuTitle\"]/XCUIElementTypeImage")
	@AndroidFindBy(xpath = "dummy")
	private MobileElement navigation_lbl_notificationcenter;
	
	public MobileElement getNavigation_icon_search() {
		return navigation_icon_search;
	}

	public MobileElement getNavigation_txt_Libraryname() {
		return navigation_txt_Libraryname;
	}

	public MobileElement getNavigation_topNavigation_navigationbar() {
		return navigation_topNavigation_navigationbar;
	}

	public MobileElement getNavigation_bottommenu_menu() {
		return navigation_bottommenu_menu;
	}

	public MobileElement getNavigation_bottommenu_programs() {
		return navigation_bottommenu_programs;
	}

	public MobileElement getNavigation_bottommenu_Browse() {
		return navigation_bottommenu_Browse;
	}

	public MobileElement getNavigation_bottommenu_Library() {
		return navigation_bottommenu_Library;
	}

	public MobileElement getNavigation_bottommenu_myshelf() {
		return navigation_bottommenu_myshelf;
	}

	public MobileElement getNavigation_bottomNavigation_navigationbar() {
		return navigation_bottomNavigation_navigationbar;
	}

	public MobileElement getNavigation_navHome_homepage() {
		return navigation_navHome_homepage;
	}

	public MobileElement getNavigation_menu_librarymenu() {
		return navigation_menu_librarymenu;
	}
	
	public MobileElement getNavigation_icon_Advancesearch() {
		return navigation_icon_Advancesearch;
	}

	public MobileElement getNavigation_txt_searchBox() {
		return navigation_txt_searchBox;
	}

	public List<MobileElement> getNavigation_suggestion_Advancesearchlistofsuggestion() {
		return navigation_suggestion_Advancesearchlistofsuggestion;
	}

	public MobileElement getNavigation_AdvancesearchCloseCta() {
		return navigation_MyprofileCloseCta;
	}

	public MobileElement getNavigation_close_AdvancesearchCloseCta() {
		return navigation_close_AdvancesearchCloseCta;
	}

	public MobileElement getNavigation_navMyshelf_myshelfscreen() {
		return navigation_navMyshelf_myshelfscreen;
	}

	public MobileElement getNavigation_navLib_libscreen() {
		return navigation_navLib_libscreen;
	}

	public MobileElement getNavigation_navBrowse() {
		return navigation_navBrowse;
	}

	public MobileElement getNavigation_navPrograms() {
		return navigation_navPrograms;
	}

	public MobileElement getNavigation_navMenu_Menuscreen() {
		return navigation_navMenu_Menuscreen;
	}

	public MobileElement getNavigation_img_avatarimg() {
		return navigation_img_avatarimg;
	}

	public MobileElement getNavigation_txt_profilescreen() {
		return myProfile_lbl_libName;
	}

	public MobileElement getNavigation_icon_notification() {
		return navigation_icon_notification;
	}

	public MobileElement getNavigation_txt_notificationcenter() {
		return navigation_lbl_notificationcenter;
	}



	/*********************** Action Methods ***************************/

	public void titleSearch() {
		if (isElementPresent(navigation_txt_library_searchBox)) {
			ClickOnMobileElement(navigation_txt_library_searchBox);
			SendKeysOnMobileElement(navigation_txt_library_searchBox, "books");

		}
		if(isElementPresent(navigation_txt_searchBox)) {
		ClickOnMobileElement(navigation_txt_searchBox);
		SendKeysOnMobileElement(navigation_txt_searchBox, "books");
		}

	}

	public void click_advanceSearch() {
		ClickOnMobileElement(navigation_icon_Advancesearch);
	}

	public boolean view_avatar() {
		boolean avatar = false;
		if(isElementPresent(navigation_img_avatarimg)) {
			logger.info("user is able to view user avatar");
			avatar = true;
		}
		return avatar;
	}

	public boolean clickAvatar_navProfilescreen() {
		boolean profileScreen = false;
		ClickOnMobileElement(navigation_img_avatarimg);
		if (myProfile_lbl_libName.isDisplayed()) {
			logger.info("system navigates to profile screen");
			profileScreen = true;
		} else {
			logger.info("system is not navigating to profile screen");
		}
		return profileScreen;
	}
	
	public void clickonAvatar_navProfilescreen() {
		//WaitForMobileElement(navigation_img_avatarimg);
		if (isElementPresent(navigation_img_avatarimg)) {
			ClickOnMobileElement(navigation_img_avatarimg);	
		}		
		else {
			logger.info("system is not navigating to profile screen");
		}
		
	}

	public void verify_minimumInputcount() {
		for (int i = 0; i < navigation_suggestion_Advancesearchlistofsuggestion.size(); i++) {
			if (navigation_suggestion_Advancesearchlistofsuggestion.size() != 0) {
				SendKeysOnMobileElement(navigation_txt_searchBox, "a");
				logger.info("minimum input count is lessthen 1 ");
				navigation_txt_searchBox.clear();
				if (navigation_suggestion_Advancesearchlistofsuggestion.size() == 1) {
					SendKeysOnMobileElement(navigation_txt_searchBox, "aa");
					logger.info("minimum input count is greaterthen 1 ");
					navigation_txt_searchBox.clear();
					if (navigation_suggestion_Advancesearchlistofsuggestion.size() == 2) {
						SendKeysOnMobileElement(navigation_txt_searchBox, "aaa");
						logger.info("minimum input count is greaterthen 1 ");
						navigation_txt_searchBox.clear();
					} else {
						logger.info("suggestion not displayed ");
					}
				}

			}
		}
	}

	public boolean verify_closeCTA() {
		boolean b = true;
		if(isElementPresent(navigation_txt_library_searchBox))
		{
			SendKeysOnMobileElement(navigation_txt_library_searchBox, "aaa");
		}else if(isElementPresent(navigation_txt_searchBox))
		{
		SendKeysOnMobileElement(navigation_txt_searchBox, "aaa");
		}
		if (isElementPresent(navigation_close_AdvancesearchCloseCta)) {
			logger.info("cancel cta should be displayed when user input keyword in search bar ");
		} else {
			logger.info("cancel cta should not be displayed when user input keyword in search bar ");
		}
		return b;
	}

	public boolean click_NavmyshelfScreen() {
		boolean myshelf = false;
		ClickOnMobileElement(navigation_bottommenu_myshelf);
		if (isElementPresent(navigation_navMyshelf_myshelfscreen)) { 
			logger.info("user navigate to myshelf screen ");
			myshelf =true;
		}
		return myshelf;
	}

	public boolean click_NavLibraryscreen() {
		boolean myLib = false;
		ClickOnMobileElement(navigation_bottommenu_Library);
		if (navigation_navLib_libscreen.isDisplayed()) {
			logger.info("user navigate to Library screen ");
			myLib = true;
		}
		return myLib;
	}

	public boolean click_NavBrowsescreen() {
		boolean browse = true;
		if(isElementPresent(navigation_bottommenu_Browse)) {
		ClickOnMobileElement(navigation_bottommenu_Browse);
			logger.info("user navigate to browse screen ");
			browse = true;
		}
		return browse;
	}

	public boolean click_Navprogramsscreen() {
		boolean prg = false;
		ClickOnMobileElement(navigation_bottommenu_programs);
		if (navigation_bottommenu_programs.isDisplayed()) {
			logger.info("user navigate to browse screen ");
			prg = true;
		}
		return prg;
	}

	public boolean click_NavMenuscreen() {
		boolean menu = false;
		ClickOnMobileElement(navigation_bottommenu_menu);
		if (navigation_navMenu_Menuscreen.isDisplayed()) {
			logger.info("user navigate to Menu screen ");
			menu =true;
		}
		return menu;
	}

	public void view_notificationicon() {
		if(isElementPresent(navigation_icon_notification)) {
		if (navigation_icon_notification.isDisplayed()) {
			logger.info("user is able to view notification ");
		} else {
			logger.info("user is not able to view notification");
		}
		}
	}

	public boolean Nav_notificationcenterpage() {
		boolean notifi = false;
		ClickOnMobileElement(navigation_icon_notification);
		if (navigation_lbl_notificationcenter.isDisplayed()) {
			logger.info("system navigate to notification center screen ");
			notifi =true;
		} else {
			logger.info("system is not navigated to notification center screen ");
		}
		return notifi;
	}

}