package eyesmanager;

import com.applitools.eyes.selenium.Eyes;

public class EyesManager {
	
	private static ThreadLocal<Eyes> eyes = new ThreadLocal<>();
	
	//private EyesManager() {}
	
	public static Eyes getEyes() {	
		return eyes.get();
	}
	
	public static void setEyes(Eyes eyes) {
		EyesManager.eyes.set(eyes);
	}
	
    public static void quitEyes() {
		try {
			EyesManager.eyes.get().close();
		} catch (Exception e) {
			//EyesManager.eyes.get().abortAsync();
		}
    }

}
