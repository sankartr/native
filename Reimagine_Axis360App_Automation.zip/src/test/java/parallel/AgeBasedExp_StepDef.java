package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.AboutandLegel;
import pom.kidszone.LoginPage;
import pom.kidszone.MenuList;
import pom.kidszone.ProfileCreation;

public class AgeBasedExp_StepDef extends CommonActions{

	LoginPage login = new LoginPage(DriverManager.getDriver());
	AboutandLegel about= new AboutandLegel(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	MenuList menu =new MenuList(DriverManager.getDriver());

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	
	/************** 109559*********************/
	
    @And("system should validate username and password")
    public void system_should_validate_username_and_password() throws Throwable {
       logger.info("Validating UserName and Password");
    }

    @And("on successful authentication system should redirect user to home screen")
    public void on_successful_authentication_system_should_redirect_user_to_home_screen() throws Throwable {
        Assert.assertEquals(login.homePgNav(),true);   
    }
}
