package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.FeaturedPrg;
import pom.kidszone.GoalsandInsights;
import pom.kidszone.LoginPage;
import pom.kidszone.MenuList;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelf;
import pom.kidszone.Newspaper_And_Magazine;

public class FeaturedCuratedList_StepDef extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	MenuList menu = new MenuList(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());
	GoalsandInsights goals = new GoalsandInsights(DriverManager.getDriver());
	MyShelf myShelf = new MyShelf(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	Newspaper_And_Magazine news = new Newspaper_And_Magazine(DriverManager.getDriver());
	FeaturedPrg featured = new FeaturedPrg(DriverManager.getDriver());

	/****************** 125501 *************************/

	@When("user navigates to the my shelf screen")
	public void user_navigates_to_the_my_shelf_screen() throws Throwable {
		goals.clickOnMyshelfFooter();
	}

	@Then("user should be able to view set featured List section based on profile with profile specific theme")
	public void user_should_be_able_to_view_set_featured_list_section_based_on_profile_with_profile_specific_theme()
			throws Throwable {

	}

	@And("featured list is set and enabled in admin portal")
	public void featured_list_is_set_and_enabled_in_admin_portal() throws Throwable {
		logger.info("list is set at the background");
	}

	@And("user should be able to view featured list title and description")
	public void user_should_be_able_to_view_featured_list_title_and_description() throws Throwable {
		Assert.assertEquals(myShelf.featurelistTitleandDescValidation(), true);
	}

	@And("user should be able to view featured list titles and description as carousel")
	public void user_should_be_able_to_view_featured_list_titles_and_description_as_carousel() throws Throwable {
		Assert.assertEquals(myShelf.featuredListCarouselValidation(), true);
	}

	@And("user should be able to click in view all cta and navigate to titles list screen for the featured list")
	public void user_should_be_able_to_click_in_view_all_cta_and_navigate_to_titles_list_screen_for_the_featured_list()
			throws Throwable {
		 featured.clickOnFeatureCarouselSeeAll();
		logger.info("- user able to see listing page");
	}

	@And("system should filter out the titles based on user profile type")
	public void system_should_filter_out_the_titles_based_on_user_profile_type() throws Throwable {

	}

	/******************* 125502 *****************/

	@When("user disables the featured list in admin portal")
	public void user_disables_the_featured_list_in_admin_portal() {
		logger.info("user disable featured list from background");
	}

	@Then("user should not view the featured list if disabled in the admin portal")
	public void user_should_not_view_the_featured_list_if_disabled_in_the_admin_portal() {
		goals.clickOnMyshelfFooter();
		
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_FeaturedCuratedList1()), false);
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_FeaturedCuratedList1()), false);
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_FeaturedCuratedList3()), false);
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_FeaturedCuratedList4()), false);
		//Assert.assertEquals(myShelf.getMyShelf_lbl_FeaturedCuratedList4().isDisplayed(), false);
		logger.info("User not able to see the featuredList");
	}

	@When("no feature list is created for the adult profile type")
	public void no_feature_list_is_created_for_the_adult_profile_type() {
		logger.info("No feature list is created for this user");
	}

	@Then("user should not view the featured list if no feature list is created for the adult profile type")
	public void user_should_not_view_the_featured_list_if_no_feature_list_is_created_for_the_adult_profile_type() {
		goals.clickOnMyshelfFooter();
		
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_FeaturedCuratedList1()), false);
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_FeaturedCuratedList1()), false);
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_FeaturedCuratedList3()), false);
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_FeaturedCuratedList4()), false);
		//Assert.assertEquals(myShelf.getMyShelf_lbl_FeaturedCuratedList4().isDisplayed(), false);
		logger.info("User not able to see the featuredList");
	}

	@When("no title in the list to be displayed")
	public void no_title_in_the_list_to_be_displayed() {
		logger.info("No title added for created feature");
	}

	@Then("user should not view the featured list if there is no title in the list to be displayed")
	public void user_should_not_view_the_featured_list_if_there_is_no_title_in_the_list_to_be_displayed() {
		goals.clickOnMyshelfFooter();
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_FeaturedCuratedList1()), false);
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_FeaturedCuratedList1()), false);
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_FeaturedCuratedList3()), false);
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_FeaturedCuratedList4()), false);
		//Assert.assertEquals(myShelf.getMyShelf_lbl_FeaturedCuratedList4().isDisplayed(), false);
		logger.info("User not able to see the featuredList");
	}

	@When("no feature list is created for the kid profile type")
	public void no_feature_list_is_created_for_the_kid_profile_type() throws Throwable {
		logger.info("No feature list is created for this user");
	}

	@Then("user should not view the featured list if no feature list is created for the kid profile type")
	public void user_should_not_view_the_featured_list_if_no_feature_list_is_created_for_the_kid_profile_type()
			throws Throwable {
		goals.clickOnMyshelfFooter();
		Assert.assertEquals(myShelf.getMyShelf_lbl_FeaturedCuratedList1().isDisplayed(), false);
		Assert.assertEquals(myShelf.getMyShelf_lbl_FeaturedCuratedList1().isDisplayed(), false);
		Assert.assertEquals(myShelf.getMyShelf_lbl_FeaturedCuratedList4().isDisplayed(), false);
		Assert.assertEquals(myShelf.getMyShelf_lbl_FeaturedCuratedList3().isDisplayed(), false);
		logger.info("User not able to see the featuredList");
	}

	@When("no feature list is created for the teen profile type")
	public void no_feature_list_is_created_for_the_teen_profile_type() throws Throwable {
		logger.info("No feature list is created for this user");
	}

	@Then("user should not view the featured list if no feature list is created for the teen profile type")
	public void user_should_not_view_the_featured_list_if_no_feature_list_is_created_for_the_teen_profile_type()
			throws Throwable {
		goals.clickOnMyshelfFooter();
		Assert.assertEquals(myShelf.getMyShelf_lbl_FeaturedCuratedList1().isDisplayed(), false);
		Assert.assertEquals(myShelf.getMyShelf_lbl_FeaturedCuratedList1().isDisplayed(), false);
		Assert.assertEquals(myShelf.getMyShelf_lbl_FeaturedCuratedList3().isDisplayed(), false);
		Assert.assertEquals(myShelf.getMyShelf_lbl_FeaturedCuratedList4().isDisplayed(), false);
		logger.info("User not able to see the featuredList");
	}

	@When("user navigates to the library page")
	public void user_navigates_to_the_library_page() throws Throwable {
		mylibrary.clickMylibrary();

	}

	@Then("user should be able to view curated lists for the library with profile specific theme")
	public void user_should_be_able_to_view_curated_lists_for_the_library_with_profile_specific_theme()
			throws Throwable {
		logger.info("Not able to vlidate Library profile theme");
	}

	@And("user should be able to view lists in order defined in the B and T admin portal")
	public void user_should_be_able_to_view_lists_in_order_defined_in_the_b_and_t_admin_portal() throws Throwable {
		logger.info("view list in order defined in B and T admin  portal");
	}

	@And("user should be able to view lists enabled for user profile only")
	public void user_should_be_able_to_view_lists_enabled_for_user_profile_only() throws Throwable {
		if(isElementPresent(mylibrary.getMyLib_lbl_FeatureTitle())) {
		 Assert.assertEquals(mylibrary.getMyLib_lbl_FeatureTitle().isDisplayed(),
		 true);
		}
	}

	@And("user should be able to titles in the list based on profile type only")
	public void user_should_be_able_to_titles_in_the_list_based_on_profile_type_only() throws Throwable {
		mylibrary.clickseeAll();

	}

	@And("user should be able to view each curated list as a carousel")
	public void user_should_be_able_to_view_each_curated_list_as_a_carousel() throws Throwable {
		logger.info("user is able to view each curated list as a carousel");

	}

	@And("user should be able to view title name as title for the carousel")
	public void user_should_be_able_to_view_title_name_as_title_for_the_carousel() throws Throwable {
		logger.info("user is able to view title name as title for the carousel");

	}

	@And("user should be able to view brief description for the carousel if available and total number of titles in the list")
	public void user_should_be_able_to_view_brief_description_for_the_carousel_if_available_and_total_number_of_titles_in_the_list()
			throws Throwable {
		logger.info("user should be able to view brief description for the carousel");
	}

	@And("user should be able to view 10 titles per carousel and scroll titles in carousel left or right")
	public void user_should_be_able_to_view_10_titles_per_carousel_and_scroll_titles_in_carousel_left_or_right()
			throws Throwable {
		logger.info("user should be able to view 10 titles per carousel and scroll titles");
	}

	@And("user should be able to click on CTA and navigate to titles list screen for the curated list")
	public void user_should_be_able_to_click_on_cta_and_navigate_to_titles_list_screen_for_the_curated_list()
			throws Throwable {
		logger.info("user should be able to click on CTA and navigate to titles list screen");
	}

	@Then("User should be able to view newspapers and magazines carousel with adult profile theme")
	public void user_should_be_able_to_view_newspapers_and_magazines_carousel_with_adult_profile_theme()
			throws Throwable {
		logger.info("theme check");
	}

	@And("user should be able to view featured publications in newspapers and magazines carousel")
	public void user_should_be_able_to_view_featured_publications_in_newspapers_and_magazines_carousel()
			throws Throwable {
		if(isElementPresent(news.getNewspaper_Magazine())) {
			Assert.assertEquals(isElementPresent(news.getNewspaper_Magazine()), true);
		}
		
	}

	@And("user should be able to click on view all cta and navigate to newspapers and magazines screen")
	public void user_should_be_able_to_click_on_view_all_cta_and_navigate_to_newspapers_and_magazines_screen()
			throws Throwable {
		news.megazine_seeAll();
	}
	@Then("user should not be able to view newspapers and magazines carousel if presssreader is disabled in admin portal")
    public void user_should_not_be_able_to_view_newspapers_and_magazines_carousel_if_presssreader_is_disabled_in_admin_portal() throws Throwable {
		if(isElementPresent(news.getNewspaper_Magazine())) {
			Assert.assertEquals(isElementPresent(news.getNewspaper_Magazine()), true);
		}
	}

    @And("user should not be able to view newspapers and magazines carousel if presssreader is disabled in admin portal for the adult profile")
    public void user_should_not_be_able_to_view_newspapers_and_magazines_carousel_if_presssreader_is_disabled_in_admin_portal_for_the_adult_profile() throws Throwable {
    	if(isElementPresent(news.getNewspaper_Magazine())) {
			Assert.assertEquals(isElementPresent(news.getNewspaper_Magazine()), true);
		}
    	
    }

}
