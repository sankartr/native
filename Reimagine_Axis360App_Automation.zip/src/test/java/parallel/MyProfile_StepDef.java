package parallel;

import io.cucumber.java.en.Given;
import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.appium.java_client.MobileElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.AboutandLegel;
import pom.kidszone.GoalsandInsights;
import pom.kidszone.InterestSurvey;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelf;
import pom.kidszone.ProfileCreation;

public class MyProfile_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	AboutandLegel about = new AboutandLegel(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	MyShelf myShelf = new MyShelf(DriverManager.getDriver());
	ManageProfile manage = new ManageProfile(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	GoalsandInsights goals = new GoalsandInsights(DriverManager.getDriver());
	InterestSurvey interest = new InterestSurvey(DriverManager.getDriver());

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	/******************* 124474 *********************/

	@When("user clicks on user avatar in top navigation bar")
	public void user_clicks_on_user_avatar_in_top_navigation_bar() throws Throwable {
		login.clickFooterMenu();
		login.clickmyprofile();
	}

	@And("user clicks without edit on user {string} avatar in top navigation bar")
	public void user_clicks_without_edit_on_user_avatar_in_top_navigation_bar(String profileType) throws Throwable {
		profile.chooseProfile(profileType);
	}

	@Then("user should be able to navigate to my profile screen")
	public void user_should_be_able_to_navigate_to_my_profile_screen() throws Throwable {
		logger.info("User should able to navigate to my profile screen");
	}

	@And("user should be able to see available profile information pre populated")
	public void user_should_be_able_to_see_available_profile_information_pre_populated() throws Throwable {
		logger.info("User should able to see available profile information pre populated");
	}

	public void user_should_be_able_to_view_and_update_profile_avatar_and_display_name_and_profile_type_and_security_question_and_answer()
			throws Throwable {
		Assert.assertEquals(profile.getProfile_lbl_editprofileavatar().isDisplayed(), true);
		// Assert.assertEquals(profile.getProfile_lbl_editprofiledisplayname().isDisplayed(),
		// true);
		Assert.assertEquals(profile.getProfile_btn_profilesequestion().isDisplayed(), true);
		// Assert.assertEquals(profile.getProfile_btn_profilesequestionanswer().isDisplayed(),
		// true);
	}

	@And("user should be able to enable and disable option to automatically checkout titles on hold and display checkout history and display insights and badges fields")
	public void user_should_be_able_to_enable_and_disable_option_to_automatically_checkout_titles_on_hold_and_display_checkout_history_and_display_insights_and_badges_fields()
			throws Throwable {
		logger.info("User should be able to enable and disable option to automatically");
	}

	@And("user should be able to view interest cta and navigated to interest survey on clicking the cta")
	public void user_should_be_able_to_view_interest_cta_and_navigated_to_interest_survey_on_clicking_the_cta()
			throws Throwable {
		swipeDown();
		swipeDown();
		swipeDown();
		if (isElementPresent(profile.getProfile_btn_viewinterests())) {
			Assert.assertEquals(profile.getProfile_btn_viewinterests().isDisplayed(), true);
		}
		profile.clickInterestview();
		Thread.sleep(2000);
		profile.navBackfromIntrestPg();

	}

	@And("user should be able to view checkout and hold and recommendations limit set by the library")
	public void user_should_be_able_to_view_checkout_and_hold_and_recommendations_limit_set_by_the_library()
			throws Throwable {
		swipeDown();
	}

	@And("user should be able to click on edit avatar and navigate to update profile avatar screen")
	public void user_should_be_able_to_click_on_edit_avatar_and_navigate_to_update_profile_avatar_screen()
			throws Throwable {
		swipeUp();
		swipeUp();
		manage.updateAvatar();
	}

	@And("user should be able click save cta to save updated changes")
	public void user_should_be_able_click_save_cta_to_save_updated_changes() throws Throwable {
		manage.saveUpdatedAvatar();
	}

	@And("system should enable Save CTA when user has made any changes")
	public void system_should_enable_save_cta_when_user_has_made_any_changes() throws Throwable {
		swipeDown();
		swipeDown();
		swipeDown();
	}

	@And("user should be able to view Interest Survey CTA and click on CTA to navigate to interest survey Screen")
	public void user_should_be_able_to_view_interest_survey_cta_and_click_on_cta_to_navigate_to_interest_survey_screen()
			throws Throwable {
		profile.clickInterestview();
	}

	@When("user clicks on disable button for the 'Checkout titles on hold','Display checkout history','Display insights and badges fields'")
	public void user_clicks_on_disable_button_for_the_checkout_titles_on_holddisplay_checkout_historydisplay_insights_and_badges_fields()
			throws Throwable {
		profile.disableAllOptionsinMyProfilePg();
	}

	@When("user clicks on enable button for the 'Checkout titles on hold','Display checkout history','Display insights and badges fields'")
	public void user_clicks_on_enable_button_for_the_checkout_titles_on_holddisplay_checkout_historydisplay_insights_and_badges_fields()
			throws Throwable {
		swipeDown();
		swipeDown();
		// profile.selectCheckoutHistory();
		profile.selectCheckoutTitles();
		profile.selectInsightbadges();
	}

	@Then("user should not able to view the 'Checkout titles on hold','Display checkout history','Display insights and badges fields' in the app")
	public void user_should_not_able_to_view_the_checkout_titles_on_holddisplay_checkout_historydisplay_insights_and_badges_fields_in_the_app()
			throws Throwable {
		goals.clickOnMyshelfFooter();
	}

	@Then("user should able to view the 'Checkout titles on hold','Display checkout history','Display insights and badges fields' in the app")
	public void user_should_able_to_view_the_checkout_titles_on_holddisplay_checkout_historydisplay_insights_and_badges_fields_in_the_app()
			throws Throwable {
		profile.selectCheckoutTitles();
		profile.selectInsightbadges();
	}

	@And("user should not be able to edit profile type when kid profile is mapped to an adult profile")
	public void user_should_not_be_able_to_edit_profile_type_when_kid_profile_is_mapped_to_an_adult_profile()
			throws Throwable {
		logger.info("user should not be able to edit profile type when kid profile is mapped");
	}

	@When("user clicks on enable button for the 'Display checkout history','Display insights and badges fields'")
	public void user_clicks_on_enable_button_for_the_display_checkout_historydisplay_insights_and_badges_fields()
			throws Throwable {

		profile.enableAllOptionsinMyProfilePg();
		profile.selectInsightbadges();

	}

	@Then("user should able to view the'Display checkout history','Display insights and badges fields'")
	public void user_should_able_to_view_thedisplay_checkout_historydisplay_insights_and_badges_fields()
			throws Throwable {
		myShelf.clickMyself();
		if(isElementPresent(myShelf.getMyShelf_lbl_currentlyCheckoutHeader())) {
		Assert.assertEquals(isElementPresent(myShelf.getMyShelf_lbl_currentlyCheckoutHeader()), true);
		}
	}

	@When("user clicks on disable button for the 'Display checkout history','Display insights and badges fields'")
	public void user_clicks_on_disable_button_for_the_display_checkout_historydisplay_insights_and_badges_fields()
			throws Throwable {
		profile.disableAllOptionsinMyProfilePg();
		/*swipeDown();
		swipeDown();
		swipeDown();
		profile.selectInsightbadges();*/
	}

	@Then("user should not able to view the 'Display checkout history','Display insights and badges fields'")
	public void user_should_not_able_to_view_the_display_checkout_historydisplay_insights_and_badges_fields()
			throws Throwable {
		if (isElementPresent(profile.getProfile_lbl_displycheckouthistory())) {
			Assert.assertEquals(isElementPresent(profile.getProfile_lbl_displycheckouthistory()), false);
			Assert.assertEquals(isElementPresent(profile.getProfile_chk_insightandBadges()), false);
		}
	}

	@When("user navigates to my profile screen")
	public void user_navigates_to_my_profile_screen() throws Throwable {
		myShelf.clickMyself();
	}

	@Then("user is able to view cta for interest survey")
	public void user_is_able_to_view_cta_for_interest_survey() throws Throwable {
		swipeDown();
		swipeDown();
		swipeDown();

	}

	@And("recommendations are enabled for the library")
	public void recommendations_are_enabled_for_the_library() throws Throwable {
		logger.info("Recommendation enabled for library");
	}

	@And("user has kidszone subscription")
	public void user_has_kidszone_subscription() throws Throwable {
		logger.info("user has kidszone subscription");
	}

	@And("user is able to navigate to interest survey screen on taping the cta")
	public void user_is_able_to_navigate_to_interest_survey_screen_on_taping_the_cta() throws Throwable {
		swipeDown();
		swipeDown();
		waitFor(1000);
		swipeDown();
		mylibrary.clickInterestsurvey();
		login.handleNothankspopup();
		profile.clickBackbutton();
		interest.closeButton();
		logger.info("navigate to interest survey screen");
	}

	@And("user is able set my shelf as default landing page")
	public void user_is_able_set_my_shelf_as_default_landing_page() throws Throwable {
		profile.enablemyShelfLanding();

	}

	@And("system should navigate user to my shelf on login if my shelf is set as default landing page")
	public void system_should_navigate_user_to_my_shelf_on_login_if_my_shelf_is_set_as_default_landing_page()
			throws Throwable {
//		myShelf.getMyShelf_lbl_footer().click();
		logger.info("user is able set my shelf as default landing page");
	}

	@Then("user is able to view option to set my shelf as default landing page")
	public void user_is_able_to_view_option_to_set_my_shelf_as_default_landing_page() throws Throwable {
		swipeDown();
		swipeDown();
	}

	@And("system should navigate user to library on login if my shelf is not set as default landing page")
	public void system_should_navigate_user_to_library_on_login_if_my_shelf_is_not_set_as_default_landing_page()
			throws Throwable {
		logger.info("ystem should navigate user to library");
	}

	@And("user disable my shelf as default landing page")
	public void user_disable_my_shelf_as_default_landing_page() throws Throwable {
		profile.disablemyShelfLanding();
	}

	@And("select Adult profile")
	public void select_Adult_profile() throws Throwable {
		manage.adultprofileSelection();
		login.handleNothankspopup();
	}

	@Given("user click on login button after user enter kidszone subscription only {string}")
	public void user_click_on_login_button_after_user_enter_kidszone_subscription_only(String userName) {
		login.enterUserName(userName);
		hideMobileKeyboard();
		login.clickSignInBtn();
	}
	@And("select kid profile")
	public void select_something_profile() throws Throwable {
		waitFor(2000);
		manage.kidprofileSelection();
		login.handleNothankspopup();
	}

	@And("user navigate to profile screen")
    public void user_navigate_to_profile_screen() throws Throwable {
		profile.clickBackbutton();
    }
	
	@And("select teen profile")
    public void select_teen_profile() throws Throwable {
		manage.teenprofileSelection();
		login.handleNothankspopup();
    }
	
	@And("click edit and select kid profile")
	public void click_edit_and_select_kid_profile() throws Throwable {
		manage.editBtnClick();
	}

	@And("click edit and select teen profile")
	public void click_edit_and_select_teen_profile() throws Throwable {
		manage.editBtnClick();
		manage.teenprofileSelection();
	}

	@And("click edit and select adult profile")
	public void click_edit_and_select_adult_profile() throws Throwable {
		manage.editBtnClick();
		manage.adultprofileSelection();
	}

	@And("user able to see profile option under menulist")
	public void user_able_to_see_profile_option_under_menulist() throws Throwable {
		menu.clickprofileMenu();
	}

	@And("system should not show the option to set my shelf as default landing page for user profile type adult")
	public void system_should_not_show_the_option_to_set_my_shelf_as_default_landing_page_for_user_profile_type_adult() {
		for (int i = 0; i < 5; i++) {
			swipeDown();
		}
		logger.info("user not able to see option to set myshelf as landing page");
		profile.clickonSaveCTA();
	}

	@Then("user should be able to view list of existing profile with name and profile type")
	public void user_should_be_able_to_view_list_of_existing_profile_with_name_and_profile_type() throws Throwable {
	profile.checkprofileCount();
	}

	@And("user is not select avatar")
	public void user_is_not_select_avatar() throws Throwable {
		logger.info("user is not selected avatar");
	}

	@And("user should be able to view 'default avatar image' as the profile picture if no avatar is selected")
	public void user_should_be_able_to_view_default_avatar_image_as_the_profile_picture_if_no_avatar_is_selected()
			throws Throwable {
		if(isElementPresent(profile.manageProf_icon_edit.get(0))){
		Assert.assertEquals(isElementPresent(profile.manageProf_icon_edit.get(0)), true);
		}
	}

	@And("user should be able to tap on edit icon")
	public void user_should_be_able_to_tap_on_edit_icon() throws Throwable {
		profile.clickEditprofile();
		profile.clickpenicon();
	}

	@And("user should be able to view white pen to guarantee the pen is always visible")
	public void user_should_be_able_to_view_white_pen_to_guarantee_the_pen_is_always_visible() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getProfile_btn_backbtn()), true);
		profile.clickBackbutton();
	}
	@And("user is not uploaded profile picture")
    public void user_is_not_uploaded_profile_picture() throws Throwable {
		logger.info("user is not uploaded profile picture");
    }

    @And("user should be able to view 'default avatar image' as the profile picture if no profile picture is uploaded")
    public void user_should_be_able_to_view_default_avatar_image_as_the_profile_picture_if_no_profile_picture_is_uploaded() throws Throwable {
    	Assert.assertEquals(isElementPresent(profile.manageProf_icon_edit.get(0)), true);
    	logger.info("user should be able to view 'default avatar image'");
    }
    @When("user is able to view profile icon in header")
    public void user_is_able_to_view_profile_icon_in_header() throws Throwable {
    Assert.assertEquals(isElementPresent(profile.getProfile_btn_backbtn()), true);
	logger.info("user should be able to view 'default avatar image'");
    }

    @Then("user should be able to view 'default avatar image' on profile icon in header")
    public void user_should_be_able_to_view_default_avatar_image_on_profile_icon_in_header() throws Throwable {
    	Assert.assertEquals(isElementPresent(profile.manageProf_icon_edit.get(0)), true);
    	logger.info("user should be able to view 'default avatar image'");
    }

    @And("user is not uploaded profile picture or avatar")
    public void user_is_not_uploaded_profile_picture_or_avatar() throws Throwable {
   logger.info("user is not uploaded profile picture");
    }
    @When("user is able to tap edit and tap on pen icon on adult profile")
    public void user_is_able_to_tap_edit_and_tap_on_pen_icon_on_adult_profile() throws Throwable {
    	profile.clickEditprofile();
		manage.adultprofileSelection();
    }

    @Then("system should be able to navigate to adult profile detail screen")
    public void system_should_be_able_to_navigate_to_adult_profile_detail_screen() throws Throwable {
    	Assert.assertEquals(isElementPresent(profile.getProfile_title()), true);
    }

    @And("user is navigate to profile section from menu in down navigation bar")
    public void user_is_navigate_to_profile_section_from_menu_in_down_navigation_bar() throws Throwable {
		login.handleNothankspopup();
    	login.clickFooterMenu();
		profile.clickBackbutton();
    }

    @And("user is able to view list of profiles")
    public void user_is_able_to_view_list_of_profiles() throws Throwable {
    	profile.checkprofileCount();
    }

    @And("user should be able to view cancel account CTA")
    public void user_should_be_able_to_view_cancel_account_cta() throws Throwable {
    	for(int i=0;i<7;i++)
		{
			if(isElementPresent(manage.getEditprofile_btn_deltProfile()))
			{
				break;
			}else
			{
				swipeDown();
			}
		}
    Assert.assertEquals(isElementPresent(manage.getEditprofile_btn_deltProfile()), true);
    }

    @And("user should be able to view cancel account button for library which has Prefix registration type")
    public void user_should_be_able_to_view_cancel_account_button_for_library_which_has_prefix_registration_type() throws Throwable {
    Assert.assertEquals(isElementPresent(manage.getEditprofile_btn_deltProfile()), true);
    }
    @When("user is able to tap edit and tap on pen icon on kid profile")
    public void user_is_able_to_tap_edit_and_tap_on_pen_icon_on_kid_profile() throws Throwable {
    	profile.clickEditprofile();
		manage.kidprofileSelection();
    }

    @When("user is able to tap edit and tap on pen icon on teen profile")
    public void user_is_able_to_tap_edit_and_tap_on_pen_icon_on_teen_profile() throws Throwable {
		waitFor(3000);
    	profile.clickEditprofile();
		manage.teenprofileSelection();
    }

    @Then("system should be able to navigate to kid profile detail screen")
    public void system_should_be_able_to_navigate_to_kid_profile_detail_screen() throws Throwable {
    Assert.assertEquals(isElementPresent(profile.getProfile_title()), true);
    }

    @Then("system should be able to navigate to teen profile detail screen")
    public void system_should_be_able_to_navigate_to_teen_profile_detail_screen() throws Throwable {
    	 Assert.assertEquals(isElementPresent(profile.getProfile_title()), true);
    }
    
    @Then("user clicks on the profile icon")
    public void user_clicks_on_the_profile_icon() {
//    	waitFor(3000);
//    	mylibrary.clickMylibrary();
//    	waitFor(1000);
    	profile.clickProfile();
    }


}
