package parallel;

import org.junit.Assert;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.appium.java_client.MobileElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.MenuList;
import pom.kidszone.ProfileCreation;
import pom.kidszone.SetParentPin;


public class ProfileCreation_StepDef extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());
	SetParentPin setPin = new SetParentPin(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	
	@Given("user is in the manage profile screen")
	public void user_is_in_the_manage_profile_screen() throws Throwable {
	//	login.handleNothankspopup();
		Assert.assertEquals(isElementPresent(profile.getProfile_txt_title()), true);
	}

	@When("user clicks on the create new profile cta '+'")
	public void user_clicks_on_the_create_new_profile_cta_() throws Throwable {
		profile.addProfileCta();
	}

//	@Then("user views the profile creation page with options {string}")
//	public void user_views_the_profile_creation_page_with_options_something(String profileType) throws Throwable {
//		profile.selectProfile(profileType);
//	}

	@And("user selects the Add a teen")
	public void user_selects_the_add_a_teen() throws Throwable {
		Assert.assertEquals(profile.getProfile_txt_addprofiletitle().isDisplayed(), true);
	}

	@And("user enters the profile details like displayname {string} and email and select avatar optional")
	public void user_enters_the_profile_details_like_display_namemandatoryemailoptionalselect_avataroptional(
			String displayname) throws Throwable {
		profile.setDisplayName(displayname);
	}

	@And("user clicks on the done button to create the profile")
	public void user_clicks_on_the_done_button_to_create_the_profile() throws Throwable {
		profile.clickDonebutton();
	}

	@And("user navigates to profiles page by displaying the toast message as {string} in the bottom of the screen")
	public void user_navigates_to_profiles_page_by_displaying_the_toast_message_as_something_in_the_bottom_of_the_screen(
			String strArg1) throws Throwable {
		if(isElementPresent(profile.getProfile_txt_successmsg()))
		{
		 Assert.assertEquals(profile.getProfile_txt_successmsg().isDisplayed(), true);
		 logger.info("Pop up message Displayed");	
		}else
		{
		logger.info("Pop up message Displayed 5'th profile created");	
		}
		
	}

	@And("user selects the Add a kid")
	public void user_selects_the_add_a_kid() throws Throwable {
		Assert.assertEquals(profile.getProfile_txt_addprofiletitle().isDisplayed(), true);
	}

	@And("select avatar")
	public void select_avatar() throws Throwable {
		profile.selectAvatar();
	}

	@And("check whether upload image option disable")
	public void check_whether_upload_image_option_disable() throws Throwable {
		if(isElementPresent(profile.getProfile_btn_uploadphoto())) {
			Assert.assertEquals(!profile.getProfile_btn_uploadphoto().isDisplayed(), true);
		} else {
		try {
			Assert.assertEquals(isElementPresent(profile.getProfile_btn_uploadphoto()), false);
			logger.info("Upload option enable");
		} catch (ElementNotInteractableException e) {
			logger.info("Upload option not enable");
		}
		}
	}

	@And("user is clicking the profile from menu")
	public void user_is_clicking_the_profile_from_menu() throws Throwable {
		login.clickFooterMenu();
		menu.clickprofileMenu();
	}

	@And("enter the parent Pin {string}")
	public void enter_the_parent_pin() throws Throwable {
	}

	@When("user clicks on edit cta in the manage profile screen")
	public void user_clicks_on_edit_cta_in_the_manage_profile_screen() throws Throwable {
		profile.clickEditprofile();
	}

	@Then("edited details should be updated in the system and user able to view the saved details")
	public void edited_details_should_be_updated_in_the_system_and_user_able_to_view_the_saved_details()
			throws Throwable {
		swipeDown();
		swipeDown();
		swipeDown();
		Assert.assertEquals(profile.getProfile_txt_title().isDisplayed(), true);
	}
	
	@And("user click pen icon on the profile avatar Kid")
	public void user_click_pen_icon_on_the_profile_avatar_Kid() throws Throwable {
		profile.clickpeniconTeen();
	}

	@And("user click pen icon on the profile avatar Teen")
	public void user_click_pen_icon_on_the_profile_avatar_Teen() throws Throwable {
		profile.clickpeniconTeen();
	}
	
	@And("user click pen icon on the profile avatar")
	public void user_click_pen_icon_on_the_profile_avatar() throws Throwable {
		profile.clickpenicon();
	}

	@And("user should be redirect to profile detail page")
	public void user_should_be_redirect_to_profile_detail_page() throws Throwable {
	//	Assert.assertEquals(profile.getProfile_lbl_editprofileavatar().isDisplayed(), true);

	}

	@And("user should be able to view the profile avatar, display name, parental email.")
	public void user_should_be_able_to_view_the_profile_avatar_display_name_parental_email() throws Throwable {
		Assert.assertEquals(isElementPresent(profile.getProfile_lbl_editprofiledisplayname()), true);
		Assert.assertEquals(isElementPresent(profile.getProfile_lbl_editprofileavatar()), true);
		logger.info("user is able to see the avatar, display name,parental pin");
	}

	@And("user should also view the library information like the library name, check out limit, hold limit, recommendation limit counts")
	public void user_should_also_view_the_library_information_like_the_library_name_check_out_limit_hold_limit_recommendation_limit_counts() {
		
		Assert.assertEquals(isElementPresent(profile.getProfile_lbl_editcheckoutlimit()), true);
		Assert.assertEquals(isElementPresent(profile.getProfile_lbl_editholdlimit()), true);
		Assert.assertEquals(isElementPresent(profile.getProfile_lbl_editrecommendationlimit()), true);
		logger.info("user is able to see the lib name,checoutlimit,hold limit,recom limit");
	}

	@And("user also able to see the view checkout history button to view the history of check out done")
	public void user_also_able_to_see_the_view_checkout_history_button_to_view_the_history_of_check_out_done()
			throws Throwable {
		swipeDown();
		swipeDown();
		Assert.assertEquals(isElementPresent(profile.getProfile_lbl_displycheckouthistory()), true);
		logger.info("user is able to see checkouthistory button");

	}

	@And("user should be able to view the Kid 0-12 link to change the profile from {string}")
    public void user_should_be_able_to_view_the_kid_012_link_to_change_the_profile_from_kid_to_teen(String args) throws Throwable {
        swipeUp();
        profile.checkandchangeProfiletype(args);
    }

	@And("user should be able to edit {string} in edit profile page and clicks save button")
	public void user_should_be_able_to_edit_something_in_edit_profile_page_and_clicks_save_button(String displayname)
			throws Throwable {
		profile.editdisplayname(displayname);
	}

	@And("user should see enable edit pen icon in each of the profile available")
	public void user_should_see_enable_edit_pen_icon_in_each_of_the_profile_available() throws Throwable {
		for (int i = 0; i <= profile.getProfile_list_pencilicon().size() - 1; i++) {
			Assert.assertEquals(profile.getProfile_list_pencilicon().get(i).isDisplayed(), true);
		}
	}

    @And("user should be able to view the Teen 13-17 link to change the profile from {string}")
    public void user_should_be_able_to_view_the_teen_1317_link_to_change_the_profile_from_kid_to_teen(String args) throws Throwable {
    	swipeUp();
    	profile.checkandchangeProfiletype(args);
    }
    @Then("system should be able to view the delete profile option")
    public void system_should_be_able_to_view_the_delete_profile_option() throws Throwable {
    	swipeDown();
    	swipeDown();
    	swipeDown();
    	swipeDown();
    	swipeDown();
    	Assert.assertEquals(profile.getProfile_txt_deleteprofile().isDisplayed(), true);
    }
    @And("user clicks on delete profile")
    public void user_clicks_on_delete_profile() throws Throwable {
    	profile.clickDeleteprofile();
    }

    @And("user should see confirmation popup with Yes or No")
    public void user_should_see_confirmation_popup_with_yes_or_no() throws Throwable {
    	Assert.assertEquals(profile.getProfile_btn_saveconfirmyes().isDisplayed(), true);
    }

    @And("user selecting {string} from the popup profile will be deleted and redirect to manage profile page")
    public void user_selecting_yes_from_the_popup_profile_will_be_deleted_and_redirect_to_manage_profile_page(String confirm) throws Throwable {
    profile.deleteprofile(confirm);
    //Assert.assertEquals(profile.getProfile_txt_title().isDisplayed(), true);
    
    }
    @And("user selecting {string} from the popup profile should not delete")
    public void user_selecting_something_from_the_popup_profile_should_not_delete(String confirm) throws Throwable {
    	profile.deleteprofile(confirm);
    }

	@And("user should be able to view all the profiles in the manage profile page")
	public void user_should_be_able_to_view_all_the_profiles_in_the_manage_profile_page() throws Throwable {
		Assert.assertEquals(profile.getProfile_txt_title().isDisplayed(), true);

	}

	@And("user enter {string} for the login")
	public void user_enter_something_for_the_login(String patronpin) throws Throwable {
		if (System.getProperty("platform").equalsIgnoreCase("ios")) {
			profile.enter_setPin(patronpin);
			profile.clickSubmit();
		}
		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
			setPin.parentPin();
		}
	}

	@And("user should see popup message for profile creation {string} Do you want to create another profile?")
	public void user_should_see_popup_message_for_profile_creation_something_do_you_want_to_create_another_profile(
			String strArg1) throws Throwable {
		if(isElementPresent(profile.getProfile_txt_successmsg()))
		{
		Assert.assertEquals(profile.getProfile_txt_successmsg().isDisplayed(), true);
		logger.info("Pop up message Displayed");
		}
		else
		{
		logger.info("Pop up message Not Displayed");	
		}
	}

	@And("user clicks on {string} cta it should redirected to creation page to create another profile")
	public void user_clicks_on_something_cta_it_should_redirected_to_creation_page_to_create_another_profile(
			String strArg1) throws Throwable {
		if(isElementPresent(profile.profile_txt_saveconfirmyes))
		{
			profile.createProfileMore(strArg1);
			Assert.assertEquals(profile.getProfile_txt_addtitle().isDisplayed(), true);	
		}else
		{
			logger.info("Pop up message Displayed 5'th profile created");	
		}
		
	}

	@And("user clicks on {string} cta it should redirected to manage profile screen")
	public void user_clicks_on_something_cta_it_should_redirected_to_manage_profile_screen(String strArg1)
			throws Throwable {
		if(isElementPresent(profile.profile_txt_saveconfirmyes))
		{
		profile.createProfileMore(strArg1);
		Assert.assertEquals(profile.getProfile_txt_title().isDisplayed(), true);
		}else
		{
			logger.info("Pop up message Displayed 5'th profile created");	
		}
	}

	@And("user should see popup message for profile creation {string} with OK button")
	public void user_should_see_popup_message_for_profile_creation_something_with_ok_button(String strArg1)
			throws Throwable {
		if(isElementPresent(profile.profile_txt_saveconfirmyes))
		{
			 Assert.assertEquals(profile.getProfile_txt_successmsg().isDisplayed(), true);
	}else
	{
		logger.info("Pop up message Displayed 5'th profile created");	
	}
	}
}
