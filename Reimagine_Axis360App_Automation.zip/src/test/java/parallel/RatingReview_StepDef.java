package parallel;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pom.kidszone.LoginPage;
import pom.kidszone.MyLibrary;
import pom.kidszone.RatingReview;
import pom.kidszone.TitleDetails;

public class RatingReview_StepDef extends CommonActions {

	RatingReview rating = new RatingReview(DriverManager.getDriver());
	TitleDetails details = new TitleDetails(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());
	MyLibrary library = new MyLibrary(DriverManager.getDriver());

	public static final Logger logger = LoggerFactory.getLogger(RatingReview_StepDef.class);

	/********************* Reusable Step **********************/

	@When("user taps on the title card of a book that has not been rated")
	public void user_taps_on_the_title_card_of_a_book_that_has_not_been_rated() throws Throwable {
		details.scrollAndTapeBooknotrated();
	}

	@When("user taps on the title card of a book that has review")
	public void user_taps_on_the_title_card_of_a_book_that_has_review() throws Throwable {
		//rating.scrollAndTapBookHasReview();
		details.scrollAndTapeBookhasreview();
	}

	@When("user taps on the title card of an ebook that has not been reviewed by the user")
	public void user_taps_on_the_title_card_of_an_ebook_that_has_not_been_reviewed_by_the_user() throws Throwable {
		rating.eBookNotReviewed();
	}

	@When("user taps on the title card of an audio book that has not been reviewed by the user")
	public void user_taps_on_the_title_card_of_an_audio_book_that_has_not_been_reviewed_by_the_user() throws Throwable {
		rating.scrollAndTapAudioBookNotReviewed();
	}

	@And("user taps on the title card of an ebook with submitted review has not been approved by admin")
	public void user_taps_on_the_title_card_of_an_ebook_with_submitted_review_has_not_been_approved_by_admin() throws Throwable {
		rating.scrollAndTapBookReviewHasNotBeenApproved();
	}

	@And("user taps on the title card of an ebook with submitted review has been approved by admin")
	public void user_taps_on_the_title_card_of_an_ebook_with_submitted_review_has_been_approved_by_admin() throws Throwable {
		rating.scrollAndTapBookReviewHasBeenApproved();
	}

	@And("user taps on the title card of an ebook with rejected review")
	public void user_taps_on_the_title_card_of_an_ebook_with_rejected_review() throws Throwable {
		rating.scrollAndTapBookReviewRejected();
	}

	@And("user taps on the title card of an audio book with rejected review")
	public void user_taps_on_the_title_card_of_an_audio_book_with_rejected_review() throws Throwable {
		rating.scrollAndTapAudioBookReviewRejected();
	}

	/********************* 146968 **********************/
	@And("^user is on title details screen$")
	public void user_is_on_title_details_screen() throws Throwable {

	}

	@And("^user has not rated the title$")
	public void user_has_not_rated_the_title() throws Throwable {
		waitFor(5000);
		Assert.assertEquals(rating.getNotRated().isDisplayed(), true);
	}

	@And("^user has rated the title$")
	public void user_has_rated_the_title() throws Throwable {
		logger.info("User has rated the title");
	}

	@And("^user should be able to view rating for the title based on average of ratings input for that title by the patrons of that library$")
	public void user_should_be_able_to_view_rating_for_the_title_based_on_average_of_ratings_input_for_that_title_by_the_patrons_of_that_library()
			throws Throwable {
		waitFor(5000);
		//swipeDown();
		Assert.assertEquals(rating.getAverageRating().isDisplayed(), true);
		rating.verifyAverageRating();

	}

	@And("^user should be able to view rating with one star as minimum$")
	public void user_should_be_able_to_view_rating_with_one_star_as_minimum() throws Throwable {
		Assert.assertEquals(isElementPresent(rating.getRatingOneStar()), true);
	}

	@And("^user should be able to view rating with 5 stars as maximum$")
	public void user_should_be_able_to_view_rating_with_5_stars_as_maximum() throws Throwable {
		Assert.assertEquals(isElementPresent(rating.getRatingFiveStar()), true);
	}

	@And("^user should be able to view rating as text based on average of ratings input for that title by the patrons of that library from total number of ratings$")
	public void user_should_be_able_to_view_rating_as_text_based_on_average_of_ratings_input_for_that_title_by_the_patrons_of_that_library_from_total_number_of_ratings()
			throws Throwable {
		waitFor(5000);
		swipeDown();
		Assert.assertEquals(rating.getAverageRating().isDisplayed(), true);
		rating.verifyAverageRating();
	}

	@And("^system should show submitted ratings and calculate average rating based on the submitted ratings only$")
	public void system_should_show_submitted_ratings_and_calculate_average_rating_based_on_the_submitted_ratings_only()
			throws Throwable {
		logger.info("Average rating displayed based on the submitted ratings only");
	}

	/********************* 146969 **********************/

	/*@And("^user has rated the title$")
	public void user_has_rated_the_title() throws Throwable {

	}

	@And("^User should be able to view rating for the title based on rating given by the user$")
	public void user_should_be_able_to_view_rating_for_the_title_based_on_rating_given_by_the_user() throws Throwable {

	}

	@And("^User should see the rating starts in the blue color when user has rated the title$")
	public void user_should_see_the_rating_starts_in_the_blue_color_when_user_has_rated_the_title() throws Throwable {

	} */

	/********************* 146970 **********************/

	@When("^user click on start ratings$")
	public void user_click_on_start_ratings() throws Throwable {
		rating.startRating();
	}

	@And("^user should be able to view the drawer to select and submit the rating$")
	public void user_should_be_able_to_view_the_drawer_to_select_and_submit_the_rating() throws Throwable {
		Assert.assertEquals(rating.getRatingDrawer().isDisplayed(), true);
	}

	@And("^user should be able to select the rating to rate title or update the rating given by the user$")
	public void user_should_be_able_to_select_the_rating_to_rate_title_or_update_the_rating_given_by_the_user()
			throws Throwable {
		rating.selectRating();
	}

	@And("^user should be able to view the rating submitted by the user on the title details page$")
	public void user_should_be_able_to_view_the_rating_submitted_by_the_user_on_the_title_details_page()
			throws Throwable {
		waitFor(3000);
		Assert.assertEquals(rating.getAverageRating().isDisplayed(), true);
		rating.verifyAverageRating();

	}

	@And("^user should be able to view the success toast message on successful submission of rating$")
	public void user_should_be_able_to_view_the_success_toast_message_on_successful_submission_of_rating()
			throws Throwable {
		//waitFor(5000);
		if (isElementPresent(rating.getSuccessRatingMsg())) {
			Assert.assertEquals(isElementPresent(rating.getSuccessRatingMsg()), true);
		}
	}

	@And("^user should be able to view error toast message in case of failure of rating submission$")
	public void user_should_be_able_to_view_error_toast_message_in_case_of_failure_of_rating_submission() {
		waitFor(5000);
		Assert.assertEquals(isElementPresent(rating.getFailureRatingMsg()), false);
	}

	@And("^User should be able to dismiss the drawer and navigate back to the title details screen without updating/submitting the rating$")
	public void user_should_be_able_to_dismiss_the_drawer_and_navigate_back_to_the_title_details_screen_without_updatingsubmitting_the_rating()
			throws Throwable {
		rating.dismissDrawer();

	}

	@And("^user should be able to select the rating to rate title the rating given by the user$")
	public void user_should_be_able_to_select_the_rating_to_rate_title_the_rating_given_by_the_user() throws Throwable {
		rating.selectRating();

	}

	/********************* 146971 **********************/
	@And("^user should be able to view reviews submitted by the patrons and the user$")
	public void user_should_be_able_to_view_reviews_submitted_by_the_patrons_and_the_user() throws Throwable {
		details.tapDetailsTab();
		rating.scrollToSubmittedReview();
		Assert.assertEquals(rating.getReviewSubmitted().isDisplayed(), true);
	}

	@And("^user should be able to view number of reviews submitted for the title$")
	public void user_should_be_able_to_view_number_of_reviews_submitted_for_the_title() throws Throwable {
		Assert.assertEquals(rating.getNoOfReviewSubmitted().isDisplayed(), true);
		rating.viewNumberOfReviewSubmitted();
	}

	@And("^user should be able to view total number of readers reviews$")
	public void user_should_be_able_to_view_total_number_of_readers_reviews() throws Throwable {
		Assert.assertEquals(rating.getNoOfReviewSubmitted().isDisplayed(), true);
		rating.viewNumberOfReviewSubmitted();
	}

	@And("^user should be able to view approved reviews only$")
	public void user_should_be_able_to_view_approved_reviews_only() throws Throwable {
		logger.info("user should be able to view approved reviews only");
	}

	@And("^user should be able to view the review submitted by the user as first review$")
	public void user_should_be_able_to_view_the_review_submitted_by_the_user_as_first_review() throws Throwable {
		logger.info("user should be able to view the review submitted by the user as first review");
	}

	/********************* 146972 **********************/

	@And("^user click on write a review cta$")
	public void user_click_on_write_a_review_cta() throws Throwable {
		//rating.tapWriteReviewButton();
		swipeDown();
		rating.writeReview();
	}

	@And("^user should be navigated to write a review screen$")
	public void user_should_be_navigated_to_write_a_review_screen() throws Throwable {
		Assert.assertEquals(rating.getWriteReviewScreen().isDisplayed(), true);
	}

	@And("user should be able to write maximum 1000 {string} review")
	public void user_should_be_able_to_write_maximum_1000_characters_review(String characterMax) throws Throwable {
		rating.verifyWriteReviewField(characterMax);
	}

	@And("system should enable submit button only when user has input minimum of 3 {string}")
	public void system_should_enable_submit_button_only_when_user_has_input_minimum_of_3_characters(String characterMin) throws Throwable {
		rating.verifyWriteReviewField(characterMin);
		Assert.assertEquals(rating.getSubmitBtnEnabled().isEnabled(), true);
	}

	@And("^user should be able to submit the review by clicking Submit cta$")
	public void user_should_be_able_to_submit_the_review_by_clicking_submit_cta() throws Throwable {
		rating.tapSubmitReviewBtn();
	}

	@And("user should be able to write maximum 2 {string} review")
	public void user_should_be_able_to_write_maximum_2_characters_review(String character) throws Throwable {
		rating.verifyWriteReviewField(character);
	}

	@And("^system should disable submit button only when user has input 2 characters$")
	public void system_should_disable_submit_button_only_when_user_has_input_2_characters() throws Throwable {
		Assert.assertEquals(rating.getSubmitBtnEnabled().isEnabled(), false);
		ClickOnMobileElement(rating.getCloseCTA());
	}

	@And("^user should be able to view success confirmation message of review submission$")
	public void user_should_be_able_to_view_success_confirmation_message_of_review_submission() throws Throwable {
		//waitFor(3000);
		Assert.assertEquals(isElementPresent(rating.getSuccessReviewMsg()), false);
	}

	@And("^system should submit the review to admin for approval$")
	public void system_should_submit_the_review_to_admin_for_approval() throws Throwable {
		logger.info("system should submit the review to admin for approval");
	}

	@And("^user should be able to navigate back to title details screen by clicking close cta$")
	public void user_should_be_able_to_navigate_back_to_title_details_screen_by_clicking_close_cta() throws Throwable {
		rating.tapCloseBtn();
		Assert.assertEquals(isElementPresent(rating.getWriteReviewScreen()), false);
	}

	@And("^user should be able to Submit the review before rating the title$")
	public void user_should_be_able_to_submit_the_review_before_rating_the_title() throws Throwable {
		logger.info("user should be able to Submit the review before rating the title");
	}

	/********************* 146974 **********************/

	@When("^user clicks on write review cta$")
	public void user_clicks_on_write_review_cta() throws Throwable {
		rating.tapWriteReviewButton();
	}

	@Then("^user should be navigated to review input screen with the review submitted by the user$")
	public void user_should_be_navigated_to_review_input_screen_with_the_review_submitted_by_the_user()
			throws Throwable {
		Assert.assertEquals(isElementPresent(rating.getReviewField()), true);
		rating.viewReviewFieldwithSubmittedReview();
	}

	@And("^user has submitted review for that title and has not been approved by admin$")
	public void user_has_submitted_review_for_that_title_and_has_not_been_approved_by_admin() throws Throwable {
		logger.info("user has submitted review for that title and has not been approved by admin");
	}

	@And("^user should be able to view the message for review approved by admin 'You have already submitted a review for this title, which is still pending library review\\.'$")
	public void user_should_be_able_to_view_the_message_for_review_approved_by_admin_you_have_already_submitted_a_review_for_this_title_which_is_still_pending_library_review()
			throws Throwable {
		Assert.assertEquals(isElementPresent(rating.getApprovedReviewMsg()), true);
	}

	@And("^user should be able to view the message for review that has not been approved by admin 'Review has been submitted for Approval'$")
	public void user_should_be_able_to_view_the_message_for_review_that_has_not_been_approved_by_admin_review_has_been_submitted_for_approval()
			throws Throwable {
		Assert.assertEquals(isElementPresent(rating.getNotApprovedReviewMsg()), true);
	}

	@And("^user has submitted review for that title and has been approved by admin$")
	public void user_has_submitted_review_for_that_title_and_has_been_approved_by_admin() throws Throwable {
		logger.info("user has submitted review for that title and has been approved by admin");
	}

	@And("^user should not be able to edit the review once submitted$")
	public void user_should_not_be_able_to_edit_the_review_once_submitted() throws Throwable {
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			Assert.assertEquals(rating.getReviewField().isEnabled(), true);
		}
		ClickOnMobileElement(rating.getCloseCTA());
	}

	/********************* 146975 **********************/

	@When("^user click write a review$")
	public void user_click_write_a_review() throws Throwable {
		rating.tapWriteReviewButton();
	}

	@Then("^user navigates to review input screen$")
	public void user_navigates_to_review_input_screen() throws Throwable {
		Assert.assertEquals(rating.getWriteReviewScreen().isDisplayed(), true);
	}

	@And("^admin has rejected the review submitted by the user$")
	public void admin_has_rejected_the_review_submitted_by_the_user() throws Throwable {
		logger.info("admin has rejected the review submitted by the user");
	}

	@And("user give input 3 {string}")
	public void user_give_input_3_characters(String character) throws Throwable {
		rating.verifyWriteReviewField(character);
	}

	@And("^system should enable submit button only when adult user has input minimum of 3 characters$")
	public void system_should_enable_submit_button_only_when_adult_user_has_input_minimum_of_3_characters()
			throws Throwable {
		Assert.assertEquals(isElementPresent(rating.getSubmitBtnEnabled()), true);
	}

	@And("^user click on submit button$")
	public void user_click_on_submit_button() throws Throwable {
		rating.clickSubmitBtn();
	}

	@And("user delete {int} {string}")
	public void user_delete_1_character(Integer int1, String character) throws Throwable {
		rating.deleteCharacters(character);
	}

	@And("^submit button should be disabled$")
	public void submit_button_should_be_disabled() throws Throwable {
		Assert.assertEquals(rating.getSubmitBtnEnabled().isEnabled(), false);
		ClickOnMobileElement(rating.getCloseCTA());
	}

	@And("^user give input characters$")
	public void user_give_input_characters() throws Throwable {
		logger.info("input character");
		Assert.assertEquals(rating.getWriteReviewScreen().isEnabled(), true);
	}

	@And("user give input more than 1000 characters")
	public void user_give_input_more_than_1000_characters() throws Throwable {
		logger.info("input character");
	}

	@And("user should not be able to write more than 1000 {string} review")
	public void user_should_not_be_able_to_write_more_than_1000_characters_review(String character) throws Throwable {
		rating.verifyWriteReviewField(character);
	}

	@And("user write a {string}")
	public void user_write_a_review(String review) throws Throwable {
		rating.verifyWriteReviewField(review);
	}

	@And("^user click submit cta$")
	public void user_click_submit_cta() throws Throwable {
		rating.tapSubmitReviewBtn();
	}

	@And("^user click close cta$")
	public void user_click_close_cta() throws Throwable {
		rating.tapCloseBtn();
	}

    @Then("user should be able view Adult profile in library page")
    public void userShouldBeAbleViewAdultProfileInLibraryPage() {
		waitFor(2000);
		Assert.assertEquals(rating.getAdultProfile().isDisplayed(), true);
	}

	@And("user clicks on ebook title and navigates to titles details page")
	public void userClicksOnEbookTitleAndNavigatesToTitlesDetailsPage() {
		library.clickFormat_Dropdown();
		library.click_eBook_BottomDrawer();
		waitFor(2000);
		for (int i = 0; i <= 5; i++) {
			if (isElementPresent(library.eBook_title())) {
				swipeDown();
				break;
			} else {
				swipeDown();
			}
		}
		library.click_eBook_title();
		waitFor(2000);
		Assert.assertEquals(library.eBook_Title_Details().isDisplayed(), true);
	}

	@And("user should be able to view star rating with count")
	public void userShouldBeAbleToViewStarRatingWithCount() {
		swipeDown();
		waitFor(2000);
		Assert.assertEquals(library.get_eBook_Star_Rating().isDisplayed(), true);
		Assert.assertEquals(library.get_eBook_Star_Rating_Count().isDisplayed(), true);
	}

	@And("system should show as Be the first to write a review if the title being added new and user comes as first")
	public void systemShouldShowAsBeTheFirstToWriteAReviewIfTheTitleBeingAddedNewAndUserComesAsFirst() {
		waitFor(2000);
		for (int i = 0; i <= 5; i++) {
			if (isElementPresent(rating.get_eBook_Details())) {
				swipeDown();
				break;
			} else {
				swipeDown();
			}
		}
		rating.click_eBook_Details();
		waitFor(2000);

		for (int i = 0; i <= 5; i++) {
			if (isElementPresent(library.eBook_Reviews())) {
				swipeDown();
				break;
			} else {
				swipeDown();
			}
		}
		Assert.assertEquals(library.eBook_Reviews_Count().isDisplayed(), true);
		Assert.assertEquals(library.eBook_First_Review().isDisplayed(), true);
	}

	@And("user by clicking on star rating system should open a window to provide rating")
	public void userByClickingOnStarRatingSystemShouldOpenAWindowToProvideRating() {
		library.click_eBook_Star_Rating();
		Assert.assertEquals(library.eBook_Star_RatingWindow().isDisplayed(), true);
		library.click_eBook_5StarRating();
	}

	@And("user should be able to provide review in the same page")
	public void userShouldBeAbleToProvideReviewInTheSamePage() {
		library.click_eBook_Review();
		library.enter_eBook_Review();
	}

	@Then("user should be able view Teen profile in library page")
	public void userShouldBeAbleViewTeenProfileInLibraryPage() {
		waitFor(2000);
		Assert.assertEquals(rating.getAdultProfile().isDisplayed(), true);
	}

	@Then("user should be able view Kid profile in library page")
	public void userShouldBeAbleViewKidProfileInLibraryPage() {
		Assert.assertEquals(rating.getAdultProfile().isDisplayed(), true);
	}

	@And("user clicks on eAudio title and navigates to titles details page")
	public void userClicksOnEAudioTitleAndNavigatesToTitlesDetailsPage() {
		library.clickFormat_Dropdown();
		library.click_eAudio_BootomDrawer();
		waitFor(2000);
		for (int i = 0; i <= 5; i++) {
			if (isElementPresent(library.get_eAudio_title())) {
				swipeDown();
				break;
			} else {
				swipeDown();
			}
		}
		library.click_eAudio_title();
		Assert.assertEquals(library.eBook_Title_Details().isDisplayed(), true);
	}

	@And("user clicks on Video title and navigates to titles details page")
	public void userClicksOnVideoTitleAndNavigatesToTitlesDetailsPage() {
		library.clickFormat_Dropdown();
		library.click_Video_BottomDrawer();
		waitFor(2000);
		for (int i = 0; i <= 5; i++) {
			if (isElementPresent(library.get_Video_title())) {
				swipeDown();
				break;
			} else {
				swipeDown();
			}
		}
		library.click_Video_title();
		swipeDown();
		Assert.assertEquals(library.get_Video_Title_Details().isDisplayed(), true);
	}

	@And("user clicks on vBook title and navigates to titles details page")
	public void userClicksOnVBookTitleAndNavigatesToTitlesDetailsPage() {
		library.clickFormat_Dropdown();
		library.click_vBook_BottomDrawer();
		waitFor(2000);
		for (int i = 0; i <= 5; i++) {
			if (isElementPresent(library.get_vBook_title())) {
				swipeDown();
				break;
			} else {
				swipeDown();
			}
		}
		library.click_vBook_title();
		swipeDown();
		Assert.assertEquals(library.get_Video_Title_Details().isDisplayed(), true);
	}
	@And("user should be able to submit the review as {string}")
	public void userShouldBeAbleToSubmitTheReview(String review) {
		rating.tapWriteReviewButton();
		rating.inputReview(review);
		rating.clickSubmitBtn();
		Assert.assertEquals(library.eBook_Title_Details().isDisplayed(), true);
//	@And("user should be able to submit the review as {string}")
//	public void userShouldBeAbleToSubmitTheReview(String review) {
//		rating.tapWriteReviewButton();
//		rating.inputReview(review);
//		rating.clickSubmitBtn();
//	}
	}
}