package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LearningActivity;
import pom.kidszone.MyLibrary;
import pom.kidszone.TitleDetails;

public class LearningActivity_StepDef extends CommonActions {

	LearningActivity learningact = new LearningActivity(DriverManager.getDriver());
	MyLibrary myLib = new MyLibrary(DriverManager.getDriver());
	TitleDetails details = new TitleDetails(DriverManager.getDriver());
	MyLibrary library = new MyLibrary(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(TitleDetails_StepDef.class);

	@When("user click one of learning resources and fun activities content")
	public void user_click_one_of_learning_resources_and_fun_activities_content() throws Throwable {
		learningact.scrollAndTapOnLANavigation();
	}

	@Then("user should be navigated to learning activites list screen")
	public void user_should_be_navigated_to_learning_activites_list_screen() throws Throwable {
		Assert.assertEquals(learningact.getLearningActivityTitle().isDisplayed(), true);
	}

	/********************* 148892 ***********************/

	@And("user should be able to view the learning activities list page header")
	public void user_should_be_able_to_view_the_learning_activities_list_page_header() throws Throwable {
		Assert.assertEquals(learningact.getLearningActivityList().isDisplayed(), true);
	}

	@And("user should be able to view each learning activities title as a card and titles listed as tile view")
	public void user_should_be_able_to_view_each_learning_activities_title_as_a_card_and_titles_listed_as_tile_view()
			throws Throwable {
		Assert.assertEquals(learningact.getLearningActivityCard().isDisplayed(), true);
	}

	@And("user should be able to view xxx number of learning activities titles loaded")
	public void user_should_be_able_to_view_xxx_number_of_learning_activities_titles_loaded() throws Throwable {
		Assert.assertEquals(learningact.getNoOfLearningActivity().isDisplayed(), true);
		learningact.verifyNoOfLearningActivity();
	}

	@And("user browse towards bottom of the titles displayed")
	public void user_browse_towards_bottom_of_the_titles_displayed() throws Throwable {
		logger.info("user should be able to browse towards bottom");
	}

	@And("user should be able to see lazy load next 10 number of learning activities titles")
	public void user_should_be_able_to_see_lazy_load_next_10_number_of_learning_activities_titles() throws Throwable {
		logger.info("user should be able to see lazy load");
	}

	@And("user click refine icon")
	public void user_click_refine_icon() throws Throwable {
		learningact.tapOnRefinersIcon();
	}

	@And("user navigated to refiners screen")
	public void user_navigated_to_refiners_screen() throws Throwable {
		Assert.assertEquals(learningact.getRefinersScreenHeader().isDisplayed(), true);
	}

	@And("user should be able to view page header")
	public void user_should_be_able_to_view_page_header() throws Throwable {
		Assert.assertEquals(learningact.getRefinersScreenHeader().isDisplayed(), true);
	}

	/********************* 148893 ***********************/

	@When("user click expand icon")
	public void user_click_expand_icon() throws Throwable {
		learningact.tapOnRefinersExpandIcon();
	}

	@Then("the filter options should be expanded")
	public void the_filter_options_should_be_expanded() throws Throwable {
		logger.info("filter option should be expanded");
	}

	@And("user should be able to view refines section for sort and filter")
	public void user_should_be_able_to_view_refines_section_for_sort_and_filter() throws Throwable {
		Assert.assertEquals(learningact.getSortSection().isDisplayed(), true);
		Assert.assertEquals(learningact.getActivityTypeSection().isDisplayed(), true);
		Assert.assertEquals(learningact.getAudienceLvlSection().isDisplayed(), true);
	}

	@And("user click again the icon")
	public void user_click_again_the_icon() throws Throwable {
		learningact.tapOnRefinersExpandIcon();
	}

	@And("the filter options should be collapsed")
	public void the_filter_options_should_be_collapsed() throws Throwable {
		logger.info("filter option should be collapsed");
	}

	@And("user should be able to view the selected refiners pre-populated if refiners are already applied")
	public void user_should_be_able_to_view_the_selected_refiners_prepopulated_if_refiners_are_already_applied()
			throws Throwable {
		swipeUp();
		Assert.assertEquals(learningact.getSelectedSort().isDisplayed(), true);
		Assert.assertEquals(learningact.getSelectedActivityType().isDisplayed(), true);
		swipeDown();
		swipeDown();
		Assert.assertEquals(learningact.getSelectedAudienceLvl().isDisplayed(), true);
	}

	@And("user click search")
	public void user_click_search() throws Throwable {
		learningact.tapOnViewResultsButton();
	}

	@And("user should go back to title list screen to view the updated results based on sort option and refiners selected")
	public void user_should_go_back_to_title_list_screen_to_view_the_updated_results_based_on_sort_option_and_refiners_selected()
			throws Throwable {
		Assert.assertEquals(learningact.getNoOfLearningActivity().isDisplayed(), true);
		learningact.verifyNoOfLearningActivity();
	}

	@When("user click clear cta")
	public void user_click_clear_cta() throws Throwable {
		learningact.tapOnClearButton();
	}

	@Then("user should be able to reset the refiners and sort applied")
	public void user_should_be_able_to_reset_the_refiners_and_sort_applied() throws Throwable {
		learningact.tapOnViewResultsButton();
		Assert.assertEquals(isElementPresent(learningact.getRefinersPills()), false);
	}

	@And("should be able to view clear cta on refiner screen when refiners are applied by the user")
	public void should_be_able_to_view_clear_cta_on_refiner_screen_when_refiners_are_applied_by_the_user()
			throws Throwable {
		learningact.scrollToViewResults();
		Assert.assertEquals(isElementPresent(learningact.getClearCTA()), true);
	}

	@And("user click close refiners")
	public void user_click_close_refiners() throws Throwable {
		learningact.scrollToCloseRefiners();
		ClickOnMobileElement(learningact.getCloseRefiners());
	}

	/********************* 148894 ***********************/

	@When("user is on refiners screen for learning activities lists screen")
	public void user_is_on_refiners_screen_for_learning_activities_lists_screen() throws Throwable {
		Assert.assertEquals(learningact.getRefinersScreenHeader().isDisplayed(), true);
	}

	@Then("user should be able to view sort option in the refiner section")
	public void user_should_be_able_to_view_sort_option_in_the_refiner_section() throws Throwable {
		learningact.tapOnRefinersExpandIcon();
	}

	@And("user should be able to see refine icon")
	public void user_should_be_able_to_see_refine_icon() throws Throwable {
		Assert.assertEquals(isElementPresent(learningact.getRefinersIcon()), true);
	}

	@And("user click on refine icon and navigated to refiners screen")
	public void user_click_on_refine_icon_and_navigated_to_refiners_screen() throws Throwable {
		learningact.tapOnRefinersIcon();
	}

	@And("user should be able to view sort option which consist of 'Name', 'Type', 'Name of Book title mapped', and 'Publisher'")
	public void user_should_be_able_to_view_sort_option_which_consist_of_name_type_name_of_book_title_mapped_and_publisher()
			throws Throwable {
		learningact.scrollToCloseRefiners();
		Assert.assertEquals(learningact.getSortOption().isDisplayed(), true);
	}

	@And("user should be able to expand and collapse the sort section")
	public void user_should_be_able_to_expand_and_collapse_the_sort_section() throws Throwable {
		// swipeUp();
		// learningact.tapOnRefinersCollapseIcon();
		learningact.tapOnExpandCollapseIcon();
	}

	@And("user should be able to select a sort option for the learning activities titles listed")
	public void user_should_be_able_to_select_a_sort_option_for_the_learning_activities_titles_listed()
			throws Throwable {
		swipeUp();
		learningact.tapOnSortOption();
		learningact.tapOnActivityOption();
		swipeDown();
		swipeDown();
		learningact.tapOnAudienceOption();
	}

	@And("user should be able to view the selected sort option below the sort section header")
	public void user_should_be_able_to_view_the_selected_sort_option_below_the_sort_section_header() throws Throwable {
		swipeUp();
		Assert.assertEquals(learningact.getSelectedSort().isDisplayed(), true);
	}

	@And("user should be able view the titles sorted based on selection")
	public void user_should_be_able_view_the_titles_sorted_based_on_selection() throws Throwable {
		Assert.assertEquals(learningact.getNoOfLearningActivity().isDisplayed(), true);
		learningact.verifyNoOfLearningActivity();
	}

	@And("user should be able to view the titles sorted alphabetical by book title by default")
	public void user_should_be_able_to_view_the_titles_sorted_alphabetical_by_book_title_by_default() throws Throwable {
		logger.info("title sorted alphabetically");
	}

	/********************* 148895 ***********************/

	@Then("user should be to view refine options for the learning activities titles listed")
	public void user_should_be_to_view_refine_options_for_the_learning_activities_titles_listed() throws Throwable {
		Assert.assertEquals(learningact.getActivityTypeSection().isDisplayed(), true);
		Assert.assertEquals(learningact.getAudienceLvlSection().isDisplayed(), true);
	}

	@And("user should be able to view each refine option collapsed by default which consist of 'Activity Type' and 'Audience Level'")
	public void user_should_be_able_to_view_each_refine_option_collapsed_by_default_which_consist_of_activity_type_and_audience_level()
			throws Throwable {
		learningact.tapOnRefinersExpandIcon();
	}

	@And("user should be able to expand and view sub-options for each refine option available such as type of learning resources or audience level")
	public void user_should_be_able_to_expand_and_view_suboptions_for_each_refine_option_available_such_as_type_of_learning_resources_or_audience_level()
			throws Throwable {
//		Assert.assertEquals(learningact.getActivityTypeOption().isDisplayed(), true);
		ClickOnMobileElement(learningact.getLearningActivity_btn_refinersAudienceExpandIcon());		
		Assert.assertEquals(learningact.getAudienceLvlOption().isDisplayed(), true);
	}

	@And("user should not view the refine option if no sub-option is available for that")
	public void user_should_not_view_the_refine_option_if_no_suboption_is_available_for_that() throws Throwable {
		Assert.assertEquals(isElementPresent(learningact.getActivityTypeOption()), false);
		Assert.assertEquals(isElementPresent(learningact.getAudienceLvlOption()), false);
	}

	@And("user should be able to select a refine option and sub-option")
	public void user_should_be_able_to_select_a_refine_option_and_suboption() throws Throwable {
		ClickOnMobileElement(learningact.getActivityTypeOption());
		ClickOnMobileElement(learningact.getAudienceLvlOption());
	}

	@And("user should be able to view the selected refine sub-option option below the refine option")
	public void user_should_be_able_to_view_the_selected_refine_suboption_option_below_the_refine_option()
			throws Throwable {
		Assert.assertEquals(learningact.getSelectedAudienceLvl().isDisplayed(), true);
		swipeUp();
		Assert.assertEquals(learningact.getSelectedActivityType().isDisplayed(), true);
	}

	@And("user should be able to view the results updated based on that refine option")
	public void user_should_be_able_to_view_the_results_updated_based_on_that_refine_option() throws Throwable {
		learningact.tapOnViewResultsButton();
		Assert.assertEquals(learningact.getLearningActivityCard().isDisplayed(), true);
	}

	/********************* 148896 ***********************/

	@And("user should be able to view the selected refiners sub-options on the screen as pills")
	public void user_should_be_able_to_view_the_selected_refiners_suboptions_on_the_screen_as_pills() throws Throwable {
		Assert.assertEquals(learningact.getRefinersPills().isDisplayed(), true);
	}

	@And("user should be able to remove refiners applied by clicking X on refiner sub-option pill")
	public void user_should_be_able_to_remove_refiners_applied_by_clicking_x_on_refiner_suboption_pill()
			throws Throwable {
		ClickOnMobileElement(learningact.getRefinersPillsRemover());
	}

	@And("system should update the refiner section when refiners are removed")
	public void system_should_update_the_refiner_section_when_refiners_are_removed() throws Throwable {
		Assert.assertEquals(learningact.getLearningActivityCard().isDisplayed(), true);
		Assert.assertEquals(isElementPresent(learningact.getRefinersPills2()), false);

	}

	/********************* 148897 ***********************/

	@And("user should be able each learning activity title listed as a card")
	public void user_should_be_able_each_learning_activity_title_listed_as_a_card() throws Throwable {
		Assert.assertEquals(learningact.getLearningActivityCard().isDisplayed(), true);
	}

	@And("user should be able to view cover image for the learning activity title")
	public void user_should_be_able_to_view_cover_image_for_the_learning_activity_title() throws Throwable {
		Assert.assertEquals(learningact.getCardImageCover().isDisplayed(), true);
	}

	@And("user should be able to view title of the learning activity title")
	public void user_should_be_able_to_view_title_of_the_learning_activity_title() throws Throwable {
		Assert.assertEquals(learningact.getCardTitle().isDisplayed(), true);
	}

	@And("user should be able to view learning activity title type")
	public void user_should_be_able_to_view_learning_activity_title_type() throws Throwable {
		Assert.assertEquals(learningact.getCardTitleType().isDisplayed(), true);
	}

	@And("user should be able to view title mapped to learning activity title")
	public void user_should_be_able_to_view_title_mapped_to_learning_activity_title() throws Throwable {
		Assert.assertEquals(learningact.getCardTitleMapped().isDisplayed(), true);
	}

	@And("user should be able to click on mapped title and navigate to title details screen")
	public void user_should_be_able_to_click_on_mapped_title_and_navigate_to_title_details_screen() throws Throwable {
		ClickOnMobileElement(learningact.getCardTitleMapped());
	}

	@And("user should be able to view download cta and clicks on download cta to download the title on user device")
	public void user_should_be_able_to_view_download_cta_and_clicks_on_download_cta_to_download_the_title_on_user_device()
			throws Throwable {
		ClickOnMobileElement(learningact.getDownloadButton());
		learningact.tapOnLACard();
	}

	@And("user should be able to click on card other than mapped title and download cta to view the learning activity title in browser")
	public void user_should_be_able_to_click_on_card_other_than_mapped_title_and_download_cta_to_view_the_learning_activity_title_in_browser()
			throws Throwable {
		ClickOnMobileElement(learningact.getLearningActivityCard());
		learningact.tapOnLACard();
	}

	/********************* 148899 ***********************/

	@When("user clicks on download cta")
	public void user_clicks_on_download_cta() throws Throwable {
		ClickOnMobileElement(learningact.getDownloadButton());
		learningact.tapOnLACard();
	}

	@Then("​system should initiate the download of the learning activity title on the user device")
	public void system_should_initiate_the_download_of_the_learning_activity_title_on_the_user_device()
			throws Throwable {
		Assert.assertEquals(learningact.getDownloadProgressBar().isDisplayed(), true);
	}

	@And("user should view the progress bar with % completed for the download status")
	public void user_should_view_the_progress_bar_with_completed_for_the_download_status() throws Throwable {
		Assert.assertEquals(isElementPresent(learningact.getDownloadProgressPercentage()), false);
	}

	@And("user should view pause cta to pause the download")
	public void user_should_view_pause_cta_to_pause_the_download() throws Throwable {
		Assert.assertEquals(isElementPresent(learningact.getPauseButton()), false);
	}

	/*
	 * @And("user should view resume cta if the download is paused") public void
	 * user_should_view_resume_cta_if_the_download_is_paused() throws Throwable {
	 * Assert.assertEquals(learningact.getPauseButton().isDisplayed(), true); }
	 */

	@And("user should view 'X' cta to cancel the download")
	public void user_should_view_x_cta_to_cancel_the_download() throws Throwable {
		Assert.assertEquals(isElementPresent(learningact.getStopButton()), false);
	}

	/********************** 124721 ******************************/

	@Then("user should be able to view learning resources section with kid theme")
	public void user_should_be_able_to_view_learning_resources_section_with_kid_theme() throws Throwable {
		learningact.scrollToLearningResourceFunActivities();
		Assert.assertEquals(learningact.getLearningResourceFa().isDisplayed(), true);
	}

	@And("user should be able to view the fun activities with kid theme")
	public void user_should_be_able_to_view_the_fun_activities_with_kid_theme() throws Throwable {
		Assert.assertEquals(learningact.getLearningResourceFa().isDisplayed(), true);
	}

	@And("user should be able to view brief description for the learning resources section")
	public void user_should_be_able_to_view_brief_description_for_the_learning_resources_section() throws Throwable {
	//	learningact.getLearningResourceFaDesc();
//		Assert.assertEquals(isElementPresent(learningact.getLearningResourceFaDesc()),true);
	}

	@And("user should be able to view brief description for the fun activities")
	public void user_should_be_able_to_view_brief_description_for_the_fun_activities() throws Throwable {
//		Assert.assertEquals(learningact.getLearningResourceFaDesc().isDisplayed(), true);
	}

	@And("user should be able to view 10 category")
	public void user_should_be_able_to_view_10_category() throws Throwable {
		learningact.getCategory();
	}

	@And("user should be able to view learning activities list screen with theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_learning_activities_list_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type()
			throws Throwable {
	}

	@And("user click back cta")
	public void user_click_back_cta() throws Throwable {
	}

	@And("user navigate back to last screen")
	public void user_navigate_back_to_last_screen() throws Throwable {
	}

	@And("user should be able to see learning activities list screen as per mock")
	public void user_should_be_able_to_see_learning_activities_list_screen_as_per_mock() throws Throwable {
	}

	@And("user should be able to see 'See all' cta")
	public void user_should_be_able_to_see_learn_more_cta() throws Throwable {
		learningact.getLearnMore();
	}

	@And("user click back button")
	public void user_click_back_button() throws Throwable {
		ClickOnMobileElement(details.getBackButton());
	}

	@And("user click on one of the category")
	public void user_click_on_one_of_the_category() throws Throwable {
		learningact.tapOnCategory();
	}

	@And("user should be redirected to listing page")
	public void user_should_be_redirected_to_listing_page() throws Throwable {
		Assert.assertEquals(learningact.getListingPage().isDisplayed(), true);
	}

	@And("user click 'Learn More' cta")
	public void user_click_learn_more_cta() throws Throwable {
		learningact.tapOnLearnMore();
	}

	@And("user should be redirected to learning activities tab")
	public void user_should_be_redirected_to_learning_activities_tab() throws Throwable {
		logger.info("user should be redirected to learning activities tab");
	}

	@Then("user should not view learning activities section on my library page if there is no learning activity")
	public void user_should_not_view_learning_activities_section_on_my_library_page_if_there_is_no_learning_activity()
			throws Throwable {
		Assert.assertEquals(isElementPresent(learningact.getLearningResourceFa()), true);
	}

	@And("user click related items tab")
	public void user_click_related_items_tab() throws Throwable {
		details.scrollToDetailsTab();
		details.tapOnRelatedItemsTab();
	}

	@And("user should not view learning activities if there is no learning activity")
	public void user_should_not_view_learning_activities_if_there_is_no_learning_activity() throws Throwable {
		details.scrollToDetailsTab();
		details.tapOnRelatedItemsTab();
		Assert.assertEquals(isElementPresent(learningact.getLearningActivity()), false);
	}

	@And("user validates the description of the resouce hub")
	public void userValidatesTheDescriptionOfTheResouceHub() {
		if(!isElementPresent(details.resoruceDesc())) {
			swipeDown();
		}		
		Assert.assertEquals(isElementPresent(details.resoruceDesc()), true);
	}

	@And("user clicks on the See all cta of the resource hub")
	public void userClicksOnTheSeeAllCtaOfTheResourceHub() {
		details.clickResourceHubSeeAll();
	}

	@And("user validates the refine option and clicks on the refine option")
	public void userValidatesTheRefineOptionAndClicksOnTheRefineOption() {
		Assert.assertTrue(isElementPresent(details.resourceHubRefine()));
		details.clickResourceHubRefine();

	}

	@Then("user should see the filter options")
	public void userShouldSeeTheFilterOptions() {
		Assert.assertTrue(isElementPresent(details.resourceFilterSortby()));
		Assert.assertTrue(isElementPresent(details.resourceFilterType()));
		Assert.assertTrue(isElementPresent(details.resourceFilterAudience()));
	}

	@And("user modifies the filter and clicks search button")
	public void userModifiesTheFilterAndResetAndThenClicksSearchButton() {
		details.clickResourceFilterSortby();
		Assert.assertTrue(isElementPresent(details.resourceFilterLinkedtitlee()));
		details.clickResourceFilterType();
		details.clickResourceFilterTypeAll();
		details.clickResourceFilterTypeEducator();
		details.clickResourceFilterTypeActivities();
		details.clickResourceFilterAudience();
		details.clickResourceFilterTypeAll();
		details.clickResourceFilterAudienceTeen();
		details.clickResourceFilterSearch();

	}

	@Then("user validates the filtered pills are present with clear all pill")
	public void userValidatesTheFilteredPillsArePresentWithClearAllPill() {
		Assert.assertTrue(isElementPresent(details.resourcePillActivities()));
		Assert.assertTrue(isElementPresent(details.resourcePillEducator()));
		waitFor(1000);
		Assert.assertTrue(isElementPresent(details.resourcePillTeen()));
		swipeRightToLeft(details.resourcePillClearAll());
		Assert.assertTrue(isElementPresent(details.resourcePillClearAll()));
		details.clickResourcePillClearAll();
		Assert.assertFalse(isElementPresent(details.resourcePillActivities()));
		Assert.assertFalse(isElementPresent(details.resourcePillEducator()));
//		Assert.assertFalse(isElementPresent(details.resourcePillTeen()));
	}


}
