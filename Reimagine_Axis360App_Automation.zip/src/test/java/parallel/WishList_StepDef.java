package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import pom.kidszone.InterestSurvey;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.MyCheckouts;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelf;
import pom.kidszone.ProfileCreation;
import pom.kidszone.WishList;

public class WishList_StepDef extends CommonActions {
	LoginPage login = new LoginPage(DriverManager.getDriver());
	MyShelf myshelf = new MyShelf(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	ManageProfile manage = new ManageProfile(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	MyCheckouts checkout = new MyCheckouts(DriverManager.getDriver());
	InterestSurvey interest = new InterestSurvey(DriverManager.getDriver());
	WishList wishlist= new WishList(DriverManager.getDriver());

	public static final Logger logger = LoggerFactory.getLogger(WishList_StepDef.class);

	@Then("user should be able to click on sort to view sort options")
	public void user_should_be_able_to_click_on_sort_to_view_sort_options() throws Throwable {
		checkout.clickSort();
		logger.info("User able to click on sort to view sort options");
		checkout.clickLatestAdded();
	}

	@And("tap on wishlist cta and app lands on wishlist screen")
	public void tap_on_wishlist_cta_and_app_lands_on_wishlist_screen() throws Throwable {
		myshelf.clickwishlist();
		logger.info("Tapped on wishlist cta and app lands on wishlist screen");
	}

	@And("user should be able to view sort options like latest added to wishlist and rating and a to z as sort based on title name a-z")
	public void user_should_be_able_to_view_sort_options_like_latest_added_to_wishlist_and_rating_and_a_to_z_as_sort_based_on_title_name_az()
			throws Throwable {
		if(isElementPresent(checkout.getCheckout_listView())) {
		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()), true);
		}else {
			logger.info("Program data not avilable");
		}
		logger.info(
				"user should be able to view sort options like latest added to wishlist and rating and a to z as sort based on title name a-z");
	}

	@And("user should view the titles sorted with latest title added to wishlist first by default as latest added to wishlist")
	public void user_should_view_the_titles_sorted_with_latest_title_added_to_wishlist_first_by_default_as_latest_added_to_wishlist()
			throws Throwable {
		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()), true);
		logger.info(
				"user should view the titles sorted with latest title added to wishlist first by default as latest added to wishlist");
	}

 
	@And("user should be select latest added to wishlist option")
	public void user_should_be_select_latest_added_to_wishlist_option() throws Throwable {
		logger.info("user should be select latest added to wishlist option");
	}

	@And("user should be able to view titles sorted based on options latest added to wishlist selected")
	public void user_should_be_able_to_view_titles_sorted_based_on_options_latest_added_to_wishlist_selected()
			throws Throwable {
		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()),true);
		logger.info("user should be able to view titles sorted based on options latest added to wishlist selected");
	}

	@And("user should be select rating option")
	public void user_should_be_select_rating_option() throws Throwable {
		
		logger.info("user should be select rating option");
	}

	@And("user should be able to view titles sorted based on options rating selected")
	public void user_should_be_able_to_view_titles_sorted_based_on_options_rating_selected() throws Throwable {
		
		logger.info("user should be able to view titles sorted based on options rating selected");
	}

	@And("user should be select a to z option")
	public void user_should_be_select_a_to_z_option() throws Throwable {
		
		logger.info("user should be select a to z option");
	}

	@And("user should be able to view titles sorted based on options a to z selected")
	public void user_should_be_able_to_view_titles_sorted_based_on_options_a_to_z_selected() throws Throwable {
		logger.info("user should be able to view titles sorted based on options a to z selected");
	}

	@And("user should be able to view titles sorted based on options {string} selected")
	public void user_should_be_able_to_view_titles_sorted_based_on_options_selected(String options) throws Throwable {
		checkout.hidepopup();
		checkout.clickSort();
		checkout.sort(options);
	}

//	@Then("user checkout the available title")
//	public void user_checkout_the_available_title() throws Throwable {
//		logger.info("user checkout the available title");
//	}

	@And("system should update the wishlist screen and count once remove the checked out title from the wishlist")
	public void system_should_update_the_wishlist_screen_and_count_once_remove_the_checked_out_title_from_the_wishlist()
			throws Throwable {
		logger.info(
				"system should update the wishlist screen and count once remove the checked out title from the wishlist");
	}

	@And("count should update based on remaining titles")
	public void count_should_update_based_on_remaining_titles() throws Throwable {
		logger.info("count should update based on remaining titles");
	}

	@Then("user should be able to view wishlist screen with teen theme for kidszone library subscription and adult user profile type")
	public void user_should_be_able_to_view_wishlist_screen_with_teen_theme_for_kidszone_library_subscription_and_adult_user_profile_type()
			throws Throwable {
		logger.info("Theme Checking");
	}

	@Then("user should be able to view wishlist screen with kid theme for kidszone library subscription and kid user profile type")
	public void user_should_be_able_to_view_wishlist_screen_with_kid_theme_for_kidszone_library_subscription_and_kid_user_profile_type()
			throws Throwable {
		logger.info("Theme Checking");
	}

	@Then("user should be able to view wishlist screen with kid theme for kidszone and axis360 library subscription and kid user profile type")
	public void user_should_be_able_to_view_wishlist_screen_with_kid_theme_for_kidszone_and_axis360_library_subscription_and_kid_user_profile_type()
			throws Throwable {
		logger.info("Theme Checking");
	}

	@Then("user should be able to view wishlist screen with teen theme for kidszone library subscription and teen user profile type")
	public void user_should_be_able_to_view_wishlist_screen_with_teen_theme_for_kidszone_library_subscription_and_teen_user_profile_type()
			throws Throwable {
		logger.info("Theme Checking");
	}

	@Then("user should be able to view wishlist screen with teen theme for kidszone ane axis360 library subscription and teen user profile type")
	public void user_should_be_able_to_view_wishlist_screen_with_teen_theme_for_kidszone_ane_axis360_library_subscription_and_teen_user_profile_type()
			throws Throwable {
		logger.info("Theme Checking");
	}

	@Then("user should be able to view already added titles to wishlist by that user only")
	public void user_should_be_able_to_view_already_added_titles_to_wishlist_by_that_user_only() throws Throwable {
		Assert.assertEquals(isElementPresent(myshelf.gettitle_list()), true);
	}

	@Then("user should be able to click on back cta to navigate back to last screen")
	public void user_should_be_able_to_click_on_back_cta_to_navigate_back_to_last_screen() throws Throwable {
		interest.closeButton();
//		interest.closeButton();
	}
	
	@Then("user click on the back button")
	public void user_click_on_the_back_button() {
		interest.closeButton();
	}

	@And("user should be able to view titles sorted by latest added title first by default")
	public void user_should_be_able_to_view_titles_sorted_by_latest_added_title_first_by_default() throws Throwable {

		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()), true);
		checkout.clickCheckoutView();
		Assert.assertEquals(isElementPresent(checkout.getCheckout_gridView()), true);
	}

	@And("user should be able to click on list aand grid view icon to switch been list view and grid view")
	public void user_should_be_able_to_click_on_list_aand_grid_view_icon_to_switch_been_list_view_and_grid_view()
			throws Throwable {
//		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()), false);
//		checkout.clickCheckoutView();
//		Assert.assertEquals(isElementPresent(checkout.getCheckout_gridView()), false);
	}

	@Then("user should be able to view wishlist screen with teen theme for kidszone library subscription and user profile type")
	public void user_should_be_able_to_view_wishlist_screen_with_teen_theme_for_kidszone_library_subscription_and_user_profile_type()
			throws Throwable {
		logger.info("Theme checking");
	}

	@And("user should be able to view no title wishlist screen")
	public void user_should_be_able_to_view_no_title_wishlist_screen() throws Throwable {
		Assert.assertEquals(isElementPresent(myshelf.getNo_titleFound()), true);
		logger.info("user should be able to view no title wishlist");
	}

	@And("inline message should be you currenlty have no Wishlist")
	public void inline_message_should_be_you_currenlty_have_no_wishlist() throws Throwable {
		Assert.assertEquals(isElementPresent(myshelf.getNo_titleFound()), true);
		logger.info("inline message should be you currenlty have no Wishlist");
	}

	@Then("user should be able to view wishlist screen with teen theme for kidszone and axis360 library subscription and user profile type")
	public void user_should_be_able_to_view_wishlist_screen_with_teen_theme_for_kidszone_and_axis360_library_subscription_and_user_profile_type()
			throws Throwable {
		logger.info("Theme checking");
	}

	@Then("user should be able to view wishlist screen with kid theme for kidszone library subscription and user profile type")
	public void user_should_be_able_to_view_wishlist_screen_with_kid_theme_for_kidszone_library_subscription_and_user_profile_type()
			throws Throwable {
		logger.info("Theme checking");
	}

	@Then("user should be able to view titles listed as list view by default and sorted by latest title added to wishlist first by default")
	public void user_should_be_able_to_view_titles_listed_as_list_view_by_default_and_sorted_by_latest_title_added_to_wishlist_first_by_default()
			throws Throwable {
		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()),true);
	}

	@And("user should be able to view each title listed as a card")
	public void user_should_be_able_to_view_each_title_listed_as_a_card() throws Throwable {
		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()),true);
		
	}

	@And("user should be able view title cover image and title name and author name on card")
	public void user_should_be_able_view_title_cover_image_and_title_name_and_author_name_on_card() throws Throwable {
		logger.info("Theme checking");
	}

	@Then("user should be able to view primary action for the title as a button")
	public void user_should_be_able_to_view_primary_action_for_the_title_as_a_button() throws Throwable {
	Assert.assertEquals(isElementPresent(wishlist.getPrimary_button()), true);
	}

	@And("user should be able to view more options cta to view secondary actions available for the title")
	public void user_should_be_able_to_view_more_options_cta_to_view_secondary_actions_available_for_the_title()
			throws Throwable {
		Assert.assertEquals(isElementPresent(wishlist.getSecondary_button()), true);	
	}
	
	@And("user should be able to view titles sorted based on options selected")
    public void user_should_be_able_to_view_titles_sorted_based_on_options_selected() throws Throwable {
        logger.info("user should be able to view titles sorted");
    }
	@And("user should be able to click in more options cta and view secondary actions for the title as a drawer")
	public void user_should_be_able_to_click_in_more_options_cta_and_view_secondary_actions_for_the_title_as_a_drawer()
			throws Throwable {
		wishlist.clickMoreoptions();
		wishlist.removeList();
		
	}

	@Then("user should be able to click on card other than primary and secondary cta area to navigate to title details screen")
    public void user_should_be_able_to_click_on_card_other_than_primary_and_secondary_cta_area_to_navigate_to_title_details_screen() throws Throwable {
    wishlist.clickprimaryoptions();
    Assert.assertEquals(isElementPresent(wishlist.getImage_coverDetails()), true);
    wishlist.closeBtnOption();
	}
	@Then("user should not able to view rating options in sort option")
    public void user_should_not_able_to_view_rating_options_in_sort_option() throws Throwable {
		Assert.assertEquals(checkout.getSort_ratingview(), false);
		logger.info("user should not able to view rating options in sort option");
	}

    @And("rating and review is disabled in admin")
    public void rating_and_review_is_disabled_in_admin() throws Throwable {
    	logger.info("disabled rating and review in admin");
    }

}
