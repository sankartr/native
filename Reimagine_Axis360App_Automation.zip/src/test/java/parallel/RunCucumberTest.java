package parallel;

import com.utilities.JvmReport;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/Features" },
                glue = {"parallel" }, 
                dryRun = false,
                plugin = { "pretty","json:target/ResultsMobile/RunCucumberTest.json","html:target/ResultsMobile/RunCucumberTest.html" }, 
				monochrome = true,
                tags="@RunCucumberTest and @Regression")

  public class RunCucumberTest {
	@BeforeClass
	public static void beforeClass() throws IOException {
		// String tag = System.getProperty("tag1");
        // if (tag != null) {
        //     System.setProperty("cucumber.filter.tags", String.format("@RunCucumberTest and %s", tag));
        // }
		LocalDateTime instance = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy kk:mm:ss");
		String start_time = format.format(instance);
		System.setProperty("start_time", start_time);
	}
	@AfterClass
	public static void afterClass() throws IOException {
		LocalDateTime instance = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy kk:mm:ss");
		String Endtime_time = format.format(instance);
		System.setProperty("Endtime_time", Endtime_time);
		JvmReport.generateReport(System.getProperty("user.dir") + "/target/ResultsMobile/RunCucumberTest.json");
	}
}
