package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.ProfileCreation;

public class LoginWithidandPin_StepDef extends CommonActions{

	public static final Logger logger = LoggerFactory.getLogger(LoginWithidandPin_StepDef.class);

	LoginPage login = new LoginPage(DriverManager.getDriver());
	ManageProfile manage =new ManageProfile(DriverManager.getDriver());

	@When("user enters the {string} and {string} and clicks on sign in")
	public void user_enters_the_something_and_something_and_clicks_on_sign_in(String libraryid, String pin)
			throws Throwable {
		login.loginwithidandPin(libraryid, pin);
	}

	@And("user should be redirected to the home page based on library module subscription and profile type")
	public void user_should_be_redirected_to_the_home_page_based_on_library_module_subscription_and_profile_type()
			throws Throwable {
		login.handleNothankspopup();
		Assert.assertEquals(login.homePgNav(), true);
	}

	@And("user should be able to view error message in authentication failure")
	public void user_should_be_able_to_view_error_message_in_authentication_failure() throws Throwable {
		if(isElementPresent(login.getLogo_lbl_InvalidLoginError()))
		{
			logger.info("Popup Error message Displayed");	
		}else
		{
			logger.info("Popup Error message not Displayed");	
		}
	}

    @And("user clicks on login button in independent library and enters {string} and {string}")
    public void userClicksOnLoginButtonInIndependentLibraryAndEntersAnd(String libraryid, String pin) {
		login.enterUserName(libraryid);
		login.enterPwd(pin);
		login.clickSignInBtn();
		login.closepopup();
    }
}
