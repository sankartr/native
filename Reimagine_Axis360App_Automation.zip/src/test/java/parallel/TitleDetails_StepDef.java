package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.*;

import java.util.NoSuchElementException;

public class TitleDetails_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	TitleDetails details = new TitleDetails(DriverManager.getDriver());
	MyLibrary myLib = new MyLibrary(DriverManager.getDriver());
	ManageProfile manage = new ManageProfile(DriverManager.getDriver());
	MyShelf myshelf = new MyShelf(DriverManager.getDriver());
	LearningActivity learningact = new LearningActivity(DriverManager.getDriver());
	SearchPage search = new SearchPage(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(TitleDetails_StepDef.class);



	@And("user should be navigated to library screen")
	public void user_should_be_navigated_to_library_screen() throws Throwable {
		myLib.clickMylibrary();
	}

	@When("user taps on the title card of an ebook")
	public void user_taps_on_the_title_card_of_an_ebook() throws Throwable {
//		waitFor(8000);
//		swipeDown();
//		waitFor(1000);
//		swipeDown();
//		waitFor(1000);
//		swipeDown();
//		waitFor(1000);
//		swipeDown();
//		waitFor(1000);
//		swipeDown();
//		waitFor(1000);
//		swipeDown();
		waitFor(1000);
		details.clickEbbook();
	}

	@When("user taps on the title card of an audio book")
	public void user_taps_on_the_title_card_of_an_audio_book() throws Throwable {
		// details.scrollAndTapAudioBook();
		details.selectAvailableNowTitles();
		waitFor(8000);
		details.selecteAudioTitles();
		waitFor(8000);
		swipeDown();
		swipeDown();
		swipeDown();
		swipeDown();
		details.clickAudioTitle();
	}

	@Then("user should be navigated to title details screen")
	public void user_should_be_navigated_to_title_details_screen() throws Throwable {
		details.clickDetailstab();
	}

//	@And("user logout of the application")
//	public void user_logout_of_the_application() throws Throwable {
//		ClickOnMobileElement(details.getBackButton());
//		login.logOut();
//
//	}

	/********************* 146941 **********************/
	@And("user should be able to view title of an ebook")
	public void user_should_be_able_to_view_title_of_an_ebook() {
		Assert.assertEquals(details.gettitleDetails_lbl_title().isDisplayed(), true);
		details.verifyTitleIsDisplayed();
	}

	@And("user should be able to view title of an audio book")
	public void user_should_be_able_to_view_title_of_an_audio_book() {
		Assert.assertEquals(details.gettitleDetails_lbl_title().isDisplayed(), true);
		details.verifyTitleIsDisplayed();
	}

	@And("user should be able to view subtitle of an ebook if available")
	public void user_should_be_able_to_view_subtitle_of_an_ebook_if_available() {
		if (isElementPresent(details.getsubtitle())) {
			Assert.assertEquals(isElementPresent(details.getsubtitle()), true);
		}
	}

	@And("user should be able to view subtitle of an audio book if available")
	public void user_should_be_able_to_view_subtitle_of_an_audio_book_if_available() {
		Assert.assertEquals(isElementPresent(details.getsubtitle()), false);
	}

	@And("user should not be able to view subtitle if the ebook does not have a subtitle")
	public void user_should_not_be_able_to_view_subtitle_if_the_ebook_does_not_have_a_subtitle() {
		Assert.assertEquals(isElementPresent(details.getsubtitle()), false);
	}

	@And("user should not be able to view subtitle if the audio book does not have a subtitle")
	public void user_should_not_be_able_to_view_subtitle_if_the_audio_book_does_not_have_a_subtitle() {
		Assert.assertEquals(isElementPresent(details.getsubtitle()), false);
	}

	/********************* 146942 **********************/

	@And("user should be able to view title cover image")
	public void user_should_be_able_to_view_title_cover_image() {
		swipeUp();
		Assert.assertEquals(details.getimageCover().isDisplayed(), true);
	}

	@And("user should be able to view the ebook format icon on the title cover image")
	public void user_should_be_able_to_view_the_ebook_format_icon_on_the_title_cover_image() {
		Assert.assertEquals(isElementPresent(details.getebookFormatIcon()), false);
	}

	@And("user should be able to view the audio book format icon on the title cover image")
	public void user_should_be_able_to_view_the_audio_book_format_icon_on_the_title_cover_image() {
		Assert.assertEquals(isElementPresent(details.getaudiobookFormatIcon()), true);
	}

	@And("user should be able to view default cover image if title cover image is not available")
	public void user_should_be_able_to_view_default_cover_image_if_title_cover_image_is_not_available() {
		Assert.assertEquals(isElementPresent(details.getdefaultimageCover()), true);
	}

	/********************* 146944 **********************/

	@And("user should be able to view the title reading progress based on last read location in the title")
	public void user_should_be_able_to_view_the_title_reading_progress_based_on_last_read_location_in_the_title() {
		details.getLibraryReadingProgress();
	}

	@And("user should be able to view the title reading progress based on last listened location in the title")
	public void user_should_be_able_to_view_the_title_reading_progress_based_on_last_listened_location_in_the_title() {
		details.getLibraryReadingProgress();
	}

	/********************* 146945 **********************/

	@Then("user should be able to view primary action, wishlist cta and share cta when title has only one action available other than add\\/remove to wishlist and share")
	public void user_should_be_able_to_view_primary_action_wishlist_cta_and_share_cta_when_title_has_only_one_action_available_other_than_add_remove_to_wishlist_and_share() {
		swipeDown();
		details.verifyWishlist();
		details.verifyShare();
		details.getPrimaryCTA();
	}

	@Then("user should be able to view primary and secondary action when title has more than one actions available other than add\\/remove to wishlist and share")
	public void user_should_be_able_to_view_primary_and_secondary_action_when_title_has_more_than_one_actions_available_other_than_add_remove_to_wishlist_and_share() {
		details.verifyWishlist();
		details.verifyShare();
		details.getPrimaryCTA();
	}

	@And("user should not be able to view wishlist cta and share cta as separate icons when secondary cta is shown")
	public void user_should_not_be_able_to_view_wishlist_cta_and_share_cta_as_separate_icons_when_secondary_cta_is_shown() {
		details.verifyWishlist();
		details.verifyShare();
		details.getPrimaryCTA();
	}

	/********************* 146946 **********************/

	@And("user should be able to view wishlist cta on title details screen when title has only one action available other than add to wishlist and share")
	public void user_should_be_able_to_view_wishlist_cta_on_title_details_screen_when_title_has_only_one_action_available_other_than_add_to_wishlist_and_share() {
		swipeDown();
		details.verifyWishlist();
		details.verifyShare();
		details.getPrimaryCTA();
	}

	@And("user should be able to view wishlist cta on title details screen when title has only one action available other than remove to wishlist and share")
	public void user_should_be_able_to_view_wishlist_cta_on_title_details_screen_when_title_has_only_one_action_available_other_than_remove_to_wishlist_and_share() {
		details.verifyWishlist();
	}

	@And("user should be able to view the wishlist icon for title not in wishlist")
	public void user_should_be_able_to_view_the_wishlist_icon_for_title_not_in_wishlist() {
		details.verifyWishlist();
	}

	@And("user should be able to click the icon to add a title to wishlist")
	public void user_should_be_able_to_click_the_icon_to_add_a_title_to_wishlist() {
		details.ClickWishlist();
	}

	@And("user should be able to view the wishlist icon for title that is in the wishlist")
	public void user_should_be_able_to_view_the_wishlist_icon_for_title_that_is_in_the_wishlist() {
		details.verifyWishlist();
	}

	@And("user should be able to view the icon updated when title is in the wishlist and view the icon for title in the wishlist")
	public void user_should_be_able_to_view_the_icon_updated_when_title_is_in_the_wishlist_and_view_the_icon_for_title_in_the_wishlist() {
		details.verifyWishlist();
	}

	@And("User should be able to view the confirmation toast message for adding title from the wishlist")
	public void User_should_be_able_to_view_the_confirmation_toast_message_for_adding_title_from_the_wishlist() {
		details.verifyAddMessageWishlist();
	}

	@And("user should be able to view the wishlist icon for title is in wishlist")
	public void user_should_be_able_to_view_the_wishlist_icon_for_title_is_in_wishlist() {
		details.verifyWishlist();
	}

	@And("user should be able to click the icon to remove a title from wishlist and view the icon for the title not in the wishlist")
	public void user_should_be_able_to_click_the_icon_to_remove_a_title_from_wishlist_and_view_the_icon_for_the_title_not_in_the_wishlist() {
		details.ClickWishlist();
	}

	@And("user should be able to view the confirmation toast message for removing title from the wishlist")
	public void user_should_be_able_to_view_the_confirmation_toast_message_for_removing_title_from_the_wishlist() {
		details.verifyRemoveMessageWishlist();
	}

	@And("user should not be able to view the wishlist icon for the title checked out")
	public void user_should_not_be_able_to_view_the_wishlist_icon_for_the_title_checked_out() {
		details.verifyWishlist();
	}

	/********************* 146947 **********************/

	@And("user should be able to view primary and secondary actions for ebooks when title available")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_title_available() {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to view primary and secondary actions for audio book when title available")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_available() {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to see checkout primary action")
	public void user_should_be_able_to_see_checkout_primary_action() {
		logger.info("user should be able to see checkout primary action");
	}

	@And("click on 'Add to Wishlist' and add the title to the wishlist")
	public void click_on_add_to_wishlist_and_add_the_title_to_the_wishlist() {
		details.clickWishList();
//		Assert.assertEquals(isElementPresent(details.getToastMessageAddWishlist()), true);
//		details.closeToastMessageWishList();
	}

	@And("click on 'Remove From Wishlist' and remove the title from the wishlist")
	public void click_on_remove_from_wishlist_and_remove_the_title_from_the_wishlist() {
		details.clickWishList();
		swipeDown();
//		Assert.assertEquals(isElementPresent(details.getToastMessageRemoveWishlist()), true);
//		details.closeToastMessageWishList();
	}

	@And("user should be able to see 'Share title'")
	public void user_should_be_able_to_see_share_title() throws Throwable {
		// Assert.assertEquals(details.getShareCTA().isDisplayed(), true);
		details.getShareCTAButton();
	}

	@When("^user taps on the title card of an ebook with place hold$")
	public void user_taps_on_the_title_card_of_an_ebook_with_place_hold() throws Throwable {
		details.scrollAndTapeBookWithPlaceHold();
	}

	@When("^user taps on the title card of an audio book with place hold$")
	public void user_taps_on_the_title_card_of_an_audio_book_with_place_hold() throws Throwable {
		details.scrollAndTapAudioBookWithPlaceHold();
	}

	@And("user should be able to click on 'Place Hold' and put title on hold")
	public void user_should_be_able_to_click_on_place_hold_and_put_title_on_hold() throws Throwable {
		details.clickPlaceHold();
	}

	@Then("user should be able to click on {string} and put title on hold for Purchase request Title")
	public void user_should_be_able_to_click_on_and_put_title_on_hold_for_purchase_request_title(String string) {
		details.clickPlaceHold();
	}

	@And("user should be able to view primary and secondary actions for ebooks when title not available")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_title_not_available() {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to view primary and secondary actions for audio book when title not available")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_not_available() {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to view primary and secondary actions for ebooks when title has checkout and title not downloaded")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_title_has_checkout_and_not_downloaded()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();

	}

	@And("user should be able to click on 'Download' and download the title")
	public void user_should_be_able_to_click_on_download_and_download_the_title() throws Throwable {
		details.getDownloadButton();
	}

	@And("user should be able to view progress bar after click download cta")
	public void user_should_be_able_to_view_progress_bar_after_click_download_cta() throws Throwable {
		logger.info("user should be able to view progress bar after click download cta");
	}

	@And("user should be able to click on 'Read Online' and navigate to ereader online")
	public void user_should_be_able_to_click_on_read_online_and_navigate_to_ereader_online() throws Throwable {
		logger.info("user should be able to click on 'Read Online' and navigate to ereader online");
//		details.getReadOnline();
	}

	@And("user should be able to click on 'Continue' and navigate to erader player of the title to the last read location")
	public void user_should_be_able_to_click_on_continue_and_navigate_to_erader_player_of_the_title_to_the_last_read_location()
			throws Throwable {
		logger.info(
				"user should be able to click on 'Continue' and navigate to erader player of the title to the last read location");
	}

	@And("user should be able to see return, renew, and share title")
	public void user_should_be_able_to_see_return_renew_and_share_title() throws Throwable {
		swipeUp();
		details.getReturnRenewShareButton();

	}

	@And("user should be able to view primary and secondary actions for audio book when title has checkout and title not downloaded")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_has_checkout_and_title_not_downloaded()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to view the pop-up to confirm for the actions return")
	public void user_should_be_able_to_view_the_popup_to_confirm_for_the_actions_return() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getReturnConfirmation()), false);
	}

	@And("user should be able to view primary and secondary actions for audio book when title on hold")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_on_hold()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to click on 'Suspend Hold' and suspend the hold temporarily for the title put on hold")
	public void user_should_be_able_to_click_on_suspend_hold_and_suspend_the_hold_temporarily_for_the_title_put_on_hold()
			throws Throwable {
		details.clickSecondaryDropdownCTA();
		details.clickSuspendHoldBtn();
		logger.info("user should be able to click on 'Suspend Hold'");
	}

	@And("user should be able to click on 'Remove Hold' and remove hold put on the title")
	public void user_should_be_able_to_click_on_remove_hold_and_remove_hold_put_on_the_title() throws Throwable {
		waitFor(3000);
		details.clickActivateHold();
//		details.clickSecondaryDropdownCTA();
		logger.info("user should be able to click on 'Remove Hold'");
	}

	@And("user should be able to click on 'Return' and return the title")
	public void user_should_be_able_to_click_on_return_and_return_the_title() throws Throwable {
		ClickOnMobileElement(details.getSecondaryDropdownCTA());
		ClickOnMobileElement(details.getReturnBtn());
	}

	@And("user should be able to click on 'Renew' and renew the ebook")
	public void user_should_be_able_to_click_on_renew_and_renew_the_ebook() throws Throwable {
		ClickOnMobileElement(details.getSecondaryDropdownCTA());
		ClickOnMobileElement(details.getRenewBtn());
	}

	@And("user should be able to view the pop-up to confirm for the actions renew")
	public void user_should_be_able_to_view_the_popup_to_confirm_for_the_actions_renew() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getRenewConfirmation()), false);
	}

	@And("user should be able to view primary and secondary actions for ebooks when title has checkout and title downloaded")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_title_has_checkout_and_title_downloaded()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to view primary and secondary actions for audio book when title has checkout and title downloaded")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_has_checkout_and_title_downloaded()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to click on 'Read Now' and navigate to ereader online")
	public void user_should_be_able_to_click_on_read_now_and_navigate_to_ereader_online() throws Throwable {
		ClickOnMobileElement(details.getSecondaryDropdownCTA());
		ClickOnMobileElement(details.getReadNowBtn());
	}

	@And("^user should be able to click on Remove download and delete the downloaded title$")
	public void user_should_be_able_to_click_on_remove_download_and_delete_the_downloaded_title() throws Throwable {
		ClickOnMobileElement(details.getSecondaryDropdownCTA());
		ClickOnMobileElement(details.getRemoveDownload());
	}

	@And("^user should be able to view the popup to confirm for the actions Remove download$")
	public void user_should_be_able_to_view_the_popup_to_confirm_for_the_actions_remove_download() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getRemoveDownloadConfPopup()), true);
		ClickOnMobileElement(details.getRemoveDownloadYesConf());
	}

	@And("user should be able to click on 'Remove (delete download)' and delete the downloaded title")
	public void user_should_be_able_to_click_on_remove_delete_download_and_delete_the_downloaded_title()
			throws Throwable {
		ClickOnMobileElement(details.getSecondaryDropdownCTA());
		ClickOnMobileElement(details.getRemoveDownload());
	}

	@And("user should be able to view primary and secondary actions for audio book when title downloaded")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_downloaded()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to view primary and secondary actions for ebooks when title hold suspended")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_title_hold_suspended()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to view the pop-up to confirm for the actions 'Remove (delete download)'")
	public void user_should_be_able_to_view_the_popup_to_confirm_for_the_actions_remove_delete_download()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getRemoveConfirmation()), true);
	}

	@And("user should be able to view primary and secondary actions for ebooks when title on hold")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_title_on_hold()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();

	}

	@And("user should be able to click on 'Activate Hold' and resume the suspended hold for the title")
	public void user_should_be_able_to_click_on_activate_hold_and_resume_the_suspended_hold_for_the_title()
			throws Throwable {

	}

	@And("user should be able to view primary and secondary actions for audio book when title hold suspended")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_hold_suspended()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();

	}

	@And("user should be able to view primary and secondary actions for ebooks when recommendations title")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_recommendations_title()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to click on 'Cancel Recommendation' and cancel the recommendation for the title")
	public void user_should_be_able_to_click_on_cancel_recommendation_and_cancel_the_recommendation_for_the_title()
			throws Throwable {

	}

	@And("user should be able to view primary and secondary actions for audio book when recommendations title")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_recommendations_title()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to view 'Add/Remove to Wishlist' as a primary and 'Share title' as a secondary actions for ebooks when ppc budget maxed out")
	public void user_should_be_able_to_view_addremove_to_wishlist_as_a_primary_and_share_title_as_a_secondary_actions_for_ebooks_when_ppc_budget_maxed_out()
			throws Throwable {

	}

	@And("user should be able to view 'Add/Remove to Wishlist' as a primary and 'Share title' as a secondary actions for audio book when ppc budget maxed out")
	public void user_should_be_able_to_view_addremove_to_wishlist_as_a_primary_and_share_title_as_a_secondary_actions_for_audio_book_when_ppc_budget_maxed_out()
			throws Throwable {

	}

	@And("user should be able to view primary and secondary actions for ebook when title downloaded")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebook_when_title_downloaded()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("No Hold & Checkout if budget is maxed out")
	public void no_hold_checkout_if_budget_is_maxed_out() throws Throwable {

	}

	/********************* 146948 **********************/
	@And("user should be able to view share icon when title is not checked out, not on hold or title is recommendations title")
	public void user_should_be_able_to_view_share_icon_when_title_is_not_checked_out_not_on_hold_or_title_is_recommendations_title() {
		details.verifyShare();
	}

	@And("user should be able to view the share action in more title actions when title has more actions than checkout/hold, add/remove to wishlist & share")
	public void user_should_be_able_to_view_the_share_action_in_more_title_actions_when_title_has_more_actions_than_checkouthold_addremove_to_wishlist_share() {
		details.verifyShare();
	}

	@And("user click on share icon and view default native share options")
	public void user_click_on_share_icon_and_view_default_native_share_options() {
		details.Clickshare();
	}

	@And("user should be able to view confirmation message on successful sharing")
	public void user_should_be_able_to_view_confirmation_message_on_successful_sharing() {
	}

	@And("user should be able to remain on title details screen after sharing")
	public void user_should_be_able_to_remain_on_title_details_screen_after_sharing() {
		details.clickshareCloseIcon();
	}

	@And("user should be able to view error message if sharing is failed")
	public void user_should_be_able_to_view_error_message_if_sharing_is_failed() {
	}

	/********************* 146949 **********************/
	@And("user should be able to view title synopsis")
	public void user_should_be_able_to_view_title_synopsis() {
		details.verifySynopsis();
	}

	@And("user should be able to view 'View all' cta to view complete synopsis if synopsis content does not fit the default height")
	public void user_should_be_able_to_view_view_all_cta_to_view_complete_synopsis_if_synopsis_content_does_not_fit_the_default_height() {
		details.verifySeeMore();
	}

	@And("user should be able to click on view all to view the complete synopsis")
	public void user_should_be_able_to_click_on_view_all_to_view_the_complete_synopsis() {
		details.ClickSeeMore();
	}

	@And("user should be able to view 'View Less' cta when synopsis is expanded")
	public void user_should_be_able_to_view_view_less_cta_when_synopsis_is_expanded() {
		details.verifySeeMore();
	}

	@And("user should be able to click on view less to collapse synopsis to default height")
	public void user_should_be_able_to_click_on_view_less_to_collapse_synopsis_to_default_height() {
		details.ClickSeeMore();

	}

	@And("user should not be able to view synopsis if no synopsis are available")
	public void user_should_not_be_able_to_view_synopsis_if_no_synopsis_are_available() {
		details.verifySynopsis();
	}

	/********************* 146950 **********************/

	@And("user should be able to view tabs more like this, related items and details")
	public void user_should_be_able_to_view_tabs_more_like_this_related_items_and_details() {
		search.clickTitleCover();
		waitFor(5000);
		details.scrollToDetailsTab();
		details.getmoreLikethisTab();
		details.getRelatedItemTab();
		Assert.assertEquals(isElementPresent(details.getdetailsTab()), true);
	}

	@And("user should be able to view tab 'More Like This' tab is opened by default")
	public void user_should_be_able_to_view_tab_more_like_this_tab_is_opened_by_default() {
		details.getmoreLikethisTab();
	}

	@And("user should be able to view recommendations based on title carousel")
	public void user_should_be_able_to_view_recommendations_based_on_title_carousel() {
		details.verifyRecommendedTitle();
	}

	@And("user should be able to view title in series carousel")
	public void user_should_be_able_to_view_title_in_series_carousel() {
		details.verifyRecommendedTitle();
	}

	@When("user click on related items tab")
	public void user_click_on_related_items_tab() {
		details.tapOnRelatedItemsTab();
	}

	@Then("user should be able to see 'Related Items' tab open")
	public void user_should_be_able_to_see_related_items_tab_open() {
		details.getRelatedItemTab();
	}

	@And("user should be able to view learning activities")
	public void user_should_be_able_to_view_learning_activities() {
		Assert.assertEquals(isElementPresent(details.getLearningActivities()), false);
	}

	@When("user click on details tab")
	public void user_click_on_details_tab() {
		details.tapDetailsTab();
	}

	@Then("user should be able to see 'Details' tab open with its information")
	public void user_should_be_able_to_see_details_tab_open_with_its_information() throws Throwable {
		Assert.assertEquals(details.getdetailsTab().isEnabled(), true);
	}

	@Then("user should be able to see 'Details' tab open and view 'Author: First Name LastName' and 'Narrator: First Name Last Name'")
	public void user_should_be_able_to_see_details_tab_open_and_view_author_first_name_lastname_and_narrator_first_name_last_name() {
		Assert.assertEquals(isElementPresent(details.getAuthorDetailsTab()), true);
	}

	@And("^user should be able to view 'Series: Series Name' and 'Format: eBook \\(eAudio, Video, vBook, Comic\\)'$")
	public void user_should_be_able_to_view_series_series_name_and_format_ebook_eaudio_video_vbook_comic()
			throws Throwable {
//		details.scrollToAuthor();
		Assert.assertEquals(isElementPresent(details.getFormatDetailsTab()), true);
//		details.verifySeriesIsDisplayed();
	}

	@And("^user should be able to view 'Edition: 2nd edition \\(Abridged, Unabridged\\)' and 'Length : 344 pages \\(12h 15m\\)'$")
	public void user_should_be_able_to_view_edition_2nd_edition_abridged_unabridged_and_length_344_pages_12h_15m()
			throws Throwable {
		details.scrollToSubject();
		details.verifyEditionIsDisplayed();
		details.verifyLengthIsDisplayed();

	}

	@And("^user should be able to view 'Language: Bilingual \\- ENG \\/ SPA' and 'Attribute: eRead\\-Along \\(Text-to-Speech, Fixed Format, Comic Panel View, Close-captioned, etc.\\)'$")
	public void user_should_be_able_to_view_language_bilingual_eng_spa_and_attribute_ereadalong_texttospeech_fixed_format_comic_panel_view_closecaptioned_etc()
			throws Throwable {
		swipeDown();
		Assert.assertEquals(isElementPresent(details.getLanguageDetailsTab()), true);
//		details.verifyAttributeIsDisplayed();
	}

	@And("^user should be able to view 'Publisher: Name' and 'Pub Date: Date \\(04-May-2022\\)'$")
	public void user_should_be_able_to_view_publisher_name_and_pub_date_date_04may2022() throws Throwable {
//		details.scrollToSubject();
		swipeDown();
		Assert.assertEquals(details.getPublisherDetailsTab().isDisplayed(), true);
		Assert.assertEquals(details.getPublishDateDetails().isDisplayed(), true);
	}

	@And("user should be able to view 'ISBN: 13 digit number' and 'Audience: Teen' and 'Age Range: 12-14' and 'Lexile: Lexile level'")
	public void user_should_be_able_to_view_isbn_13_digit_number_and_audience_teen_and_age_range_1214_and_lexile_lexile_level()
			throws Throwable {
		swipeDown();
		Assert.assertEquals(isElementPresent(details.getISBNDetailsTab()), true);

	}

	@And("^user should be able to view 'Awards: National Book Award, Corettta Scott King Award, Newbery Award, Caldicott, etc.\\)' and 'Subjects: Bisac 1 Bisac 2 Bisac'$")
	public void user_should_be_able_to_view_awards_national_book_award_corettta_scott_king_award_newbery_award_caldicott_etc_and_subjects_bisac_1_bisac_2_bisac()
			throws Throwable {
		// details.scrollToSubject();
		Assert.assertEquals(isElementPresent(details.getSubjectDetails()), true);

	}

	@And("user should be able to view reviews and write a review")
	public void user_should_be_able_to_view_reviews_and_write_a_review() {
		swipeDown();
		Assert.assertEquals(isElementPresent(details.getWriteReviewDetailsTab()), true);
	}

	@And("user should not able to see the field if there are no values for the field")
	public void user_should_not_able_to_see_the_field_if_there_are_no_values_for_the_field() {

	}

	/********************* 146951 **********************/

	@And("user should be able to view author names for the title")
	public void user_should_be_able_to_view_author_names_for_the_title() {
		Assert.assertEquals(isElementPresent(details.getAuthorName()), true);
	}

	@And("user should be able to view author names as a link")
	public void user_should_be_able_to_view_author_names_as_a_link() {
		swipeUpLess();
		Assert.assertTrue(isElementPresent(details.getAuthorNameCTA()));
	}

	@And("user click on author name")
	public void user_click_on_author_name() {
		details.clickOnAuthorName();
	}

	@And("user should navigate to search results screen with search results for that author")
	public void user_should_navigate_to_search_results_screen_with_search_results_for_that_author() {
		ClickOnMobileElement(details.getBackButton());
	}

	/********************* 146953 **********************/

	@And("user should be able to view available formats for the title")
	public void user_should_be_able_to_view_available_formats_for_the_title() {
	for (int i = 0; i <= 5; i++) {
			if (isElementPresent(details.getFormatDetailsTab())) {
				break;
			} else {
				swipeDown();
			}
		}
		Assert.assertEquals(isElementPresent(details.getFormatDetailsTab()), true);
	}

	/********************* 146954 **********************/
	@Then("User should be able to view isbn for the title")
	public void user_should_be_able_to_view_isbn_for_the_title() throws Throwable {
		details.scrollToSubject();
		Assert.assertEquals(isElementPresent(details.getISBNDetailsTab()), true);
	}

	@And("User should be able to view publisher for the title")
	public void user_should_be_able_to_view_publisher_for_the_title() throws Throwable {
		details.scrollToPublisher();
		Assert.assertEquals(isElementPresent(details.getPublisherDetailsTab()), true);
	}

	@And("User should be able to view release date for the title")
	public void user_should_be_able_to_view_release_date_for_the_title() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getPublishDateDetails()), true);
	}

	@And("User should be able to view the date in the format 'DD MMM, YYYY'")
	public void user_should_be_able_to_view_the_date_in_the_format_dd_mmm_yyyy() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getPublishDateDetails()), true);
	}

	@And("User should be able to view language for the title")
	public void user_should_be_able_to_view_language_for_the_title() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getLanguageDetailsTab()), true);
	}

	/********************* 146955 **********************/

	@And("user should be able to see details tab open")
	public void user_should_be_able_to_see_details_tab_open() {
		Assert.assertEquals(details.getdetailsTab().isEnabled(), true);
	}

	@And("user should be able to view name of the books series as cta")
	public void user_should_be_able_to_view_name_of_the_books_series_as_cta() {
		details.verifySeriesIsDisplayed();
	}

	@When("user clicks on book series")
	public void user_clicks_on_book_series() {
		ClickOnMobileElement(details.getSeriesName());
		waitFor(5000);
	}

	@Then("user should be able to navigate to title list screen for the titles in the series")
	public void user_should_be_able_to_navigate_to_title_list_screen_for_the_titles_in_the_series() {
		details.getSeriesListScreen();
	}

	@And("user should not be able to view the book series cta if title is not in series")
	public void user_should_not_be_able_to_view_the_book_series_cta_if_title_is_not_in_series() throws Throwable {
		logger.info("user should not be able to view the book series cta if title is not in series");
	}

	/********************* 146956 ***********************/

	@And("user should be able to view 'Copies' for the title i.e. 'Copies: 1 of 2 available'")
	public void user_should_be_able_to_view_copies_for_the_title_ie_copies_1_of_2_available() throws Throwable {
		swipeDown();
		Assert.assertEquals(isElementPresent(details.getAvailableCopy()), true);
	}

	@When("user taps on the title card of an ebook with unlimited copies for general collection")
	public void user_taps_on_the_title_card_of_an_ebook_with_unlimited_copies_for_general_collection()
			throws Throwable {
		details.scrollAndTapeBook();
	}

	@When("user taps on the title card of an audio book with unlimited copies for general collection")
	public void user_taps_on_the_title_card_of_an_audio_book_with_unlimited_copies_for_general_collection()
			throws Throwable {
		details.scrollAndTapAudioBook();
	}

	@And("user should be able to view 'Available' for the title i.e. 'Copies: Available'")
	public void user_should_be_able_to_view_available_for_the_title() throws Throwable {
		waitFor(5000);
		swipeDown();
		swipeDown();
		swipeDown();
		Assert.assertEquals(details.getAvailableCopy().isDisplayed(), true);
		details.verifyCopiesLabelIsDisplayed();
	}

	@When("user taps on the title card of an ebook with unlimited copies for always available collection")
	public void user_taps_on_the_title_card_of_an_eboook_with_unlimited_copies_for_always_available_collection()
			throws Throwable {
		details.scrollAndTapeBook();
	}

	@When("user taps on the title card of an audio book with unlimited copies for always available collection")
	public void user_taps_on_the_title_card_of_an_audio_boook_with_unlimited_copies_for_always_available_collection()
			throws Throwable {
		details.scrollAndTapAudioBook();
	}

	@When("user taps on the title card of an ebook that is not exist in library's inventory")
	public void user_taps_on_the_title_card_of_an_ebook_that_is_not_exist_in_library_inventory() throws Throwable {
		details.scrollAndTapeBook();
	}

	@When("user taps on the title card of an audio book that is not exist in library's inventory")
	public void user_taps_on_the_title_card_of_an_audio_book_that_is_not_exist_in_library_inventory() throws Throwable {
		details.scrollAndTapAudioBook();
	}

	@And("user should not see copies label")
	public void user_should_not_see_copies_label() throws Throwable {
		swipeDown();
		swipeDown();
		Assert.assertEquals(details.getAvailableCopy().isDisplayed(), true);
		details.verifyCopiesLabelIsDisplayed();
	}

	/********************* 146957 ***********************/
	@And("user taps on details tab")
	public void user_taps_on_details_tab() throws Throwable {
		details.tapDetailsTab();
	}

	@And("user should be able to view patrons on hold count for the title")
	public void user_should_be_able_to_view_patrons_on_hold_count() throws Throwable {
		waitFor(3000);
		swipeDown();
		swipeDown();
		details.tapDetailsSection();
		swipeDown();
		Assert.assertEquals(isElementPresent(details.getPatronOnHold()), true);
		swipeUp();
		swipeUp();
		waitFor(3000);
		swipeUp();
		details.scrollAndTapToolTip();
	}

	/********************* 146958 ***********************/

	@When("user taps on the title card of an ebook with a hold position")
	public void user_taps_on_the_title_card_of_an_ebook_with_a_hold_positon() throws Throwable {
		details.tapBookWithRemoveHold();
	}

	@When("user taps on the title card of an audio book with a hold position")
	public void user_taps_on_the_title_card_of_an_audio_book_with_a_hold_position() throws Throwable {
		details.tapBookWithRemoveHold();
	}

	@And("user should be able to view hold position of the patron for the title")
	public void user_should_be_able_to_view_hold_position_of_the_patron() throws Throwable {
		details.getPatronOnHoldSection();
	}

	@And("user should be able to view tool tip for the hold position")
	public void user_should_be_able_to_view_tool_tip_for_the_hold_position() throws Throwable {
		details.verifyToolTipIsDisplayed();
	}

	@And("user taps on the tool tip")
	public void user_taps_on_the_tool_tip() throws Throwable {
		details.tapToolTip();
	}

	@And("user should be able to view the tool tip verbiage displayed as 'You may move forward or backward in the queue as other patrons suspend and reactivate their hold. You will receive an email when it is available for checkout.'")
	public void user_should_be_able_to_view_the_tool_tip_verbiage() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getToolTipVerbiage()), true);
		ClickOnMobileElement(details.getToolTipVerbiageClose());
	}

	/********************* 146959 ***********************/

	@And("user should be able to view Level 1 and Level 2 subjects mapped to the title based on bisac")
	public void user_should_be_able_to_view_level1_and_level2_subjects_mapped_to_the_title_based_on_bisac()
			throws Throwable {
		details.tapDetailsTab();
		details.scrollToSubject();
		Assert.assertEquals(details.getSubjectDetails().isDisplayed(), true);
	}

	@And("user should be able to view subjects as cta")
	public void user_should_be_able_to_view_subjects_as_cta() throws Throwable {
		Assert.assertEquals(details.getSubjectDetails().isDisplayed(), true);
	}

	@And("user should be able to click on a subject")
	public void user_should_be_able_to_click_on_a_subject() throws Throwable {
		logger.info("user should be able to tap on subject");
	}

	@And("navigate to titles list screen for that subject")
	public void navigate_to_title_list_screen_for_that_subject() throws Throwable {
		logger.info("Title list screen is not displayed");
	}

	/********************* 146960 ***********************/

	@And("user should be able to view narrator names for the audio book titles as read by\\/narrated by attribute")
	public void user_should_be_able_to_view_narrator_names_for_the_audio_book() throws Throwable {
		details.tapDetailsTab();
		Assert.assertEquals(isElementPresent(details.getNarratorName()), true);

	}

	@And("user should be able to view narrator names for Read By\\/Narrated by as ctas")
	public void user_should_be_able_to_view_narrator_names_for_read_by_narrated_by_as_ctas() throws Throwable {
		Assert.assertEquals(details.getNarratorNameCTA().isDisplayed(), true);
	}

	@And("user should be able to click on narrator name")
	public void user_should_be_able_to_click_on_narrator_name() throws Throwable {
		details.clickOnNarratorName();
	}

	@And("navigate to search results screen with search results for that narrator")
	public void navigate_to_search_results_screen_with_search_results_for_that_narrator() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getNarratorSearchResultScreen()), true);
		ClickOnMobileElement(details.getBackButton());
	}

	/********************* 146961 ***********************/

	@And("user should be able to view edition for the audio book")
	public void user_should_be_able_to_view_edition_for_the_audio_book() throws Throwable {
		details.tapDetailsTab();
		details.verifyEditionIsDisplayed();
	}

	/********************* 146963 ***********************/

	@And("user should be able to view duration of the audio book")
	public void user_should_be_able_to_view_duration_of_the_audio_book() throws Throwable {
		swipeDown();
		Assert.assertEquals(isElementPresent(details.checkAudioFronat()), true);
		Assert.assertEquals(isElementPresent(details.getDuration()), true);
	}

	@And("user should be able to view duration as 'XX Hours XX Minutes'")
	public void user_should_be_able_to_view_duration_as_hours_minutes() throws Throwable {
		Assert.assertEquals(isElementPresent(details.checkAudioLength()), true);
	}

	@And("user should be able to view duration as 'XX Hours' if no minute available to be displayed")
	public void user_should_be_able_to_view_duration_as_hours_if_no_minute_available() throws Throwable {
		logger.info("user should be able to view duration as 'XX Hours' if no minute available to be displayed");
	}

	@And("user should be able to view duration as 'XX Minutes' if title is less than one hour")
	public void user_should_be_able_to_view_duration_as_minutes_if_less_than_one_hour() throws Throwable {
		logger.info("user should be able to view duration as 'XX Minutes' if title is less than one hour");
	}

	/********************* 146964 ***********************/

	@And("user should be able to view text to speech for the titles that have test to speech")
	public void user_should_be_able_to_view_text_to_speech_for_the_titles_that_have_text_to_speech() throws Throwable {
		details.tapDetailsTab();
		swipeDown();
		Assert.assertEquals(details.getAttribute().isDisplayed(), true);
	}

	@And("user should not be able to view text to speech if text to speech is not available for the title or if eRead Along is available")
	public void user_should_not_be_able_to_view_text_to_speech_if_not_available() throws Throwable {
		details.tapDetailsTab();
		details.verifyAttributeIsDisplayed();
	}

	/********************* 146965 ***********************/

	@Then("user should be able to view total number of pages for the ebook as attribute pages")
	public void user_should_be_able_to_view_total_number_of_pages_for_the_ebook_as_attribute_pages() throws Throwable {
		details.tapDetailsTab();
		Assert.assertEquals(details.getNoOfPageAttribute().isDisplayed(), true);
	}

	/********************* 146966 ***********************/

	@When("user is on title details screen of an ebook")
	public void user_is_on_title_details_screen_of_an_ebook() throws Throwable {
		logger.info("user is on title details screen");
	}

	@When("user is on title details screen of an audio book")
	public void user_is_on_title_details_screen_of_an_audio_book() throws Throwable {
		logger.info("user is on title details screen");
	}

	@Then("user should be able to view size of the title file")
	public void user_should_be_able_to_view_size_of_the_title_file() throws Throwable {
		details.tapDetailsTab();
		swipeDown();
		Assert.assertEquals(details.getTitleFileSize().isDisplayed(), true);
	}

	/********************* 146967 ***********************/

//	@Then("user should be able to view recommended titles based on the title being viewed")
//	public void user_should_be_able_to_view_recommended_titles_based_on_the_title_being_viewed() throws Throwable {
//		details.scrollToDetailsTab();
//		details.verifyRecommendedTitle();
//	}

	@And("user should be able to view \"No Recommended books available\" displayed if no title to be recommended")
	public void user_should_be_able_to_view_no_recommended_books_available_displayed_if_no_title_to_be_recommended()
			throws Throwable {
		details.scrollToDetailsTab();
		details.verifyRecommendedTitle();
	}

	@And("user should be able to view recommended titles as first carousel of \"More Like This\" tab")
	public void user_should_be_able_to_view_recommended_titles_as_first_carousel_of_more_like_this_tab()
			throws Throwable {
		// Assert.assertEquals(details.getTitleCard().isDisplayed(), true);
		logger.info("Recommended title as first carousel");
	}

	@And("user should be able to view each title as title card")
	public void user_should_be_able_to_view_each_title_as_title_card() throws Throwable {
		// Assert.assertEquals(details.getTitleCard().isDisplayed(), true);
		logger.info("Title card is displayed");
	}

	/********************* 146977 ***********************/

	@And("user taps on the title card of an ebook in the carousel")
	public void user_taps_on_the_title_card_of_an_ebook_in_the_carousel() throws Throwable {
		details.scrollAndTapeBook();
	}

	@And("user taps on the title card of an audio book in the carousel")
	public void user_taps_on_the_title_card_of_an_audio_book_in_the_carousel() throws Throwable {
		details.scrollAndTapAudioBook();
	}

	@When("user is on title details screen")
	public void user_is_on_title_details_screen() throws Throwable {
		logger.info("User is on details screen");
	}

	@Then("user should be able to swipe left to navigate to the title details screen of the previous title in the list")
	public void user_should_be_able_to_swipe_left_to_navigate_to_the_title_details_screen_of_the_previous_title_in_the_list()
			throws Throwable {
		details.swipeLeftCard();
	}

	@And("user should be able to swipe right to navigate to the title details screen of the next title in the list")
	public void user_should_be_able_to_swipe_right_to_navigate_to_the_title_details_screen_of_the_next_title_in_the_list()
			throws Throwable {
		details.swipeRightCard();
	}

	@And("user should not be able to swipe to the left if it is the first title in the list")
	public void user_should_not_be_able_to_swipe_to_the_left_if_it_is_the_first_title_in_the_list() throws Throwable {
		details.swipeLeftLastCard();
	}

	@And("user should not be able to swipe to the right if it is the last title in the list")
	public void user_should_not_be_able_to_swipe_to_the_right_if_it_is_the_last_title_in_the_list() throws Throwable {
		details.swipeRightFirstCard();
	}

	@And("user should be able to swipe left")
	public void user_should_be_able_to_swipe_left() throws Throwable {
		details.swipeLeftCard();
	}

	/********************* 148838 ***********************/

	@Then("user should be able to view selected title information on title details screen")
	public void user_should_be_able_to_view_selected_title_information_on_title_details_screen() throws Throwable {
		Assert.assertEquals(details.gettitleDetails_lbl_title().isDisplayed(), true);
		details.verifyTitleIsDisplayed();
	}

	@And("user should be able to view format as an icon")
	public void user_should_be_able_to_view_format_as_an_icon() throws Throwable {
		swipeDown();
		Assert.assertEquals(details.getTitleFormatIcon().isDisplayed(), true);
	}

	@And("user should be able to view profile as an icon based on title age\\/audience level")
	public void user_should_be_able_to_view_profile_as_an_icon_based_on_title_ageaudience_level() throws Throwable {
		// Assert.assertEquals(details.getProfileIcon().isDisplayed(), true);
		logger.info("profile icon is covered in 6a");
	}

	@And("user should be able to view age based on title audience level as an icon")
	public void user_should_be_able_to_view_age_based_on_title_audience_level_as_an_icon() throws Throwable {
		// Assert.assertEquals(details.getAgeIcon().isDisplayed(), true);
		logger.info("age and audience level are covered in 6a");
	}

	@And("user should be able to view language of the title as an icon")
	public void user_should_be_able_to_view_language_of_the_title_as_an_icon() throws Throwable {
		Assert.assertEquals(details.getLanguageIcon().isDisplayed(), true);
	}

	@And("user should be able to view number of pages for ebook")
	public void user_should_be_able_to_view_number_of_pages_for_ebook() throws Throwable {
		// Assert.assertEquals(details.getNoOfPages().isDisplayed(), true);
		logger.info("number of pages is covered in future sprint");
	}

	@Then("user should be able to view duration for audiobooks as icon")
	public void user_should_be_able_to_view_duration_for_audiobooks_as_icon() {
		// Assert.assertEquals(details.getDuration().isDisplayed(), true);
		logger.info("duration is covered in future sprint");
	}

	@And("user should be able to view text to speech as text or eread-along if applicable")
	public void user_should_be_able_to_view_text_to_speech_as_text_or_ereadalong_if_applicable() throws Throwable {
		details.verifyQuickInfoTextToSpeech();
	}

	@And("user should be able to view subject as text and view release date as text")
	public void user_should_be_able_to_view_subject_as_text_and_view_release_date_as_text() throws Throwable {
		if (isElementPresent(details.getSubjectText())) {
			Assert.assertEquals(isElementPresent(details.getSubjectText()), true);
			Assert.assertEquals(details.getReleaseDate().isDisplayed(), true);
		}
	}

	/********************* 149736 ***********************/

	@Then("user should be able to view eread along for the titles that have eread along available")
	public void user_should_be_able_to_view_eread_along_for_the_titles_that_have_eread_along_available()
			throws Throwable {
		Assert.assertEquals(details.geteReadAlong().isDisplayed(), true);
	}

	@Then("user should not be able to view eread along if eread along is not available for the title")
	public void user_should_not_be_able_to_view_eread_along_if_eread_along_is_not_available_for_the_title()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.geteReadAlong()), false);
	}

	/********************* 159581 ***********************/

	@Then("user should be able to view purchase request filter")
	public void user_should_be_able_to_view_purchase_request_filter() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getPurchaseReqFilter()), true);
	}

	@And("user selects the 'Purchase Request' option from the availble filter")
	public void user_selects_the_purchase_request_option_from_the_availble_filter() throws Throwable {
		ClickOnMobileElement(details.getPurchaseReqFilter());
	}

	@And("system should redirect the user to the search result page")
	public void system_should_redirect_the_user_to_the_search_result_page() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getPurchaseReqResultScreen()), true);
	}

	@And("user should be able to view list of books with 'Request' cta")
	public void user_should_be_able_to_view_list_of_books_with_request_cta() throws Throwable {
		details.getPurchaseReqBookList();
	}

	@And("user click any of the available ebook title")
	public void user_click_any_of_the_available_ebook_title() throws Throwable {
		details.clickPurchaseReqBookList();
	}

	@And("user should not view the copies attribute for title from purchase request collection")
	public void user_should_not_view_the_copies_attribute_for_title_from_purchas_request_collection() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getAvailableCopy()), false);
	}

	@And("user click any of the available audio book title")
	public void user_click_any_of_the_available_audio_book_title() throws Throwable {
		details.clickPurchaseReqBookList();
	}

	@And("user should be able to see request and share title cta")
	public void user_should_be_able_to_see_request_and_share_title_cta() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getCheckoutCTA()), true);
		Assert.assertEquals(isElementPresent(details.getShareCTA()), true);
	}

	@And("user click on 'Request' cta")
	public void user_click_on_request_cta() throws Throwable {
		ClickOnMobileElement(details.getCheckoutCTA());
	}

	@And("^system should show success notification message as 'Your purchase request has been sent to the library for consideration.'$")
	public void system_should_show_success_notification_message_as_your_purchase_request_has_been_sent_to_the_library_for_consideration()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getPurchaseReqSuccessMsg()), false);
	}

	@And("user should view 'Cancel Request' and share title cta if the book is already requested")
	public void user_should_view_cancel_request_and_share_title_cta_if_the_book_is_already_requested()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getCancelPurchaseReqBtn()), true);
		Assert.assertEquals(isElementPresent(details.getShareCTA()), true);
		ClickOnMobileElement(details.getBackButton());
	}

	@And("user should be able to see remove hold, cancel request and share title cta")
	public void user_should_be_able_to_see_remove_hold_cancel_request_and_share_title_cta() throws Throwable {
		ClickOnMobileElement(details.getSecondaryDropdownCTA());
		Assert.assertEquals(isElementPresent(details.getRemoveHoldBtn()), true);
		Assert.assertEquals(isElementPresent(details.getCancelReqDrawer()), true);
	}

	/********************* 159582 ***********************/

	@When("^user taps on the title card of an ebook that reached daily checkout Limit$")
	public void user_taps_on_the_title_card_of_an_ebook_that_reached_daily_checkout_limit() throws Throwable {
		details.scrollAndTapeBookWithLimit();
	}

	@When("^user taps on the title card of an audio book that reached daily checkout Limit$")
	public void user_taps_on_the_title_card_of_an_audio_book_that_reached_daily_checkout_limit() throws Throwable {
		details.scrollAndTapAudioBookWithLimit();
	}

	@And("library has setup daily checkout limit")
	public void library_has_setup_daily_checkout_limit() throws Throwable {
		logger.info("library has setup daily checkout limit");
	}

	@And("user taps on the Checkout title")
	public void user_taps_on_the_checkout_title() throws Throwable {
		ClickOnMobileElement(details.getCheckoutCTA());
	}

	@And("the library has exceeded the daily limit")
	public void the_library_has_exceeded_the_daily_limit() throws Throwable {
		logger.info("the library has exceeded the daily limit");
	}

	@And("^system should throw message as 'The library has reached its daily checkout limit.  Please add items to your Wishlist and return later to check out.'")
	public void system_should_throw_message_as_the_library_has_reached_its_daily_checkout_limit_please_add_items_to_your_wishlist_and_return_later_to_check_out()
			throws Throwable {
		details.getCheckoutLimitMsg();
	}

	@And("user should be able to view 'Add to Wish List' and share cta in the detail page if the library has exceeded the daily limit")
	public void user_should_be_able_to_view_add_to_wish_list_and_share_cta_in_the_detail_page_if_the_library_has_exceeded_the_daily_limit()
			throws Throwable {
		Assert.assertEquals(details.getShareCTA().isDisplayed(), true);
		Assert.assertEquals(details.getWishlist().isDisplayed(), true);
	}

	/********************* 160258 ***********************/

	@When("user taps on the title card of an ebook with checkout button")
	public void user_taps_on_the_title_card_of_an_ebook_with_checkout_button() throws Throwable {
		details.scrollAndTapeBookWithCheckout();
	}

	@When("user taps on the title card of an audio book with checkout button")
	public void user_taps_on_the_title_card_of_an_audio_book_with_checkout_button() throws Throwable {
		details.scrollAndTapAudioBookWithCheckout();
	}

	@And("user click on checkout button")
	public void user_click_on_checkout_button() throws Throwable {
//    	details.getDownloadButton();
//    	ClickOnMobileElement(details.getCheckoutCTA());
//    	waitFor(5000);
	}

	@And("user should be able to see success confirmation message written as '[Title] was successfully checked out'")
	public void user_should_be_able_to_see_success_confirmation_message_written_as_title_was_successfully_checked_out()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getCheckoutFailMsg()), false);
	}

	@And("user will not able to see success add to wishlist confirmation message")
	public void user_will_not_able_to_see_success_add_to_wishlist_confirmation_message() throws Throwable {
		details.getWishlistFail();
	}

	@When("user taps on the title card of an ebook with read now button")
	public void user_taps_on_the_title_card_of_an_ebook_with_read_now_button() throws Throwable {
		details.scrollAndTapeBookWithReadNow();
	}

	@And("no message will be displayed for read now action")
	public void no_message_will_be_displayed_for_read_now_action() throws Throwable {
//    	Assert.assertEquals(isElementPresent(details.getReadNowFailMsg()), false);
		waitFor(5000);
		androidKeyBack();
	}

	@When("user taps on the title card of an audio book with listen now button")
	public void user_taps_on_the_title_card_of_an_audio_book_with_listen_now_button() throws Throwable {
		details.scrollAndTapAudioBookWithListenNow();
	}

	@And("no message will be displayed for listen now action")
	public void no_message_will_be_displayed_for_listen_now_action() throws Throwable {
//		Assert.assertEquals(isElementPresent(details.getReadNowFailMsg()), false);
		waitFor(5000);
		androidKeyBack();
	}

	@When("user taps on the title card of an ebook with download button")
	public void user_taps_on_the_title_card_of_an_ebook_with_download_button() throws Throwable {
		details.scrollAndTapeBookWithDownload();
	}

	@When("user taps on the title card of an audio book with download button")
	public void user_taps_on_the_title_card_of_an_audio_book_with_download_button() throws Throwable {
		details.scrollAndTapAudioBookWithDownload();
	}

	@And("no message will be displayed for download action")
	public void no_message_will_be_displayed_for_download_action() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getDownloadFailMsg()), false);
	}

	@And("user should be able to click on 'Remove'")
	public void user_should_be_able_to_click_on_remove() throws Throwable {
		ClickOnMobileElement(details.getSecondaryDropdownCTA());
		ClickOnMobileElement(details.getRemoveDownload());
	}

	@And("user should be able to see popup with text 'Removing the title will delete the download from your device. Are you sure you want to Remove?'")
	public void user_should_be_able_to_see_popup_with_text_removing_the_title_will_delete_the_download_from_your_device_are_you_sure_you_want_to_remove()
			throws Throwable {
		Assert.assertEquals(details.getRemoveConfirmation().isDisplayed(), true);
	}

	@And("user should be able to see no cta to cancel the process")
	public void user_should_be_able_to_see_no_cta_to_cancel_the_process() throws Throwable {
		Assert.assertEquals(details.getRemoveNoConfirmation().isDisplayed(), true);
	}

	@And("user should be able to see yes cta to proceed the process")
	public void user_should_be_able_to_see_yes_cta_to_proceed_the_process() throws Throwable {
		Assert.assertEquals(details.getRemoveYesConfirmation().isDisplayed(), true);
	}

	@And("user click on yes cta")
	public void user_click_on_yes_cta() throws Throwable {
		ClickOnMobileElement(details.getRemoveYesConfirmation());
	}

	@And("^user should be able to see success confirmation message written as 'Success title removed from download'")
	public void user_should_be_able_to_see_success_confirmation_message_written_as_success_title_removed_from_download()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getRemoveFailMsg()), false);
	}

	@And("user should be able to click on 'Listen Now' and navigate to ereader online")
	public void user_should_be_able_to_click_on_listen_now_and_navigate_to_ereader_online() throws Throwable {
		ClickOnMobileElement(details.getListenNowBtn());
	}

	@And("user click on pause download button")
	public void user_click_on_pause_download_button() throws Throwable {
//    	ClickOnMobileElement(details.getPauseDownload());
		logger.info("user click on pause download button");
	}

	@And("user should be able to pause the download and no message will displayed")
	public void user_should_be_able_to_pause_the_download_and_no_message_will_displayed() throws Throwable {
//    	Assert.assertEquals(isElementPresent(details.getPauseDownloadFailMsg()), false);
		logger.info("user should be able to pause the download and no message will displayed");
	}

	@And("user click on cancel download button")
	public void user_click_on_cancel_download_button() throws Throwable {
		ClickOnMobileElement(details.getCancelDownload());
	}

	@And("user should be able to cancel the download and no message will displayed")
	public void user_should_be_able_to_cancel_the_download_and_no_message_will_displayed() throws Throwable {
		Assert.assertEquals(details.getCancelDownloadFailMsg().isDisplayed(), false);
	}

	@And("^user should be able to see success confirmation message written as 'You have returned Title.'")
	public void user_should_be_able_to_see_success_confirmation_message_written_as_you_have_returned_title()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getReturnFailMsg()), false);
	}

	@And("user should be able to see success confirmation message written as 'You have renewed \\[Title\\].'")
	public void user_should_be_able_to_see_success_confirmation_message_written_as_you_have_renewed_title()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getRenewFailMsg()), false);
	}

	@Then("user should be able to see success confirmation message after renew written as {string}")
	public void user_should_be_able_to_see_success_confirmation_message_written_after_renew_written_as()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getRenewFailMsg()), false);
	}

	@When("user taps on the title card of an ebook with place on hold button")
	public void user_taps_on_the_title_card_of_an_ebook_with_place_on_hold_button() throws Throwable {
		details.scrollAndTapeBookWithSuspendHold();
	}

	@When("user taps on the title card of an audio book with place on hold button")
	public void user_taps_on_the_title_card_of_an_audio_book_with_place_on_hold_button() throws Throwable {
		details.scrollAndTapAudioBookWithSuspendHold();
	}

	@And("user should be able to view primary and secondary actions for ebooks when title not checked out and not on hold and not available")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_title_not_checked_out_and_not_on_hold_and_not_available()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to view primary and secondary actions for audio book when title not checked out and not on hold and not available")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_not_checked_out_and_not_on_hold_and_not_available()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to click on 'Place on Hold'")
	public void user_should_be_able_to_click_on_place_on_hold() throws Throwable {
		ClickOnMobileElement(details.getPlaceOnHoldBtn());
		waitFor(5000);
	}

	@And("^user should be able to see success confirmation message written as 'You have placed Title on hold.'")
	public void user_should_be_able_to_see_success_confirmation_message_written_as_you_have_placed_title_on_hold()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getPlaceOnHoldFailMsg()), false);
	}

	@When("user taps on the title card of an ebook with suspend hold button")
	public void user_taps_on_the_title_card_of_an_ebook_with_suspend_hold_button() throws Throwable {
		details.scrollAndTapeBookWithSuspendHold();
	}

	@When("user taps on the title card of an audio book with suspend hold button")
	public void user_taps_on_the_title_card_of_an_audio_book_with_suspend_hold_button() throws Throwable {
		details.scrollAndTapAudioBookWithSuspendHold();
	}

	@And("user should be able to click on 'Remove Hold'")
	public void user_should_be_able_to_click_on_remove_hold() throws Throwable {
		ClickOnMobileElement(details.getRemoveHoldBtn());
	}

	@And("user should be able to see success confirmation message written as 'You have removed your hold from Title.'")
	public void user_should_be_able_to_see_success_confirmation_message_written_as_you_have_removed_your_hold_from_title()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getRemoveHoldFailMsg()), false);
	}

	@And("user should be able to click on 'Suspend Hold'")
	public void user_should_be_able_to_click_on_suspend_hold() throws Throwable {
		ClickOnMobileElement(details.getSecondaryDropdownCTA());
		ClickOnMobileElement(details.getSuspendHoldBtn());
	}

	@And("user should be able to see success confirmation message written as 'You have suspended your hold for Title.'")
	public void user_should_be_able_to_see_success_confirmation_message_written_as_you_have_suspended_your_hold_for_title()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getSuspendHoldFailMsg()), false);
	}

	@When("user taps on the title card of an ebook with activate hold button")
	public void user_taps_on_the_title_card_of_an_ebook_with_activate_hold_button() throws Throwable {
		details.scrollAndTapeBookWithActivateHold();
	}

	@When("user taps on the title card of an audio book with activate hold button")
	public void user_taps_on_the_title_card_of_an_audio_book_with_activate_hold_button() throws Throwable {
		details.scrollAndTapAudioBookWithActivateHold();
	}

	@And("user should be able to click on 'Re-Activate Hold'")
	public void user_should_be_able_to_click_on_reactivate_hold() throws Throwable {
		ClickOnMobileElement(details.getReactivateHoldBtn());
	}

	@And("user should be able to see success confirmation message written as 'You have reactivated your hold for Title.'")
	public void user_should_be_able_to_see_success_confirmation_message_written_as_you_have_reactivated_your_hold_fortitle()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getReactivateHoldFailMsg()), false);
	}

	@And("^user should be able to see success confirmation message after reactivated your hold written as 'You have reactivated your hold for Title.'$")
	public void user_should_be_able_to_see_success_confirmation_message_after_reactivated_your_hold_written_as_you_have_reactivated_your_hold_for_title()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getReactivateHoldFailMsg()), false);
	}

	@And("user should be able to view primary and secondary actions for ebooks when title available and in wishlist")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_ebooks_when_title_available_and_in_wishlist()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("user should be able to view primary and secondary actions for audio book when title available and in wishlist")
	public void user_should_be_able_to_view_primary_and_secondary_actions_for_audio_book_when_title_available_and_in_wishlist()
			throws Throwable {
		details.getPrimaryCTA();
		details.getSecondaryCTA();
	}

	@And("click on 'Remove to Wishlist'")
	public void click_on_remove_to_wishlist() throws Throwable {
		details.ClickWishlist();
	}

	@And("user will not able to see success remove to wishlist confirmation message")
	public void user_will_not_able_to_see_success_remove_to_wishlist_confirmation_message() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getRemoveWishlistFailMsg()), false);
	}

	@And("user should be able to see success message as 'Your purchase request has been sent to the library for consideration.'")
	public void user_should_be_able_to_see_success_message_as_your_purchase_request_has_been_sent_to_the_library_for_consideration()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getPurchaseReqSuccessMsg()), false);
	}

	@And("user should view 'Cancel Request' cta if the book is already requested")
	public void user_should_view_cancel_request_cta_if_the_book_is_already_requested() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getCancelPurchaseReqBtn()), true);
	}

	@And("user clicks cancel request cta")
	public void user_clicks_cancel_request_cta() throws Throwable {
		ClickOnMobileElement(details.getCancelPurchaseReqBtn());
	}

	@And("user should be able to see success message as 'You have cancelled your purchase request for Title.'")
	public void user_should_be_able_to_see_success_message_as_you_have_cancelled_your_purchase_request_for_title()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getPurchaseReqCancelFailMsg()), false);
	}

	/********************* 164678 ***********************/
	@And("^user taps on the title card of an ebook in learning activity screen$")
	public void user_taps_on_the_title_card_of_an_ebook_in_learning_activity_screen() throws Throwable {
		learningact.scrollToLearningResourceFunActivities();
		ClickOnMobileElement(learningact.getLearningActivityCategory());
		ClickOnMobileElement(learningact.getCardTitleMapped());
	}

	@And("^user taps on the title card of an audio book in learning activity screen$")
	public void user_taps_on_the_title_card_of_an_audio_book_in_learning_activity_screen() throws Throwable {
		learningact.scrollToLearningResourceFunActivities();
		ClickOnMobileElement(learningact.getLearningActivityCategory());
		ClickOnMobileElement(learningact.getCardTitleMapped());
	}

	@And("user should be able to see learning activities listed as a card which is mapped to the linked title")
	public void user_should_be_able_to_see_learning_activities_listed_as_a_card_which_is_mapped_to_the_linked_title()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getLearningActivities()), true);
	}

	@And("user should be able to see cover image, title, and type for the learning activity")
	public void user_should_be_able_to_see_cover_image_title_and_type_for_the_learning_activity() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getLACoverImage()), true);
		Assert.assertEquals(isElementPresent(details.getLATitle()), true);
		Assert.assertEquals(isElementPresent(details.getLAType()), true);
	}

	@And("user should be able to see default image for Learning Activity if the cover image is not available")
	public void user_should_be_able_to_see_default_image_for_learning_activity_if_the_cover_image_is_not_available()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getLACoverImage()), true);
	}

	@And("user should be able to see linked title mapped to the learning activity and click on linked title to navigate to title details screen")
	public void user_should_be_able_to_see_linked_title_mapped_to_the_learning_activity_and_click_on_linked_title_to_navigate_to_title_details_screen()
			throws Throwable {
		ClickOnMobileElement(learningact.getCardTitleMapped());
		ClickOnMobileElement(details.getBackButton());
	}

	@And("user should be able to see and click on download cta for system to initiate the download of the learning activity title on the user device")
	public void user_should_be_able_to_see_and_click_on_download_cta_for_system_to_initiate_the_download_of_the_learning_activity_title_on_the_user_device()
			throws Throwable {
		swipeDown();
		ClickOnMobileElement(learningact.getDownloadButton());
	}

	@And("user should be able to see progress bar with % completed for the download status")
	public void user_should_be_able_to_see_progress_bar_with_completed_for_the_download_status() throws Throwable {
		details.getLADownloadProgressBar();
	}

	@And("user should be able to see pause cta to pause the download")
	public void user_should_be_able_to_see_pause_cta_to_pause_the_download() throws Throwable {
		details.getLAPauseDownload();
	}

	@And("user should view resume cta if the download is paused")
	public void user_should_view_resume_cta_if_the_download_is_paused() throws Throwable {
		details.getLAResumeDownload();
	}

	/********************* 166291 ***********************/

	@And("user should be able to see Audience and Age Level for respective Titles in Quick title information based on the mapping")
	public void user_should_be_able_to_see_audience_and_age_level_for_respective_titles_in_quick_title_information_based_on_the_mapping()
			throws Throwable {
		details.getAudienceQuickText();
		details.getAgeRangeQuickText();
	}

	@And("user should be able to see Audience in 3 format types: Kid, Teen, and Gen Adult")
	public void user_should_be_able_to_see_audience_in_3_format_types_kid_teen_and_gen_adult() throws Throwable {
		details.getAudienceQuickText();
	}

	@And("user should be able to see Age Level displayed as bottom range")
	public void user_should_be_able_to_see_age_level_displayed_as_bottom_range() throws Throwable {
		details.getAgeRangeQuickText();
	}

	@And("user should be able to see Age Level as 18 in eBook if the audience is Gen Adult")
	public void user_should_be_able_to_see_age_level_as_18_in_ebook_if_the_audience_is_gen_adult() throws Throwable {
		details.getAudienceQuickText();
		details.getAgeRangeQuickText();
	}

	@Then("user should be able to see Audience and Age Level for respective Titles under Details tab based on the mapping")
	public void user_should_be_able_to_see_audience_and_age_level_for_respective_titles_under_details_tab_based_on_the_mapping()
			throws Throwable {
		swipeDown();
		swipeDownMore();
		Assert.assertEquals(isElementPresent(details.getAudienceText()), true);
		Assert.assertEquals(isElementPresent(details.getAgeRangeText()), true);
	}

	@And("user should be able to see Audience mapping as is from response")
	public void user_should_be_able_to_see_audience_mapping_as_is_from_response() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getAudienceText()), true);
	}

	@And("user should be able to see Age Level mapping split from Audience response")
	public void user_should_be_able_to_see_age_level_mapping_split_from_audience_response() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getAgeRangeText()), true);
	}

	@And("should be able to see Age Level as 18+ if the audience doesn't have age range")
	public void should_be_able_to_see_age_level_as_18_if_the_audience_doesnt_have_age_range() throws Throwable {
		details.verifyAgeLevelContent();
	}

	/********************* 163362 ***********************/

	@When("user click on 'Place Hold'")
	public void user_click_on_place_hold() throws Throwable {
		details.clickPlaceHold();
	}

	@Then("system check if the email is set up for the adult profile")
	public void system_check_if_the_email_is_set_up_for_the_adult_profile() throws Throwable {
		logger.info("system check if the email is set up for the adult profile");
	}

	@And("if no the system should show popup with notification to update email")
	public void if_no_the_system_should_show_popup_with_notification_to_update_email() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getNotificationPopup()), true);
	}

	@And("user should be able to view short description in ebook as 'Please enter a valid email address that can be used to notify you when the title is available for checkout.'")
	public void user_should_be_able_to_view_short_description_in_ebook_as_please_enter_a_valid_email_address_that_can_be_used_to_notify_you_when_the_title_is_available_for_checkout()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getShortDescription()), true);
	}

	@And("user should be able to view text box enter the 'eMail Address' and 'Confirm eMail Address'")
	public void user_should_be_able_to_view_text_box_enter_the_email_address_and_confirm_email_address()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getEmailAddress()), true);
		Assert.assertEquals(isElementPresent(details.getConfirmEmailAddress()), true);
	}

	@And("^user should be able to fill in eMail Address text box with invalid email \"([^\"]*)\"")
	public void user_should_be_able_to_fill_in_email_address_text_box_with_invalid_email_something(String invalidemail)
			throws Throwable {
		details.enterInvalidEmailUpdate(invalidemail);
	}

	@And("^user should be able to fill in Confirm eMail Address text box with invalid email \"([^\"]*)\"")
	public void user_should_be_able_to_fill_in_confirm_email_address_text_box_with_invalid_email_something(
			String invalidemail) throws Throwable {
		details.enterInvalidConfirmEmailUpdate(invalidemail);
	}

	@And("user should be able to view 'Ok' button to submit")
	public void user_should_be_able_to_view_ok_button_to_submit() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getOkButton()), true);
	}

	@And("user should be able to click 'Ok' button")
	public void user_should_be_able_to_click_ok_button() throws Throwable {
		ClickOnMobileElement(details.getOkButton());
	}

	@And("system should validate the email format and show error message if invalid 'Invalid Email' in eBook")
	public void system_should_validate_the_email_format_and_show_error_message_if_invalid_invalid_email_in_ebook()
			throws Throwable {
		ClickOnMobileElement(details.getOkButton());
		details.getInvalidErrorMessage();
	}

	@And("user should be able to view short description in audio book as 'Please enter a valid email address that can be used to notify you when the title is available for checkout.'")
	public void user_should_be_able_to_view_short_description_in_audio_book_as_please_enter_a_valid_email_address_that_can_be_used_to_notify_you_when_the_title_is_available_for_checkout()
			throws Throwable {
		Assert.assertEquals(isElementPresent(details.getShortDescription()), true);
	}

	@And("^user click on update email close button")
	public void user_click_on_update_email_close_button() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getButtonCloseUpdateEmail()), true);
		ClickOnMobileElement(details.getButtonCloseUpdateEmail());
	}

	@And("^user should be able to fill in eMail Address text box \"([^\"]*)\"")
	public void user_should_be_able_to_fill_in_email_address_text_box_something(String validemail) throws Throwable {
		details.enterValidEmailUpdate(validemail);
	}

	@And("^user should be able to fill in Confirm eMail Address text box with same email \"([^\"]*)\"")
	public void user_should_be_able_to_fill_in_confirm_email_address_text_box_with_same_email_something(
			String validemail) throws Throwable {
		details.enterValidConfirmEmailUpdate(validemail);
	}

	@And("^user should be able to fill in Confirm eMail Address text box with the different email \"([^\"]*)\"")
	public void user_should_be_able_to_fill_in_confirm_email_address_text_box_with_the_different_email_something(
			String invalidemail) throws Throwable {
		details.enterInvalidConfirmEmailUpdate(invalidemail);
	}

	@And("system should show error message if the email and confirm email did not match 'Email addresses do not match'")
	public void system_should_show_error_message_if_the_email_and_confirm_email_did_not_match_email_addresses_do_not_match()
			throws Throwable {
		ClickOnMobileElement(details.getOkButton());
		details.getNotMatchErrorMessage();
	}

	@And("^system show success toast message 'Email has been updated successfully'")
	public void system_show_success_toast_message_email_has_been_updated_successfully() throws Throwable {
		details.getToastMessageUpdateSuccess();
	}

	/********************* 160319 ***********************/

	@When("^user taps on the title card of an ebook with remove hold$")
	public void user_taps_on_the_title_card_of_an_ebook_with_remove_hold() throws Throwable {
//    	details.scrollAndTapeBookWithRemoveHold();
		details.tapBookWithRemoveHold();
	}

	@When("^user taps on the title card of an audio book with remove hold$")
	public void user_taps_on_the_title_card_of_an_audio_book_with_remove_hold() throws Throwable {
//    	details.scrollAndTapAudioBookWithRemoveHold();
		details.tapBookWithRemoveHold();
	}

	@And("user should be able to view estimated wait time for the title ebook")
	public void user_should_be_able_to_view_estimated_wait_time_for_the_title_ebook() throws Throwable {
		details.getEstimateWaitTime();
	}

	@And("user should be able to view estimated wait time for the title audio book")
	public void user_should_be_able_to_view_estimated_wait_time_for_the_title_audio_book() throws Throwable {
		details.getEstimateWaitTime();
	}

	@And("user should not able to view estimated wait time when it is not available for the title")
	public void user_should_not_able_to_view_estimated_wait_time_when_it_is_not_available_for_the_title()
			throws Throwable {
		details.getEstimateWaitTime();
	}

	@And("library admin has enabled {string} in admin portal")
	public void library_admin_has_enabled_something_in_admin_portal(String strArg1) throws Throwable {
		logger.info("library admin has enabled Patron Reviews in admin portal");
	}

	@And("^user should be able to view the available approved reviews for the title$")
	public void user_should_be_able_to_view_the_available_approved_reviews_for_the_title() throws Throwable {
		swipeDown();
		swipeDown();
		swipeDown();
		Assert.assertEquals(isElementPresent(details.getReviews()), true);
	}

	@And("^user should be able to view the available write review cta for the title$")
	public void user_should_be_able_to_view_the_available_write_review_cta_for_the_title() throws Throwable {
		Assert.assertEquals(isElementPresent(details.getWriteReview()), true);
	}

	@And("^user should be navigated to rating screen$")
	public void user_should_be_navigated_to_rating_screen() throws Throwable {
		swipeUp();
		swipeUp();
		swipeUp();

	}

	@When("user taps on the title card")
	public void user_Taps_On_The_Title_Card() throws Throwable {
		details.scrollAndTapeBook();
	}

	@And("user should be able to view title details screen with theme rendered based on library subscription and user profile type")
	public void user_Should_Be_Able_To_View_Title_Details_Screen_With_Theme_Rendered_Based_On_Library_Subscription_And_User_Profile_Type() {
		logger.info(
				"user should be able to view title details screen with theme rendered based on library subscription and user profile type");
	}

	@And("user should be able to see title details screen as per mock")
	public void user_Should_Be_Able_To_See_Title_Details_Screen_As_Per_Mock() {
		logger.info("user should be able to see title details screen as per mock");
	}

	@Then("user should be navigated back to last screen")
	public void user_Should_Be_Navigated_Back_To_Last_Screen() {
		logger.info("user should be navigated back to last screen");
	}

	@And("user should be able to view title of an ebook as per mock")
	public void user_Should_Be_Able_To_View_Title_Of_An_Ebook_As_Per_Mock() {
		logger.info("user should be able to view title of an ebook as per mock");
	}

	@And("user should be able to view title of an audio book as per mock")
	public void user_Should_Be_Able_To_View_Title_Of_An_audio_book_As_Per_Mock() {
		logger.info("user should be able to view title of an audio book as per mock");
	}

	@And("user should be able to view subtitle of an audio book if available as per mock")
	public void user_Should_Be_Able_To_View_Subtitle_Of_An_Audio_Book_If_Available_As_Per_Mock() {
		logger.info("user should be able to view subtitle of an audio book if available as per mock");
	}

	@And("user should be able to view subtitle of an ebook if available as per mock")
	public void user_Should_Be_Able_To_View_Subtitle_Of_An_ebook_If_Available_As_Per_Mock() {
		logger.info("user should be able to view subtitle of an eBook if available as per mock");
	}

	@And("user should be able to view title cover image as per mock")
	public void user_Should_Be_Able_To_View_Title_Cover_Image_As_Per_Mock() {
		logger.info("user should be able to view title cover image as per mock");
	}

	@And("user should be able to view the ebook format icon on the title cover image as per mock")
	public void user_Should_Be_Able_To_View_The_Ebook_Format_Icon_On_The_TitleCoverImageAsPerMock() {
		logger.info("user should be able to view the ebook format icon on the title cover image as per mock");
	}

	@And("user should be able to view the audio book format icon on the title cover image as per mock")
	public void user_Should_Be_Able_To_View_The_Audio_Book_Format_Icon_On_The_Title_Cover_Image_As_Per_Mock() {
		logger.info("user should be able to view the audio book format icon on the title cover image as per mock");
	}

	@And("user should be able to read the book offline")
	public void user_Should_Be_Able_To_Read_The_Book_Offline() {
		logger.info("user should be able to read the book offline");
	}

	@And("user switch to online")
	public void user_Switch_To_Online() {
		logger.info("ser switch to online");
	}

	@And("title reading progress should be recorded when user switch from offline to online while reading book")
	public void title_Reading_Progress_Should_Be_Recorded_When_User_Switch_From_Offline_To_Online_While_ReadingBook() {
		logger.info(
				"title_Reading_Progress_Should_Be_Recorded_When_User_Switch_From_Offline_To_Online_While_ReadingBook");
	}

	@And("user should not be able to view the reading progress if insights preferences are disabled in the user preferences")
	public void user_Should_Not_Be_Able_To_View_The_Reading_Progress_If_Insights_Preferences_Are_Disabled_In_The_User_Preferences() {
		logger.info(
				"user should not be able to view the reading progress if insights preferences are disabled in the user preferences");
	}

	@And("user should not be able to view the reading progress if title progress or last read location of the title is not available")
	public void userShouldNotBeAbleToViewTheReadingProgressIfTitleProgressOrLastReadLocationOfTheTitleIsNotAvailable() {
		logger.info(
				"user should not be able to view the reading progress if title progress or last read location of the title is not available");
	}

	@And("user should be able to view the title reading progress based on last read location in the title as per mock")
	public void userShouldBeAbleToViewTheTitleReadingProgressBasedOnLastReadLocationInTheTitleAsPerMock() {
		logger.info(
				"user should be able to view the title reading progress based on last read location in the title as per mock");
	}

	@And("user should be able to view the title reading progress based on last listened location in the title as per mock")
	public void userShouldBeAbleToViewTheTitleReadingProgressBasedOnLastListenedLocationInTheTitleAsPerMock() {
		logger.info(
				"user should be able to view the title reading progress based on last listened location in the title as per mock");
	}

	@And("user should be able to view the title reading progress based on last read location in the Title")
	public void userShouldBeAbleToViewTheTitleReadingProgressBasedOnLastReadLocationInTheTitle() {
		logger.info("user should be able to view the title reading progress based on last read location in the Title");
	}

	@And("title reading progress should be sync on cross devices")
	public void titleReadingProgressShouldBeSyncOnCrossDevices() {
		logger.info("title reading progress should be sync on cross devices");
	}

	@And("title reading progress should be recorded when user switch from offline to online while listening book")
	public void titleReadingProgressShouldBeRecordedWhenUserSwitchFromOfflineToOnlineWhileListeningBook() {
		logger.info(
				"title reading progress should be recorded when user switch from offline to online while listening book");
	}

	@And("size and alignment of view primary action, secondary action, wishlist and share ctas on title details screen should match with mock")
	public void sizeAndAlignmentOfViewPrimaryActionSecondaryActionWishlistAndShareCtasOnTitleDetailsScreenShouldMatchWithMock() {
		logger.info(
				"size and alignment of view primary action, secondary action, wishlist and share ctas on title details screen should match with mock");
	}

	@And("text size and font style of view primary action, secondary action, wishlist and share ctas on title details screen should match with mock")
	public void textSizeAndFontStyleOfViewPrimaryActionSecondaryActionWishlistAndShareCtasOnTitleDetailsScreenShouldMatchWithMock() {
		logger.info(
				"text size and font style of view primary action, secondary action, wishlist and share ctas on title details screen should match with mock");
	}

	@And("user should be able to view primary action, wishlist cta and share cta when title has only one action available other than add or remove to wishlist and share")
	public void userShouldBeAbleToViewPrimaryActionWishlistCtaAndShareCtaWhenTitleHasOnlyOneActionAvailableOtherThanAddOrRemoveToWishlistAndShare() {
		logger.info(
				"user should be able to view primary action, wishlist cta and share cta when title has only one action available other than add or remove to wishlist and share");
	}

	@And("user should be able to view primary and secondary action when title has more than one actions available other than add or remove to wishlist and share")
	public void userShouldBeAbleToViewPrimaryAndSecondaryActionWhenTitleHasMoreThanOneActionsAvailableOtherThanAddOrRemoveToWishlistAndShare() {
		logger.info(
				"user should be able to view primary and secondary action when title has more than one actions available other than add or remove to wishlist and share");
	}

	@And("size and alignment of view wishlist cta on title details screen should match with mock")
	public void sizeAndAlignmentOfViewWishlistCtaOnTitleDetailsScreenShouldMatchWithMock() {
		logger.info("size and alignment of view wishlist cta on title details screen should match with mock");

	}

	@And("text size and font style of view wishlist cta on title details screen should match with mock")
	public void textSizeAndFontStyleOfViewWishlistCtaOnTitleDetailsScreenShouldMatchWithMock() {
		logger.info("text size and font style of view wishlist cta on title details screen should match with mock");
	}

	@And("text size and font style of primary and secondary actions on title details screen should match with mock")
	public void textSizeAndFontStyleOfPrimaryAndSecondaryActionsOnTitleDetailsScreenShouldMatchWithMock() {
		logger.info("");
	}

	@And("size and alignment of primary and secondary actions on title details screen should match with mock")
	public void sizeAndAlignmentOfPrimaryAndSecondaryActionsOnTitleDetailsScreenShouldMatchWithMock() {
		logger.info("");
	}

	@And("user should be able to view primary and secondary actions for ebooks and audio book")
	public void userShouldBeAbleToViewPrimaryAndSecondaryActionsForEbooksAndAudioBook() {
		logger.info("user should be able to view primary and secondary actions for ebooks and audio book");
	}

	@And("user should be able to view the share action in more title actions when title has more actions than checkout or hold, add or remove to wishlist & share")
	public void userShouldBeAbleToViewTheShareActionInMoreTitleActionsWhenTitleHasMoreActionsThanCheckoutHoldAddRemoveToWishlistShare() {
		logger.info(
				"user should be able to view the share action in more title actions when title has more actions than checkout or hold, add or remove to wishlist & share");
	}

	@And("text size and font style of share action are displayed as per mockup")
	public void textSizeAndFontStyleOfShareActionAreDisplayedAsPerMockup() {
		logger.info("text size and font style of share action are displayed as per mockup");
	}

	@And("text size and font style of title synopsis are displayed as per mockup")
	public void textSizeAndFontStyleOfTitleSynopsisAreDisplayedAsPerMockup() {
		logger.info("text size and font style of title synopsis are displayed as per mockup");
	}

	@And("user should be able to see success confirmation message")
	public void userShouldBeAbleToSeeSuccessConfirmationMessageWrittenAsTitleWasSuccessfullyCheckedOut() {
		logger.info("Success Confirmation message is displayed");

	}

	@And("user filter the ebook available titles in the library screen")
	public void userFilterTheEbookAvailableTitlesInTheLibraryScreen() {
		details.selectAvailableNowTitles();
		waitFor(8000);
		details.selecteBookTitles();
	}

	@And("user filter the eAudio available titles in the library screen")
	public void userFilterTheEAudioAvailableTitlesInTheLibraryScreen() {
		details.selectAvailableNowTitles();
		waitFor(8000);
		details.selecteAudioTitles();
	}

	@And("user should be able to see success message as {string}")
	public void userShouldBeAbleToSeeSuccessMessageAsCancellationOfYourPurchaseRequestWasNotCompletedPleaseTryAgain() {
		logger.info("user should be able to see success message");

	}

	@And("there is a failure to complete the action")
	public void thereIsAFailureToCompleteTheAction() {
		logger.info("there is a failure to complete the action");
	}

	@And("user should be able to see error message written as {string}")
	public void userShouldBeAbleToSeeErrorMessageWrittenAsYourCheckoutCouldNotBeCompletedPleaseTryAgain() {
		logger.info("user should be able to see error message");
	}

	@And("And user will not able to see success confirmation message")
	public void andUserWillNotAbleToSeeSuccessConfirmationMessage() {
		logger.info("user will not able to see success confirmation message");
	}

	@And("no message will displayed")
	public void noMessageWillDisplayed() {
		logger.info("no message will displayed");
	}

	@And("user should be able to click on {string}")
	public void userShouldBeAbleToClickOnListenNow() {
		logger.info("user should be able to click on icon");

	}

	@And("user should be able to see error message written as {string}re having trouble retrieving your title.  If this issue continues, please Remove the title and re-download.'")
	public void userShouldBeAbleToSeeErrorMessageWrittenAsWeReHavingTroubleRetrievingYourTitleIfThisIssueContinuesPleaseRemoveTheTitleAndReDownload() {
		logger.info(
				"user should be able to see error message written as {string}re having trouble retrieving your title.  If this issue continues, please Remove the title and re-download.");
	}

	@And("user should be able to view estimated wait time for the title")
	public void userShouldBeAbleToViewEstimatedWaitTimeForTheTitle() {
		logger.info("user should be able to view estimated wait time for the title\"");
	}

	@And("user will not able to see success confirmation message")
	public void userWillNotAbleToSeeSuccessConfirmationMessage() {
		logger.info("user will not able to see success confirmation message");
	}

	@And("user should be able to view narrator names for the audio book titles as read by or narrated by attribute")
	public void userShouldBeAbleToViewNarratorNamesForTheAudioBookTitlesAsReadByNarratedByAttribute() {
		logger.info(
				"user should be able to view narrator names for the audio book titles as read by or narrated by attribute");
	}

	@And("user should be able to view narrator names for Read By or Narrated by as ctas")
	public void userShouldBeAbleToViewNarratorNamesForReadByNarratedByAsCtas() {
		logger.info("user should be able to view narrator names for Read By or Narrated by as ctas");
	}

	@And("user should be able to fill in {string} text box")
	public void userShouldBeAbleToFillInEMailAddressTextBox() {
		logger.info("user should be able to fill in {string} text box");
	}

	@And("user should be able to fill in {string} text box with the different email")
	public void userShouldBeAbleToFillInConfirmEMailAddressTextBoxWithTheDifferentEmail() {
		logger.info("user should be able to fill in {string} text box with the different email");
	}

	@And("user should be able to fill in {string} text box with invalid email")
	public void userShouldBeAbleToFillInConfirmEMailAddressTextBoxWithInvalidEmail() {
		logger.info("user should be able to fill in {string} text box with invalid email");
	}

	@And("system show error message if api failed as {string}")
	public void systemShowErrorMessageIfApiFailedAsYourEMailCouldNotBeUpdatedPleaseTryAgain() {
		logger.info("system show error message if api failed ");
	}

	@And("user should be able to view short description in auido book as {string}")
	public void userShouldBeAbleToViewShortDescriptionInAuidoBookAsPleaseEnterAValidEmailAddressThatCanBeUsedToNotifyYouWhenTheTitleIsAvailableForCheckout() {
		logger.info("user should be able to view short description in auido book");
	}

	@And("email address is case sensitive")
	public void emailAddressIsCaseSensitive() {
		logger.info("email address is case sensitive");
	}

	@And("user is able to enter upper and lower-case, numbers as username component")
	public void userIsAbleToEnterUpperAndLowerCaseNumbersAsUsernameComponent() {
		logger.info("user is able to enter upper and lower-case, numbers as username component");
	}

	@And("user should not be able to fill email text box with emoticon, space, and period as the first or last character in user name or domain")
	public void userShouldNotBeAbleToFillEmailTextBoxWithEmoticonSpaceAndPeriodAsTheFirstOrLastCharacterInUserNameOrDomain() {
		logger.info(
				"user should not be able to fill email text box with emoticon, space, and period as the first or last character in user name or domain");
	}

//	@And("user is able to enter few special characters: period \\(.), underscore\\(_), hyphen \\(-) as username component")
//	public void userIsAbleToEnterFewSpecialCharactersPeriodUnderscore_HyphenAsUsernameComponent() {
//		logger.info("user is able to enter few special characters");
//	}

	@And("user is able to enter upper and lower-case, numbers, a hyphen \\(-) and a period \\(.) as domain component")
	public void userIsAbleToEnterUpperAndLowerCaseNumbersAHyphenAndAPeriodAsDomainComponent() {
		logger.info("user is able to enter upper and lower-case");
	}

	@And("user should be able to view primary and secondary actions for ebooks when Title hold suspended")
	public void userShouldBeAbleToViewPrimaryAndSecondaryActionsForEbooksWhenTitleHoldSuspended() {
		logger.info("user should be able to view primary and secondary actions for ebooks when Title hold suspended");
	}

	@When("user taps on the title card of an ebook wih place hold")
	public void userTapsOnTheTitleCardOfAnEbookWihPlaceHold() {
		logger.info("user taps on the title card of an ebook wih place hold");
	}

	@And("user should be able to fill in {string} text box with invalid email {string}")
	public void userShouldBeAbleToFillInEMailAddressTextBoxWithInvalidEmail(String arg0) {
		logger.info("user should be able to fill in field");
	}

	@And("user should be able to view primary and secondary actions for audio book when Title hold suspended")
	public void userShouldBeAbleToViewPrimaryAndSecondaryActionsForAudioBookWhenTitleHoldSuspended() {
		logger.info(
				"user should be able to view primary and secondary actions for audio book when Title hold suspended");
	}

	@And("user should be able to fill in {string} text box {string}")
	public void userShouldBeAbleToFillInEMailAddressTextBox(String arg0) {
		logger.info("user should be able to fill in field");
	}

	@And("user should be able to fill in {string} text box with the different email {string}")
	public void userShouldBeAbleToFillInConfirmEMailAddressTextBoxWithTheDifferentEmail(String arg0) {
		logger.info("user should be able to fill in field");
	}

	@And("user should be able to fill in Confirm eMail Address text box")
	public void userShouldBeAbleToFillInConfirmEMailAddressTextBox() {
		logger.info("user should be able to fill in Confirm eMail Address text box");
	}

	@And("user should be able to fill in email Address text box")
	public void userShouldBeAbleToFillInEmailAddressTextBox() {
		logger.info("user should be able to fill in email Address text box");
	}

	@And("user should not be able to see Related Items tab if there are no learning activities linked to respective title")
	public void userShouldNotBeAbleToSeeRelatedItemsTabIfThereAreNoLearningActivitiesLinkedToRespectiveTitle() {
		logger.info(
				"user should not be able to see Related Items tab if there are no learning activities linked to respective title");
	}

	@And("system should lazy load {int} number of learning activities")
	public void systemShouldLazyLoadNumberOfLearningActivities(int arg0) {
		logger.info("system should lazy load");
	}

	@And("user click on card area other than linked title and download cta")
	public void userClickOnCardAreaOtherThanLinkedTitleAndDownloadCta() {
		logger.info("user click on card area other than linked title and download cta");
	}

	@And("user should be able to view the learning activity file in Native PDF Viewer or browser")
	public void userShouldBeAbleToViewTheLearningActivityFileInNativePDFViewerOrBrowser() {
		logger.info("user should be able to view the learning activity file in Native PDF Viewer or browser");
	}

	@And("system should be able to keep and resume the download progress on the background")
	public void systemShouldBeAbleToKeepAndResumeTheDownloadProgressOnTheBackground() {
		logger.info("system should be able to keep and resume the download progress on the background");
	}

	@And("user minimizes the app")
	public void userMinimizesTheApp() {
		logger.info("user minimizes the app");
	}

	@And("system should be able to keep and resume the download progress")
	public void systemShouldBeAbleToKeepAndResumeTheDownloadProgress() {
		logger.info("system should be able to keep and resume the download progress");
	}

	@And("user browses another screen")
	public void userBrowsesAnotherScreen() {
		logger.info("user browses another screen");
	}

	@Then("user should be able to see {string} tab open")
	public void userShouldBeAbleToSeeDetailsTabOpen() {
		logger.info("user should be able to see tab open");
	}

	@And("user should be able to see Age Level displayed as {string}")
	public void userShouldBeAbleToSeeAgeLevelDisplayedAs(String arg0) {
		logger.info("user should be able to see Age Level displayed");
	}

	@And("user should be able to see Age Level as {string} in eBook if the audience is {string}")
	public void userShouldBeAbleToSeeAgeLevelAsInEBookIfTheAudienceIs(String arg0, String arg1) {
		logger.info("user should be able to see Age Level ");
	}

	@And("should be able to see Age Level as {string} if the audience doesn't have age range")
	public void shouldBeAbleToSeeAgeLevelAsIfTheAudienceDoesnTHaveAgeRange(String arg0) {
		logger.info("user should be able to see Age Level ");
	}

	@Then("user should be navigate to Details tab")
	public void userShouldBeNavigateToDetailsTab() {
		logger.info("user should be navigate to Details tab");
	}

	@And("adult user should not be able to see Audience and Age Level in eBook displayed in both Quick title information and Details tab if the audience response is not available")
	public void adultUserShouldNotBeAbleToSeeAudienceAndAgeLevelInEBookDisplayedInBothQuickTitleInformationAndDetailsTabIfTheAudienceResponseIsNotAvailable() {
		logger.info(
				"adult user should not be able to see Audience and Age Level in eBook displayed in both Quick title information and Details tab if the audience response is not available");
	}

	@And("user should be able to see Audience and Age Level for respective Titles in Quick title information based on the mapping as per mock up")
	public void userShouldBeAbleToSeeAudienceAndAgeLevelForRespectiveTitlesInQuickTitleInformationBasedOnTheMappingAsPerMockUp() {
		logger.info(
				"user should be able to see Audience and Age Level for respective Titles in Quick title information based on the mapping as per mock up");
	}

	@And("user should be able to see Audience and Age Level for respective Titles under Details tab based on the mapping as per mock up")
	public void userShouldBeAbleToSeeAudienceAndAgeLevelForRespectiveTitlesUnderDetailsTabBasedOnTheMappingAsPerMockUp() {
		logger.info(
				"user should be able to see Audience and Age Level for respective Titles under Details tab based on the mapping as per mock up");
	}

	@And("adult user should not be able to see Audience and Age Level in audio book displayed in both Quick title information and Details tab if the audience response is not available")
	public void adultUserShouldNotBeAbleToSeeAudienceAndAgeLevelInAudioBookDisplayedInBothQuickTitleInformationAndDetailsTabIfTheAudienceResponseIsNotAvailable() {
		logger.info(
				"adult user should not be able to see Audience and Age Level in audio book displayed in both Quick title information and Details tab if the audience response is not available");
	}

	@And("user should be able to view Level {int} subjects mapped to the title based on bisac")
	public void userShouldBeAbleToViewLevelSubjectsMappedToTheTitleBasedOnBisac(int arg0) {
		logger.info("user should be able to view Level {int} subjects mapped to the title based on bisac");
	}

	@And("system only show the available subject")
	public void systemOnlyShowTheAvailableSubject() {
		logger.info("system only show the available subject");
	}

	@And("text should align to two lines and more than that add ellipsis if subject level cta will be subject text is long")
	public void textShouldAlignToTwoLinesAndMoreThanThatAddEllipsisIfSubjectLevelCtaWillBeSubjectTextIsLong() {
		logger.info(
				"text should align to two lines and more than that add ellipsis if subject level cta will be subject text is long");
	}

	@And("user hould not be able to view text to speech if text to speech is not available for the title or if eRead Along is available")
	public void userHouldNotBeAbleToViewTextToSpeechIfTextToSpeechIsNotAvailableForTheTitleOrIfEReadAlongIsAvailable() {
		logger.info(
				"user hould not be able to view text to speech if text to speech is not available for the title or if eRead Along is available");
	}

	@And("the total number of pages for the ebook is displayed as per mockup")
	public void theTotalNumberOfPagesForTheEbookIsDisplayedAsPerMockup() {
		logger.info("the total number of pages for the ebook is displayed as per mockup");
	}

	@And("user should be able to view the secondory CTA icon and click on return option")
	public void userShouldBeAbleToViewTheSecondoryCTAIconAndClickOnReturnOption() {
		ClickOnMobileElement(details.getSecondaryDropdownCTA());
		Assert.assertEquals(isElementPresent(details.checkReadOnlineBtn()), true);
		Assert.assertEquals(isElementPresent(details.getShareTitle()), true);
		Assert.assertEquals(isElementPresent(details.getRenewBtn()), true);
		ClickOnMobileElement(details.getReturnBtn());
		ClickOnMobileElement(details.clickReturnConfirmation());
		waitFor(5000);
	}

	@When("user taps on the hold title card")
	public void userTapsOnTheHoldTitleCard() {
		waitFor(4000);
		details.clickHoldTitle();
	}

	@And("user should be able to cancel the purchase request from secondary cta option")
	public void userShouldBeAbleToCancelThePurchaseRequestFromSecondaryCtaOption() {
		details.clickSuspendHoldBtn();
		waitFor(5000);
	}

	@When("user taps on the Audio title card")
	public void userTapsOnTheAudioTitleCard() {
		waitFor(5000);
		details.clickAudioTitle();
	}

	@Then("user is navigated to title details screen")
	public void userIsNavigatedToTitleDetailsScreen() {
		waitFor(5000);
		Assert.assertEquals(details.gettitleDetails_lbl_title().isDisplayed(), true);
	}

	@When("user select on the see All of the eBook Carousel")
	public void userSelectOnTheSeeAllOfTheEBookCarousel() {
		details.clickSeeAllEBookCuratedList();
	}

	@And("user should be able to view details and Wishlist, Star Rate, Share the specific title and view the More like this section")
	public void userShouldBeAbleToViewDetailsAndWishlistStarRateShareTheSpecificTitleAndViewTheMoreLikeThisSection() {
	Assert.assertTrue(details.gettitleDetails_lbl_title().isDisplayed());
	try {
		details.verifyWishlist();
		details.verifystarRating();
		details.verifyShare();
		details.verifyMoreLikeThisTab();
	    }catch (NoSuchElementException e){logger.info("This option is not availabe for this title");}
	}

	@And("user by clicking on share should show multiple options to share the respective title")
	public void userByClickingOnShareShouldShowMultipleOptionsToShareTheRespectiveTitle() {
		try {
			details.Clickshare();
			details.verifyShareChromeOption();
			details.verifyMessagesShareOption();
			details.verifyToolTipVerbiageIsDisplayed();
		}catch (NoSuchElementException e){logger.info("Share option not available for this title");}
	}

	@And("user should be able to view inside the More like This tab as Titles in This Series and Other Titles Like This")
	public void userShouldBeAbleToViewInsideTheMoreLikeThisTabAsTitlesInThisSeriesAndOtherTitlesLikeThis() {
		try {
			details.verifyMoreLikeThisTab();
			details.verifyTitleInThisSeries();
			details.verifyOtherTitlesLikeThis();
		}catch (NoSuchElementException e){logger.info("This option not availbale for this title");}
	}

	@And("user should select the Related items and should be able to view sub-sections as Alternate Formats and Learning Resources")
	public void userShouldSelectTheRelatedItemsAndShouldBeAbleToViewSubSectionsAsAnd() {
		try {
			details.tapOnRelatedItemsTab();
			details.verifyAlternateFormats();
			details.verifyLearningResources();
		}catch (NoSuchElementException e){logger.info("This option not availbale for this title");}
	}

	@And("user should be able to view Details section with details of title and Write a review CTA")
	public void userShouldBeAbleToViewDetailsSectionWithDetailsOfTitleAndWriteAReviewCTA() {
		try {
			details.clickDetailstab();
			Assert.assertTrue(details.getAuthorName().isDisplayed());
		}catch (NoSuchElementException e){logger.info("Details option not available for this title");}

	}

	@And("user verify eBook reader is opened and close the reader")
	public void userVerifyEBookReaderIsOpenedAndCloseTheReader() {
		WaitForMobileElement(details.getReaderBanner());
		Assert.assertTrue(details.getReaderBanner().isDisplayed());
		logger.info("eBook reader is successfully opened");
		ClickOnMobileElement(details.getReaderBanner());
		WaitForMobileElement(details.getReaderBackBtn());
		ClickOnMobileElement(details.getReaderBackBtn());
	}

	@And("user verify eAudio reader is opened and close the reader")
	public void userVerifyEAudioReaderIsOpenedAndCloseTheReader() {
		WaitForMobileElement(details.getEAdudioReader());
		Assert.assertTrue(details.getEAdudioReader().isDisplayed());
		logger.info("eAudio reader is successfully opened");
		details.closeAudioReader();

	}
}
