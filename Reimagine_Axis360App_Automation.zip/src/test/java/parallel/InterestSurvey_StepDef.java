package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.InterestSurvey;
import pom.kidszone.LoginPage;
import pom.kidszone.Navigationbars;
import pom.kidszone.ProfileCreation;

public class InterestSurvey_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	Navigationbars navigation = new Navigationbars(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	InterestSurvey interest = new InterestSurvey(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	@Given("user search and select the kidszone texas library")
	public void user_search_and_select_the_kidszone_texas_library() {

	}

	@When("user navigates to my profile")
	public void user_navigates_to_my_profile() {
		interest.clickEditprofile();

	}

	@Then("user should be able to view the interest survey cta")
	public void user_should_be_able_to_view_the_interest_survey_cta() {
		swipeDown();
		swipeDown();
		swipeDown();
		profile.clickInterestview();
	}

	@Then("user should be able to click on interest survey cta and navigate to interest survey screen for my profile")
	public void user_should_be_able_to_click_on_interest_survey_cta_and_navigate_to_interest_survey_screen_for_my_profile() {
		if (isElementPresent(interest.getReading_Interests_hdr())) {
			Assert.assertEquals(isElementPresent(interest.getReading_Interests_hdr()), true);
			logger.info("user is in navigate to interest survey screen for my profile");
		} else if (isElementPresent(interest.getReading_Interests_hdr1())) {
			Assert.assertEquals(isElementPresent(interest.getReading_Interests_hdr1()), true);
			logger.info("user is in navigate to interest survey screen for my profile");
		}
		interest.clickBack();
		interest.closeButton();
	}

//132094
	@Given("recommendations are enabled in bakerandtaylor admin for the library")
	public void recommendations_are_enabled_in_bakerandtaylor_admin_for_the_library() {
		logger.info("recommendations are enabled in bakerandtaylor admin for the library");
	}

	@Given("user is an adult user")
	public void user_is_an_adult_user() {
		logger.info("user is an adult user");
	}

	@When("user navigates to the interest survey screen and view interest survey popup")
	public void user_navigates_to_the_interest_survey_screen_and_view_interest_survey_popup() {
		login.clickFooterMenu();
		login.clickmyprofile();
		profile.clickInterestview();
		if (isElementPresent(interest.getReading_Interests_hdr())) {
			Assert.assertEquals(isElementPresent(interest.getReading_Interests_hdr()), true);
			logger.info("user is in navigate to interest survey screen for my profile");
		} else if (isElementPresent(interest.getReading_Interests_hdr1())) {
			Assert.assertEquals(isElementPresent(interest.getReading_Interests_hdr1()), true);
			logger.info("user is in navigate to interest survey screen for my profile");
		}
		logger.info("user is in navigate to interest survey screen for my profile");

	}

	@Then("user should be able to view interest topics for adults")
	public void user_should_be_able_to_view_interest_topics_for_adults() {
		if (isElementPresent(interest.getReading_Interests_hdr())) {
			for (int i = 1; i < interest.reading_topics.size(); i++) {
				if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
					Assert.assertEquals(interest.reading_topics.get(i).getAttribute("visible").equalsIgnoreCase("true"),
							true);
				}
			}
		}
	}

	@Then("user should be able to view preferred age level options juvenile and young adult and adult")
	public void user_should_be_able_to_view_preferred_age_level_options_juvenile_and_young_adult_and_adult() {
		swipeDown();
		swipeDown();
		if (isElementPresent(interest.getOptions_young_adult())) {
			Assert.assertEquals(isElementPresent(interest.getOptions_young_adult()), true);
		}
		interest.clickBack();
	}

	@Given("user is on my profile page")
	public void user_is_on_my_profile_page() {

	}

	@When("user tap on interest survey")
	public void user_tap_on_interest_survey() {

	}

	@Then("user should be view the ui of the screen should be as per the existing application")
	public void user_should_be_view_the_ui_of_the_screen_should_be_as_per_the_existing_application() {

	}

	@Then("user should be able to view set your reading preference as heading as per the existing application")
	public void user_should_be_able_to_view_set_your_reading_preference_as_heading_as_per_the_existing_application() {

	}

	@Then("user should be able to view description as per the existing application")
	public void user_should_be_able_to_view_description_as_per_the_existing_application() {

	}

	@Then("user should be able to view prefered age level option as per the existing application")
	public void user_should_be_able_to_view_prefered_age_level_option_as_per_the_existing_application() {

	}

	@Then("user should be able to view juvenile and young adult and adult options as per the existing application")
	public void user_should_be_able_to_view_juvenile_and_young_adult_and_adult_options_as_per_the_existing_application() {

	}

	@Then("user should be able to view checkbox to select the age level as per the existing application")
	public void user_should_be_able_to_view_checkbox_to_select_the_age_level_as_per_the_existing_application() {

	}

	@Then("user should be able to view save preference and cancel option as per the existing application")
	public void user_should_be_able_to_view_save_preference_and_cancel_option_as_per_the_existing_application() {

	}

	@Then("text size and font style should be as per existing application")
	public void text_size_and_font_style_should_be_as_per_existing_application() {

	}

	@Then("alignement of the elements present in the screen should be as per existing application")
	public void alignement_of_the_elements_present_in_the_screen_should_be_as_per_existing_application() {

	}

//132100
	@Given("user has interests preferences set")
	public void user_has_interests_preferences_set() {
		logger.info("user has interests preferences set");

	}

	@When("user navigates to the interest survey screen")
	public void user_navigates_to_the_interest_survey_screen() {
		login.handleNothankspopup();
		interest.clickEditprofile();
		swipeDown();
		swipeDown();
		waitFor(1000);
		swipeDown();
		profile.clickInterestview();
		if (isElementPresent(interest.getReading_Interests_hdr())) {
			Assert.assertEquals(isElementPresent(interest.getReading_Interests_hdr()), true);
			logger.info("user is in navigate to interest survey screen for my profile");
		} else if (isElementPresent(interest.getReading_Interests_hdr1())) {
			Assert.assertEquals(isElementPresent(interest.getReading_Interests_hdr1()), true);
			logger.info("user is in navigate to interest survey screen for my profile");
		}
		logger.info("user is in navigate to interest survey screen for my profile");

	}

	@Then("user should be able to view interest survey screen with theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_interest_survey_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() {

		logger.info("theme rendered based on library subscription and user profile type");
	}

	@Then("user should be able to view interest survey topics based on library subscription and user profile type")
	public void user_should_be_able_to_view_interest_survey_topics_based_on_library_subscription_and_user_profile_type() {
		if (isElementPresent(interest.reading_topics.get(0))) {
			for (int i = 1; i < interest.reading_topics.size(); i++) {
				if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
					Assert.assertEquals(interest.reading_topics.get(i).getAttribute("visible").equalsIgnoreCase("true"),
							true);
				}
			}
		}

	}

	@Then("user should be able to view the interests title and description")
	public void user_should_be_able_to_view_the_interests_title_and_description() {
		logger.info("user should be able to view the interests title and description");

	}

	@Then("user should be able to view the list of interests icons displayed with the interests selected by the user being highlighted")
	public void user_should_be_able_to_view_the_list_of_interests_icons_displayed_with_the_interests_selected_by_the_user_being_highlighted() {
		for (int i = 1; i < interest.reading_topics.size(); i++) {
			if (System.getProperty("platform").equalsIgnoreCase("iOS")) {

				ClickOnMobileElement(interest.reading_topics.get(i));
				if (interest.reading_topics.size() == 3) {
					break;
				}
				Assert.assertEquals(interest.getSave_interests().isEnabled(), true);
			}
		}

	}

	@Then("user should be able to select the interest topics to update the preferences")
	public void user_should_be_able_to_select_the_interest_topics_to_update_the_preferences() {
		logger.info("user should be able to select the interest topics to update the preferences");

	}

	@Then("user should be able to update preferred age level options")
	public void user_should_be_able_to_update_preferred_age_level_options() {
		logger.info("user should be able to update preferred age level options");

	}

	@Then("user should have atleast one preference selected {string} to update and save the preferences")
	public void user_should_have_atleast_one_preference_selected_to_update_and_save_the_preferences(String agelevel) {
		for (int i = 1; i <= 5; i++) {
			swipeDown();
		}
		interest.selectAgelevelgroup(agelevel);

	}

	@Then("user should be able to view save changes by clicking save cta and get confirmation message of changes saved")
	public void user_should_be_able_to_view_save_changes_by_clicking_save_cta_and_get_confirmation_message_of_changes_saved() {
		Assert.assertEquals(isElementPresent(interest.getSave_interests()), true);
		interest.saveChanges();
		logger.info("User should be able to view save changes by clicking save cta");
	}

	@Given("user search and select the magic independent library")
	public void user_search_and_select_the_magic_independent_library() {

	}

	@Given("library has kidszone and axis {int} subscription")
	public void library_has_kidszone_and_axis_subscription(Integer int1) {

	}

	@Given("user preference is already set")
	public void user_preference_is_already_set() {

		logger.info("user preference is already set");
	}

	@Then("user should be able to unselect the interest topics to update the preferences")
	public void user_should_be_able_to_unselect_the_interest_topics_to_update_the_preferences() {
		if (isElementPresent(interest.getReading_Interests_hdr())) {
			for (int i = 1; i < interest.reading_topics.size(); i++) {
				if (System.getProperty("platform").equalsIgnoreCase("iOS")) {

					ClickOnMobileElement(interest.reading_topics.get(i));
					if (interest.reading_topics.size() == 3) {
						break;
					}
					Assert.assertEquals(interest.getSave_interests().isEnabled(), true);
				}
			}
		}

	}

	@Given("user is already loged in")
	public void user_is_already_loged_in() {

	}

	@When("user doesnt made any changes")
	public void user_doesnt_made_any_changes() {
		logger.info("user doesnt made any changes");

	}

	@Then("user should be able to view the save cta disable")
	public void user_should_be_able_to_view_the_save_cta_disable() {
		login.handleNothankspopup();
		if (isElementPresent(interest.getSave_interests())) {
			Assert.assertEquals(isElementPresent(interest.getSave_interests()), true);
		}
		logger.info("user should be able to view the save cta disable");

	}

	@When("user click on cancel cta")
	public void user_click_on_cancel_cta() {
		interest.cancelChanges();
		logger.info("User click on cancel cta");
	}

	@Then("user should be able to not update the interest preference")
	public void user_should_be_able_to_not_update_the_interest_preference() {
		logger.info("user should be able to not update the interest preference");

	}

	@When("user click on back cta")
	public void user_click_on_back_cta() {
		interest.clickBack();
	}

	@Given("user is on interest survey screen")
	public void user_is_on_interest_survey_screen() {

	}

	@When("user selects any of the topics")
	public void user_selects_any_of_the_topics() {

	}

	@Then("user should be able to view the ui of the screen should be as per mock")
	public void user_should_be_able_to_view_the_ui_of_the_screen_should_be_as_per_mock() {

	}

	@Then("user should be able to view the higlighter in profile specific theme color")
	public void user_should_be_able_to_view_the_higlighter_in_profile_specific_theme_color() {

	}

	@Then("user should be able to view the save cta enable in blue color as per mock")
	public void user_should_be_able_to_view_the_save_cta_enable_in_blue_color_as_per_mock() {

	}

//132101
	@Given("user is on my profile screen")
	public void user_is_on_my_profile_screen() {
		login.handleNothankspopup();
		interest.clickEditprofile();

	}

	@When("user confirms the change of profile type {string}")
	public void user_confirms_the_change_of_profile_type(String profiletype) {
		profile.checkandchangeProfiletype(profiletype);
	}

	@Then("system should reset the interest survey preferences set  by the user")
	public void system_should_reset_the_interest_survey_preferences_set_by_the_user() {
		interest.confirmpopup();
		swipeDown();
		swipeDown();
		waitFor(1000);
		swipeDown();
		profile.clickInterestview();
		logger.info("system should reset the interest survey preferences set  by the user");
		interest.clickBack();
		interest.closeButton();
	}

	@Given("user is on edit profile screen")
	public void user_is_on_edit_profile_screen() {
		login.handleNothankspopup();
		interest.clickEditprofile();
	}

	@Then("user is able to view confirmation message on changing profile type that interest survey preferences will be reset")
	public void user_is_able_to_view_confirmation_message_on_changing_profile_type_that_interest_survey_preferences_will_be_reset()
			throws Throwable {
		if (isElementPresent(interest.getAlertmsg())) {
			Assert.assertEquals(isElementPresent(interest.getAlertmsg()), true);
		}
	}

	@And("user has interests preferences set and recommendations are enabled for the library")
	public void user_has_interests_preferences_set_and_recommendations_are_enabled_for_the_library() throws Throwable {
		logger.info("user has interests preferences set and recommendations are enabled for the library");
	}

	@And("user is able to confirm to change the profile type")
	public void user_is_able_to_confirm_to_change_the_profile_type() throws Throwable {
		interest.confirmpopup();
		interest.closeButton();
		logger.info("user is able to confirm to change the profile type");
	}

	@And("user is able to cancel and discard the profile change")
	public void user_is_able_to_cancel_and_discard_the_profile_change() throws Throwable {
		interest.confirmpopup();
		interest.closeButton();
	}
}
