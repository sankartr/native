package parallel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pom.kidszone.LoginPage;
import pom.kidszone.RegisterScreen;

public class LoginPage_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	RegisterScreen register = new RegisterScreen(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(LoginPage_StepDef.class);
    private Scenario scenario;

	@Before
    public void setup(Scenario scenario) {
        this.scenario = scenario;
    }

	@Given("user launch the app and select the library {string}")
	public void user_launch_the_app_and_select_the_library(String library) throws InterruptedException {
		if (isElementPresent(login.boundlessAllow())) {
			login.clickBoundlessAllow();
		}
		// login.forceUpgrade();
		login.searchLibrary(library);
		login.initiateSearch();
		login.select_library();
	}

	@Given("Registered user clicks on login button after enters {string}")
	public void Registered_user_click_on_login_button_after_user_enter(String userName) {
		TestReaderPOJO testData = TestDataReader.getTestData(scenario, userName);
		// login.loginwithId(testData.getLibraryId());
		login.enterUserName(testData.getLibraryId());
		hideMobileKeyboard();
		login.clickSignInBtn();
	}

	@Given("Registered user clicks on the login button after enters {string} and {string}")
	public void Registered_user_click_on_the_Login_button_after_enter_username_password(String userName, String password) {
		TestReaderPOJO testData = TestDataReader.getTestData(scenario, userName);
		login.enterUserName(testData.getLibraryId());
		login.enterPwd(testData.getPassword());
		swipeDown();
		login.clickSignInBtn();
		login.handleNothankspopup();
		login.handleUpgradepopup();
	}

	@Then("user should be redirected to the profile page")
	public void user_should_be_redirected_to_the_profile_page() {
//			login.handleNothankspopup();
		login.clickFooterMenu();
		login.clickMenuprofile();
	}
	@Given("user launch the app and search the library {string}")
	public void user_launch_the_app_and_search_the_library(String library) throws InterruptedException {
		login.searchLibrary(library);
	}

	@And("user clicks on login button after entering {string}")
	public void userClicksOnLoginButtonAfterEntering(String userName) {
		TestReaderPOJO testData = TestDataReader.getTestData(scenario, userName);
		login.enterUserName(testData.getLibraryId());
		hideMobileKeyboard();
		login.clickSignInBtn();
		login.handleNothankspopup();
	}
	@And("user able to login with valid creadinitial")
	public void user_able_to_login_with_valid_creadinitial() {
		logger.info("user is able to login");
	}
	@And("user clicks on new user registration$")
    public void user_clicks_on_new_user_registration() throws Throwable {
		register.clickNewUserLink();
    }
}
