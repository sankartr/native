package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.FeaturedPrg;
import pom.kidszone.LoginPage;
import pom.kidszone.MenuList;

public class FeatureBook_StepDef extends CommonActions{

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	MenuList menu= new MenuList(DriverManager.getDriver());
	LoginPage login= new LoginPage(DriverManager.getDriver());
	FeaturedPrg featured = new FeaturedPrg(DriverManager.getDriver());
	
	@And("user has no profile selected on the device earlier navigate to manage profile screen")
    public void user_has_no_profile_selected_on_the_device_earlier_navigate_to_manage_profile_screen() throws Throwable {
		logger.info(" User has no profile selec ted on the device");
	}

//    @And("user should able to view the existing profile list")
//    public void user_should_able_to_view_the_existing_profile_list() throws Throwable {
//    logger.info("view the existing profile list");
//    }

    @And("featured titles has been set in admin portal for profile")
    public void featured_titles_has_been_set_in_admin_portal_for_profile() throws Throwable {
    	logger.info("featured titles has been set");
    }
    @Given("user selected the {string} profile")
    public void user_selected_the_something_profile(String strArg1) throws Throwable {
        
    }
    @When("user not set {string} as default landing screen")
    public void user_not_set_something_as_default_landing_screen(String strArg1) throws Throwable {
        
    }

    @And("user should able to view set featured title based on profile with adult profile specific theme")
    public void user_should_able_to_view_set_featured_title_based_on_profile_with_adult_profile_specific_theme() throws Throwable {
        Assert.assertTrue(featured.featurePrgDisplay());
    }
    
    @Then("user should able to view set featured title based on profile with teen profile specific theme")
    public void user_should_able_to_view_set_featured_title_based_on_profile_with_teen_profile_specific_theme() {
    	Assert.assertTrue(featured.featurePrgDisplay());
    }

    @Then("user should able to view set featured title based on profile with kid profile specific theme")
    public void user_should_able_to_view_set_featured_title_based_on_profile_with_kid_profile_specific_theme() {
    	Assert.assertTrue(featured.featurePrgDisplay());
    }

    @And("user should able to view featured title cover image,title name and description added by admin in admin portal")
    public void user_should_able_to_view_featured_title_cover_imagetitle_name_and_description_added_by_admin_in_admin_portal() throws Throwable {
        Assert.assertTrue(featured.getLibPg_lbl_featurePrgName().isDisplayed());
//        Assert.assertTrue(featured.getLibPg_img.isDisplayed());
    }

    @And("user should able to navigate featured title details screen when click on see all cta")
    public void user_should_able_to_navigate_featured_title_details_screen_when_click_on_see_all_cta() throws Throwable {
        Assert.assertTrue(featured.clickonFeaturePrgViewAllBtn());
    }
    
    @Then("user should not view the featured title if no featured title has been set")
    public void user_should_not_view_the_featured_title_if_no_featured_title_has_been_set() {
        
    }

    @Then("user should not view the featured title if title set is no longer available for the library")
    public void user_should_not_view_the_featured_title_if_title_set_is_no_longer_available_for_the_library() {
        
    }
    
    @When("user clicks on see all cta")
    public void user_clicks_on_see_all_cta() {
    	swipeDown();
    	swipeDown();
       featured.clickOnFeatureCarouselSeeAll();
    }

    @Then("user should be able to view listing screen of the particular carousel")
    public void user_should_be_able_to_view_listing_screen_of_the_particular_carousel() {
    	if(isElementPresent(featured.getPrdDtPg_lbl_header())) {
        Assert.assertEquals(isElementPresent(featured.getPrdDtPg_lbl_header()),true);
    	}
    }

}
