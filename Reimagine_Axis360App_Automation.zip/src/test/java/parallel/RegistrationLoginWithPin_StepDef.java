package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.RegisterScreen;
import pom.kidszone.SecurityQuestion;

public class RegistrationLoginWithPin_StepDef extends CommonActions {

	RegisterScreen register = new RegisterScreen(DriverManager.getDriver());
	SecurityQuestion security = new SecurityQuestion(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());

	@Given("user is in first time logged in")
	public void user_is_in_first_time_logged_in() throws Throwable {
		Assert.assertEquals(login.getLogo_txt_Welcome().isDisplayed(), true);
	}

//	@When("user enters the prefix {string} and pin {string} shared by the client")
//	public void user_enters_the_prefix_something_and_pin_something_shared_by_the_client(String prefix, String pin)
//			throws Throwable {
//		register.enterPrefixandpin(prefix, pin);
//	}

	@And("user initiate search the {string}")
	public void user_initiate_search(String libraryid) throws Throwable {
		register.searchLibraryName(libraryid);
	}

//	@Then("system should redirect to the registration screen")
//	public void system_should_redirect_to_the_registration_screen() throws Throwable {
//		Assert.assertEquals(register.getRegister_lbl().isDisplayed(), true);
//	}

	@And("user should enter the {string}")
	public void user_should_enter_the_something(String libraryid) throws Throwable {
		register.enterLibraryId(libraryid);
	}

	@And("user enters the pin {string}")
	public void user_enters_the_pin_something_and_something(String pin) throws Throwable {
		register.enterRegisterpin(pin);
	}

	@And("user enters the email {string} and {string}")
	public void user_enters_the_email_something_and_something(String email, String displayname) throws Throwable {
		register.enterEmailandDisplayname(email, displayname);
	}

	@And("user select security question")
	public void user_select_security_question() throws Throwable {
		waitFor(4000);
		security.selectSecurityQuestion();
	}

	@And("user clicks on register button to complete registration")
	public void user_clicks_on_register_button_to_complete_registration() throws Throwable {
		register.completeRegistration();
	}

	@When("user is able to view security question and answer field")
	public void user_is_able_to_view_security_question_and_answer_field() throws Throwable {
		waitFor(4000);
		Assert.assertEquals(security.getSec_drpd().isDisplayed(), true);
		Assert.assertEquals(security.getSec_txt_ans().isDisplayed(), true);
	}

	@When("user is able to view email and displayname in textfield form of optional")
	public void user_is_able_to_view_email_and_displayname_in_textfield_form_of_optional() throws Throwable {
		Assert.assertEquals(register.getRegister_txt_Email().isDisplayed(), true);
		Assert.assertEquals(register.getRegisterseq_txt_DisplayName().isDisplayed(), true);
	}

	@When("user able to enter the {string} and {string}")
	public void user_able_to_enter_the_something_and_something(String librarycard, String password) throws Throwable {
		register.enterlibrarycardandpassword(librarycard, password);
	}

	@And("user should be able to view the error messages for the mandatory field")
	public void user_should_be_able_to_view_the_error_messages_for_the_mandatory_field() throws Throwable {
		//Assert.assertEquals(register.errormessage.isDisplayed(), true);
	}

	@And("user should be able to view the Username and Password in textfields")
	public void user_should_be_able_to_view_the_username_and_password_in_textfields() throws Throwable {
		Assert.assertEquals(register.getReg_txt_libraryPassword1().isDisplayed(), true);
		Assert.assertEquals(register.getReg_txt_reglibraryId().isDisplayed(), true);
	}

}
