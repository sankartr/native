package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.GoalsandInsights;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.MyCheckouts;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelf;
import pom.kidszone.ProfileCreation;
import pom.kidszone.PurchaseRequest;

public class PurchaseRequest_StepDef extends CommonActions{
	LoginPage login = new LoginPage(DriverManager.getDriver());
	MyShelf myshelf = new MyShelf(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	GoalsandInsights goals = new GoalsandInsights(DriverManager.getDriver());
	ManageProfile manage = new ManageProfile(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	MyCheckouts checkout=new MyCheckouts(DriverManager.getDriver());
	PurchaseRequest purchase = new PurchaseRequest(DriverManager.getDriver());

	
	public static final Logger logger = LoggerFactory.getLogger(WishList_StepDef.class);
	

    @When("user clicks on Purchase Requests quick CTA in the My shelf screen")
    public void user_clicks_on_purchase_requests_quick_cta_in_the_my_shelf_screen() throws Throwable {
		goals.clickOnMyshelfFooter();
		purchase.clickPurchaseRequest();
		waitFor(3000);
    }

    @Then("^user should be able to view Recommendations screen with theme rendered based on library subscription and user profile type$")
    public void user_should_be_able_to_view_recommendations_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() throws Throwable {
    	logger.info("User should be able to view Recommendations screen with theme rendered based on library subscription and user profile type");  
    }

    @And("^user lands on Purchase Requests screen$")
    public void user_lands_on_purchase_requests_screen() throws Throwable {
    	Assert.assertEquals(isElementPresent(purchase.getPurchase_page()), true);
    }

    @And("^user should be able to view quick navigation CTAs as a carousel on top with Recommendations highlighted and number of titles recommended$")
    public void user_should_be_able_to_view_quick_navigation_ctas_as_a_carousel_on_top_with_recommendations_highlighted_and_number_of_titles_recommended() throws Throwable {
    	Assert.assertEquals(isElementPresent(purchase.getPurchase_page()), true);
    }

    @And("^user should be able to view titles Recommended by that user only$")
    public void user_should_be_able_to_view_titles_recommended_by_that_user_only() throws Throwable {
    	Assert.assertEquals(isElementPresent(purchase.getRecommended()), true);
    }

    @And("^user should be able to view titles sorted by latest title Recommended first by default$")
    public void user_should_be_able_to_view_titles_sorted_by_latest_title_recommended_first_by_default() throws Throwable {
        purchase.clickSort();
    	Assert.assertEquals(isElementPresent(purchase.getSortLatestTitles()), false);
    	purchase.clickSortLatest();
    }
    @And("user should be able to view Purchase Request filter and sort option for the titles")
	public void user_should_be_able_to_view_filter_and_sort_option_for_the_titles() throws Throwable {
    	Assert.assertEquals(isElementPresent(purchase.getPurchaseRequest_Sort()), true);
		Assert.assertEquals(isElementPresent(purchase.getPurchaseRequest_Filter()), true);
	}
    
    @And("^user should be able to view option to view titles as list view and grid view for purchase$")
    public void user_should_be_able_to_view_option_to_view_titles_as_list_view_and_grid_view_for_purchase() throws Throwable {
    	Assert.assertEquals(isElementPresent(purchase.getPurchase_listView()), true);
		purchase.clickPurchaseView();
		Assert.assertEquals(isElementPresent(purchase.getPurchase_gridView()), true);
    }
   
    @And("^user should be able to view titles listed as list view by default for purchase$")
    public void user_should_be_able_to_view_titles_listed_as_list_view_by_default_for_purchase() throws Throwable {
    	Assert.assertEquals(isElementPresent(purchase.getPurchase_listView()), true);
    }
    @And("^user should be able to click on List or Grid view icon to switch between list view and grid view$")
    public void user_should_be_able_to_click_on_list_or_grid_view_icon_to_switch_between_list_view_and_grid_view() throws Throwable {
    	purchase.clickPurchaseView();
		Assert.assertEquals(isElementPresent(purchase.getPurchase_gridView()), true);
    }
    
    @And("^user should be able to click on back CTA to navigate back to last screen from purchase$")
    public void user_should_be_able_to_click_on_back_cta_to_navigate_back_to_last_screen_from_purchase() throws Throwable {
    	purchase.closeButton();
    }
    
    @And("^user should not view the titles in the list when recommendation has been canceled for the title$")
    public void user_should_not_view_the_titles_in_the_list_when_recommendation_has_been_canceled_for_the_title() throws Throwable {
    	logger.info("User should not view the titles in the list when recommendation has been canceled for the title");  
    }
    @And("^user has no title is Recommended$")
    public void user_has_no_title_is_recommended() throws Throwable {
    	logger.info("user has no title is Recommended");
    }
    @Then("^user should be able to view Purchase Requests screen with theme rendered based on library subscription and user profile type$")
    public void user_should_be_able_to_view_purchase_requests_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() throws Throwable {
    	logger.info("Purchase Requests screen with theme rendered");
    }

    @And("^user should be able to view no title Purchase Requests screen$")
    public void user_should_be_able_to_view_no_title_purchase_requests_screen() throws Throwable {
    	if(isElementPresent(purchase.getNoPurchaseRequest())){
    	Assert.assertEquals(isElementPresent(purchase.getNoPurchaseRequest()), true); 
    	}
    	logger.info("User able to view no title Purchase Requests screen");
    }
    @And("^user has Recommended titles$")
    public void user_has_recommended_titles() throws Throwable {
    	logger.info("User has Recommended titles");
    }
    @Then("^user should be able to view titles listed as list view by default and sorted by latest title Recommended first by default$")
    public void user_should_be_able_to_view_titles_listed_as_list_view_by_default_and_sorted_by_latest_title_recommended_first_by_default() throws Throwable {
    	Assert.assertEquals(isElementPresent(purchase.getPurchaseRequest_Sort()), true);
    	Assert.assertEquals(isElementPresent(purchase.getPurchase_gridView()), true);
    	logger.info("user should be able to view titles listed as list view by default and sorted by latest title Recommended first by default");
    }
    @And("^user should be able view title cover image and title name and Author name on card$")
    public void user_should_be_able_view_title_cover_image_and_title_name_and_author_name_on_card() throws Throwable {
    	Assert.assertEquals(isElementPresent(purchase.getTitlename()), true);
    }
    @And("^user should be able to view primary action for the title as a button for purchase$")
    public void user_should_be_able_to_view_primary_action_for_the_title_as_a_button_for_purchase() throws Throwable {
    	Assert.assertEquals(isElementPresent(purchase.getTitle_btn()), true);
    }
    @And("^user should be able to view more options CTA to view secondary actions available for the title$")
    public void user_should_be_able_to_view_more_options_cta_to_view_secondary_actions_available_for_the_title() throws Throwable {
    	purchase.clickCard();
    	purchase.clickMoreOptions();
        purchase.closepopup();
    	purchase.clickBack();
       
    }

    @And("^user should be able to click in more options CTA and view secondary actions for the title as a drawer$")
    public void user_should_be_able_to_click_in_more_options_cta_and_view_secondary_actions_for_the_title_as_a_drawer() throws Throwable {
    	logger.info("User should be able to click in more options CTA and view secondary actions for the title as a drawer");
    }

    @And("^user should be able to click on card other than primary and secondary CTA area to navigate to title details screen$")
    public void user_should_be_able_to_click_on_card_other_than_primary_and_secondary_cta_area_to_navigate_to_title_details_screen() throws Throwable {
    	purchase.clickCard();
    }
    @Then("^user should be able to click on sort to view sort options purchase$")
    public void user_should_be_able_to_click_on_sort_to_view_sort_options_purchase() throws Throwable {
    	purchase.clickSort();
    	Assert.assertEquals(isElementPresent(purchase.getSortLatestTitles()), true);
    	purchase.clickSortLatest();
    }
    @And("^user should be able to view titles sorted based on options selected purchase$")
    public void user_should_be_able_to_view_titles_sorted_based_on_options_selected_purchase() throws Throwable {
        
    }

    @And("^user should be able to view sort options 'Latest Recommended','Rating','A-Z'$")
    public void user_should_be_able_to_view_sort_options_latest_recommendedratingaz() throws Throwable {
        
    }
    @And("^user switch to grid view for Purchase Requests screen$")
    public void user_switch_to_grid_view_for_purchase_requests_screen() throws Throwable {
    	purchase.clickPurchaseView();
    	Assert.assertEquals(isElementPresent(purchase.getPurchase_gridView()), true);
    }
    @And("^user should be able to view each title listed as a tile purchase$")
    public void user_should_be_able_to_view_each_title_listed_as_a_tile_purchase() throws Throwable {
    	logger.info("User able to view each title listed as a tile");  
    }
    @Then("^system should remove the recommended title from the user recommended section$")
    public void system_should_remove_the_recommended_title_from_the_user_recommended_section() throws Throwable {
        purchase.removeRecommend();
    }

    @And("^copy for recommended title put on hold is available$")
    public void copy_for_recommended_title_put_on_hold_is_available() throws Throwable {
    	logger.info("Copy for recommended title put on hold is available");
    }

    @And("^user should be able to view the recommended title in hold if title was put on hold with hold position$")
    public void user_should_be_able_to_view_the_recommended_title_in_hold_if_title_was_put_on_hold_with_hold_position() throws Throwable {
    	logger.info("User should be able to view the recommended title in hold");
    }

    @And("^system should auto checkout the title if title was put on hold and is available for user to checkout and user has auto checkout enabled$")
    public void system_should_auto_checkout_the_title_if_title_was_put_on_hold_and_is_available_for_user_to_checkout_and_user_has_auto_checkout_enabled() throws Throwable {
    	logger.info("User should auto checkout the title if title was put on hold");
    }

    @And("checked out title should be available in the checkout screen$")
    public void checked_out_title_should_be_available_in_the_checkout_screen() throws Throwable {
    	profile.clickBackbutton();
    	checkout.navigateCheckout();
    	Assert.assertEquals(isElementPresent(checkout.getMyShelf_lbl_checkouts()), true);
    }
}


