package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;

public class ViewLibraryNames_StepDef {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(ViewLibraryNames_StepDef.class);

	Hooks hooks = new Hooks();

	@Given("user is on the search Library page")
	public void user_is_on_the_search_library_page() throws Throwable {
		Assert.assertTrue(login.getLogo_txt_Welcome().isDisplayed());
		logger.info("User is on the Search lib screen");
	}

	@When("user enters three and more than three {string} and initiates search")
	public void user_enters_three_and_more_than_three_something_and_initiates_search(String characters)
			throws Throwable {
		login.searchLibrary(characters);
	}

	@Then("user should be able to view matching library names as search result")
	public void user_should_be_able_to_view_matching_library_names_as_search_result() throws Throwable {
		login.searchLibSuggestion();

	}

	@And("user should be able to view 10 libraries listed sorted in alphabetical order")
	public void user_should_be_able_to_view_10_libraries_listed_sorted_in_alphabetical_order() throws Throwable {
		login.searchLibOrderCheck();

	}
}
