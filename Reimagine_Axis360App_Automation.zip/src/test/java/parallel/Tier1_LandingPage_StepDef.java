package parallel;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import pom.kidszone.*;

public class Tier1_LandingPage_StepDef extends CommonActions {

    LoginPage login = new LoginPage(DriverManager.getDriver());
    MyShelf myshelf = new MyShelf(DriverManager.getDriver());

    MyLibrary library = new MyLibrary(DriverManager.getDriver());
    Tier1_LandingPage_VBookandVideo tier1LandingPage = new Tier1_LandingPage_VBookandVideo(DriverManager.getDriver());
    Tier2_TitlelistPage_VBookandVideo tier2TitlelistPage = new Tier2_TitlelistPage_VBookandVideo(
            DriverManager.getDriver());

    Tier3_LandingPage_VBookandVideo tier3LandingPage = new Tier3_LandingPage_VBookandVideo(DriverManager.getDriver());
    SearchPage search = new SearchPage(DriverManager.getDriver());

    @And("user tap see all CTA of VBook carousel in tier 1 screen")
    public void user_tap_see_all_cta_of_vbook_carousel_in_tier_1_screen() throws Throwable {
        tier1LandingPage.clickseeAllTier1_vBook();
    }

    @Then("user should be able to view the VBook title icon")
    public void user_should_be_able_to_view_the_vbook_title_icon() throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkvBookTitleIcon()), true);
    }

    @And("user navigate to title detail page by tap on available VBook title card")
    public void user_navigate_to_title_detail_page_by_tap_on_available_vbook_title_card() throws Throwable {
        tier1LandingPage.clickvBookTitleCard();
    }

    @And("user navigate to title detail page by tap on VBook title card")
    public void user_navigate_to_title_detail_page_by_tap_on_vbook_title_card() throws Throwable {
        tier1LandingPage.clickvBookTitleCard();
        // Assert.assertEquals(isElementPresent(tier1LandingPage.checkTitleDetailPageVideo()),
        // true);
        // Assert.assertEquals(tier1LandingPage.checkTitleDetailPagevBook(), true);
    }

    @When("user tap see all CTA of 3rd party carousel in library screen")
    public void user_tap_see_all_cta_of_3rd_party_carousel_in_library_screen() throws Throwable {
        // tier1LandingPage.selectVBookTitles();
        tier1LandingPage.selectVideoTitles();
        waitFor(5000);
        swipeDown();
        waitFor(1000);
        swipeDown();
        waitFor(1000);
        swipeDown();
        waitFor(2000);
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoCarouselInMyLibrary()), true);
        tier1LandingPage.clickVideoSeeAllInMyLibrary();
    }

    @When("user tap see all CTA of 3rd party carousel in library screen for Video")
    public void user_tap_see_all_cta_of_3rd_party_carousel_in_library_screen_for_video() throws Throwable {
        library.clickFormat_Dropdown();
        library.click_Video_BottomDrawer();
        waitFor(3000);
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.Video_Carousel())) {
                // swipeDown();
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.Video_Carousel().isDisplayed(), true);
    }

    @When("user tap see all CTA of 3rd party carousel in library screen for vBook")
    public void user_tap_see_all_cta_of_3rd_party_carousel_in_library_screen_for_vbook() throws Throwable {
        library.clickFormat_Dropdown();
        library.click_vBook_BottomDrawer();
        waitFor(3000);
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.vBook_Carousel())) {
                // swipeDown();
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.vBook_Carousel().isDisplayed(), true);
    }

    @Then("user should able to view play action CTA for that vBook title")
    public void user_should_able_to_view_play_action_cta_for_that_vbook_title() throws Throwable {
        if (isElementPresent(tier1LandingPage.checkVideoPlayCTAInTier1())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoPlayCTAInTier1()), true);
        } else {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoResumeCTAInTier1()), true);
        }
    }

    @And("user checkout the available title")
    public void user_checkout_the_available_title() throws Throwable {
        // tier1LandingPage.clickCheckoutAvailable();
        tier1LandingPage.selectCheckout_CTA();
        waitFor(2000);
    }

    @And("user not started watching the checkout vBook title")
    public void user_not_started_watching_the_checkout_vbook_title() throws Throwable {
        logger.info("Player integration");
    }

    @Then("user should able to view resume action CTA for that vBook title")
    public void user_should_able_to_view_resume_action_cta_for_that_vbook_title() throws Throwable {
        logger.info("Player integration");
    }

    @And("user started watching and exit from checkout vBook title")
    public void user_started_watching_and_exit_from_checkout_vbook_title() throws Throwable {
        logger.info("Player integration");
    }

    @And("library should have video carousel configured in drupal")
    public void library_should_have_video_carousel_configured_in_drupal() throws Throwable {
        logger.info("Drupal setting - video configuration in drupal");
    }

    @And("library should have subscription to Video third party")
    public void library_should_have_subscription_to_video_third_party() throws Throwable {
        logger.info("Precondition setting video third party");
    }

    @And("library should have video carousel enabled in library admin")
    public void library_should_have_video_carousel_enabled_in_library_admin() throws Throwable {
        logger.info("Precondition setting enabled in library admin");
    }

    @And("library should have Video title without title image")
    public void library_should_have_video_title_without_title_image() throws Throwable {
        logger.info("Title image check");
    }

    @And("user tap see all CTA of Video carousel in tier 1 screen")
    public void user_tap_see_all_cta_of_video_carousel_in_tier_1_screen() throws Throwable {
        waitFor(5000);
        swipeDown();
        waitFor(1000);
        swipeDown();
        waitFor(2000);
        tier1LandingPage.clickseeAllTier1Video();
    }

    @And("user navigate to title detail page by tap on available video title card")
    public void user_navigate_to_title_detail_page_by_tap_on_available_video_title_card() throws Throwable {
        tier1LandingPage.clickVideoTitleCard();
    }

    @And("user should be able to view the icon with blue background")
    public void user_should_be_able_to_view_the_icon_with_blue_background() throws Throwable {
        logger.info("Theme check - icon with blue background");
    }

    @And("user navigate to title detail page by tap on video title card")
    public void user_navigate_to_title_detail_page_by_tap_on_video_title_card() throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkTitleDetailPageVideo()), true);
        waitFor(2000);
        tier1LandingPage.clickTitleDetailPageVideo();
    }

    @And("user should be able to view carousel only if the titles are available for the specific carousel")
    public void user_should_be_able_to_view_carousel_only_if_the_titles_are_available_for_the_specific_carousel()
            throws Throwable {
        logger.info("user should be able to view carousel only");
    }

    @And("user should not able to view see all CTA if disabled in drupal")
    public void user_should_not_able_to_view_see_all_cta_if_disabled_in_drupal() throws Throwable {
        logger.info("Admin - user should not able to view see all CTA if disabled in drupal");
    }

    @And("user should get redirected to the List page by tapping on see all CTA")
    public void user_should_get_redirected_to_the_list_page_by_tapping_on_see_all_cta() throws Throwable {
        if (isElementPresent(tier1LandingPage.checkSeeAllTier2())) {
            tier1LandingPage.clickSeeAllTier2();
        }
    }

    @And("user navigate to video title detail screen by tapping on video title card")
    public void user_navigate_to_video_title_detail_screen_by_tapping_on_video_title_card() throws Throwable {
        tier2TitlelistPage.navigatetoVideodetail();
    }

    @And("user should be able to view video title detail attribute based on the metadata")
    public void user_should_be_able_to_view_video_title_detail_attribute_based_on_the_metadata() throws Throwable {
        logger.info("Drupal Configuration");
    }

    @Given("library should have vBooks carousel configured in drupal")
    public void library_should_have_v_books_carousel_configured_in_drupal() {
        logger.info("library should have vBooks carousel configured in drupal");
    }

    @Given("library should have subscription to vBooks collection third party")
    public void library_should_have_subscription_to_v_books_collection_third_party() {
        logger.info("library should have subscription to vBooks collection third party");
    }

    @Given("library should have vBooks carousel enabled in library admin")
    public void library_should_have_v_books_carousel_enabled_in_library_admin() {
        logger.info("library should have vBooks carousel enabled in library admin");
    }

    @When("user should be navigate to library screen")
    public void user_should_be_navigate_to_library_screen() {
        login.clickmylibrary();
    }

    @When("user should be navigate to vBooks title tier1 screen")
    public void user_should_be_navigate_to_vbooks_title_tier_screen() {
        tier1LandingPage.clickVBookSeeAllInMyLibrary();
        waitFor(2000);
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookTier1Title()), true);
        waitFor(2000);
        // swipeDown();
    }

    @Then("user should be able to view carousels in the Tier1 screen configured in 3rd party drupal admin")
    public void user_should_be_able_to_view_carousels_in_the_tier_screen_configured_in_3rd_party_drupal_admin(
            Integer int1) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookCarouselInTier1()), true);
    }

    @Then("user should be able to view these carousels with specified logic configured in Drupal admin portal")
    public void user_should_be_able_to_view_these_carousels_with_specified_logic_configured_in_drupal_admin_portal() {
        logger.info("Carousel Logic check");
    }

    @Then("user should be able to view the VBook Title Icon for the VBook title")
    public void user_should_be_able_to_view_the_v_book_title_icon_for_the_v_book_title() {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookTitleIcon()), true);
    }

    @Then("user should be able to view the icon with Blue background if the is available")
    public void user_should_be_able_to_view_the_icon_with_blue_background_if_the_is_available() {
        logger.info("user should be able to view the icon with Blue background if the is available");
    }

    @And("user should be able to view checkout as primary action for vBook title in tier1 page")
    public void user_Should_Be_Able_To_View_Checkout_As_Primary_Action_for_vBook_Title_Detail_Screen() {
        if (isElementPresent(tier1LandingPage.checkVBookCheckoutCTAInTier1())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookCheckoutCTAInTier1()), true);
        }
    }

    @And("user should be able to view play as primary action after checked Out for vBook title in tier1 page")
    public void user_Should_Be_Able_To_View_Play_As_Primary_Action_After_Checked_Out_for_vBook_title_in_tier1_page() {
        if (isElementPresent(tier1LandingPage.checkVBookPlayCTAInTier1())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookPlayCTAInTier1()), true);
        }
    }

    @And("user should be able to view renew as primary action for vBook title in tier1 page")
    public void user_Should_Be_Able_To_View_Renew_As_primary_Action_for_vBook_title_in_tier1_page() {
        if (isElementPresent(tier1LandingPage.checkVBookResumeCTAInTier1())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookResumeCTAInTier1()), true);
        }
    }

    @And("user can navigate to Tier1 list screen")
    public void user_Can_Navigate_To_Tier_List_Screen() {
        Assert.assertEquals(tier1LandingPage.checkVBookTier1Title(), true);
    }

    @And("user should be able to view checkout as primary action from title detail screen")
    public void user_Should_Be_Able_To_View_Checkout_As_Primary_Action_From_Title_Detail_Screen() {
        Assert.assertEquals(tier1LandingPage.checkVBookCheckoutCTAInTier1(), true);
        tier1LandingPage.clickVBookCheckoutCTAInTier1();
    }

    @And("user should be able to view play as primary action after checked Out")
    public void user_Should_Be_Able_To_View_Play_As_Primary_Action_After_Checked_Out() {
        Assert.assertEquals(tier1LandingPage.checkVBookPlayCTAInTier1(), true);
    }

    @And("user should be able to view return and renew as secondary action")
    public void user_Should_Be_Able_To_View_Return_And_Renew_As_Secondary_Action() {
        Assert.assertEquals(tier1LandingPage.checkVBookResumeCTAInTier1(), true);
    }

    @And("user should be navigate to video title tier screen")
    public void user_Should_Be_Navigate_To_Video_Title_Tier_Screen() {
        tier1LandingPage.clickVideoSeeAllInMyLibrary();
        waitFor(2000);
        Assert.assertTrue(isElementPresent(tier1LandingPage.videoTier1Heading()));
    }

    @And("^user should be navigate to video title tier-2 screen$")
    public void user_should_be_navigate_to_video_title_tier2_screen() throws Throwable {
        tier1LandingPage.clickVideoSeeAllInTier1Screen();
    }

    @And("library should have subscription to Video collection third party")
    public void library_Should_Have_Subscription_To_Video_Collection_Third_Party() {
        logger.info("Video Collection enabled in admin");
    }

    @And("user should be able to view vBook carousel in My library screen")
    public void user_Should_Be_Able_To_View_VBook_Carousel_In_My_Library_Screen() {
        library.clickFormat_Dropdown();
        library.click_vBook_BottomDrawer();
        waitFor(3000);
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.vBook_Carousel())) {
                swipeDown();
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.vBook_Carousel().isDisplayed(), true);
    }

    @And("user should be able to view video carousel in My library screen")
    public void user_Should_Be_Able_To_View_Video_Carousel_In_My_Library_Screen() {
        library.clickFormat_Dropdown();
        library.click_Video_BottomDrawer();
        waitFor(3000);
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.Video_Carousel())) {
                swipeDown();
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.Video_Carousel().isDisplayed(), true);
    }

    @When("user should be able to view video carousel in My library screen filtered")
    public void user_should_be_able_to_view_video_carousel_in_my_library_screen_filtered() {
        library.clickFormat_Dropdown();

    }

    @Then("user should be able to view list of  carousel")
    public void user_Should_Be_Able_To_View_List_Of_Carousel() {
        logger.info("Carousel type confirmation");
    }

    @And("user should be able to view the carousel type as Stack Carousel in tier1")
    public void user_Should_Be_Able_To_View_The_Carousel_Type_As_Stack_Carousel() {
        if (isElementPresent(tier1LandingPage.checkVideoStackCarouselInTier1())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoStackCarouselInTier1()), true);
        }
    }

    @And("user should be able to view the carousel type as Item Carousel in tier1")
    public void user_Should_Be_Able_To_View_The_Carousel_Type_As_Item_Carousel() {
        if (isElementPresent(tier1LandingPage.checkVideoItemCarouselInTier1())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoItemCarouselInTier1()), true);
        }
    }

    @And("user should be able to view the carousel type as Card Carousel in tier1")
    public void user_Should_Be_Able_To_View_The_Carousel_Type_As_Card_Carousel() {
        if (isElementPresent(tier1LandingPage.checkVideoCardCarouselInTier1())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoCardCarouselInTier1()), true);
        }
    }

    @Then("user should be able to view the Video Title Icon for the video title")
    public void userShouldBeAbleToViewTheVideoTitleIconForTheVideoTitle() {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoTitleIcon()), true);
    }

    @And("user should be able to view the vBook carousel type as Stack Carousel")
    public void userShouldBeAbleToViewTheVBookCarouselTypeAsStackCarousel() {
        if (isElementPresent(tier1LandingPage.checkVBookStackCarouselInTier1())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookStackCarouselInTier1()), true);
        }
    }

    @And("user should be able to view the vBook carousel type as Item Carousel")
    public void userShouldBeAbleToViewTheVBookCarouselTypeAsItemCarousel() {
        if (isElementPresent(tier1LandingPage.checkVBookItemCarouselInTier1())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookItemCarouselInTier1()), true);
        }
    }

    @And("user should be able to view the vBook carousel type as Card Carousel")
    public void userShouldBeAbleToViewTheVBookCarouselTypeAsCardCarousel() {
        if (isElementPresent(tier1LandingPage.checkVBookCardCarouselInTier1())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookCardCarouselInTier1()), true);
        }
    }

    @Then("user should be able to view checkout as primary action for video title in tier{int} page")
    public void userShouldBeAbleToViewCheckoutAsPrimaryActionForVideoTitleInTierPage(int arg0) {
        tier1LandingPage.clickVideoTitleCarouselTier1();

        if (isElementPresent(tier3LandingPage.checkAuthortextInTier3())) {
            try {
                if (isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3())) {
                    ClickOnMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
                } else {
                    tier3LandingPage.clickReturnBtnInTier3();
                    waitFor(2000);
                    ClickOnMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
                }
            } catch (Exception e) {
                logger.info("Books were returned");
            }
        } else {
            swipeDown();
        }

    }

    @And("user should be able to view play as primary action after checked Out for video title in tier{int} page")
    public void userShouldBeAbleToViewPlayAsPrimaryActionAfterCheckedOutForVideoTitleInTierPage(int arg0) {
        if (isElementPresent((tier1LandingPage.checkVideoPlayCTAInTier1()))) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoPlayCTAInTier1()), true);
        }
    }

    @And("user should be able to view renew as primary action for video title in tier{int} page")
    public void userShouldBeAbleToViewRenewAsPrimaryActionForVideoTitleInTierPage(int arg0) {
        if (isElementPresent(tier1LandingPage.checkVideoResumeCTAInTier1())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoResumeCTAInTier1()), true);
        }
    }

    @Then("user should be able to view the video categories carousel format in the Tier {int} screen")
    public void userShouldBeAbleToViewTheVideoCategoriesCarouselFormatInTheTierScreen(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideosCategoriesCarouselHeader()), true);
    }

    @And("user should be able to view video categories with name and icon")
    public void userShouldBeAbleToViewVideoCategoriesWithNameAndIcon() {
        // Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideosCategoriesName()),
        // true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideosCategoriesIcon().get(0)), true);
    }

    @Then("user should be able to view vBook categories carousel format in the Tier {int} screen")
    public void userShouldBeAbleToViewVBookCategoriesCarouselFormatInTheTierScreen(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookTitleCarouselHeader()), true);
    }

    @And("user should be able to view vBook categories with name and icon")
    public void userShouldBeAbleToViewVBookCategoriesWithNameAndIcon() {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookCategoriesName()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookCategoriesIcon().get(0)), true);
    }

    @And("user should be able to view video featured carousel in Tier{int}")
    public void userShouldBeAbleToViewVideoFeaturedCarouselInTier(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideosFeaturedCarouselHeader()), true);
    }

    @Then("user should be able to view video categories in Tier{int}")
    public void userShouldBeAbleToViewTitleVideoCarouselsInTier(int arg0) {
        for (int i = 0; i <= 8; i++) {
            if (isElementPresent(tier1LandingPage.checkVideosTitleCarouselHeader())) {
                // swipeDown();
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideosTitleCarouselHeader()), true);
    }

    @And("user should be able to view video Categories carousel in Tier{int}")
    public void userShouldBeAbleToViewVideoCategoriesCarouselInTier(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideosCategoriesCarouselHeader()), true);
    }

    @Then("user should be able to view vBook categories in Tier{int}")
    public void userShouldBeAbleToViewVBookTitleCarouselsInTier(int arg0) {
        for (int i = 0; i <= 8; i++) {
            if (isElementPresent(tier1LandingPage.checkVBookCategoryTitleInTier1Header())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookCategoryTitleInTier1Header()), true);
    }

    @And("user should be able to view vBook featured carousel in Tier{int}")
    public void userShouldBeAbleToViewVBookFeaturedCarouselInTier(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookFeaturedCarouselHeader()), true);
    }

    @And("user should be able to view vBook Categories carousel in Tier{int}")
    public void userShouldBeAbleToViewVBookCategoriesCarouselInTier(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookCategoriesCarouselHeader()), true);
    }

    @Then("user should be able to view video See all option for the Tier {int} screen carousels")
    public void userShouldBeAbleToViewSeeAllOptionForTheTierScreenCarousels(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoSeeAllCarouselInTier1()), true);
    }

    @And("user should be able to navigate to the video Tier {int} screen after clicking on see all")
    public void userShouldBeAbleToNavigateToTheTierScreenAfterClickingOnSeeAll(int arg0) {
        tier1LandingPage.clickVideoSeeAllCarouselInMyLibrary();
        // Assert.assertEquals(isElementPresent(tier1LandingPage.checkFeaturedVideoTier2Title()),
        // true);
        // tier1LandingPage.clickBackButton();
    }

    @And("user should be able to click on any video Title card")
    public void userShouldBeAbleToClickOnAnyTitleCard() {
        tier1LandingPage.clickVideoSeriesTitleCarouselTier1();
    }

    @And("user navigate to tier {int} video title details screen")
    public void userNavigateToTierTitleDetailsScreen(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoBookTitleInTier3()), true);
    }

    @Then("user should be able to view See all option for the vBook Tier {int} page carousels")
    public void userShouldBeAbleToViewSeeAllOptionForTheVBookTierPageCarousels(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookSeeAllCarouselInTier1()), true);
    }

    @And("user should be able to navigate to the vBook Tier {int} page after clicking on see all")
    public void userShouldBeAbleToNavigateToTheVBookTierPageAfterClickingOnSeeAll(int arg0) {
        tier1LandingPage.clickVBookSeeAllCarouselInMyLibrary();
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkFeaturedVBookTier2Title()), true);
    }

    @And("user should be able to click on any vBook Title card")
    public void userShouldBeAbleToClickOnAnyVBookTitleCard() {
        tier1LandingPage.clickVBookTitleCarouselTier1();
    }

    @And("user navigate to tier {int} vBook title details screen")
    public void userNavigateToTierVBookTitleDetailsScreen(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookTitleInTier3()), true);
    }

    // @When("user lands on my library screen")
    // public void user_lands_on_my_library_screen() throws Throwable {
    // login.clickmylibrary();
    // }

    @Then("user should be able to view VBooks in the carousel format")
    public void user_should_be_able_to_view_vbooks_in_the_carousel_format() throws Throwable {
        library.clickFormat_Dropdown();
        library.click_vBook_BottomDrawer();
        waitFor(3000);
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(library.vBook_Carousel())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(library.vBook_Carousel().isDisplayed(), true);

    }

    @And("user should be able to view 10 number of VBooks in the carousel , as per set by Admin in Drupal")
    public void user_should_be_able_to_view_10_number_of_vbooks_in_the_carousel_as_per_set_by_admin_in_drupal()
            throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookCarouselInMyLibrary()), true);
    }

    @And("user should be able to swipe left & Right in carousel")
    public void user_should_be_able_to_swipe_left_right_in_carousel() throws Throwable {
        swipeleft(tier1LandingPage.getvBook_thirdParty_intro());
        swiperight(tier1LandingPage.getvBook_thirdParty_intro());
    }

    @And("User should be able to view specific number of VBooks title in the carousel as per drupal")
    public void user_should_be_able_to_view_specific_number_of_vbooks_title_in_the_carousel_as_per_drupal()
            throws Throwable {
        logger.info("Drupal configuration");
    }

    @And("user should be able to view VBook titles carousel as per API response")
    public void user_should_be_able_to_view_vbook_titles_carousel_as_per_api_response() throws Throwable {
        logger.info("API Response check");
    }

    @And("user lands on Tier 2 listing page")
    public void user_lands_on_tier_2_listing_page() throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.getvBookTier1Title()), true);
    }

    public void user_should_be_able_to_view_vbook_title_in_the_carousel_format() throws Throwable {
        library.clickFormat_Dropdown();
        library.click_vBook_BottomDrawer();
        swipeDown();
        swipeDown();
        library.vBook_Carousel();
    }

    @And("User should be able to view  VBooks titles")
    public void user_should_be_able_to_view_vbooks_titles() throws Throwable {
        for(int i = 0;i<=5;i++) {
            if(isElementPresent(library.getFirstVBook())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(library.check_vBook_title()), true);
    }

    @And("user should be able to view VBooks title card with cover image with primary and secondary CTA")
    public void user_should_be_able_to_view_vbooks_title_card_with_cover_image_with_primary_and_secondary_cta()
            throws Throwable {
        Assert.assertEquals(isElementPresent(library.checkvBookCoverImage()), true);
        swipeDown();
        if (isElementPresent(library.checkPrimary_CTA1())) {
            Assert.assertEquals(isElementPresent(library.checkPrimary_CTA1()), true);
        } else if (isElementPresent(library.checkPrimary_CTA2())) {
            Assert.assertEquals(isElementPresent(library.checkPrimary_CTA2()), true);
        } else {
            Assert.assertEquals(isElementPresent(library.checkPrimary_CTA3()), true);
        }
    }

    @And("user should be able to click on VBooks title card")
    public void user_should_be_able_to_click_on_vbooks_title_card() throws Throwable {
        library.click_vBook_title_card();
    }

    @And("user lands on tier 3 details page")
    public void user_lands_on_tier_3_details_page() throws Throwable {
        for(int i = 0; i<4; i++) {
           if(isElementPresent(library.check_Tier3_details_page())) {
            break;
           } else {
                swipeDown();
           }
        }
        
        Assert.assertEquals(isElementPresent(library.check_Tier3_details_page()), true);
    }

    @And("user should be able to view secondary CTA")
    public void user_should_be_able_to_view_secondary_cta() throws Throwable {
        Assert.assertEquals(isElementPresent(library.check_Tier3_SecondaryCTA()), false);
    }

    @When("user is able to clicks on Videos and VBooks option from category in advance search option")
    public void user_is_able_to_clicks_on_videos_and_vbooks_option_from_category_in_advance_search_option()
            throws Throwable {
        hideMobileKeyboard();
        waitFor(2000);
        search.selectVideoCollection();
        search.selectVbookCollection();
        search.clicksearchResultButton();
    }

    @And("user should be able click on see all CTA")
    public void user_should_be_able_click_on_see_all_cta() throws Throwable {
        tier1LandingPage.clickVBookSeeAllInMyLibrary();
    }

    @Then("user should be able to view third party videos and vbooks two carousels in expanded search results landing screen")
    public void user_should_be_able_to_view_third_party_videos_and_vbooks_two_carousels_in_expanded_search_results_landing_screen()
            throws Throwable {
        Assert.assertEquals(search.vbookResult(), true);
    }

    @And("admin user is enabled videos and vbooks third party search flag and include in search flag in drupal")
    public void admin_user_is_enabled_videos_and_vbooks_third_party_search_flag_and_include_in_search_flag_in_drupal()
            throws Throwable {
        logger.info("Drupal configuration");
    }

    @And("library should have subscription to video third party and video carousel enabled by library admin")
    public void library_should_have_subscription_to_video_third_party_and_video_carousel_enabled_by_library_admin()
            throws Throwable {
        logger.info("library admin configuration");
    }

    @And("user is able to enter a keyword {string} in search bar from landing screen")
    public void user_is_able_to_enter_a_keyword_in_search_bar_from_landing_screen(String keyword) throws Throwable {
        tier1LandingPage.clickadvancedSearch();
        search.searchBar(keyword);
    }

    @And("user should be able to  view videos and vbooks as card title with image, title and action cta")
    public void user_should_be_able_to_view_videos_and_vbooks_as_card_title_with_image_title_and_action_cta()
            throws Throwable {
        Assert.assertEquals(search.getvBookTitle_Result().isDisplayed(), true);
    }

    @And("user should be able to view default image for not available title image")
    public void user_should_be_able_to_view_default_image_for_not_available_title_image() throws Throwable {
        logger.info("image Validation");
    }

    @And("user should be able to tap on see all cta and navigate to list screen or tier2 screen for specific category videos and vbooks")
    public void user_should_be_able_to_tap_on_see_all_cta_and_navigate_to_list_screen_or_tier2_screen_for_specific_category_videos_and_vbooks()
            throws Throwable {
        search.click_vBook_SeeAll();
    }

    @And("user should be able to tap on title and navigate to tier3 screen")
    public void user_should_be_able_to_tap_on_title_and_navigate_to_tier3_screen() throws Throwable {
        search.clickvBook_title_card();
        Assert.assertEquals(isElementPresent(library.verifyTier3Title()), true);
    }

    @Then("user should be able to view vBook Tier {int} page with Feature hero banner in the top as per configured by admin in Drupal")
    public void userShouldBeAbleToViewVbookTierPageWithFeatureHeroBannerInTheTopAsPerConfiguredByAdminInDrupal(
            int arg0) {
        if (isElementPresent(tier1LandingPage.checkFeaturedCarouselInTier1())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkFeaturedCarouselInTier1()), true);
        }
    }

    @Then("user should be able to view video Tier {int} page with Feature hero banner in the top as per configured by admin in Drupal")
    public void userShouldBeAbleToViewVideoTierPageWithFeatureHeroBannerInTheTopAsPerConfiguredByAdminInDrupal(
            int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkFeaturedCarouselInTier1()), true);
    }

    @And("user should be able to view {int} number of vBooks cards in the hero banner with carousel format configured by admin")
    public void userShouldBeAbleToViewNumberOfVBooksCardsInTheHeroBannerWithCarouselFormatConfiguredByAdmin(int arg0) {
        for (int i = 0; i <= 5; i++) {
            if (isElementPresent(tier1LandingPage.checkvBookTitleIcon())) {
                swipeDown();
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkvBookTitleIcon()), true);
    }

    @And("user should be able to view titles for videos from each publisher with alternative tiltle from publishers")
    public void userShouldBeAbleToViewTitlesForVideosFromEachPublisherWithAlternativeTiltleFromPublishers() {
        logger.info("View titles for videos from each publisher with alternative tiltle from publishers");
    }

    @And("user should be able to view videos titles sorted based on popularity or publication date")
    public void userShouldBeAbleToViewVideosTitlesSortedBasedOnPopularityOrPublicationDate() {
        logger.info("videos titles are sorted based on popularity or publication date");
    }

    @And("user should be able to view vBooks titles sorted based on popularity or publication date")
    public void userShouldBeAbleToViewVbooksTitlesSortedBasedOnPopularityOrPublicationDate() {
        logger.info("videos titles are sorted based on popularity or publication date");
    }

    @And("user should be able to view videos titles sorted by publication latest date first when popularity metrics are not available or popularity index is same")
    public void userShouldBeAbleToViewVideosTitlesSortedByPublicationLatestDateFirstWhenPopularityMetricsAreNotAvailableOrPopularityIndexIsSame() {
        logger.info(
                "videos titles sorted by publication latest date first when popularity metrics are not available or popularity index is same");
    }

    @And("user should be able to view vBooks titles sorted by publication latest date first when popularity metrics are not available or popularity index is same")
    public void userShouldBeAbleToViewVbooksTitlesSortedByPublicationLatestDateFirstWhenPopularityMetricsAreNotAvailableOrPopularityIndexIsSame() {
        logger.info(
                "videos titles sorted by publication latest date first when popularity metrics are not available or popularity index is same");
    }

    @Then("user should be able to view categories in the Tier {int} page in the carousel format")
    public void userShouldBeAbleToViewCategoriesInTheTierPageInTheCarouselFormat(int arg) {
        for (int i = 0; i <= 8; i++) {
            if (isElementPresent(tier1LandingPage.checkVBookCategoryTitleInTier1Header())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookCategoryTitleInTier1Header()), true);
    }

    @And("user should be able to view the vBook Title carousels with see all option")
    public void userShouldBeAbleToViewTheCarouselsWithSeeAllOption() {
        for (int i = 0; i <= 8; i++) {
            if (isElementPresent(tier1LandingPage.checkvBookCategorySeeAllTitleInTier1())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkvBookCategorySeeAllTitleInTier1()), true);
    }

    @And("user navigate to Tier {int} Page from clicking see all option")
    public void userNavigateToTierPageFromClickingSeeAllOption(int arg0) {
        tier1LandingPage.clickvBookCategorySeeAllTitleInTier1();
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkCategoryVBookTier2Title()), true);
    }

    @Then("user should be able to view video categories in the Tier {int} screen in the carousel format")
    public void userShouldBeAbleToViewVideoCategoriesInTheTierScreenInTheCarouselFormat(int arg0) {
        for (int i = 0; i <= 8; i++) {
            if (isElementPresent(tier1LandingPage.checkVideoCategoryTitleInTier1Header())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoCategoryTitleInTier1Header()), true);
    }

    @And("user should be able to view the video carousels with see all option")
    public void userShouldBeAbleToViewTheVideoCarouselsWithSeeAllOption() {
        for (int i = 0; i <= 8; i++) {
            if (isElementPresent(tier1LandingPage.checkVideoCategorySeeAllTitleInTier1())) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoCategorySeeAllTitleInTier1()), true);
    }

    @And("user navigate to Tier {int} screen from clicking video carousel see all option")
    public void userNavigateToTierScreenFromClickingVideoCarouselSeeAllOption(int arg0) {
        tier1LandingPage.clickVideoCategorySeeAllTitleInTier1();
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkCategoryVideoTier2Title()), true);
    }

    @And("user should be able to view specific number of video cards in the hero banner with carousel format configured by admin")
    public void userShouldBeAbleToViewSpecificNumberOfVideoCardsInTheHeroBannerWithCarouselFormatConfiguredByAdmin() {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoTitleIcon()), true);
    }

    @And("user should be able to show titles for videos from each publisher with alternative title with publishers")
    public void userShouldBeAbleToShowTitlesForVideosFromEachPublisherWithAlternativeTitleWithPublishers() {
        logger.info("Show titles for videos from each publisher with alternative title with publishers");
    }

    @And("user should be able to click any vBook category")
    public void userShouldBeAbleToClickAnyVBookCategory() {
        tier1LandingPage.clickvBookCategoriesIcon();
    }

    @And("user should be able to view tier {int} vBook categories page")
    public void userShouldBeAbleToViewTierVBookCategoriesPage(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkvBookCategoriesInTier2()), true);
    }

    @And("user should be able to click any video category")
    public void userShouldBeAbleToClickAnyVideoCategory() {
        tier1LandingPage.clickVideoCategoriesIcon();
    }

    @And("user should be able to view tier {int} video categories page")
    public void userShouldBeAbleToViewTierVideoCategoriesPage(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoCategoriesInTier2()), true);
    }

    @When("user is able to navigate search result landing screen after tap on search")
    public void user_is_able_to_navigate_search_result_landing_screen_after_tap_on_search() throws Throwable {
        search.clicksearchResultButton();
    }

    @And("user is able to view videos and vbooks third party option in advance search")
    public void user_is_able_to_view_videos_and_vbooks_third_party_option_in_advance_search() throws Throwable {
        Assert.assertEquals(isElementPresent(search.getVbook_Colletion()), true);
        // Assert.assertEquals(isElementPresent(search.getVideo_Colletion()), true);

    }

    @And("user is able tap on advance search from my shelf screen and enter any keyword {string} and select videos option in category and tap search")
    public void user_is_able_tap_on_advance_search_from_my_shelf_screen_and_enter_any_keyword_and_select_videos_option_in_category_and_tap_search(
            String keyword) {
        search.searchkeyWord(keyword);
        hideMobileKeyboard();
        search.select_Videos();
        search.click_Search_btn();
    }

    @When("user is able tap on advance search from my shelf screen and enter any keyword {string}")
    public void user_is_able_tap_on_advance_search_from_my_shelf_screen_and_enter_any_keyword_something(String keyword)
            throws Throwable {
        search.advanceSearch(keyword);
        hideMobileKeyboard();
    }

    @Then("user should be able to view expanded results for vBooks category in grid view")
    public void user_should_be_able_to_view_expanded_results_for_vbooks_category_in_grid_view() throws Throwable {
        Assert.assertEquals(search.vbookResult(), true);
    }

    @And("select eBook,eAudio,Video,vBooks option in category and vBooks from refiners section and tap search")
    public void select_ebookeaudiovideovbooks_option_in_category_and_vbooks_from_refiners_section_and_tap_search()
            throws Throwable {
        search.select_Collections_General();
        search.click_Search_btn();
        search.click_Refiner_Option();
        search.select_VBooks_Refiner();
        // search.click_Search_Refine_btn();
    }

    @Then("user should be able to view expanded results for videos category in grid view")
    public void user_should_be_able_to_view_expanded_results_for_videos_category_in_grid_view() throws Throwable {
        Assert.assertEquals(search.getVideos_SearchResults().isDisplayed(), true);
        // System.out.println("oooooo"+search.videoResult());
        // Assert.assertEquals(search.videoResult(), true);
        // Assert.assertEquals(isElementPresent(search.getVideoCategoryPills()), true);
    }

    @And("select eBook,eAudio,Video,vBooks option in category and videos from refiners section and tap search")
    public void select_ebookeaudiovideovbooks_option_in_category_and_videos_from_refiners_section_and_tap_search()
            throws Throwable {
        search.select_Collections_General();
        search.click_Search_btn();
        search.click_Refiner_Option();
        search.select_Video_Refiner();
        // search.click_Search_Refine_btn();
    }

    @Then("user should be able to view videos carousel on search landing screen")
    public void user_should_be_able_to_view_videos_carousel_on_search_landing_screen() throws Throwable {
        Assert.assertEquals(search.getVideos_Carousel_Landing().isDisplayed(), true);
    }

    @And("select videos from advance search and tap on search cta")
    public void select_videos_from_advance_search_and_tap_on_search_cta() throws Throwable {
        search.selectVideoCollection();
        search.click_Search_btn();
    }

    @And("user should be able to view other carousels along with videos carousel for other search criteria")
    public void user_should_be_able_to_view_other_carousels_along_with_videos_carousel_for_other_search_criteria()
            throws Throwable {
        Assert.assertEquals(search.getOther_Carousel_Landing().isDisplayed(), true);
    }

    @And("select vBooks from advance search and tap on search cta")
    public void select_vbooks_from_advance_search_and_tap_on_search_cta() throws Throwable {
        search.selectVbookCollection();
        search.click_Search_btn();
    }

    @Then("user should be able to view vBooks carousel on search landing screen")
    public void user_should_be_able_to_view_vbooks_carousel_on_search_landing_screen() throws Throwable {
        Assert.assertEquals(search.getvBook_Carousel_Landing().isDisplayed(), true);
    }

    @And("user should be able to view other carousels along with vBooks carousel for other search criteria")
    public void user_should_be_able_to_view_other_carousels_along_with_vbooks_carousel_for_other_search_criteria()
            throws Throwable {
        Assert.assertEquals(search.getOther_Carousel_Landing().isDisplayed(), true);
    }

    @When("user is able to navigate search result landing screen and tap see all cta")
    public void user_is_able_to_navigate_search_result_landing_screen_and_tap_see_all_cta() throws Throwable {
        Assert.assertEquals(search.getSearch_Result_Landing().isDisplayed(), true);
        search.clickSeeAll();
        waitFor(1000);
        search.click_Back_btn();
    }

    @Then("user should be able to view expanded results for videos category in list view")
    public void user_should_be_able_to_view_expanded_results_for_videos_category_in_list_view() throws Throwable {
        swipeDown();
        swipeDown();
        Assert.assertEquals(search.getVideos_Expanded_Result().isDisplayed(), true);
    }

    @Then("user should be able to view expanded results for vbooks category in list view")
    public void user_should_be_able_to_view_expanded_results_for_vbooks_category_in_list_view() throws Throwable {
        Assert.assertEquals(search.getVbook_Expanded_Result().isDisplayed(), true);
    }

    @And("user should be able to view vbooks cover image, title, dropsown menu and checkout primary cta")
    public void user_should_be_able_to_view_vbooks_cover_image_title_dropsown_menu_and_checkout_primary_cta()
            throws Throwable {
        Assert.assertEquals(search.getVbook_Cover_Image().isDisplayed(), true);
        // Assert.assertEquals(search.getVbook_Title().isDisplayed(), true);
        // Assert.assertEquals(search.getVbook_Checkout_CTA().isDisplayed(), true);
    }

    @And("user should be able to tap on checkout and not started and shows as play as primary and return/renew as secondary cta")
    public void user_should_be_able_to_tap_on_checkout_and_not_started_and_shows_as_play_as_primary_and_returnrenew_as_secondary_cta()
            throws Throwable {
        search.click_Checkout_CTA();
    }

    @And("user should be able to tap on checkout and started watching and exit the player and shows as resume as primary and return/renew as secondary cta")
    public void user_should_be_able_to_tap_on_checkout_and_started_watching_and_exit_the_player_and_shows_as_resume_as_primary_and_returnrenew_as_secondary_cta()
            throws Throwable {
        search.click_Play_CTA();
    }

    @And("user should be able to view sort order for the results based on relevance")
    public void user_should_be_able_to_view_sort_order_for_the_results_based_on_relevance() throws Throwable {
        logger.info("unable to view sort order for the results");
    }

    @And("user should be able to view lazy load after scroll down more than 24 titles")
    public void user_should_be_able_to_view_lazy_load_after_scroll_down_more_than_24_titles() throws Throwable {
        logger.info("unable to view lazy load after scroll down");
    }

    @And("system should auto filter the results based on teen profile or kid profile")
    public void system_should_auto_filter_the_results_based_on_teen_profile_or_kid_profile() throws Throwable {
        logger.info("unable to check - auto filter the results based on teen profile or kid");
    }

    @And("user is able tap on advance search from my shelf screen and enter any keyword {string} and select videos and vbooks option in category")
    public void user_is_able_tap_on_advance_search_from_my_shelf_screen_and_enter_any_keyword_and_select_videos_and_vbooks_option_in_category(
            String keyword) {
        search.advanceSearch(keyword);
        hideMobileKeyboard();
        waitFor(2000);
    }

    @And("user should be able to view categories 'eBooks, eAudio, Video & VBooks, Newspaper & Magazines, Articles, Activity Resources, Web Resources'")
    public void user_should_be_able_to_view_categories_ebooks_eaudio_video_vbooks_newspaper_magazines_articles_activity_resources_web_resources()
            throws Throwable {
        Assert.assertEquals(isElementPresent(search.getVideo_Colletion()), true);
        Assert.assertEquals(isElementPresent(search.getVbook_Colletion()), true);
        Assert.assertEquals(isElementPresent(search.getCollections_WebResource()), true);
    }

    @And("user should be able to view categories on the Display Name configured in the Drupal by Admin")
    public void user_should_be_able_to_view_categories_on_the_display_name_configured_in_the_drupal_by_admin()
            throws Throwable {
        logger.info("drupal configure");
    }

    @And("user enter any keyword {string} and select video category and should be able to view Videos carousel with see all cta in search results screen")
    public void user_should_be_able_to_view_videos_carousel_with_see_all_cta_in_search_results_screen(String keyword)
            throws Throwable {
        // search.searchkeyWord(keyword);
        // hideMobileKeyboard();
        waitFor(3000);
        // if(isElementPresent(search.getVideo_Colletion())) {
        // search.getVideo_Colletion().click();
        // }
        search.selectVideoCollection();
        waitFor(1000);
        search.clicksearchResultButton();
        Assert.assertEquals(isElementPresent(search.getvideos_Header()), true);
    }

    @And("user should be able to tap see all and view expanded results for the Videos & VBooks category")
    public void user_should_be_able_to_tap_see_all_and_view_expanded_results_for_the_videos_vbooks_category()
            throws Throwable {
        Assert.assertEquals(search.getSearch_Result().isDisplayed(), true);
    }

    @And("user should not be able to view category 'Video & VBooks'")
    public void user_should_not_be_able_to_view_category_video_vbooks() throws Throwable {
        logger.info("admin config");
    }

    @And("user should not be able to view Videos & VBooks carousel with see all cta in search results screen")
    public void user_should_not_be_able_to_view_videos_vbooks_carousel_with_see_all_cta_in_search_results_screen()
            throws Throwable {
        Assert.assertEquals(isElementPresent(search.getvideos_Header()), false);

    }

    @And("admin user is disabled videos and vbooks third party search flag and disabled include in search flag in drupal")
    public void admin_user_is_disabled_videos_and_vbooks_third_party_search_flag_and_disabled_include_in_search_flag_in_drupal()
            throws Throwable {
        logger.info("Drupal configuration");

    }

    @And("user is not able to view videos and vbooks third party option in advance search")
    public void user_is_not_able_to_view_videos_and_vbooks_third_party_option_in_advance_search() throws Throwable {
        Assert.assertEquals(isElementPresent(search.getVbook_Colletion()), false);
        Assert.assertEquals(isElementPresent(search.getVideo_Colletion()), false);

    }

    @And("user is able tap on advance search from my shelf screen and enter any keyword {string} and not able to view videos and vbooks option in category")
    public void user_is_able_tap_on_advance_search_from_my_shelf_screen_and_enter_any_keyword_and_not_able_to_view_videos_and_vbooks_option_in_category(
            String keyword) throws Throwable {
        search.advanceSearch(keyword);
        hideMobileKeyboard();
    }

    @Then("user should be able to view vbooks category as seperate carousel for the search keyword")
    public void user_should_be_able_to_view_vbooks_category_as_seperate_carousel_for_the_search_keyword()
            throws Throwable {
        Assert.assertEquals(search.vbookResult(), true);
    }

    @And("user select vbooks option in category")
    public void user_is_able_tap_on_advance_search_from_my_shelf_screen_and_enter_any_keyword_and_select_vbooks_option_in_category()
            throws Throwable {
        search.selectVbookCollection();
    }

    @And("user should be able to view vbooks come from third party resources")
    public void user_should_be_able_to_view_vbooks_come_from_third_party_resources() throws Throwable {
        search.clicksearchResultButton();
        logger.info("user should be able to view vbooks come from third party resources");
    }

    @And("user should be able to view title with VBooks icon on the jacket image")
    public void user_should_be_able_to_view_title_with_vbooks_icon_on_the_jacket_image() throws Throwable {
        Assert.assertEquals(isElementPresent(search.checkvBookSearchTitleIcon().get(0)), true);
    }

    @And("user should be able to tap on the vbooks title and navigate to vbooks detail screen from vbooks list screen")
    public void user_should_be_able_to_tap_on_the_vbooks_title_and_navigate_to_vbooks_detail_screen_from_vbooks_list_screen()
            throws Throwable {
        search.clickvBookSearchTitle();
        Assert.assertEquals(isElementPresent(search.checkTier3TextTitle()), true);
        Assert.assertEquals(isElementPresent(search.checkvBookTier3TitleIcon()), true);
    }

    @Then("user should be able to view videos category as seperate carousel for the search keyword")
    public void user_should_be_able_to_view_videos_category_as_seperate_carousel_for_the_search_keyword()
            throws Throwable {
        Assert.assertEquals(isElementPresent(search.checkVideoCategoryPills()), true);
        Assert.assertEquals(isElementPresent(search.checkvBookandVideoSearchCategoryHeader()), true);
    }

    @And("user should be able to view videos come from third party resources")
    public void user_should_be_able_to_view_videos_come_from_third_party_resources() throws Throwable {
        search.click_Search_btn();
        logger.info("user should be able to view videos come from third party resources");
    }

    @And("user should be able to view title with videos icon on the jacket image")
    public void user_should_be_able_to_view_title_with_videos_icon_on_the_jacket_image() throws Throwable {
        Assert.assertEquals(isElementPresent(search.checkVideoSearchTitleIcon().get(0)), true);
    }

    @And("user should be able to tap on the videos title and navigate to videos detail screen from videos list screen")
    public void user_should_be_able_to_tap_on_the_videos_title_and_navigate_to_videos_detail_screen_from_videos_list_screen()
            throws Throwable {
        search.clickVideoSearchTitle();
        Assert.assertEquals(isElementPresent(search.checkTier3TextTitle()), true);
        Assert.assertEquals(isElementPresent(search.checkVideoTier3TitleIcon()), true);
    }

    @And("user select videos option in category")
    public void user_select_videos_option_in_category() throws Throwable {
        hideMobileKeyboard();
        waitFor(3000);
        search.selectVideoCollection();
    }

    @When("user select the video format from the bottom drawer")
    public void user_select_the_video_format_from_the_bottom_drawer() throws Throwable {
        library.click_Video_BottomDrawer();
        swipeDown();
        swipeDown();
        swipeDown();
    }

    @Then("system should show toast message upon user clicking on the  checked out title action CTA")
    public void system_should_show_toast_message_upon_user_clicking_on_the_checked_out_title_action_cta()
            throws Throwable {
        logger.info("system should show toast message upon user clicking on the  checked out title action CTA");
    }

    @And("user landed in the My Library screen")
    public void user_landed_in_the_my_library_screen() throws Throwable {
        login.clickmylibrary();
    }

    @And("user should view format bottom drawer with option VBooks & Video")
    public void user_should_view_format_bottom_drawer_with_option_vbooks_video() throws Throwable {
        library.clickFormat_Dropdown();
        Assert.assertEquals(isElementPresent(library.check_Video_BottomDrawer()), true);
        Assert.assertEquals(isElementPresent(library.check_vBook_BottomDrawer()), true);
    }

    @And("user click the checkoutcta for videos")
    public void user_click_the_checkoutcta_for_videos() throws Throwable {
        if (isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3())) {
            tier3LandingPage.clickCheckoutBtnInTier3();
            tier1LandingPage.clickBackButton();
        } else {
            tier3LandingPage.clickReturnBtnInTier3();
            tier3LandingPage.clickCheckoutBtnInTier3();
            tier1LandingPage.clickBackButton();
        }
    }

    @And("user should be able to view success toast message")
    public void user_should_be_able_to_view_success_toast_message_you_have_checked_out_title() throws Throwable {
        if (isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3())) {
            tier3LandingPage.clickCheckoutBtnInTier3();
            Assert.assertEquals(tier1LandingPage.check_Checkout_Success_Toast_Message(), true);
            tier3LandingPage.clickRenewBtnInTier3();
            Assert.assertEquals(tier1LandingPage.checkRenew_Toast_Message(), true);
            tier3LandingPage.clickReturnBtnInTier3();
            Assert.assertEquals(tier1LandingPage.checkReturn_Toast_Message(), true);
        } else {
            tier3LandingPage.clickRenewBtnInTier3();
            Assert.assertEquals(tier1LandingPage.checkRenew_Toast_Message(), true);
            tier3LandingPage.clickReturnBtnInTier3();
            Assert.assertEquals(tier1LandingPage.checkReturn_Toast_Message(), true);
            tier3LandingPage.clickCheckoutBtnInTier3();
            Assert.assertEquals(tier1LandingPage.check_Checkout_Success_Toast_Message(), true);
        }

    }

    @When("user selects the videos format from the bottom drawer")
    public void user_selects_the_videos_format_from_the_bottom_drawer() throws Throwable {
        waitFor(2000);
        library.click_Video_BottomDrawer();
    }

    @Then("system should show toast message upon user clicking on the return title action CTA")
    public void system_should_show_toast_message_upon_user_clicking_on_the_return_title_action_cta() throws Throwable {
        // logger.info("Unable to check - toast message upon user clicking on the return
        // title action CTA");
        // Assert.assertEquals(isElementPresent(tier1LandingPage.checkReturn_Toast_Message()),true);
    }

    @Then("system should show toast message upon user clicking on the renewe title action CTA")
    public void system_should_show_toast_message_upon_user_clicking_on_the_renewe_title_action_cta() throws Throwable {
        // logger.info("toast message upon user clicking on the renewe title");
        // Assert.assertEquals(isElementPresent(tier1LandingPage.checkRenew_Toast_Message()),true);
    }

    @And("user return the VBooks title after finished the checkout from secondary action")
    public void user_return_the_vbooks_title_after_finished_the_checkout_from_secondary_action() throws Throwable {
        login.clickMyShelf();
        waitFor(2000);
        tier1LandingPage.clickCheckout_CTA();
        waitFor(2000);
        tier1LandingPage.clickCheckoutAvailable();
        waitFor(2000);
        tier1LandingPage.clickReturn_title();
    }

    @And("user sould be select renew the title from secondary action")
    public void user_sould_be_select_renew_the_title_from_secondary_action() throws Throwable {
        login.clickMyShelf();
        waitFor(2000);
        tier1LandingPage.clickCheckout_CTA();
        waitFor(2000);
        tier1LandingPage.clickCheckoutAvailable();
        waitFor(2000);
        tier1LandingPage.clickRenew_title();
    }

    @Then("system should show toast message upon user clicking on the title action CTA")
    public void system_should_show_toast_message_upon_user_clicking_on_the_title_action_cta() throws Throwable {
        // logger.info("System should show toast message upon user clicking on the title
        // action CTA");
        tier1LandingPage.clickRemove_title();
        tier1LandingPage.clickRemovalConfirmationPopup();
        Assert.assertEquals(tier1LandingPage.checkRemove_Checkout_History(), true);
    }

    @Then("system should show failure toast message upon user clicking on the title action CTA")
    public void system_should_show_failure_toast_message_upon_user_clicking_on_the_title_action_cta() throws Throwable {
        logger.info("Unable to check - failure toast message");
    }

    @And("user is navigated to checkout history")
    public void user_is_navigated_to_checkout_history() throws Throwable {
        login.clickMyShelf();
        waitFor(2000);
        myshelf.clickwishlist();
        waitFor(2000);
        tier1LandingPage.clickPurchaseRequest_CTA();
        waitFor(2000);
        tier1LandingPage.clickDownload_CTA();
        waitFor(2000);
        // horizontalSwipe(tier1LandingPage.checkCheckoutHistory());
        tier1LandingPage.clickHistory_CTA();
        waitFor(2000);
        // tier1LandingPage.clickCheckoutHistoryAvailable();
        // waitFor(2000);
    }

    @Given("user navigate to manage profile screen and switch to teen user")
    public void user_navigate_to_manage_profile_screen_and_switch_to_teen_user() throws Throwable {
        // tier1LandingPage.clickMenu();
        // tier1LandingPage.clickProfiles();
        tier1LandingPage.teenprofileSelection();
        login.handleNothankspopup();
    }

    @When("user can be view titles in My Stuff checkouts screen")
    public void user_can_be_view_titles_in_my_stuff_checkouts_screen() throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoTitles_Checkedout()), true);
    }

    @Then("user can be view combined section for eBook & eAudio,Videos & VBooks")
    public void user_can_be_view_combined_section_for_ebook_eaudiovideos_vbooks() throws Throwable {
        tier1LandingPage.clickFilter_option();
        tier1LandingPage.clickFilter_vBooks();
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkvBookTitles_Checkedout()), true);

        tier1LandingPage.clickFilter_option();
        tier1LandingPage.clickFilter_Videos();
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoTitles_Checkedout()), true);
    }

    @And("library should have video and vbook carousel configured in drupal")
    public void library_should_have_video_and_vbook_carousel_configured_in_drupal() throws Throwable {
        logger.info("Admin - video and vbook carousel configured in drupal");
    }

    @And("library should have subscription to Video and vbook collection third party")
    public void library_should_have_subscription_to_video_and_vbook_collection_third_party() throws Throwable {
        logger.info("Admin - subscription to Video and vbook collection");
    }

    @And("library should have video and vbook carousel enabled in library admin")
    public void library_should_have_video_and_vbook_carousel_enabled_in_library_admin() throws Throwable {
        logger.info("Admin - video and vbook carousel enabled in library");
    }

    @And("user navigate to tier 1 page from library screen")
    public void user_navigate_to_tier_1_page_from_library_screen() throws Throwable {
        login.clickmylibrary();
        library.clickFormat_Dropdown();
        library.click_Video_BottomDrawer();
        waitFor(3000);
        swipeDown();
        swipeDown();
        swipeDown();
        tier1LandingPage.clickVideoSeeAllInMyLibrary();
    }

    @And("user tap to checkout in any titles from tier 1,2,3 screens")
    public void user_tap_to_checkout_in_any_titles_from_tier_123_screens() throws Throwable {
        tier1LandingPage.clickSeeAllTier2();
        waitFor(2000);
        tier1LandingPage.selectCheckout_CTA();
        waitFor(2000);
        tier1LandingPage.clickClose_1stCheckout();
        waitFor(2000);
        tier1LandingPage.clickBackButton();
        waitFor(2000);
        tier1LandingPage.clickBackButton();
    }

    @And("user navigate to checkout category pills from Myshelf screen")
    public void user_navigate_to_checkout_category_pills_from_myshelf_screen() throws Throwable {
        tier1LandingPage.clickMyShelf();
        waitFor(2000);
        tier1LandingPage.clickCheckout_CTA();
    }

    @And("user can be view titles listed as list view by default")
    public void user_can_be_view_titles_listed_as_list_view_by_default() throws Throwable {
        logger.info("Unable to validate the UI -user can be view titles listed as list view by default");
    }

    @And("user can be view titles in checkout screen last read order by default")
    public void user_can_be_view_titles_in_checkout_screen_last_read_order_by_default() throws Throwable {
        logger.info("Unable to check - titles in checkout screen last read order by default");
    }

    @And("user can be view title cover image and title name and Author name on card")
    public void user_can_be_view_title_cover_image_and_title_name_and_author_name_on_card() throws Throwable {
        tier1LandingPage.clickFilter_option();
        tier1LandingPage.clickFilter_Videos();
        Assert.assertEquals(isElementPresent(tier1LandingPage.verifyCheckout_Video()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.title_Cover_Image()), true);
        tier1LandingPage.clickBackButton();
    }

    @And("user can be view title due date for checkout expiry and return date")
    public void user_can_be_view_title_due_date_for_checkout_expiry_and_return_date() throws Throwable {
        logger.info("Unable to find title due date for checkout ");
    }

    @And("user can be view primary action for the title as a button")
    public void user_can_be_view_primary_action_for_the_title_as_a_button() throws Throwable {
        if (isElementPresent(tier1LandingPage.checkPrimary_Action())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.checkPrimary_Action()), true);
        } else if (isElementPresent(tier1LandingPage.getPrimary_Action_Resume())) {
            Assert.assertEquals(isElementPresent(tier1LandingPage.getPrimary_Action_Resume()), true);
        }
    }

    @And("user can be view more options CTA to view secondary actions available for each title")
    public void user_can_be_view_more_options_cta_to_view_secondary_actions_available_for_each_title()
            throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkSecondary_Action1()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkSecondary_Action2()), true);
    }

    @And("user can be view reading progress of the title as a progress bar as static")
    public void user_can_be_view_reading_progress_of_the_title_as_a_progress_bar_as_static() throws Throwable {
        logger.info("Unable to view reading progress of the title");
    }

    @And("user can be view reading progress percentage on the card for checkout only")
    public void user_can_be_view_reading_progress_percentage_on_the_card_for_checkout_only() throws Throwable {
        logger.info("Unable to view reading progress percentage on the card");
    }

    @And("user can be view the Primary CTA and Secondary CTA")
    public void user_can_be_view_the_primary_cta_and_secondary_cta() throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkPrimary_Action()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkSecondary_Action1()), true);
    }

    @And("user should be redirected to title detail page from checkout screen")
    public void user_should_be_redirected_to_title_detail_page_from_checkout_screen() throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.title_Author_Name()), true);
    }

    @Then("user should able to view primary CTA as Remove")
    public void user_should_able_to_view_primary_cta_as_play() throws Throwable {
        Assert.assertEquals(isElementPresent(myshelf.getHistory_primaryCTA()), true);
    }

    @And("user navigates to my stuff screen")
    public void user_navigates_to_my_stuff_screen() throws Throwable {
        myshelf.clickMyShelf();
    }

    @And("user clicks on history pills")
    public void user_clicks_on_history_pills() throws Throwable {
        myshelf.clickrecommendation();
        myshelf.clickhistory();
    }

    @When("^user is able tap on checkout cta from mystuff screen and navigate to checkout screen$")
    public void user_is_able_tap_on_checkout_cta_from_mystuff_screen_and_navigate_to_checkout_screen()
            throws Throwable {
        tier1LandingPage.clickMyShelf();
        tier1LandingPage.clickCheckout_CTA();
    }

    @Then("^user should be able to view titles as grid view and sorted by latest title checked out first$")
    public void user_should_be_able_to_view_titles_as_grid_view_and_sorted_by_latest_title_checked_out_first()
            throws Throwable {
        logger.info("able to view titles as grid view");
    }

    @And("^user have checked out titiles$")
    public void user_have_checked_out_titiles() throws Throwable {
        logger.info("user have checked out titiles");
    }

    @And("^user should be able to view reading progress of the title as progress bar and percentage on card$")
    public void user_should_be_able_to_view_reading_progress_of_the_title_as_progress_bar_and_percentage_on_card()
            throws Throwable {
        logger.info("user should be able to view reading progress of the title");
    }

    @And("^user should be able to click on title image and navigate to title detail screen$")
    public void user_should_be_able_to_click_on_title_image_and_navigate_to_title_detail_screen() throws Throwable {
        tier1LandingPage.clickTitle_Image();
        waitFor(2000);
        if (isElementPresent(search.checkTitle_Details())) {
            Assert.assertEquals(isElementPresent(search.checkTitle_Details()), true);
        } else if (isElementPresent(search.getTitle_resume())) {
            Assert.assertEquals(isElementPresent(search.getTitle_resume()), true);
        }
    }

    @When("^user is able tap on checkout cta from mystuff screen$")
    public void user_is_able_tap_on_checkout_cta_from_mystuff_screen() throws Throwable {
        waitFor(2000);
        tier3LandingPage.clickBackIcon();
        waitFor(2000);
        tier3LandingPage.clickBackIcon();
        waitFor(2000);
        tier1LandingPage.clickMyShelf();
        waitFor(4000);
        tier1LandingPage.clickCheckout_CTA();
        logger.info("Checkout button clicked");
    }

    @Then("^user should be able to view two sections eBook and eAudio and videos and vbooks$")
    public void user_should_be_able_to_view_two_sections_ebook_and_eaudio_and_videos_and_vbooks() throws Throwable {
        tier1LandingPage.clickFilter_option();
        Assert.assertEquals(isElementPresent(tier1LandingPage.check_eBook_Filter_option()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.check_eAudio_Filter_option()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.check_Videos_Filter_option()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.check_vBooks_Filter_option()), true);
    }

    @And("^user should be able to view video titles checkedout in videos and vbooks section$")
    public void user_should_be_able_to_view_video_titles_checkedout_in_videos_and_vbooks_section() throws Throwable {
        tier1LandingPage.clickFilter_Videos();
        waitFor(2000);
        Assert.assertEquals(isElementPresent(tier1LandingPage.check_Video_title().get(0)), true);
        tier1LandingPage.clickFilter_option();
        tier1LandingPage.clickFilter_vBooks();

    }

    @And("^user should be able to view each video title listed as card in grid view$")
    public void user_should_be_able_to_view_each_video_title_listed_as_card_in_grid_view() throws Throwable {
        logger.info("Video titles listed as card in grid view");
    }

    @And("^user should be able to view titles as list view by default$")
    public void user_should_be_able_to_view_titles_as_list_view_by_default() throws Throwable {
        logger.info("There is no option provided for list view by default");
    }

    @And("^user should be able to view the titles sorted by latest title checkedout first by default$")
    public void user_should_be_able_to_view_the_titles_sorted_by_latest_title_checkedout_first_by_default()
            throws Throwable {
        tier1LandingPage.clickFilter_option();
        tier1LandingPage.clickFilter_Videos();
        tier1LandingPage.clickSort_option();
        tier1LandingPage.clickSort_Recently_Checkedout();
        Assert.assertEquals(isElementPresent(tier1LandingPage.title_Image.get(0)), true);
    }

    @When("^user is in the My Shelf Screen$")
    public void user_is_in_the_my_shelf_screen() throws Throwable {
        waitFor(5000);
        tier1LandingPage.clickBackButton();
        tier1LandingPage.clickMyShelf();
        // DriverManager.getDriver().navigate().refresh();
        // waitFor(5000);
        // tier1LandingPage.clickCheckout_CTA();
        // tier1LandingPage.clickBackButton();
    }

    @Then("^user should be able to view checked out video titles section$")
    public void user_should_be_able_to_view_checked_out_titles_section() throws Throwable {
        // tier1LandingPage.clickFilter_option();
        // tier1LandingPage.clickFilter_Videos();
        // Assert.assertEquals(isElementPresent(tier1LandingPage.check_Video_title().get(0)),true);
        Assert.assertEquals(isElementPresent(tier3LandingPage.checkCurrentlyCheckedOutSection()), true);
    }

    @Then("^user should be able to view checked out vbook titles section$")
    public void user_should_be_able_to_view_checked_out_vbook_titles_section() throws Throwable {
        // tier1LandingPage.clickFilter_option();
        // tier1LandingPage.clickFilter_vBooks();
        // Assert.assertEquals(isElementPresent(tier1LandingPage.check_vBooks_title().get(0)),true);
        Assert.assertEquals(isElementPresent(tier3LandingPage.checkCurrentlyCheckedOutSection()), true);
    }

    @And("^user selects the Video format from the bottom drawer$")
    public void user_selects_the_video_format_from_the_bottom_drawer() throws Throwable {
        library.click_Video_BottomDrawer();
    }

    @And("^user should be able to select the Video by clicking checkout cta$")
    public void user_should_be_able_to_select_the_video_by_clicking_checkout_cta() throws Throwable {
        tier1LandingPage.clickseeAllTier1Video();
    }

    @And("^user checked out the Video Title$")
    public void user_checked_out_the_video_title() throws Throwable {
        tier1LandingPage.clickVideoTitleCarouselTier1();
        waitFor(2000);
        swipeDown();
        if (isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3())) {
            waitFor(2000);
            ClickOnMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
            waitFor(5000);
            tier3LandingPage.clickBackIcon();
        } else {
            tier3LandingPage.clickReturnBtnInTier3();
            waitFor(5000);
            ClickOnMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
            waitFor(5000);
            tier3LandingPage.clickBackIcon();
        }
        waitFor(2000);
        // tier3LandingPage.clickCheckoutBtnInTier3();
        // waitFor(5000);
        tier1LandingPage.clickBackButton();
        waitFor(2000);
        tier1LandingPage.clickBackButton();
    }

    @And("^user checked out the Video Title from Tier1$")
    public void user_checked_out_the_Video_Title_from_Tier1() throws Throwable {
        // tier1LandingPage.selectCheckout_CTA();
        // waitFor(2000);
        tier1LandingPage.clickVideoTitleCarouselTier1();
        waitFor(2000);
        swipeDown();
        if (isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3())) {
            waitFor(2000);
            ClickOnMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
            waitFor(5000);
            tier3LandingPage.clickBackIcon();
        } else {
            swipeUp();
            tier3LandingPage.clickReturnBtnInTier3();
            waitFor(5000);
            ClickOnMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
            waitFor(5000);
            tier3LandingPage.clickBackIcon();
        }
        // tier1LandingPage.selectCheckout_CTA();
        waitFor(2000);
        // tier1LandingPage.clickVideoCheckoutCTAInTier1();
    }

    @And("^user should be able to view the Currently checked-out vbook carousel$")
    public void user_should_be_able_to_view_the_currently_checkedout_carousel() throws Throwable {
        // tier1LandingPage.clickSort_option();
        // tier1LandingPage.clickSort_Recently_Checkedout();
        // Assert.assertEquals(isElementPresent(tier1LandingPage.getLatest_title_vbook_checkedout()),true);
        swipeDown();
        tier3LandingPage.verifyCheckedOutTitle();
    }

    @And("^user should be able to view the Currently checked-out video carousel$")
    public void user_should_be_able_to_view_the_currently_checkedout_video_carousel() throws Throwable {
        // tier1LandingPage.clickSort_option();
        // tier1LandingPage.clickSort_Recently_Checkedout();
        // Assert.assertEquals(isElementPresent(tier1LandingPage.getLatest_title_video_checkedout()),true);
        swipeDown();
        tier3LandingPage.verifyCheckedOutTitle();
    }

    @And("^user should be able to view  VBooks Title as part of the Currently checked out carousel$")
    public void user_should_be_able_to_view_vbooks_title_as_part_of_the_currently_checked_out_carousel()
            throws Throwable {
        // tier1LandingPage.clickFilter_option();
        // tier1LandingPage.clickFilter_vBooks();
        // waitFor(2000);
        // Assert.assertEquals(isElementPresent(tier1LandingPage.check_vBooks_title().get(0)),true);
        Assert.assertEquals(isElementPresent(tier3LandingPage.verifyCheckedOutTitleAuthorName()), true);
    }

    @And("^user should be able to view Video title as part of the Currently checked out carousel$")
    public void user_should_be_able_to_view_video_title_as_part_of_the_currently_checked_out_carousel()
            throws Throwable {
        // tier1LandingPage.clickFilter_option();
        // tier1LandingPage.clickFilter_Videos();
        // waitFor(2000);
        // Assert.assertEquals(isElementPresent(tier1LandingPage.check_Video_title().get(0)),true);
        Assert.assertEquals(isElementPresent(tier3LandingPage.verifyCheckedOutTitleAuthorName()), true);
    }

    @And("^user selects the VBooks format from the drop down$")
    public void user_selects_the_vbooks_format_from_the_drop_down() throws Throwable {
        library.click_vBook_BottomDrawer();
    }

    @And("^user should be able to select the VBooks by clicking checkout cta$")
    public void user_should_be_able_to_select_the_vbooks_by_clicking_checkout_cta() throws Throwable {
        tier1LandingPage.clickseeAllTier1_vBook();
    }

    @And("^user checked out the VBooks Title$")
    public void user_checked_out_the_vbooks_title() throws Throwable {
        tier1LandingPage.clickVBookTitleCarouselTier1();
        if (isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3())) {
            tier3LandingPage.clickCheckoutBtnInTier3();
            tier3LandingPage.clickBackIcon();
        } else {
            tier3LandingPage.clickReturnBtnInTier3();
            tier3LandingPage.clickBackIcon();
        }
        // tier1LandingPage.selectCheckout_CTA();
        waitFor(2000);
    }

    @Then("^user can be view sort features with order based on A-Z,Recently checkedout and ratings$")
    public void user_can_be_view_sort_features_with_order_based_on_azrecently_checkedout_and_ratings()
            throws Throwable {
        tier1LandingPage.clickSort_option();
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkSort_Recently_Checkedout()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkSort_AtoZ_Checkedout()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkSort_Ratings_Checkedout()), true);
    }

    @And("^user can be view only those titles based on selection from the sort dropdown$")
    public void user_can_be_view_only_those_titles_based_on_selection_from_the_sort_dropdown() throws Throwable {
        tier1LandingPage.clickSort_Recently_Checkedout();
        // Assert.assertEquals(isElementPresent(tier1LandingPage.check_Video_title()),true);
    }

    @And("^user can switch anytime from the sort dropdown$")
    public void user_can_switch_anytime_from_the_sort_dropdown() throws Throwable {
        tier1LandingPage.clickSort_option();
    }

    @And("^user can be view list option in checkout sort screen from My stuff$")
    public void user_can_be_view_list_option_in_checkout_sort_screen_from_my_stuff() throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.check_Video_title().get(0)), true);
    }

    @Then("user can be view search feature with keyword with existing functionality {string}")
    public void user_can_be_view_search_feature_with_keyword_with_existing_functionality(String searchkeyword)
            throws Throwable {
        tier1LandingPage.clickSearchIcon_Checkouts();
        tier1LandingPage.search_Keyword(searchkeyword);
    }

    @And("^user should be retrieve the titles which match the search keyword$")
    public void user_should_be_retrieve_the_titles_which_match_the_search_keyword() throws Throwable {
        tier1LandingPage.check_Video_title();
    }

    @And("^user can be view list option in checkout search screen from My stuff$")
    public void user_can_be_view_list_option_in_checkout_search_screen_from_my_stuff() throws Throwable {
        tier1LandingPage.clickSort_option();
    }

    @Then("^user can be view filter feature with the dropdown options for All,ebook,eaudio,vbook and video$")
    public void user_can_be_view_filter_feature_with_the_dropdown_options_for_allebookeaudiovbook_and_video()
            throws Throwable {
        tier1LandingPage.clickFilter_option();
        Assert.assertEquals(isElementPresent(tier1LandingPage.check_All_Filter_option()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.check_eBook_Filter_option()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.check_eAudio_Filter_option()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.check_Videos_Filter_option()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.check_vBooks_Filter_option()), true);
    }

    @And("^user should be able to view \"([^\"]*)\" titles selected by default upon landing on the checkout screen$")
    public void user_should_be_able_to_view_something_titles_selected_by_default_upon_landing_on_the_checkout_screen(
            String strArg1) throws Throwable {
        tier1LandingPage.clickFilter_All();
    }

    @And("^user can be view only those titles based on selection from the filter dropdown$")
    public void user_can_be_view_only_those_titles_based_on_selection_from_the_filter_dropdown() throws Throwable {
        tier1LandingPage.clickFilter_option();
        tier1LandingPage.clickFilter_vBooks();
        tier1LandingPage.checkvBookTitle();
        logger.info("User able to see the vBook titles based on the filter option");
    }

    @And("^user can switch anytime from the filter dropdown$")
    public void user_can_switch_anytime_from_the_filter_dropdown() throws Throwable {
        tier1LandingPage.clickFilter_option();
        tier1LandingPage.clickFilter_Videos();
        tier1LandingPage.checkVideoTitle();
        logger.info("User able to see the Video titles based on the filter option");
    }

    @And("^user can be view the sub head and the total number of titles in parenthesis except for \"ALL\" from filter option$")
    public void user_can_be_view_the_sub_head_and_the_total_number_of_titles_in_parenthesis_except_for_ALL_from_filter_option(
            String strArg1) throws Throwable {
        logger.info("Need to verify - the sub head and the total number of titles in parenthesis");
    }

    @And("^user can be view list option in checkout filter screen from My stuff$")
    public void user_can_be_view_list_option_in_checkout_filter_screen_from_my_stuff() throws Throwable {
        tier1LandingPage.clickSort_option();
        tier1LandingPage.clickSort_Recently_Checkedout();
    }

    @And("^user can be view an indicator of red dot on the Filter if the Default is not selected$")
    public void user_can_be_view_an_indicator_of_red_dot_on_the_filter_if_the_default_is_not_selected()
            throws Throwable {
        logger.info("Verified an indicator of red dot on the Filter if the Default is not selected ");
    }

    @And("select the vBook category in category section")
    public void selectTheVBookCategoryInCategorySection() {
        search.selectVbookCollection();
    }

    @And("select the video category in category section")
    public void selectTheVideoCategoryInCategorySection() {
        waitFor(2000);
        search.selectVideoCollection();
    }

    @And("user should be able to tap on video title and navigate to tier{int} screen")
    public void userShouldBeAbleToTapOnVideoTitleAndNavigateToTierScreen(int arg0) {
        search.clickvideo_title_card();
        Assert.assertEquals(isElementPresent(library.verifyTier3Title()), true);
    }

    @And("user searches the keyword {string} in the search field")
    public void userSearchesTheKeywordInTheSearchField(String searchKeyword) {
        search.globalSearch(searchKeyword);
        if (System.getProperty("platform").equalsIgnoreCase("android")) {
            hideMobileKeyboard();
            // } else if(isElementPresent(search){
            // search.clickIOSKeyboardDone();
            // } else{
            // // search.clickSearchKeyboard();
            // }
            waitFor(1000);
            search.clickSearchIcon();
        }
    }

    @Then("user should be able to view vbook and video in expanded carousel format")
    public void userShouldBeAbleToViewVbookAndVideoInExpandedCarouselFormat() {
        search.verifyVideoSearchResult();
        search.verifyvBookSearchResult();
    }

    @And("user should be able to scroll down the results and see lazy load below the results")
    public void userShouldBeAbleToScrollDownTheResultsAndSeeLazyLoadBelowTheResults() {
        logger.info("UI Validation");
    }

    @And("user should be able to view third party search results based on drupal configuration")
    public void userShouldBeAbleToViewThirdPartySearchResultsBasedOnDrupalConfiguration() {
        logger.info("Drupal Configuration");
    }

    @And("user should be view title sort order based on relevance")
    public void userShouldBeViewTitleSortOrderBasedOnRelevance() {
        logger.info("UI Validation");
    }

    @And("user should not be able to view third party option in advance search after library has disable thord party search flag")
    public void userShouldNotBeAbleToViewThirdPartyOptionInAdvanceSearchAfterLibraryHasDisableThordPartySearchFlag() {
        logger.info("Disable function");
    }

    @And("user can be view primary action for the title in checkout history screen")
    public void userCanBeViewPrimaryActionForTheTitleInCheckoutHistoryScreen() {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkCheckout_History_Primary_Action()), true);
    }

    @Then("user can be view sort features with order based on A-Z,Recently checkedout and Due Date in checkout screen")
    public void userCanBeViewSortFeaturesWithOrderBasedOnAZRecentlyCheckedoutAndDueDateInCheckoutScreen() {
        tier1LandingPage.clickSort_option();
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkSort_Recently_Checkedout()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkSort_AtoZ_Checkedout()), true);
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkSort_DueDate_Checkedout()), true);
    }

    @And("user checkout the available vbook title")
    public void userCheckoutTheAvailableVbookTitle() {
        tier1LandingPage.clickVBookTitleCarouselTier1();
        waitFor(2000);
        if (isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3())) {
            waitFor(2000);
            ClickOnMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
        } else {
            tier3LandingPage.clickReturnBtnInTier3();
            waitFor(2000);
            ClickOnMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
        }
        // tier1LandingPage.selectCheckout_CTA();
    }

    @And("user checkout the available video title")
    public void userCheckoutTheAvailableVideoTitle() {
        tier1LandingPage.clickVideoTitleCarouselTier1();
        waitFor(5000);
        if (isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3())) {
            waitFor(2000);
            ClickOnMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
        } else if (isElementPresent(tier3LandingPage.checkReturnBtnInTier3())) {
            tier3LandingPage.clickReturnBtnInTier3();
            waitFor(2000);
            ClickOnMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
        }
        // tier1LandingPage.selectCheckout_CTA();
    }

    @Then("user should able to view play action CTA for that video title")
    public void userShouldAbleToViewPlayActionCTAForThatVideoTitle() {
        logger.info("view play action for video is not feasible");
    }

    @And("user should be able to click on any vBook Series Title card")
    public void userShouldBeAbleToClickOnAnyVBookSeriesTitleCard() {
        tier1LandingPage.clickBackButton();
        waitFor(1000);
        tier1LandingPage.clickVBookSeriesTitleCarouselTier1();
    }

    @And("user able to check out the video Title from Tier{int}")
    public void userAbleToCheckOutTheVideoTitleFromTier(int arg0) {
        tier1LandingPage.clickVideoTitleCarouselTier1();
        tier3LandingPage.checkoutTitle();
        // tier1LandingPage.selectCheckout_CTA();
        waitFor(5000);
        // tier1LandingPage.clickVideoCheckoutCTAInTier1();
    }

    @And("user able to check out the vBook Title from Tier{int}")
    public void userAbleToCheckOutTheVBookTitleFromTier(int arg0) {
        // tier1LandingPage.clickVBookTitleCarouselTier1();
        tier1LandingPage.clickVBookTitleCarouselTier1();
        if (isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3())) {
            tier3LandingPage.getTitle();
            ClickOnMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
            waitFor(5000);
            tier3LandingPage.clickBackIcon();
        } else {
            tier3LandingPage.clickReturnBtnInTier3();
            tier3LandingPage.getTitle();
            ClickOnMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
            waitFor(5000);
            tier3LandingPage.clickBackIcon();
        }
        // tier1LandingPage.selectCheckout_CTA();
        waitFor(5000);
        // tier1LandingPage.clickVideoCheckoutCTAInTier1();
    }

    @And("user should be able click on video see all CTA")
    public void userShouldBeAbleClickOnVideoSeeAllCTA() {
        tier1LandingPage.clickVideoSeeAllInMyLibrary();
    }

    @And("user is able tap on advance search from my shelf screen and enter {string} keyword and select videos option in category and tap search")
    public void userIsAbleTapOnAdvanceSearchFromMyShelfScreenAndEnterKeywordAndSelectVideosOptionInCategoryAndTapSearch(
            String keyword) {
        search.advanceSearch(keyword);
        hideMobileKeyboard();
        waitFor(2000);
        search.click_Search_btn();
    }

    @When("user is able to navigate search result landing screen and tap see all cta of vBook")
    public void userIsAbleToNavigateSearchResultLandingScreenAndTapSeeAllCtaOfVBook() {
        search.click_vBook_SeeAll();
        waitFor(2000);
    }

    @And("user navigate to manage profile screen and switch to Kid user")
    public void userNavigateToManageProfileScreenAndSwitchToKidUser() {
        // tier1LandingPage.clickMenu();
        // tier1LandingPage.clickProfiles();
        tier1LandingPage.clickKidprofileSelection();
        login.handleNothankspopup();
    }

    @And("user search for the unavailable {string} Title")
    public void userSearchForTheUnavailableTitle(String keyword) {
        waitFor(3000);
        tier1LandingPage.clickadvancedSearch();
        search.searchkeyWord(keyword);
        hideMobileKeyboard();
        search.clicksearchResultButton();
    }

    @And("user click on search icon")
    public void userClickOnSearchIcon() {
        search.click_Search_btn();
    }

    @When("user clicks on the see all link of the video widgets")
    public void userClicksOnTheSeeAllLinkOfTheVideoWidgets() {
        tier1LandingPage.clickVideoWidgetsSeeAllLinkInMyLibrary();
    }

    @And("user is navigated to the Tier {int} screen fo the video widgets")
    public void userIsNavigatedToTheTierScreenFoTheVideoWidgets(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideoTier1Title()), true);
    }

    @And("user clicks on the see all link of the video widgets in the tier{int} screen")
    public void userClicksOnTheSeeAllLinkOfTheVideoWidgetsInTheTierScreen(int arg0) {
        tier1LandingPage.clickVideoWidgetsSeeAllLinkInTier1();
    }

    @When("user clicks on the see all link of the vBooks widgets")
    public void userClicksOnTheSeeAllLinkOfTheVBooksWidgets() {
        for (int i = 0; i <= 2; i++) {
            if (isElementPresent(library.vBook_Diff_Publishers())) {
                break;
            } else {
                swipeDown();
            }

        }

        tier1LandingPage.clickVBookWidgetsSeeAllLinkInMyLibrary();
    }

    @And("user is navigated to the Tier {int} screen fo the vBooks widgets")
    public void userIsNavigatedToTheTierScreenFoTheVBooksWidgets(int arg0) {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVBookTier1Title()), true);
    }

    @And("user clicks on the see all link of the vBooks widgets in the tier{int} screen")
    public void userClicksOnTheSeeAllLinkOfTheVBooksWidgetsInTheTierScreen(int arg0) {
        tier1LandingPage.clickVBookWidgetsSeeAllLinkInTier1();
    }

    @Then("user should be able to view the titles in list format")
    public void user_should_be_able_to_view_the_titles_in_list_format() {
        Assert.assertEquals(isElementPresent(library.Tier1_listing_page()), true);
    }

    @Then("user should be able to see the refiner icon and click the refiner")
    public void user_should_be_able_to_see_the_refiner_icon_and_click_the_refiner() {
        Assert.assertEquals(isElementPresent(tier1LandingPage.RefineCTA()), true);
        tier1LandingPage.clickRefineCTA();
    }

    @When("user clicks on the see all link of the vBooks carousel")
    public void userClicksOnTheSeeAllLinkOfTheVBooksCarousel() {
        swipeDown();
        tier1LandingPage.clickVBookCarouselSeeAll();
    }

    @Then("user is navigated to the Tier {int} screen for the vBooks carousel")
    public void userIsNavigatedToTheTierScreenForTheVBooksCarousel(int arg0) {
        Assert.assertTrue(tier1LandingPage.tier1Heading().isDisplayed());
    }

    @When("user clicks on the see all link of the video carousel")
    public void userClicksOnTheSeeAllLinkOfTheVideoCarousel() {
        swipeDown();
        tier1LandingPage.clickVideoCarouselSeeAll();

    }

    @Then("user is navigated to the Tier {int} screen fo the video carousel")
    public void userIsNavigatedToTheTierScreenFoTheVideoCarousel(int arg0) {
        isElementPresent(tier1LandingPage.getFirstVideo());
        Assert.assertTrue(isElementPresent(tier1LandingPage.checkCategoryVideoTier2Title()));
    }

    @And("user should be able to see the refiner icon")
    public void userShouldBeAbleToSeeTheRefinerIcon() {
        tier1LandingPage.clickRefine();
    }

    @And("user tap All Videos carousal See All cta from Checkers Library Tv tier{int} page")
    public void userTapAllVideosCarousalSeeAllCtaFromCheckersLibraryTvTierPage(int arg0) {
        Assert.assertTrue(isElementPresent(tier1LandingPage.checkFeaturedVideoTier2Title()));
        tier1LandingPage.clickallVideosSeeAll();
    }

    @And("user should be redirected to All Videos tier{int} pages")
    public void userShouldBeRedirectedToAllVideosTierPages(int arg0) {
        Assert.assertTrue(isElementPresent(tier1LandingPage.checkFeaturedVBookTier2Title()));
    }

    @And("user tap on All Videobooks carousal See All cta from Videobooks tier{int} page")
    public void userTapOnAllVideobooksCarousalSeeAllCtaFromVideobooksTierPage(int arg0) {
        Assert.assertTrue(isElementPresent(tier1LandingPage.checkFeaturedVideoTier2Title()));
        tier1LandingPage.clickAllVideobooksSeeAll();

    }

    @And("user should be redirected to All Videobooks tier{int} pages")
    public void userShouldBeRedirectedToAllVideobooksTierPages(int arg0) {
        Assert.assertTrue(isElementPresent(tier1LandingPage.checkFeaturedVBookTier2Title()));
    }

    @And("user should tap on popular video carousal See All from tier{int} page")
    public void userShouldTapOnPopularVideoCarousalSeeAllFromTierPage(int arg0) {
        tier1LandingPage.clickPopularVideosSeeAll();
    }

    @Given("user should select the any video in popular Videos carousal")
    public void userShouldSelectTheAnyVideoInPopularVideosCarousal() {
        tier1LandingPage.clickVideosTitle();
    }

    @And("user click on the featured see all of checkers library")
    public void userClickOnTheFeaturedSeeAllOfCheckersLibrary() {
        Assert.assertTrue(isElementPresent(tier1LandingPage.FeaturedSeeAll()));
        tier1LandingPage.clickSeeall();
    }

    @And("user clicks on the featured see all of videbooks carousel")
    public void userClicksOnTheFeaturedSeeAllOfVidebooksCarousel() {
        Assert.assertTrue(isElementPresent(tier1LandingPage.FeaturedSeeAll()));
        tier1LandingPage.clickSeeall();
    }
}
