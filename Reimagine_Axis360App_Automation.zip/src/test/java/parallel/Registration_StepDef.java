package parallel;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.ProfilePage;
import pom.kidszone.RegisterScreen;
import pom.kidszone.SearchPage;
import pom.kidszone.SetParentPin;

public class Registration_StepDef extends CommonActions {

    RegisterScreen register = new RegisterScreen(DriverManager.getDriver());
    LoginPage login = new LoginPage(DriverManager.getDriver());
    ProfilePage profile = new ProfilePage(DriverManager.getDriver());
    SetParentPin setPin = new SetParentPin(DriverManager.getDriver());
    SearchPage search = new SearchPage(DriverManager.getDriver());

    @When("user enters the prefix {string} and pin {string} shared by the client")
    public void user_enters_the_prefix_something_and_pin_something_shared_by_the_client(String prefix, String pin)
            throws Throwable {
        register.enterPrefixandpin(prefix, pin);
       // login.handleNothankspopup();
    }

    @And("user enters the prefix {string} login")
    public void user_enters_the_prefix(String libraryid) throws Throwable {
        register.enterPrefixLogin(libraryid);
    }

    @Then("system should redirect to the registration screen")
    public void system_should_redirect_to_the_registration_screen() throws Throwable {
        WaitForMobileElement(register.getRegister_lbl());
        Assert.assertEquals(register.getRegister_lbl().isDisplayed(), true);
    }

    @And("user clicks on new user CTA in sign in screen")
    public void userClicksOnNewUserCTAInSignInScreen() {
        register.clickNewUserLink();
    }

    @And("user enters the  {string} and click on register button")
    public void userEntersTheAndClickOnRegisterButton(String newpassword) {
        register.enterpassword(newpassword);
        register.clickRegisterButton();
    }

    @And("user should be able to view registration screen with library card id,Security Question,Security Answer,Display Name and Email Address fields")
    public void userShouldBeAbleToViewRegistrationScreenWithLibraryCardIdSecurityQuestionSecurityAnswerDisplayNameAndEmailAddressFields() {
        Assert.assertEquals(register.checkCardNumberField().isDisplayed(),true);
        Assert.assertEquals(register.checkSecurityQuestionField().isDisplayed(),true);
        Assert.assertEquals(register.checkSecurityAnswerField().isDisplayed(),true);
        Assert.assertEquals(register.checkDisplayNameField().isDisplayed(),true);
        Assert.assertEquals(register.checkEmailField().isDisplayed(),true);
        Assert.assertEquals(isElementPresent(register.checkAdultInRegScreen()),false);
        Assert.assertEquals(isElementPresent(register.checkTeenInRegScreen()),false);
        Assert.assertEquals(isElementPresent(register.checkKidInRegScreen()),false);
    }

    @And("user should be able to view registration screen with library card id,Pin,Security Question,Security Answer,Display Name and Email Address fields")
    public void userShouldBeAbleToViewRegistrationScreenWithLibraryCardIdPinSecurityQuestionSecurityAnswerDisplayNameAndEmailAddressFields() {
        Assert.assertEquals(register.checkCardNumberField().isDisplayed(),true);
        Assert.assertEquals(register.checkPinField().isDisplayed(),true);
        Assert.assertEquals(register.checkSecurityQuestionField().isDisplayed(),true);
        Assert.assertEquals(register.checkSecurityAnswerField().isDisplayed(),true);
        Assert.assertEquals(register.checkDisplayNameField().isDisplayed(),true);
        Assert.assertEquals(register.checkEmailField().isDisplayed(),true);
        Assert.assertEquals(isElementPresent(register.checkAdultInRegScreen()),false);
        Assert.assertEquals(isElementPresent(register.checkTeenInRegScreen()),false);
        Assert.assertEquals(isElementPresent(register.checkKidInRegScreen()),false);
    }

    @When("user submitting the registation form with SecurityAnswer field value and display name field is left blank")
    public void userSubmittingTheRegistationFormWithSecurityAnswerFieldValueAndDisplayNameFieldIsLeftBlank() {
        waitFor(5000);
        register.selectSecurityQuestion();
        register.enterEmailFieldValue();
        register.completeRegistration();
    }

    @Then("user should be navigated to profile landing screen and able to view the Admin, Teen and Kid profiles created by default")
    public void userShouldBeNavigatedToProfileLandingScreenAndAbleToViewTheAdminTeenAndKidProfilesCreatedByDefault() {
        Assert.assertEquals(isElementPresent(register.checkProfilelandingScreen()),true);
        Assert.assertEquals(isElementPresent(register.checkAdultProfile()),true); 
        Assert.assertEquals(isElementPresent(register.checkTeenProfile1()),true);
        Assert.assertEquals(isElementPresent(register.checkKidProfile1()),true);
    }

    @And("user should be able to view Teen profile with Teen as the Title name")
    public void userShouldBeAbleToViewTeenProfileWithTeenAsTheTitleName() {
        Assert.assertEquals(isElementPresent(register.checkTeenProfile1()),true);
        Assert.assertEquals(isElementPresent(register.checkTeenProfile1DisplayName()),true);
    }

    @And("user should be able to view Kid profile with Kid as the Title name")
    public void userShouldBeAbleToViewKidProfileWithKidAsTheTitleName() {
        Assert.assertEquals(isElementPresent(register.checkKidProfile1()),true);
        Assert.assertEquals(isElementPresent(register.checkKidProfile1DisplayName()),true);
    }

    @And("user should be able to view Admin value in the Name field")
    public void userShouldBeAbleToViewAdminValueInTheNameField() {
        Assert.assertEquals(register.checkAdminValue(),true);
        Assert.assertEquals(isElementPresent(register.checkAdultProfile()),true);
    }

    @And("user clicks on + icon")
    public void userClicksOnIcon() {
        register.addProfileCta();
    }

    @Then("user views the profile creation page with options {string}")
    public void user_views_the_profile_creation_page_with_options_something(String profileType) throws Throwable {
        register.selectProfile(profileType);
//        register.selectAvatar();
    }

    @And("user enters the teen profile details like displayname {string} and email and select avatar optional")
    public void user_enters_the_teen_profile_details_like_display_namemandatoryemailoptionalselect_avataroptional(
            String displayname) throws Throwable {
        register.setDisplayName(displayname);
        register.clickSaveButton();
//        register.clickDonebutton();
    }

    @And("user enters the kid profile details like displayname {string} and email and select avatar optional")
    public void userEntersTheKidProfileDetailsLikeDisplaynameAndEmailAndSelectAvatarOptional(String displayname) {
        register.setDisplayName(displayname);
        register.clickSaveButton();
//        register.clickDonebutton();
//        register.clickProfileConfirmationPopup();
    }

    @And("user should be see the fourth profile in the profile screen")
    public void userShouldBeSeeTheFourthProfileInTheProfileScreen() {
    	waitFor(4000);
        Assert.assertEquals(isElementPresent(register.checkTeenProfile2()),true);
    }

    @And("user should not able to see + icon after fifth profile creation in profile screen")
    public void userShouldNotAbleToSeeIconAfterFifthProfileCreationInProfileScreen() {
        Assert.assertEquals(isElementPresent(register.checkProfileCta()),false);
    }

    @When("user submitting the registration form with {string} field and email field value")
    public void userSubmittingTheRegistrationFormWithFieldAndEmailFieldValue(String displayName) {
        waitFor(4000);
        register.selectSecurityQuestion();
        register.enterDisplayNameValue(displayName);
        register.enterEmailFieldValue();
        register.completeRegistration();
        waitFor(2000);
//        login.handleNothankspopup();
    }

    @And("user should be able to view {string} value in the Name field")
    public void userShouldBeAbleToViewTesterValueInTheNameField(String DisplayName) {
    	waitFor(2000);
        Assert.assertEquals(register.checkAdultProfileWithDisplayName(DisplayName),true);
    }

    @When("user submitting the registation form withn SecurityAnswer and PIN field value and display name field is left blank")
    public void userSubmittingTheRegistationFormWithnSecurityAnswerAndPINFieldValueAndDisplayNameFieldIsLeftBlank() {
        register.enterPin();
        register.selectSecurityQuestion();
        register.enterEmailFieldValue();
        register.completeRegistration();
    }

    @When("user submitting the registation form with {string} SecurityAnswer and PIN field value")
    public void userSubmittingTheRegistationFormWithSecurityAnswerAndPINFieldValue(String displayName) {
        register.enterPin();
        register.selectSecurityQuestion();
        register.enterDisplayNameValue(displayName);
        register.enterEmailFieldValue();
        register.completeRegistration();
    }

    @When("user submitting the registation form with {string} SecurityAnswer and Password field value and display name field is left blank")
    public void userSubmittingTheRegistationFormWithSecurityAnswerAndPasswordFieldValueAndDisplayNameFieldIsLeftBlank(String username) {
        register.enterCardNumber(username);
        register.enterPin();
        register.selectSecurityQuestion();
        register.enterEmailFieldValue();
        register.completeRegistration();
    }

    @When("user submitting the registation form with {string} SecurityAnswer Password and {string} field value")
    public void userSubmittingTheRegistationFormWithSecurityAnswerPasswordAndFieldValue(String username, String DisplayName) {
        register.enterCardNumber(username);
        register.enterPin();
        register.selectSecurityQuestion();
        register.enterDisplayNameValue(DisplayName);
        register.enterEmailFieldValue();
        register.completeRegistration();
    }

    @Then("user should be able to view profile image at center position")
    public void userShouldBeAbleToViewProfileImageAtCenterPosition() {
        logger.info("Profile UI Validation");
    }

    @And("user should be able to view manage profile CTA at the bottom of the profiles")
    public void userShouldBeAbleToViewManageProfileCTAAtTheBottomOfTheProfiles() {
        logger.info("Profile UI Validation");
    }

    @And("user should be able to view Profiles title left aligned")
    public void userShouldBeAbleToViewProfilesTitleLeftAligned() {
        logger.info("Profile UI Validation");
    }

    @And("user should able to view equidistance between each profile icons")
    public void userShouldAbleToViewEquidistanceBetweenEachProfileIcons() {
        logger.info("Profile UI Validation");
    }

    @And("user should not able to view + icon in profile screen")
    public void userShouldNotAbleToViewIconInProfileScreen() {
        Assert.assertEquals(isElementPresent(register.checkProfileCta()),false);
    }

    @And("user should be able to view profile icons wrap based on the breakpoint")
    public void userShouldBeAbleToViewProfileIconsWrapBasedOnTheBreakpoint() {
        logger.info("Profile UI Validation");
    }

    @And("user should be able to view only one profile selected at a time")
    public void userShouldBeAbleToViewOnlyOneProfileSelectedAtATime() {
        logger.info("Profile UI Validation");
    }

    @And("User should be able to view Profiles Limit Reached text")
    public void userShouldBeAbleToViewProfilesLimitReachedText() {
        Assert.assertEquals(register.checkProfileLimitHeadertext(),"");
        Assert.assertEquals(register.checkProfileLimitMessage(),"");
    }

    @And("user navigate to adult my profile screen")
    public void userNavigateToAdultMyProfileScreen() {
    	waitFor(2000);
        register.adultprofileSelection();
        login.handleNothankspopup();
    }

    @And("user should be able to view Enable Profile PIN as optional and not mandatory for all three profiles")
    public void userShouldBeAbleToViewEnableProfilePINAsOptionalAndNotMandatoryForAllThreeProfiles() {        
    	waitFor(3000);
        swipeDown();
        swipeDown();
        swipeDown();
        register.clickEnablePinAllProfiles();
        Assert.assertEquals(isElementPresent(register.verifyEnableProfilePinText()),true);
        Assert.assertEquals(isElementPresent(register.checkProfilePinIsDisabled()),true);
    }

    @And("user navigates to Adult profile screen")
    public void userNavigatesToAdultProfileScreen() {
        waitFor(3000);
        register.clickEditOption();
        waitFor(4000);
        register.adultprofileSelection();
    }

    @And("user clicks on the enable profile pin option")
    public void userClicksOnTheEnableProfilePinOption() {
        waitFor(1000);
        register.clickDisabledProfilePin();
    }

    @And("system to check if the security question AND email is set up, if YES, then user should be able to Enable Profile PIN")
    public void systemToCheckIfTheSecurityQuestionANDEmailIsSetUpIfYESThenUserShouldBeAbleToEnableProfilePIN() {
        Assert.assertEquals(isElementPresent(register.verifyParentalPinSetupText()),true);
    }

    @And("user should be able to be redirected to a screen where they can set a Four digit {string} Parental PIN")
    public void userShouldBeAbleToBeRedirectedToAScreenWhereTheyCanSetAFourDigitParentalPIN(String ParentPin) {
        register.enterParentPin(ParentPin);
    }

    @And("system should redirect the user to PIN Confirmation page and ask the user to enter wrong pin {string}")
    public void systemShouldRedirectTheUserToPINConfirmationPageAndAskTheUserToEnterWhetherTheMatchesWithTheAlreadyEnteredPIN(String wrongpin) {
        Assert.assertEquals(isElementPresent(register.verifyConfirmPinSetupText()),true);
        register.enterConfirmPin(wrongpin);
    }

    @And("system should throw error message if the PIN doesn't match")
    public void systemShouldThrowErrorMessageIfThePINDoesnTMatch() {
//        Assert.assertEquals(register.verifyWrongPinMessage(),"PIN FAILED");
    }

    @And("user should be able to click on browser back button to navigate back to previous screen to re-enter the {string} PIN again")
    public void userShouldBeAbleToClickOnBrowserBackButtonToNavigateBackToPreviousScreenToReEnterThePINAgain(String correctpin) {
        waitFor(2000);
        register.clickBackIcon();
        setPin.setParentPin();
//        register.enterConfirmPin(correctpin);
//        Assert.assertEquals(isElementPresent(register.verifySuccessPinSetupMessage()),true);
    }

    @And("user should be able to edit email at a later time once PIN is set but can't leave it blank")
    public void userShouldBeAbleToEditEmailAtALaterTimeOncePINIsSetButCanTLeaveItBlank() {
        swipeUp();
        waitFor(1000);
        swipeUp();
        waitFor(1000);
        register.clearEmailValue();
        register.clearEmailValue();
        waitFor(1000);
        swipeDown();
        waitFor(1000);
        swipeDown();
        waitFor(1000);
        swipeDown();
        Assert.assertEquals(register.saveInPrfileSreen().isEnabled(),false);
    }

    @And("Automatically Check out Titles on Hold once they become available button should have info icon with tooltip")
    public void automaticallyCheckOutTitlesOnHoldOnceTheyBecomeAvailableButtonShouldHaveInfoIconWithTooltip() {
        waitFor(1000);
        swipeDown();
        waitFor(1000);
        swipeDown();
        Assert.assertEquals(isElementPresent(register.verifyAdultCheckoutToolTipIcon()),true);
        register.clickAdultCheckoutToolTipIcon();
        Assert.assertEquals(register.verifyAdultCheckoutToolTipText(),"Only the Admin Profile can enable or disable automatic checkouts. All profiles under your barcode will inherit this setting.");
        register.clickDismissOptionInCheckout();
    }

    @And("Automatically Check out Titles on Hold once they become available Option should be Editable for the Adult profile")
    public void automaticallyCheckOutTitlesOnHoldOnceTheyBecomeAvailableOptionShouldBeEditableForTheAdultProfile() {
        register.scrollToSaveButton();
        Assert.assertEquals(register.saveInPrfileSreen().isEnabled(),false);
        register.clickCheckoutHoldCheckbox();
     //   Assert.assertEquals(register.saveInPrfileSreen().isEnabled(),true);
    }

    @When("user submitting the registration form with {string} field and without email field value")
    public void userSubmittingTheRegistrationFormWithFieldAndWithoutEmailFieldValue(String displayName) {
        register.selectSecurityQuestion();
        register.enterDisplayNameValue(displayName);
        waitFor(2000);
        register.completeRegistration();
        waitFor(4000);
        login.handleNothankspopup();
    }

    @And("user should be able to view a prompt to add mandatory data I.e. Email and Security question before they can set a PIN")
    public void userShouldBeAbleToViewAPromptToAddMandatoryDataIEEmailAndSecurityQuestionBeforeTheyCanSetAPIN() {
        Assert.assertEquals(register.checkEmailVerificationPopup(),"Can’t Enable PIN - Action Required by Admin");
        register.clickDismissOptionInCheckout();
    }

    @And("user enter value in email {string} field")
    public void userEnterValueInEmailField(String email) {
        register.enterEmailValue(email);
    }

    @And("user tap on the save cta and system should displays the success prompt toast message")
    public void userTapOnTheSaveCtaAndSystemShouldDisplaysTheSuccessPromptToastMessage() {
        hideMobileKeyboard();
        swipeDown();
        swipeDown();
        swipeDown();
        waitFor(4000);
        register.saveInPrfileSreen().click();
        waitFor(4000);
        try {
        Alert alert = DriverManager.getDriver().switchTo().alert();
        alert.accept();
    } catch (NoAlertPresentException e) {
        System.out.println("No alert present");
    }

        register.saveInPrfileSreen().click();
//        register.clickSaveButton();
        logger.info("Save button clicked");
//        waitFor(3000);
//        Assert.assertEquals(isElementPresent(register.success_Toast_Msg()),true);
    }

    @And("user navigate to the teen my profile screen")
    public void userNavigateToTheTeenMyProfileScreen() {
        register.teenprofileSelection();
        login.handleNothankspopup();
    }

    @And("user switches to the Adult my profile screen")
    public void userSwitchesToTheAdultMyProfileScreen() {
        register.clickCloseButton();
//        login.clickFooterMenu();
//        login.clickMenuprofile();
        register.clickEditOption();
        register.adultprofileSelection();
//        login.handleNothankspopup();
    }

    @And("user switches to the teen my profile screen")
    public void userSwitchesToTheTeenMyProfileScreen() {
        waitFor(4000);
        register.clickCloseButton();
//        login.clickFooterMenu();
//        login.clickMenuprofile();
        register.clickEditOption();
        register.teenprofileSelection();
//        login.handleNothankspopup();
    }

    @And("user navigates to the Kid profile my screen")
    public void userNavigatesToTheKidProfileMyScreen() {
        register.kidprofileSelection();
        login.handleNothankspopup();
    }

    @And("user switches to the kid my profile screen")
    public void userSwitchesToTheKidMyProfileScreen() {
        register.clickCloseButton();
//        login.clickFooterMenu();
//        login.clickMenuprofile();
        register.clickEditOption();
        register.kidprofileSelection();
//        login.handleNothankspopup();
    }

    @Then("user should be able to disable an already set pin by clicking on the disable pin cta in the profile details screen")
    public void userShouldBeAbleToDisableAnAlreadySetPinByClickingOnTheDisablePinCtaInTheProfileDetailsScreen() {
    	waitFor(2000);
        register.clickEnabledPin();
    }

    @And("user provides the {string} in pin field")
    public void userProvidesTheInPinField(String pin) {
        register.enterConfirmPin(pin);
    }

    @And("user should displayed with error message and restricted from moving forward")
    public void userShouldDisplayedWithErrorMessageAndRestrictedFromMovingForward() {
        Assert.assertEquals(register.disablePinConfirmationPopupText.isDisplayed(),false);
    }

    @And("user is able to view confirmation popup")
    public void userIsAbleToViewConfirmationPopupAreYouSureYouWantToDisablePINForThisProfile() {
    	waitFor(2000);
        Assert.assertEquals(register.checkDisablePinConfirmationPopupText(),"Are you sure you want to disable PIN for this profile?");
    }

    @And("user clicks on Cancel button in the popup")
    public void userClicksOnCancelButtonInThePopup() {
        register.clickCancelInDisablePopup();
    }

    @And("user should dismiss from the disabling action")
    public void userShouldDismissFromTheDisablingAction() {
    	Assert.assertEquals(isElementPresent(register.enablePin),true);
    }

    @And("user clicks on yes button in the popup")
    public void userClicksOnYesButtonInThePopup() {
        register.clickYesInDisablePopup();
    }

    @And("user is able to verify success message - PIN has been successfully Disabled. regarding pin disable statement")
    public void userIsAbleToVerifySuccessMessagePINHasBeenSuccessfullyDisabledRegardingPinDisableStatement() {
//        Assert.assertEquals(isElementPresent(register.pinDisableText),true);
    	logger.info("Success message shown");
    }

    @And("user needs to be navigated to profile details screen")
    public void user_needs_to_be_navigated_to_profile_details_screen() throws Throwable {
       Assert.assertEquals(isElementPresent(register.getProfiles_title()), true);
    }
    
    @And("user needs to be navigated to profile details screen for Teen")
    public void user_needs_to_be_navigated_to_profile_details_screen_for_Teen() throws Throwable {
    	profile.clickEditPenIcon_FirstTeen();
    }

    @And("user update the details in the {string} field in profile screen")
    public void user_update_the_details_in_the_something_field_in_profile_screen(String dispalyname) throws Throwable {
    	waitFor(2000);
    	swipeUp();
       register.edit_displayName(dispalyname);
       hideMobileKeyboard();
    }

    @And("user save the updated details successfully")
    public void user_save_the_updated_details_successfully() throws Throwable {
       register.clickSaveButton();
       logger.info("Save button clicked");
    }

    @When("user taps on any of the title")
    public void user_taps_on_any_of_the_title() throws Throwable {
    	register.ClickTitle();
    }

    @Then("user should not able to view the alternate tab section as carosuel in details page for adult user with axis360 subscription")
    public void user_should_not_able_to_view_the_alternate_tab_section_as_carosuel_in_details_page_for_adult_user_with_axis360_subscription() throws Throwable {
    	search.clickTitleCover();
    	waitFor(1000);
		swipeDown();
		swipeDown();
    	Assert.assertEquals(isElementPresent(register.alsoAvailable()),false);
    }

    @And("user is in the my library homescreen")
    public void user_is_in_the_my_library_homescreen() throws Throwable {
    	Assert.assertEquals(isElementPresent(register.MyLibraryHomeScreen()),true);
    }
    
    @Then("user should be able to view the alternate tab section as carosuel in details page for adult user with kidszone subscription")
    public void user_should_be_able_to_view_the_alternate_tab_section_as_carosuel_in_details_page_for_adult_user_with_kidszone_subscription() throws Throwable {    	
		search.clickTitleCover();
		for(int i = 0;i<=5;i++) {
			if(isElementPresent(search.btn_RelatedItems)) {
				break;
			}
			else {
				swipeDown();
			}
		}
		Assert.assertEquals(isElementPresent(search.btn_RelatedItems), true);
    }

    @And("user should be able to view 'Also Available' that are available for the same title")
    public void user_should_be_able_to_view_alternate_format_that_are_available_for_the_same_title() throws Throwable {
    	waitFor(2000);
    	search.relatedItems().click();
    	Assert.assertEquals(isElementPresent(register.alsoAvailable()),true);
    }

    @And("user should be able to view each available 'Also Available' as title card")
    public void user_should_be_able_to_view_each_available_alternate_format_as_title_card() throws Throwable {
    	Assert.assertEquals(isElementPresent(register.alsoAvailable()),true);
    }
    
    @Then("user should not able to view the profile selection in the registration screen")
    public void user_should_not_able_to_view_the_profile_selection_in_the_registration_screen() throws Throwable {
    	Assert.assertEquals(isElementPresent(register.profile_Selection_Registration()),false);
    }

    @And("user should be able to view registration screen with 'library card id' 'Security Question' 'Security Answer' 'Display Name' and 'Email Address' fields")
    public void user_should_be_able_to_view_registration_screen_with_library_card_id_security_question_security_answer_display_name_and_email_address_fields() throws Throwable {
    	Assert.assertEquals(isElementPresent(register.get_Library_Card_Id()),true);
    	Assert.assertEquals(isElementPresent(register.get_Security_Question()),true);
    	Assert.assertEquals(isElementPresent(register.get_Security_Answer()),true);
    	Assert.assertEquals(isElementPresent(register.get_Display_Name()),true);
    }
    
    @And("user should be able to view registration screen with 'library card id' 'Pin' 'Security Question' 'Security Answer' 'Display Name' and 'Email Address' fields")
    public void user_should_be_able_to_view_registration_screen_with_library_card_id_pin_security_question_security_answer_display_name_and_email_address_fields() throws Throwable {
    	Assert.assertEquals(isElementPresent(register.get_Library_Card_Id()),true);
    	Assert.assertEquals(isElementPresent(register.get_Login_Pin()),true);
    	Assert.assertEquals(isElementPresent(register.get_Security_Question()),true);
    	Assert.assertEquals(isElementPresent(register.get_Security_Answer()),true);
    	Assert.assertEquals(isElementPresent(register.get_Display_Name()),true);
    }
    
    @And("user should be able to view registration screen with 'User name' 'Password' 'Security Question' 'Security Answer' 'Display Name' and 'Email Address' fields")
    public void user_should_be_able_to_view_registration_screen_with_user_name_password_security_question_security_answer_display_name_and_email_address_fields() throws Throwable {
    	Assert.assertEquals(isElementPresent(register.get_User_Name()),true);
    	Assert.assertEquals(isElementPresent(register.get_Login_Password()),true);
    	Assert.assertEquals(isElementPresent(register.get_Security_Question()),true);
    	Assert.assertEquals(isElementPresent(register.get_Security_Answer()),true);
    	Assert.assertEquals(isElementPresent(register.get_Display_Name()),true);
    }
    
    @And("user clicks on 'new user' CTA in sign in screen")
    public void user_clicks_on_new_user_cta_in_sign_in_screen() throws Throwable {
    	register.click_New_User();
    }
    
    @Given("user selects the profile icon in the static header")
    public void user_selects_the_profile_icon_in_the_static_header() throws Throwable {
    	login.handleNothankspopup();
    	register.click_Bottom_Menu();
    	profile.clickMenuProfile();
    }
    
    @Given("user selects the profile icon in the static header for profile details")
    public void user_selects_the_profile_icon_in_the_static_header_for_profile_details() throws Throwable {
    	login.handleNothankspopup();
    	register.click_Profile_Icon();
    }

    @When("user should be able to view profile screen")
    public void user_should_be_able_to_view_profile_screen() throws Throwable {
    	Assert.assertEquals(isElementPresent(register.checkProfilelandingScreen()),true); 
    }

    @Then("user click on edit button in the header")
    public void user_click_on_edit_button_in_the_header() throws Throwable {
    	register.click_Profile_Edit_Btn();
    }

    @And("user on clicking the profile edit icon for adult")
    public void user_on_clicking_the_profile_icon_for_adult() throws Throwable {
    	//register.select_Profile_Icon_Image();
    	//profile.clickEditPenIcon_FirstTeen();
    	profile.clickEditPenIcon_Adult();
    }

    
    @And("user needs to provide validpin in the pin screen")
    public void user_needs_to_provide_validpin_in_the_pin_screen() {
    	//register.enter_Valid_Pin(validpin);
    	setPin.parentPin();
    }
    
    @And("user needs to provide invalidpin in the pin screen")
    public void user_needs_to_provide_invalidpin_in_the_pin_screen() {
    	//register.enter_Valid_Pin(validpin);
    	setPin.invalidparentPin();
    }
    
    @Given("user clicks on Menu option in the bottom navigation bar")
    public void user_clicks_on_menu_option_in_the_bottom_navigation_bar() throws Throwable {
    	register.click_Bottom_Menu();
    }

    @And("user selects teen profile from the profile screen list")
    public void user_selects_teen_profile_from_the_profile_screen_list() throws Throwable {
    	register.select_Teen_Profile();
    }
    
    @And("user should be able to switch between the profiles by clicking on the particular profile")
    public void user_should_be_able_to_switch_between_the_profiles_by_clicking_on_the_particular_profile() throws Throwable {
//    	register.select_Teen();
//    	waitFor(2000);
//    	setPin.parentPin();
    	 logger.info("User should be able to switch between the profiles");
    }

    @And("user clicks on edit button in the header")
    public void user_clicks_on_edit_button_in_the_header() throws Throwable {
    	register.click_Profile_Edit_Btn(); 
    }


    @When("user submitting the registation form with {string} SecurityAnswer and Password field value and email field is left blank")
    public void userSubmittingTheRegistationFormWithSecurityAnswerAndPasswordFieldValueAndEmailFieldIsLeftBlank(String username) {
        register.enterCardNumber(username);
        register.enterPin();
        register.selectSecurityQuestion();
//        register.enterEmailFieldValue();
        register.completeRegistration();
    }

    @And("user navigates to Teen profile screen")
    public void userNavigatesToTeenProfileScreen() {
        waitFor(10000);
        register.clickEditOption();
        register.teenprofileSelection();
    }

    @Then("For Non Adult profile,Automatically Check out Titles on Hold once they become available button should have info icon with tooltip")
    public void forNonAdultProfileAutomaticallyCheckOutTitlesOnHoldOnceTheyBecomeAvailableButtonShouldHaveInfoIconWithTooltip() {
        waitFor(1000);
        swipeDown();
        waitFor(1000);
        swipeDown();
        Assert.assertEquals(isElementPresent(register.verifyAdultCheckoutToolTipIcon()),true);
        register.clickAdultCheckoutToolTipIcon();
        Assert.assertEquals(register.verifyCheckoutToolTipText(),"Automatic checkout settings are controlled in the Admin Profile.");
        register.clickDismissOptionInCheckout();
    }

    @And("Automatically Check out Titles on Hold once they become available Option should not be Editable for the other profile")
    public void automaticallyCheckOutTitlesOnHoldOnceTheyBecomeAvailableOptionShouldNotBeEditableForTheOtherProfile() {
        register.scrollToSaveButton();
        Assert.assertEquals(register.verifyCheckoutHoldCheckbox().isEnabled(),false);
    }

    @And("user navigates to Kid profile screen")
    public void userNavigatesToKidProfileScreen() {
        waitFor(10000);
        register.clickEditOption();
        register.kidprofileSelection();
    }

    @And("For Adult user,user should be able to view a prompt to add mandatory data I.e. Email and Security question before they can set a PIN")
    public void forAdultUserUserShouldBeAbleToViewAPromptToAddMandatoryDataIEEmailAndSecurityQuestionBeforeTheyCanSetAPIN() {
        Assert.assertEquals(register.checkEmailVerificationPopup(), "Please add your email address and security question to enable your PIN");
        register.clickDismissOptionInCheckout();
    }

    @Then("system should redirect the user to PIN Confirmation page and ask the user to re-enter correct pin")
    public void system_should_redirect_the_user_to_pin_confirmation_page_and_ask_the_user_to_re_enter_correct_pin() throws Throwable {
    	waitFor(2000);
    	setPin.parentPin();
//		register.pinSubmitBtn();
    }
    
    @And("For Teen user,user should be able to view a prompt to add mandatory data I.e. Email and Security question before they can set a PIN")
    public void forTeenUserUserShouldBeAbleToViewAPromptToAddMandatoryDataIEEmailAndSecurityQuestionBeforeTheyCanSetAPIN() {
        Assert.assertEquals(register.checkDisablePinConfirmationPopupText(), "Please add an email to enable your Profile PIN");
        register.clickDismissOptionInCheckout();
        swipeUp();
        register.teen_Same_Email_Adult().click();
        swipeDown();
        register.clickDisabledProfilePin();
    }
    
    @And("For teen user,user should be able to view a prompt to add mandatory data I.e. Email and Security question before they can set a PIN")
    public void forteenUserUserShouldBeAbleToViewAPromptToAddMandatoryDataIEEmailAndSecurityQuestionBeforeTheyCanSetAPIN() {
        Assert.assertEquals(register.checkDisablePinConfirmationPopupTextTeen(), "Please add an email to enable your Profile PIN");
        register.clickDismissOptionInCheckout();
        waitFor(1000);
        swipeUp();
//        register.teen_Same_Email_Adult().click();
//        swipeDown();
//        register.clickDisabledProfilePin();
    }

}
