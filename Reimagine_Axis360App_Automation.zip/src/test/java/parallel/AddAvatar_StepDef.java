package parallel;

import javax.swing.event.SwingPropertyChangeSupport;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.ProfileCreation;

public class AddAvatar_StepDef extends CommonActions{

	LoginPage login = new LoginPage(DriverManager.getDriver());
	ManageProfile manageProf = new ManageProfile(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(ViewLibraryNames_StepDef.class);

/******************************109597*********************************/
	
	@Then("user selects profile image from select avatar system displays the list of images added")
	public void user_selects_profile_image_from_select_avatar_system_displays_the_list_of_images_added() {
	   manageProf.updateAvatar();   
	}

	@Then("user clicks on the save button")
	public void user_clicks_on_the_save_button() {
	   manageProf.saveUpdatedAvatar();
	}
	
	@And("user click pen icon on the teen profile avatar")
    public void user_click_pen_icon_on_the_teen_profile_avatar() throws Throwable {
		manageProf.teenprofileSelection();
    }
	
	@And("user click pen icon on the kid profile avatar")
	public void user_click_pen_icon_on_the_kid_profile_avatar() throws Throwable {
		manageProf.kidprofileSelection();
	}
	
	@And("user selects the image")
    public void user_selects_the_image() throws Throwable {
        logger.info("User selected the avatar image from the list");
    }
	
}
