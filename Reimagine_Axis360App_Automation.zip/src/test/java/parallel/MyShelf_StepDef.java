package parallel;

import com.reusableMethods.CommonActions;
import io.appium.java_client.MobileElement;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.*;

import java.util.NoSuchElementException;

public class MyShelf_StepDef extends CommonActions {

    LoginPage login = new LoginPage(DriverManager.getDriver());
    public static final Logger logger = LoggerFactory.getLogger(MyShelf_StepDef.class);

    MyLibrary library = new MyLibrary(DriverManager.getDriver());

    ProfilePage profile = new ProfilePage(DriverManager.getDriver());
    Tier1_LandingPage_VBookandVideo tier1LandingPage = new Tier1_LandingPage_VBookandVideo(DriverManager.getDriver());
    Tier2_TitlelistPage_VBookandVideo tier2TitlelistPage = new Tier2_TitlelistPage_VBookandVideo(DriverManager.getDriver());
    SearchPage search = new SearchPage(DriverManager.getDriver());
    MyShelf myShelf = new MyShelf(DriverManager.getDriver());
    TitleDetails details = new TitleDetails(DriverManager.getDriver());

    @When("^user is able to tap on checkout cta from mystuff screen and navigate to checkedout screen$")
    public void user_is_able_tap_on_checkout_cta_from_mystuff_screen_and_navigate_to_checkedout_screen() throws Throwable {
        tier1LandingPage.clickMyShelf();
        waitFor(5000);
        tier1LandingPage.clickCheckout_CTA();
    }

    @Then("^user should be able to view the action cta for the video and vbooks titles$")
    public void user_should_be_able_to_view_the_action_cta_for_the_video_and_vbooks_titles() throws Throwable {
        tier1LandingPage.clickFilter_option();
        tier1LandingPage.clickVideos_option();
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkVideo_action_CTA()), true);
        tier1LandingPage.clickFilter_option();
        tier1LandingPage.clickvBook_option();
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkvBook_action_CTA()), true);
    }

    @And("^library should have subscription to video and vbooks third party and video and vbooks carousel enabled by library admin$")
    public void library_should_have_subscription_to_video_and_vbooks_third_party_and_video_and_vbooks_carousel_enabled_by_library_admin() throws Throwable {
        logger.info("Admin settings - video and vbooks");
    }

    @And("^system should display cta based on the title status$")
    public void system_should_display_cta_based_on_the_title_status() throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkvBook_action_CTA()), true);
        logger.info("Most of the checked out videos/ vbooks have the play cta");
    }

    @And("^user should be able to see the title checked out and not started watching the title$")
    public void user_should_be_able_to_see_the_title_checked_out_and_not_started_watching_the_title() throws Throwable {
        logger.info("video/ vbooks are in play status");
    }

    @And("^user should be able to see play as primary cta and return and renew are the secondary cta$")
    public void user_should_be_able_to_see_play_as_primary_cta_and_return_and_renew_are_the_secondary_cta() throws Throwable {
        Assert.assertEquals(isElementPresent(tier1LandingPage.checkvBook_action_CTA()), true);
    }

    @And("^user should be able to see the title checked out and started watching and exit without complete$")
    public void user_should_be_able_to_see_the_title_checked_out_and_started_watching_and_exit_without_complete() throws Throwable {
        tier1LandingPage.clickPlay_Video();

        tier1LandingPage.clickBack_Button();
    }

    @And("^user should be able to see resume as primary cta and return and renew are the secondary cta$")
    public void user_should_be_able_to_see_resume_as_primary_cta_and_return_and_renew_are_the_secondary_cta() throws Throwable {
        logger.info("see resume as primary cta and return and renew are the secondary cta");
    }

    @When("if user already saved some interest survey")
    public void if_user_already_saved_some_interest_survey() {
        login.readingInterestPopupback();
    }

    @When("user click on menu and select {string}")
    public void user_click_on_menu_and_select(String string) {
        tier1LandingPage.clickMyShelf();
    }

    @When("user click on {string} Cta in Based on interest carousal")
    public void user_click_on_cta_in_based_on_interest_carousal(String string) {
        waitFor(2000);
        myShelf.clickSeeAll();
//    	Assert.assertEquals(isElementPresent(myShelf.readingInterestSeeAll()),true);
//    	Assert.assertEquals(myShelf.readingInterestSeeAll().getText(),"see all");
//    	myShelf.readingInterestSeeAll().click();
    }

    @Then("verify navigate to title list screen")
    public void verify_naviagate_to_title_list_screen() {
        Assert.assertEquals(isElementPresent(myShelf.basedOnInterestTitle()), true);
    }

    @Then("user click on {string} cta navigate to interest survey screen")
    public void user_click_on_cta_navigate_to_interest_survey_screen(String string) {
        myShelf.clickEditPreferences();
        Assert.assertEquals(isElementPresent(login.readingInterestPopupHeading()), true);
    }

    @Then("user update the interest topic and click save cta")
    public void user_update_the_interest_topic_and_click_save_cta() {
        myShelf.clickReadingPreference();
        myShelf.clickReadingInterestSaveBTN();

    }

    @Then("user navigate to title list screen if interest topics have recommendation title")
    public void user_navigate_to_title_list_screen_if_interest_topics_have_recommendation_title() {
        Assert.assertEquals(isElementPresent(login.readingInterestPopupHeading()), true);
        profile.clickBack_Btn();
    }

    @Then("user update the interest topic and without save interest click on back")
    public void user_update_the_interest_topic_and_without_save_interest_click_on_back() {
        myShelf.clickReadingPreference();
        login.readingInterestPopupback();
        Assert.assertEquals(isElementPresent(login.readingInterestPopupHeading()), true);
    }

    @Then("user navigate to title list screen without change any title")
    public void user_navigate_to_title_list_screen_without_change_any_title() {
        logger.info("List displayed without any change");
    }

    @When("user clicks on the myshelf icon")
    public void user_clicks_on_the_myshelf_icon() {
        myShelf.clickMyShelf();
    }

    @When("user clicks on the checkouts pill")
    public void user_clicks_on_the_checkouts_pill() {
        myShelf.clickCheckout_CTA();
    }

    @Then("user clicks on the hold pill")
    public void user_clicks_on_the_hold_pill() {
        myShelf.clickmyShelfHoldBTN();
    }

    @Then("user clicks on the wishlist pill")
    public void user_clicks_on_the_wishlist_pill() {
        myShelf.clickwishlistBTN();
    }

    @Then("user clicks on the history pill")
    public void user_clicks_on_the_history_pill() {
        myShelf.clickrecommendation();
        myShelf.clickdownloadsBTN();
        myShelf.clickHistoryBTN();
    }

    @And("user clicks on the Recommendation pills")
    public void userClicksOnTheRecommendationPills() {
        myShelf.clickrecommendation();
        waitFor(3000);
    }

    @And("user clicks on the Download CTA")
    public void userClicksOnTheDownloadCTA() {
        myShelf.clickdownloadsBTN();
        waitFor(3000);
    }

    @And("user should be able to view the titles in my wishlist")
    public void userShouldBeAbleToViewTheTitlesInMyWishlist() {
        Assert.assertTrue(myShelf.getWishlistTitle().isDisplayed());
        myShelf.getWishlistTitle().click();
        logger.info("Title successfully added in wishlist");
    }

    @And("user removes the titles from checkouts screen")
    public void userRemovesTheTitlesFromCheckoutsScreen() {
        try {
            myShelf.clickCheckout();
            myShelf.tapCheckedOutTitles();
            myShelf.tapOnSecondaryCTA();
            myShelf.tapReturnTitle();
            myShelf.tapOK();
            logger.info("Titles removed from checkout");
        } catch (NoSuchElementException e) {
            logger.info("No titles in checkout");
        }
    }

    @And("user should able to add the titles back to wishlist")
    public void userShouldAbleToAddTheTitlesBackToWishlist() {
        try {
            myShelf.clickCheckout();
            myShelf.tapCheckedOutTitles();
            details.clickWishList();
            details.getBackButton().click();
            details.clickWishList();
            Assert.assertTrue(myShelf.getWishlistTitle().isDisplayed());
            logger.info("Title successfully added in back to wishlist from checkout");
        } catch (NoSuchElementException e) {
            logger.info("No Titles in checkout");
        }
    }

    @And("user removes the titles from checkouts screen and wishlist")
    public void userRemovesTheTitlesFromCheckoutsScreenAndWishlist() {
        try {
            myShelf.clickCheckout();
            myShelf.tapCheckedOutTitles();
            details.clickWishList();
            myShelf.tapOnSecondaryCTA();
            myShelf.tapReturnTitle();
            myShelf.tapOK();
            logger.info("Titles removed from checkout");
        } catch (NoSuchElementException e) {
            logger.info("No titles in checkout and wishlist");
        }

    }


    @And("user should be able to return the eBook title in checkout screen")
    public void xuserShouldBeAbleToReturnTheEBookTitleInCheckoutScreen() {
        try {
            myShelf.tapCheckedOutTitles();
            WaitForMobileElement(details.gettitleDetails_lbl_title());
            swipeDown();
            myShelf.tapOnSecondaryCTA();
            myShelf.returnEBook();
            myShelf.tapOK();
            details.getBackButton().click();
            Assert.assertTrue(isDisplayed(myShelf.getNo_titleFound()));
            logger.info("No titles in myshelf checkout ");
        } catch (AssertionError e) {
            logger.info("Titles are already available in checkout screen");
            e.printStackTrace();
        }

    }

    @And("user should be able to return eAudio the title in checkout screen")
    public void userShouldBeAbleToReturnEAudioTheTitleInCheckoutScreen() {
        try {
            myShelf.tapCheckedOutTitles();
            WaitForMobileElement(details.gettitleDetails_lbl_title());
            swipeDown();
            myShelf.tapOnSecondaryCTA();
            myShelf.returnEAudio();
            myShelf.tapOK();
            details.getBackButton().click();
            Assert.assertTrue(isDisplayed(myShelf.getNo_titleFound()));
            logger.info("No titles in myshelf checkout ");
        } catch (AssertionError e) {
            logger.info("Titles are already available in checkout screen");
            e.printStackTrace();
        }

    }

    @And("user verify the title count in myshelf checkout")
    public void userVerifyTheTitleCountInMyshelfCheckout() {
        WaitForMobileElement(myShelf.getCheckout_page());
        myShelf.clickCheckout();
        int pillsCount = myShelf.getCheckoutPillsCount();
        System.out.println(pillsCount);
        int titlesCount = myShelf.getCheckoutTitlesCount();
        System.out.println(titlesCount);
        Assert.assertEquals(pillsCount, titlesCount);
        logger.info("Checout pills and titles counts are equal");
    }

    @And("user should be able to return tha eBook title in title details screen")
    public void userShouldBeAbleToReturnThaEBookTitleInTitleDetailsScreen() {
        swipeDown();
        myShelf.tapOnSecondaryCTA();
        myShelf.returnEBook();
        myShelf.tapOK();
        WaitForMobileElement(details.getCheckoutCTA());
        Assert.assertTrue(details.getCheckoutCTA().isDisplayed());
        logger.info("eBook successfully returned");
    }

    @And("user should be able to return tha eAudio title in title details screen")
    public void userShouldBeAbleToReturnThaEAudioTitleInTitleDetailsScreen() {
        swipeDown();
        myShelf.tapOnSecondaryCTA();
        myShelf.returnEAudio();
        myShelf.tapOK();
        WaitForMobileElement(details.getCheckoutCTA());
        Assert.assertTrue(details.getCheckoutCTA().isDisplayed());
        logger.info("eBook successfully returned");
    }
}

