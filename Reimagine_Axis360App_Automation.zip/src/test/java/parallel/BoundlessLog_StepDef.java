package parallel;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.BoundlessLogo;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.ProfileCreation;


public class BoundlessLog_StepDef extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	LoginPage login = new LoginPage(DriverManager.getDriver());
	BoundlessLogo boundless = new BoundlessLogo(DriverManager.getDriver());
	ManageProfile manage =new ManageProfile(DriverManager.getDriver());

	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());

	TestDataReader testDataLoader = new TestDataReader();
	private Scenario scenario;
	TestReaderPOJO testData;
	
	@Before
    public void setup(Scenario scenario) {
        this.scenario = scenario;
    }
	
	@Given("user launches the application")
	public void user_launches_the_application() {
		Assert.assertEquals(login.getLogo_txt_Welcome().isDisplayed(), true);
	}

	@Given("user search and select the {string}")
	public void user_search_and_select_the(String libraryName) {
		login.searchLibrary(libraryName);
		login.initiateSearch();
		login.select_library();
		System.out.println("Library selected");

	}

	@Given("user navigates to landing screen and adult as an active user")
	public void user_navigates_to_landing_screen_and_adult_as_an_active_user() {
		login.handleNothankspopup();
		Assert.assertTrue(boundless.verifyLibraryHeader());
	}

	@Given("user clicks on menu from bottom navigation")
	public void user_clicks_on_menu_from_bottom_navigation() {
		login.clickFooterMenu();

	}

	@Given("user clicks on profile option from menu list")
	public void user_clicks_on_profile_option_from_menu_list() {
		Assert.assertTrue(boundless.clickProfiles());
	}

	@When("user lands on profiles list screen")
	public void user_lands_on_profiles_list_screen() {
		Assert.assertTrue(boundless.verifyProfilesHeader());
	}

	@Then("user should be able to view teen theme")
	public void user_should_be_able_to_view_teen_theme() {
		boundless.verifingTheme();

	}

	@Then("user should be able to view the boundless logo on profile list screen")
	public void user_should_be_able_to_view_the_boundless_logo_on_profile_list_screen() {
		if (System.getProperty("platform").equalsIgnoreCase("ioS")) {
			profile.clickBackbutton();
		}
		swipeDown();
		swipeDown();
		Assert.assertTrue(boundless.verifyboundlessLogo());
	}

	@Then("user logged out of the application")
	public void user_logged_out_of_the_application() {
		Assert.assertTrue(boundless.clickSignOutAndYesOption());
		Assert.assertTrue(boundless.clickSignOutPopUpYes());
		Assert.assertTrue(boundless.verifySingPage());
	}

	@Given("user clicks on login button after enters {string} and {string}")
	public void user_clicks_on_login_button_after_enters_and(String userName, String pin) {
		TestReaderPOJO testData = TestDataReader.getTestData(scenario, userName);
		login.enterUserName(testData.getLibraryId());
		login.enterPwd(testData.getPassword());
		login.clickSignInBtn();
	}
	
	@Given("user clicks on login button after enters {string}")
	public void user_clicks_on_login_button_after_enters(String libraryid) throws Exception {
		testData = TestDataReader.getTestData(scenario, libraryid);
		login.loginwithId(testData.getLibraryId());
//		login.loginwithId(libraryid);

	}

	@Then("user should be able to view existing axis application theme")
	public void user_should_be_able_to_view_existing_axis_application_theme() {
		boundless.infoExistingAxisApplicationTheme();
	}

	@Then("user should not be able to view the boundless logo for KidsZone and axis360 subscription on profiles list screen")
	public void user_should_not_be_able_to_view_the_boundless_logo_for_kids_zone_and_axis360_subscription_on_profiles_list_screen() {
		Assert.assertTrue(boundless.verifyboundlessLogo());
		boundless.infoBoundlessLogText();
	}

	@Then("user should be able to view current axis {int} logo")
	public void user_should_be_able_to_view_current_axis_logo(Integer int1) {
		Assert.assertTrue(boundless.verifyboundlessLogo());
		boundless.infoBoundlessLogText();
	}

	@Then("user should be able to view the boundless logo on profiles list screen")
	public void user_should_be_able_to_view_the_boundless_logo_on_profiles_list_screen() {
		swipeDown();
		swipeDown();
		Assert.assertTrue(boundless.verifyboundlessLogo());
	}

	@Then("user should be able to view kid theme")
	public void user_should_be_able_to_view_kid_theme() {

		boundless.verifingTheme();
	}

	@Then("user should click the tean profile")
	public void user_should_click_the_tean_profile() {
		Assert.assertTrue(boundless.clickTeenProfile());

	}

	@When("user should click the kid profile")
	public void user_should_click_the_kid_profile() {
		Assert.assertTrue(boundless.clickKidProfile());
	}

//	@Given("user navigates to landing screen")
//	public void user_navigates_to_landing_screen() {
//		login.handleNothankspopup();
//		if (System.getProperty("platform").equalsIgnoreCase("Android")) {
//			manage.adultprofileSelection();
//		}
//		login.handleNothankspopup();
//		Assert.assertTrue(boundless.verifyLibraryHeader());
//	}

	@Given("user clicks on plus option from profile manage screen")
	public void user_clicks_on_plus_option_from_profile_manage_screen() {
		Assert.assertTrue(boundless.clickProfliePulsIcon());

	}

	@When("user lands on select profile type screen")
	public void user_lands_on_select_profile_type_screen() {
		Assert.assertTrue(boundless.verifyAddProfileScreen());

	}

	@Then("user should be able to view the boundless logo for KidsZone application on select profile type screen")
	public void user_should_be_able_to_view_the_boundless_logo_for_kids_zone_application_on_select_profile_type_screen() {
		Assert.assertTrue(boundless.verifyboundlessLogo());
	}

	@Then("user click on back button from add a profile screen")
	public void user_click_on_back_button_from_add_a_profile_screen() {
		Assert.assertTrue(boundless.clickBackButtonfromAddProfile());
	}

	@Then("user should not be able to view the boundless logo for KidsZone application on select profile type screen")
	public void user_should_not_be_able_to_view_the_boundless_logo_for_kids_zone_application_on_select_profile_type_screen() {
		Assert.assertTrue(boundless.verifyboundlessLogo());
		boundless.infoBoundlessLogText();
	}

	@Given("user navigates to landing screen and adult as active user")
	public void user_navigates_to_landing_screen_and_adult_as_active_user() {
		login.handleNothankspopup();
		Assert.assertTrue(boundless.verifyLibraryHeader());
	}

	@Given("user navigates to manage profile screen and select teen profile")
	public void user_navigates_to_manage_profile_screen_and_select_teen_profile() {
		login.clickFooterMenu();
		Assert.assertTrue(boundless.clickProfiles());
		Assert.assertTrue(boundless.clickTeenProfile());
	}

	@Given("user navigates to manage profile screen and select kid profile")
	public void user_navigates_to_manage_profile_screen_and_select_kid_profile() {
		login.clickFooterMenu();
		Assert.assertTrue(boundless.clickProfiles());
		Assert.assertTrue(boundless.clickKidProfile());
	}

	@Given("user clicks on menu option from bottom navigation")
	public void user_clicks_on_menu_option_from_bottom_navigation() {
		login.clickFooterMenu();

	}

	@When("user lands on menu drawer")
	public void user_lands_on_menu_drawer() {
		Assert.assertTrue(boundless.verifyAddMenuScreen());
	}

	@Then("user User should be able to view the boundless logo for KidsZone application on menu drawer")
	public void user_user_should_be_able_to_view_the_boundless_logo_for_kids_zone_application_on_menu_drawer() {
		Assert.assertTrue(boundless.verifyboundlessLogo());
	}

	@Then("user User should be able to view the no boundless logo for KidsZone application on menu drawer")
	public void user_user_should_be_able_to_view_the_no_boundless_logo_for_kids_zone_application_on_menu_drawer() {
	//	Assert.assertFalse(boundless.verifyboundlessLogo());
		Assert.assertEquals(boundless.verifyboundlessLogo(),false);
	}

	@Then("user clicks on back button from profiles screen")
	public void user_clicks_on_back_button_from_profiles_screen() {
		Assert.assertTrue(boundless.clickBacktoMenu());
	}

//	@Given("user click on login button after user enter {string}")
//	public void user_click_on_login_button_after_user_enter(String libId) {
//		Assert.assertTrue(boundless.enterLibraryId(libId));
//		hideMobileKeyboard();
//		Assert.assertTrue(boundless.clickLogInBtn());
//	}
	
	
}
