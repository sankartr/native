package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Holds;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelf;
import pom.kidszone.ProfileCreation;

public class MySelfScreen_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	MyShelf myshelf = new MyShelf(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	ManageProfile manage = new ManageProfile(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	Holds holds = new Holds(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(ViewLibraryNames_StepDef.class);

	@When("user lands on my shelf screen")
	public void user_lands_on_my_shelf_screen() throws Throwable {
		login.handleNothankspopup();
		myshelf.clickMyself();
		Assert.assertEquals(myshelf.getMyShelf_lbl_footer().isDisplayed(), true);
	}

	@Then("user should be able to view quick navigation cta for checkouts")
	public void user_should_be_able_to_view_quick_navigation_cta_for_checkouts() throws Throwable {
		Assert.assertEquals(myshelf.getMyShelf_btn_checkout().isDisplayed(), true);
	}

	@And("user should be able to click on checkout and navigate to checkout screen")
	public void user_should_be_able_to_click_on_checkout_and_navigate_to_checkout_screen() throws Throwable {
		myshelf.clickCheckout();
		Assert.assertEquals(myshelf.getMyShelf_lbl_checkout().isDisplayed(), true);
	}

	@Then("user should be able to view quick navigation cta for holds")
	public void user_should_be_able_to_view_quick_navigation_cta_for_holds() throws Throwable {
		Assert.assertEquals(myshelf.getMyShelf_btn_hold().isDisplayed(), true);
	}

	@Then("user should be able to view quick navigation cta for wishlist")
	public void user_should_be_able_to_view_quick_navigation_cta_for_wishlist() throws Throwable {
		Assert.assertEquals(myshelf.getMyShelf_btn_wishlist().isDisplayed(), true);
	}

	@And("user should be able to click on holds and navigate to holds screen")
	public void user_should_be_able_to_click_on_holds_and_navigate_to_holds_screen() throws Throwable {
		myshelf.clickholds();
		Assert.assertEquals(myshelf.getMyShelf_lbl_hold().isDisplayed(), true);
	}

	@And("user should be able to click on wishlist and navigate to wishlist screen")
	public void user_should_be_able_to_click_on_wishlist_and_navigate_to_wishlist_screen() throws Throwable {
		myshelf.clickwishlist();
	}

	@When("user navigates to user profile preferences in profile")
	public void user_navigates_to_user_profile_preferences_in_profile() throws Throwable {
		manage.editBtnClick();
		manage.kidprofileSelection();
	}

	@Then("user should able to see option to set 'My Shelf' as default landing screen")
	public void user_should_able_to_see_option_to_set_my_shelf_as_default_landing_screen() throws Throwable {
		swipeDown();
		swipeDown();
		swipeDown();
	}

	@And("library has kidszone subscription with adult user")
	public void library_has_kidszone_subscription_with_adult_user() throws Throwable {
		logger.info("library has kidszone subscription with adult user");
	}

	@And("user should able to set 'My Shelf' as default landing screen")
	public void user_should_able_to_set_my_shelf_as_default_landing_screen() throws Throwable {
		profile.enablemyShelfLanding();
//		manage.saveUpdatedAvatar();
		logger.info("user confifured my shelf as default landing screen");
	}

	@And("user should navigated to 'My Shelf' screen on login when 'My Shelf' is set as default landing screen")
	public void user_should_navigated_to_my_shelf_screen_on_login_when_my_shelf_is_set_as_default_landing_screen()
			throws Throwable {
		Assert.assertEquals(isElementPresent(myshelf.getMyShelf_lbl_header()), true);
	}

	@And("user disables My Shelf default landing option")
	public void user_disables_my_shelf_default_landing_option() throws Throwable {
		manage.clickProfileImage();
		profile.disablemyShelfLanding();
	}

	@And("user should navigated to 'Library' screen on login when 'My Shelf' is not set as default landing screen")
	public void user_should_navigated_to_library_screen_on_login_when_my_shelf_is_not_set_as_default_landing_screen()
			throws Throwable {
		mylibrary.clickMylibrary();
		logger.info("user landed on Library page");
	}

	@And("logout application")
	public void logout_application() throws Throwable {
		login.logOut();
	}

	@And("library has kidszone subscription with teen user")
	public void library_has_kidszone_subscription_with_teen_user() throws Throwable {
		logger.info("library has kidszone subscription with teen user");
	}

	@And("library has kidszone subscription with kid user")
	public void library_has_kidszone_subscription_with_kid_user() throws Throwable {
		logger.info("library has kidszone subscription with kid user");
	}

	@And("library has axis360 and kidszone subscription with teen user")
	public void library_has_axis360_and_kidszone_subscription_with_teen_user() throws Throwable {
		logger.info("library has kidszone subscription with kid user");
	}

	@And("library axis360 and kidszone subscription with teen kid")
	public void library_axis360_and_kidszone_subscription_with_teen_kid() throws Throwable {
		logger.info("library axis360 and kidszone subscription with teen kid");
	}

	@Then("user with profile type adult and library subscription axis360 only")
	public void user_with_profile_type_adult_and_library_subscription_axis360_only() throws Throwable {
		logger.info("user with profile type adult and library subscription axis360 only");
	}

	@Then("user with profile type Adult and both library's subscription as kidsZone and axis360")
	public void user_with_profile_type_adult_and_both_librarys_subscription_as_kidszone_and_axis360() throws Throwable {
		logger.info("user with profile type Adult and both library's subscription as kidsZone and axis360");
	}

	@And("library has axis360 accessonly")
	public void library_has_axis360_accessonly() throws Throwable {
		logger.info("library has axis360 accessonly");
	}

	@And("user should not be able to view myshelf option")
	public void user_should_not_be_able_to_view_myshelf_option() throws Throwable {
		logger.info("user should not be able to view myshelf option");
	}

	@And("user should able to view myshelf option")
	public void user_should_able_to_view_myshelf_option() throws Throwable {
		Assert.assertEquals(myshelf.getMyShelf_lbl_header().isDisplayed(), true);
	}

	@And("library has axis360 and kidszone subscription")
	public void library_has_axis360_and_kidszone_subscription() throws Throwable {
		logger.info("Library has axis360 and kidszone subscription");
	}

	@When("user is on my shelf screen and clicks checkout cta")
	public void user_is_on_my_shelf_screen_and_clicks_checkout_cta() throws Throwable {
		myshelf.clickMyself();
		myshelf.clickCheckout();

	}

	@Then("user should be able to view the search icon")
	public void user_should_be_able_to_view_the_search_icon() throws Throwable {
		logger.info("user should be able to view the search icon");
		if (isElementPresent(myshelf.getSearchMenu())) {
			Assert.assertEquals(isElementPresent(myshelf.getSearchMenu()), true);
		} else {
			logger.info("for search data is not avialble");
		}
	}

	@And("user lands on the checkouts screen")
	public void user_lands_on_the_checkouts_screen() throws Throwable {
		waitFor(2000);
		Assert.assertEquals(isElementPresent(myshelf.getCheckout_page()), true);
	}

	@And("user should be able to click on search icon to view the search bar in the screen")
	public void user_should_be_able_to_click_on_search_icon_to_view_the_search_bar_in_the_screen() throws Throwable {
		logger.info("user should be able to click on search icon to view the search bar in the screen");
	}

	@And("user should be able give input {string} characters and initiate the search for the titles from the checkout screen")
	public void user_should_be_able_give_input_characters_and_initiate_the_search_for_the_titles_from_the_checkout_screen(
			String title) throws Throwable {
		myshelf.search(title);
	}

	@And("user should be able to view the results based on search string from the titles checked out")
	public void user_should_be_able_to_view_the_results_based_on_search_string_from_the_titles_checked_out()
			throws Throwable {
		if (isElementPresent(myshelf.gettitle_list())) {
			Assert.assertEquals(isElementPresent(myshelf.gettitle_list()), true);
		}
		logger.info("user should be able to view the results based on search string from the titles checked out");
	}

	@When("user is on my shelf screen and clicks holds cta")
	public void user_is_on_my_shelf_screen_and_clicks_holds_cta() throws Throwable {
		login.handleNothankspopup();
		myshelf.clickMyself();
		myshelf.clickholds();
		logger.info("User is on my shelf screen and clicks holds cta");
	}

	@When("user is on my shelf screen and clicks wishlist cta")
	public void user_is_on_my_shelf_screen_and_clicks_wishlist_cta() throws Throwable {
		login.handleNothankspopup();
		myshelf.clickMyself();
		login.handleNothankspopup();
		myshelf.clickwishlist();
		logger.info("User is on my shelf screen and clicks holds cta");
	}

	@When("user is on my shelf screen and clicks recommendations cta")
	public void user_is_on_my_shelf_screen_andclicks_history_cta() throws Throwable {
		myshelf.clickMyself();
		myshelf.clickwishlist();
		myshelf.clickrecommendation();
		logger.info("User is on my shelf screen and clicks history cta");
	}

	@When("user is on my shelf screen and clicks history cta")
	public void user_is_on_my_shelf_screen_and_clicks_history_cta() throws Throwable {
		myshelf.clickMyself();
		myshelf.clickrecommendation();
		waitFor(1000);
		myshelf.clickdownload();
//    	horizontalSwipe(holds.getHistory_titles_hdr());
//	horizontalSwipe(holds.getHistory_titles_hdr());
		waitFor(1000);
		myshelf.clickhistory();
		logger.info("User is on my shelf screen and clicks history cta");
//		horizontalSwipe(holds.getHistory_titles_hdr());
//		horizontalSwipe(holds.getHistory_titles_hdr());
	}


	@And("user lands on the holds screen")
	public void user_lands_on_the_holds_screen() throws Throwable {
		Assert.assertEquals(myshelf.getHolds_page().isDisplayed(), true);
	}

	@And("user is on my shelf screen and clicks downloads cta")
	public void user_lands_on_the_holdsscreen() throws Throwable {
		myshelf.clickMyself();
		myshelf.clickwishlist();
		myshelf.clickdownload();
	}

	@And("user should be able give input {string} characters and initiate the search for the titles from the hold screen")
	public void user_should_be_able_give_input_characters_and_initiate_the_search_for_the_titles_from_the_hold_screen(
			String title) throws Throwable {
		myshelf.search(title);
	}

	@And("user should be able to view the results based on search string from the titles  on hold")
	public void user_should_be_able_to_view_the_results_based_on_search_string_from_the_titles_on_hold()
			throws Throwable {
		logger.info("user should be able to view the results based on search string from the titles  on hold");
	}

	@And("user lands on the wishlist screen")
	public void user_lands_on_the_wishlist_screen() throws Throwable {
		Assert.assertEquals(myshelf.getWishlist_page().isDisplayed(), true);
	}

	@And("user should be able give input {string} characters and initiate the search for the titles from the wishlist screen")
	public void user_should_be_able_give_input_characters_and_initiate_the_search_for_the_titles_from_the_wishlist_screen(
			String title) throws Throwable {
		myshelf.search(title);
	}

	@And("user should be able to view the results based on search string from the titles in wishlist")
	public void user_should_be_able_to_view_the_results_based_on_search_string_from_the_titles_in_wishlist()
			throws Throwable {
		logger.info("user should be able to view the results based on search string from the titles in wishlist");
	}

	@And("user lands on the recommendations screen")
	public void user_lands_on_the_recommendations_screen() throws Throwable {
		Assert.assertEquals(myshelf.getRecommendation_view().isDisplayed(), true);
	}

	@And("user should be able give input {string} characters and initiate the search for the titles from the recommendation screen")
	public void user_should_be_able_give_input_characters_and_initiate_the_search_for_the_titles_from_the_recommendation_screen(
			String title) throws Throwable {
		myshelf.search(title);
	}

	@And("user should be able to view the results based on search string from the titles recommended")
	public void user_should_be_able_to_view_the_results_based_on_search_string_from_the_titles_recommended()
			throws Throwable {
		logger.info("user should be able to view the results based on search string from the titles in recommended");
	}

	@And("user lands on the history screen")
	public void user_lands_on_the_history_screen() throws Throwable {
		Assert.assertEquals(myshelf.getHistory_page().isDisplayed(), true);
	}

	@And("user should be able give input {string} characters and initiate the search for the titles from the history screen")
	public void user_should_be_able_give_input_characters_and_initiate_the_search_for_the_titles_from_the_history_screen(
			String title) throws Throwable {
		myshelf.search(title);
	}

	@And("user should be able to view the results based on search string from the titles in history")
	public void user_should_be_able_to_view_the_results_based_on_search_string_from_the_titles_in_history()
			throws Throwable {
		logger.info("user should be able to view the results based on search string from the titles in history");
	}

	@And("user lands on the downloads screen")
	public void user_lands_on_the_downloads_screen() throws Throwable {
		Assert.assertEquals(myshelf.getDownload_page().isDisplayed(), true);
	}

	@And("user should be able give input {string} characters and initiate the search for the titles from the download screen")
	public void user_should_be_able_give_input_characters_and_initiate_the_search_for_the_titles_from_the_download_screen(
			String title) throws Throwable {
		myshelf.search(title);
	}

	@And("user should be able to view the results based on search string from the titles or publications downloaded")
	public void user_should_be_able_to_view_the_results_based_on_search_string_from_the_titles_or_publications_downloaded()
			throws Throwable {
		logger.info("user should be able to view the results based on search string");
	}

	@When("user is on my shelf screen and clicks recommendation cta")
	public void user_is_on_my_shelf_screen_and_clicks_recommendation_cta() throws Throwable {
		myshelf.clickMyself();
		waitFor(2000);
		myshelf.clickwishlist();
		waitFor(2000);
		myshelf.clickrecommendation();
		logger.info("User lands on my shelf screen and clicks recommendation cta");
	}

	@And("user lands on holds screen")
	public void user_lands_on_holds_screen() throws Throwable {
		WaitForMobileElement(myshelf.getHolds_page());
		Assert.assertEquals(isElementPresent(myshelf.getHolds_page()), true);
		logger.info("User lands on holds screen");
	}

	@And("user lands on wishlist screen")
	public void user_lands_on_wishlist_screen() throws Throwable {
		WaitForMobileElement(myshelf.getWishlist_page());
		Assert.assertEquals(isElementPresent(myshelf.getWishlist_page()), true);
		logger.info("User lands on wishlist screen");
	}

	@And("user lands on recommendation screen")
	public void user_lands_on_recommendation_screen() throws Throwable {
		WaitForMobileElement(myshelf.getPurchase_page());
		waitFor(2000);
		Assert.assertEquals(isElementPresent(myshelf.getPurchase_page()), true);
	}

	@And("user lands on checkout history screen")
	public void user_lands_on_checkout_history_screen() throws Throwable {
		WaitForMobileElement(myshelf.getHistory_page());
		Assert.assertEquals(isElementPresent(myshelf.getHistory_page()), true);
	}

	@Then("user should be able to view quick navigation ctas for checkouts, holds, wishlist, recommendations, checkout history and downloads screen with title count for each of the section")
	public void user_should_be_able_to_view_quick_navigation_ctas_for_checkouts_holds_wishlist_recommendations_checkout_history_and_downloads_screen_with_title_count_for_each_of_the_section()
			throws Throwable {
		Assert.assertEquals(isElementPresent(myshelf.getLogo_txt_Checkout()), true);
		Assert.assertEquals(isElementPresent(myshelf.getLogo_txt_Hold()), true);
		Assert.assertEquals(isElementPresent(myshelf.getWishlist_View()), true);
	}

	@And("user should be able to click on checkout cta and navigate to checkout screen")
	public void user_should_be_able_to_click_on_checkout_cta_and_navigate_to_checkout_screen() throws Throwable {
		myshelf.clickCheckout();
		if(isElementPresent(myshelf.getCheckout_page())) {
			Assert.assertEquals(isElementPresent(myshelf.getCheckout_page()), true);
		}
		logger.info("User should be able to click on checkout cta and navigate to checkout screen");
	}

	@And("user should be able to click on checkout history cta and navigate to checkout history screen")
	public void user_should_be_able_to_click_on_checkout_history_cta_and_navigate_to_checkout_history_screen()
			throws Throwable {
		myshelf.clickrecommendation();
		myshelf.clickhistory();
		logger.info("User should be able to click on checkout history cta and navigate to checkout history screen");
	}

	@And("user should be able to click on downloads cta and navigate to downloaded content screen")
	public void user_should_be_able_to_click_on_downloads_cta_and_navigate_to_downloaded_content_screen()
			throws Throwable {
		myshelf.clickdownload();
		logger.info("User should be able to click on downloads cta and navigate to downloaded content screen");
	}

	@And("user should be able to click on recommendations cta and navigate to recommendations screen")
	public void user_should_be_able_to_click_on_recommendations_cta_and_navigate_to_recommendations_screen()
			throws Throwable {
		myshelf.clickrecommendation();
		logger.info("User should be able to click on recommendations cta and navigate to recommendations screen");
	}

	@And("user should be able to click on wishlist cta and navigate to wishlist screen")
	public void user_should_be_able_to_click_on_wishlist_cta_and_navigate_to_wishlist_screen() throws Throwable {
		myshelf.clickwishlist();
		if(isElementPresent(myshelf.getWishlist_page())) {
			Assert.assertEquals(isElementPresent(myshelf.getWishlist_page()), true);
		}
		logger.info("User should be able to click on wishlist cta and navigate to wishlist screen");
	}

	@And("user should be able to click on holds cta and navigate to holds screen")
	public void user_should_be_able_to_click_on_holds_cta_and_navigate_to_holds_screen() throws Throwable {
		myshelf.clickholds();
		if(isElementPresent(myshelf.getHolds_page())){
			Assert.assertEquals(isElementPresent(myshelf.getHolds_page()), true);
		}
		logger.info("User should be able to click on holds cta and navigate to holds screen");
	}

	@When("user navigates to my shelf and lands on checkout screen")
	public void user_navigates_to_my_shelf_and_lands_on_checkout_screen() throws Throwable {
		myshelf.clickMyself();
		myshelf.clickCheckout();
		logger.info("User navigated to my shelf and landed on checkout screen");
	}

	@When("user is on my shelf screen and clicks checkouts cta")
	public void user_is_on_my_shelf_screen_and_clicks_checkouts_cta() throws Throwable {
		myshelf.clickMyself();
		waitFor(1000);
		myshelf.clickCheckout();
		logger.info("User is on my shelf screen and clicks checkouts cta");
	}
	@Then("user clicks on checkout CTA via myshelf")
	public void user_clicks_on_checkout_cta_via_myshelf() {
		myshelf.clickCheckout();
	}
	@Then("user should not be able to view history cta in the top quick navigation cta carousel")
	public void user_should_not_be_able_to_view_history_cta_in_the_top_quick_navigation_cta_carousel()
			throws Throwable {
		logger.info("User should not be able to view history cta in the top quick navigation cta carousel");
	}

	@And("history is disabled in user preferences")
	public void history_is_disabled_in_user_preferences() throws Throwable {
		logger.info("History is disabled in user preferences");
	}

	@When("user navigates to my shelf and lands on holds screen")
	public void user_navigates_to_my_shelf_and_lands_on_holds_screen() throws Throwable {
		login.handleNothankspopup();
		myshelf.clickMyself();
		myshelf.clickholds();
		if (isElementPresent(myshelf.getLogo_txt_Hold())) {
			Assert.assertEquals(isElementPresent(myshelf.getLogo_txt_Hold()), true);
		}
		logger.info("User navigated to my shelf and landed on Hold screen");
	}

	@When("user navigates to my shelf and lands on recommendations screen")
	public void user_navigates_to_my_shelf_and_lands_on_recommendations_screen() throws Throwable {
		myshelf.clickMyself();
		myshelf.clickwishlist();
		myshelf.clickrecommendation();
		logger.info("User navigates to my shelf and lands on recommendations screen");
	}

	@When("user navigates to my shelf and lands on wishlist screen")
	public void user_navigates_to_my_shelf_and_lands_on_wishlist_screen() throws Throwable {
		login.handleNothankspopup();
		myshelf.clickMyself();
		myshelf.clickwishlist();
		if(isElementPresent(myshelf.getWishlist_View())){
			Assert.assertEquals(isElementPresent(myshelf.getWishlist_View()), true);
		}
		logger.info("User navigated to my shelf and landed on Hold screen");

	}

	@When("user navigates to my shelf and lands on downloads screen")
	public void user_navigates_to_my_shelf_and_lands_on_downloads_screen() throws Throwable {
		login.handleNothankspopup();
		myshelf.clickMyself();
		myshelf.clickwishlist();
		myshelf.clickrecommendation();
		logger.info("User navigates to my shelf and lands on downloads screen");
	}

	@Then("user should able to view history cta in the top quick navigation cta carousel")
	public void user_should_able_to_view_history_cta_in_the_top_quick_navigation_cta_carousel() throws Throwable {
		logger.info("User should able to view history cta in the top quick navigation cta carousel");
	}

	@And("history is enable in user preferences")
	public void history_is_enable_in_user_preferences() throws Throwable {
		logger.info("History is enabled in user preferences");
	}

	@Then("user should be able to view history cta in the top quick navigation cta carousel")
	public void user_should_be_able_to_view_history_cta_in_the_top_quick_navigation_cta_carousel() throws Throwable {
		myshelf.clickwishlist();
		myshelf.clickdownload();
		if (isElementPresent(myshelf.getHistroy_view())) {
			Assert.assertEquals(isElementPresent(myshelf.getHistroy_view()), true);
		}

		logger.info("User should be able to view history cta in the top quick navigation cta carousel");
	}

	@Then("user clicks on holds CTA")
	public void user_clicks_on_holds_cta() {
		myshelf.clickholds();
		waitFor(2000);
	}

	@Then("user clicks on wishlist CTA")
	public void user_clicks_on_wishlist_cta() {
		myshelf.clickwishlist();

	}

	@Then("user clicks on recommendation CTA")
	public void user_clicks_on_recommendation_cta() {
		myshelf.clickrecommendation();

	}

	@Then("user clicks on Checkout History CTA")
	public void user_clicks_on_checkout_history_cta() {
		myshelf.clickdownload();
		myshelf.clickhistory();
		waitFor(2000);
	}
}
