package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import pom.kidszone.LoginPage;
import pom.kidszone.MyShelf;


public class Recommendation_StepDef extends CommonActions {
	
	MyShelf myself = new MyShelf(DriverManager.getDriver());
	
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	
	@And("user has completed interest survey")
    public void user_has_completed_interest_survey() throws Throwable {
        logger.info("user has completed interest survey");
    }
    @And("user lands on 'My Shelf' screen")
    public void user_lands_on_my_shelf_screen() throws Throwable {
    	myself.clickMyself();
    }
    @And("user should able to view recommendations carousel based on interest survey with profile based theme")
    public void user_should_able_to_view_recommendations_carousel_based_on_interest_survey_with_profile_based_theme() throws Throwable {
    	logger.info("theme check");
    }
    @And("user should able to view the titles recommended based on interest survey, preferred age set in the interest survey and user profile type")
    public void user_should_able_to_view_the_titles_recommended_based_on_interest_survey_preferred_age_set_in_the_interest_survey_and_user_profile_type() throws Throwable {
    	myself.clickrecommendedSeeAll();
    }
    @And("user should able to click on view all CTA and navigate interest based recommendations titles list screen")
    public void user_should_able_to_click_on_view_all_cta_and_navigate_interest_based_recommendations_titles_list_screen() throws Throwable {
       myself.clickrecommendedSeeAll();
    }
    @Then("user should not view recommendations carousel based on interest survey if user has not taken interest survey")
    public void user_should_not_view_recommendations_carousel_based_on_interest_survey_if_user_has_not_taken_interest_survey() throws Throwable {
    	 Assert.assertEquals(myself.getMyPrgs_lbl_recommendedhdr().isDisplayed(), false);
    }

    @And("user has not completed interest survey")
    public void user_has_not_completed_interest_survey() throws Throwable {
    	logger.info("user has not completed interest survey");
    }


}
