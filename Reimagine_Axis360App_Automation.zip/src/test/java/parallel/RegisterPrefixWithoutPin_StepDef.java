package parallel;

import com.driverfactory.DriverManager;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pom.kidszone.LoginPage;
import pom.kidszone.RegisterScreen;

public class RegisterPrefixWithoutPin_StepDef {

	public static final Logger logger = LoggerFactory.getLogger(RegisterPrefixWithoutPin_StepDef.class);

	RegisterScreen register = new RegisterScreen(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());

	@Then("system should show only the Library Card ID field")
	public void system_should_show_only_the_library_card_id_field() {
		Assert.assertTrue(login.getSignIn_txt_libId().isDisplayed());
		Assert.assertEquals(login.getLogo_txt_libraryPin().isDisplayed(), false);
		logger.info("User is not able to see the pin field");
	}

	@Then("user should be able to view Sigin cta")
	public void user_should_be_able_to_view_sigin_cta() {
		Assert.assertTrue(login.getLogo_btn_signin().isDisplayed());
		logger.info("User is able to see the sigin button");
	}

	@When("user enters the {string} and click on signin")
	public void user_enters_the_and_click_on_signin(String libraryid) {
		register.enterLibraryId(libraryid);
		register.clicksigin();
	}

	@When("user is able to view Library Card id textfield")
	public void user_is_able_to_view_library_card_id_textfield() {
		Assert.assertTrue(register.getRegister_txt_CardName().isDisplayed());
	}

	@When("user is able to view Display Name and Email Address in textfield form of optional")
	public void user_is_able_to_view_display_name_and_email_address_in_textfield_form_of_optional() {
		Assert.assertTrue(register.getRegister_txt_DisplayName().isDisplayed());
		Assert.assertTrue(register.getRegister_txt_Email().isDisplayed());
	}

	@Then("user should be able to enter the {string} and {string}")
	public void user_should_be_able_to_enter_the_and(String displayName, String email) {
		register.enterEmailandDisplayname(displayName, email);
	}

	@Then("user should be able to enter the {string}")
	public void user_should_be_able_to_enter_the(String libID) {
		register.enterLibCardId(libID);
	}

	@Then("user should navigate to registration screen")
	public void user_should_navigate_to_registration_screen() {
		Assert.assertTrue(register.getNewregister_txt_DisplayName().isDisplayed());
		logger.info("user in registration page");
	}

	@Then("user should be able to view the User name in textfields")
	public void user_should_be_able_to_view_the_user_name_in_textfields() {
		if (System.getProperty("platform").equalsIgnoreCase("ios")) {
			String gettext=register.getRegister_txt_CardName().getText();
			String register_txt_CardName=gettext.substring(gettext.lastIndexOf("*") + 2);
			Assert.assertEquals(register_txt_CardName, login.newUserName);
		}else
		{
		Assert.assertEquals(register.getRegister_txt_CardName().getText(), login.newUserName);
		logger.info("User able to see the user name in the field");
		}
	}

	@Then("clicks on the Register CTA")
	public void clicks_on_the_register_cta() {
		register.clickRegister();
	}

	@Then("user enters {string} and {string} in textfield")
	public void user_enters_and_in_textfield(String displayname, String email) {
		register.onlylibrarywithEmailandDisplayname(displayname, email);
	}

	@When("user skips the mandatory fields User name in textfields")
	public void user_skips_the_mandatory_fields_user_name_in_textfields() {
		register.removeCardName();
	}

	@Then("system should show the error messages for the mandatory fields")
	public void system_should_show_the_error_messages_for_the_mandatory_fields() {

	}
	@Then("user should be able to view disable signin cta")
    public void user_should_be_able_to_view_disable_signin_cta() throws Throwable {
		boolean signInCTA =login.getLogo_btn_signin().isEnabled();
		if(signInCTA)
		{
		logger.info("signInCTA button Enabled");	
		}else
		{
		logger.info("signInCTA button not Enabled");
		}
		
    }
    @And("user enters only {string} in pin textfield wihtout entering Library Id")
    public void user_enters_only_something_in_pin_textfield_wihtout_entering_library_id(String pin) throws Throwable {
    	login.enterpinonly(pin);
    }
}
