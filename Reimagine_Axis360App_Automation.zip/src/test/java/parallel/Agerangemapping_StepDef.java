package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Agerangemapping;
import pom.kidszone.BoundlessLogo;
import pom.kidszone.LoginPage;

public class Agerangemapping_StepDef extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	LoginPage login = new LoginPage(DriverManager.getDriver());
	Agerangemapping agerange = new Agerangemapping(DriverManager.getDriver());
		
}
