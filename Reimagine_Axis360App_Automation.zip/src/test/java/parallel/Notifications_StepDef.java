package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.AboutandLegel;
import pom.kidszone.GoalsandInsights;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MyShelf;

import pom.kidszone.Navigationbars;
import pom.kidszone.Notifications;
import pom.kidszone.Preference;
import pom.kidszone.ProfileCreation;
import pom.kidszone.RegisterScreen;

public class Notifications_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	Navigationbars navigation = new Navigationbars(DriverManager.getDriver());
	Notifications notification = new Notifications(DriverManager.getDriver());
	Preference preference = new Preference(DriverManager.getDriver());
	GoalsandInsights goals = new GoalsandInsights(DriverManager.getDriver());
	MyShelf myself = new MyShelf(DriverManager.getDriver());

	ManageProfile manage = new ManageProfile(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	// 133865-Adult
	@Given("user launch the {string} that has KidsZone Subscription only")
	public void user_launch_the_that_has_kids_zone_subscription_only(String library) {
		login.searchLibrary(library);
		login.initiateSearch();
		login.select_library();
	}

	@Given("existing user enters {string} and {string}")
	public void existing_user_enters_and(String libraryid, String pin) {
		login.loginwithidandPin(libraryid, pin);

	}

	@Then("user should be able to tap on bell icon to navigate to notifications center")
	public void user_should_be_able_to_tap_on_bell_icon_to_navigate_to_notifications_center() {
		notification.view_notificationicon();
		notification.Nav_notificationcenterpage();
	}

	// 133866-Adult
	@When("user navigates to notification center screen using bell icon in top header")
	public void user_navigates_to_notification_center_screen_using_bell_icon_in_top_header() {
		notification.Nav_notificationcenterpage();

	}

	@Then("user should be able to view unread notifications grouped on top followed by read notifications grouped below unread notification")
	public void user_should_be_able_to_view_unread_notifications_grouped_on_top_followed_by_read_notifications_grouped_below_unread_notification() {
		Assert.assertEquals(notification.validate_read(), true);

	}

	@Then("user should be able to view notifications sorted by received date and time with latest notification first within unread and read group")
	public void user_should_be_able_to_view_notifications_sorted_by_received_date_and_time_with_latest_notification_first_within_unread_and_read_group() {
		notification.verifyingLatestMessage();
	}

	@Then("user should be able to view and scroll through list of notifications for kid user only")
	public void user_should_be_able_to_view_and_scroll_through_list_of_notifications_for_kid_user_only() {
		notification.navigate_back();
		// swipeDown();
	}

	@Given("user launches the app search and select library {string} that has KidsZone Subscription only")
	public void user_launches_the_app_search_and_select_library_that_has_kids_zone_subscription_only(String library) {
		login.searchLibrary(library);
		login.initiateSearch();
		login.select_library();

	}

	@Given("user enters {string} and {string} credentials in login screen")
	public void user_enters_and_credentials_in_login_screen(String libraryid, String pin) {
		login.loginwithidandPin(libraryid, pin);

	}

	@Then("user should be able to view edit CTA in top navigation bar of the notification center screen")
	public void user_should_be_able_to_view_edit_cta_in_top_navigation_bar_of_the_notification_center_screen() {
		notification.view_notification_Edit_icon();

	}

	@Then("user should be able to tap on edit CTA and navigate to notification edit screen")
	public void user_should_be_able_to_tap_on_edit_cta_and_navigate_to_notification_edit_screen() {
		notification.click_Nav_Notification_Editscreen();

	}

	@Given("user is logged in and navigated to notification center screen using bell icon in top header")
	public void user_is_logged_in_and_navigated_to_notification_center_screen_using_bell_icon_in_top_header() {
		notification.view_notificationicon();
		notification.Nav_notificationcenterpage();

	}

	@When("on notification center landing screen user swipes left on a unread notifications")
	public void on_notification_center_landing_screen_user_swipes_left_on_a_unread_notifications() {
		notification.Swipeleft_On_Unread_read_Notification();

	}

	@Then("user should be able to view options Delete and Mark as Read for unread notifications")
	public void user_should_be_able_to_view_options_delete_and_mark_as_read_for_unread_notifications() {

		notification.view_notificationicon_Markas_read();
		notification.view_notificationicon_Delete();
	}

	@Then("user should be able to tap on Mark as Read to make unread notification as read")
	public void user_should_be_able_to_tap_on_mark_as_read_to_make_unread_notification_as_read() {
		notification.click_Markasread_Notification();
	}

	@When("on notification center landing screen user swipes left on a read notifications")
	public void on_notification_center_landing_screen_user_swipes_left_on_a_read_notifications() {
		notification.Swipeleft_On_Unread_read_Notification();

	}

	@Then("user should be able to view options Delete and Mark as Unread for read notifications")
	public void user_should_be_able_to_view_options_delete_and_mark_as_unread_for_read_notifications() {
		notification.view_notificationicon_Markas_Unread();
		notification.view_notificationicon_Delete();

	}

	@Then("User should be able to tap on Mark as Unread to make read notification as unread")
	public void user_should_be_able_to_tap_on_mark_as_unread_to_make_read_notification_as_unread() {
		notification.click_MarkasUnread_Notification();

	}

	@Then("user should be able to tap on Delete to delete a notification")
	public void user_should_be_able_to_tap_on_delete_to_delete_a_notification() {

		notification.click_Delete_Notification();
	}

	@Then("system should display delete confirmation pop-up with yes and no options")
	public void system_should_display_delete_confirmation_pop_up_with_yes_and_no_options() {
		notification.view_notification_Delete_Confirmation_msg();
		notification.view_notification_Delete_Confirmation_msg_Yes_Button();
		notification.view_notification_Delete_Confirmation_msg_No_Button();

	}

	@Then("user should be able to select yes from delete confirmation pop-up")
	public void user_should_be_able_to_select_yes_from_delete_confirmation_pop_up() {
		notification.click_Delete_Confirmation_Yes_Notification();

	}

	@Then("user should be able to select no from delete confirmation pop-up")
	public void user_should_be_able_to_select_no_from_delete_confirmation_pop_up() {
		notification.click_Delete_Confirmation_No_Notification();

	}

	// 133869-Adult/Kid/Teen
	@When("user tap on edit CTA and naviagtes to edit screen of the notification center")
	public void user_tap_on_edit_cta_and_naviagtes_to_edit_screen_of_the_notification_center() {
		notification.click_Nav_Notification_Editscreen();

	}

	@Then("user should be able to select one notifications")
	public void user_should_be_able_to_select_one_notifications() {
		notification.click_Select_One_Notification();
	}

	@Then("user should be able to view options Select All and Cancel")
	public void user_should_be_able_to_view_options_select_all_and_cancel() {

		notification.view_SelectAll_Notification();
		notification.view_Cancel_Notification();
	}

	@Then("user should be able to tap on Select All to select all the notifications displayed in the notification list")
	public void user_should_be_able_to_tap_on_select_all_to_select_all_the_notifications_displayed_in_the_notification_list() {

		notification.click_SelectAll_Notification();
	}

	@Then("user should be able to view Unselect All CTA after tap Select All")
	public void user_should_be_able_to_view_unselect_all_cta_after_tap_select_all() {
		notification.view_UnSelectAll_Notification();

	}

	@Then("user should be able to tap on Unselect all to unselect all notifications")
	public void user_should_be_able_to_tap_on_unselect_all_to_unselect_all_notifications() {
		notification.click_UnSelectAll_Notification();

	}

	@Then("user should be able to tap on cancel to exit edit mode and go back to Notification Center landing screen")
	public void user_should_be_able_to_tap_on_cancel_to_exit_edit_mode_and_go_back_to_notification_center_landing_screen() {
		notification.click_Cancel_Notification();

	}

	@Then("view Mark and Delete option")
	public void view_mark_and_delete_option() {
		notification.view_notificationicon_Delete();

	}

	@Given("user is logged in and navigated to notification listing screen")
	public void user_is_logged_in_and_navigated_to_notification_listing_screen() {
		login.handleNothankspopup();
		notification.Nav_notificationcenterpage();
	}

	@When("user is on alerts tab of notification screen")
	public void user_is_on_alerts_tab_of_notification_screen() {
		Assert.assertEquals(isElementPresent(notification.getNotification_alert_tab()), true);

	}

	@Then("user should be able to view the detail of the notifications by clicking the notification")
	public void user_should_be_able_to_view_the_detail_of_the_notifications_by_clicking_the_notification() {

		notification.navigate_message_details();
		Assert.assertEquals(isElementPresent(notification.getNotification_details()), true);
	}

	@Then("user should be able to click on Delete CTA to delete the notification and view the delete confirmation pop-up")
	public void user_should_be_able_to_click_on_delete_cta_to_delete_the_notification_and_view_the_delete_confirmation_pop_up() {
		Assert.assertEquals(isElementPresent(notification.getDelete_CTA()), true);
		notification.delete_msg();
		Assert.assertEquals(isElementPresent(notification.getAlert_Message()), true);

	}

	@And("user clicks on the cancel CTA in the survey interest popup")
	public void user_Clicks_On_The_Cancel_CTA_In_The_Survey_Interest_Popup() {
		login.handleNothankspopup();
	}
}