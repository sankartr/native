package parallel;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pom.kidszone.LoginPage;
import pom.kidszone.Tier2_TitlelistPage_VBookandVideo;
import pom.kidszone.Tier3_LandingPage_VBookandVideo;

public class Tier3_LandingPage_StepDef extends CommonActions {

    LoginPage login = new LoginPage(DriverManager.getDriver());

    Tier3_LandingPage_VBookandVideo tier3LandingPage = new Tier3_LandingPage_VBookandVideo(DriverManager.getDriver());
    Tier2_TitlelistPage_VBookandVideo Tier2_TitlelistPage = new Tier2_TitlelistPage_VBookandVideo(
			DriverManager.getDriver());

    public static final Logger logger = LoggerFactory.getLogger(Tier3_LandingPage_StepDef.class);

    @Then("user should be able to view the Video Title detail page with Title Heading, Title Image, Video Icon and Description")
    public void userShouldBeAbleToViewTheVideoTitleDetailPageWithTitleHeadingTitleImageVideoIconAndDescription() {
        Assert.assertEquals(isElementPresent(tier3LandingPage.checkTier3TitleHeader()),true);
        Assert.assertEquals(isElementPresent(tier3LandingPage.checkvideoTitleIconInTier3()),true);
    }

    @And("user should be able to view the primary CTA and secondary CTA")
    public void userShouldBeAbleToViewThePrimaryCTAAndSecondaryCTA() {
         waitFor(1000);
        //swipeDown();
        if(isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3()),true);
            tier3LandingPage.clickCheckoutBtnInTier3();
            waitFor(5000);
            if(isElementPresent(tier3LandingPage.checkPlayBtnInTier3())) {
                Assert.assertEquals(isElementPresent(tier3LandingPage.checkPlayBtnInTier3()), true);
            }
            else {
                Assert.assertEquals(isElementPresent(tier3LandingPage.checkResumeBtnInTier3()),true);
            }
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkRenewBtnInTier3()),true);
                for (int i = 0; i < 5; i++) {
                    if (isElementPresent(tier3LandingPage.checkReturnBtnInTier3())) {
                        break;
                    } else {
                        swipeDown();
                    }
                }
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkReturnBtnInTier3()),true);
        }
        else {
            if(isElementPresent(tier3LandingPage.checkPlayBtnInTier3())) {
                Assert.assertEquals(isElementPresent(tier3LandingPage.checkPlayBtnInTier3()), true);
            }
            else {
                Assert.assertEquals(isElementPresent(tier3LandingPage.checkResumeBtnInTier3()),true);
            }
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkRenewBtnInTier3()),true);
            for (int i = 0; i < 5; i++) {
                if (isElementPresent(tier3LandingPage.checkReturnBtnInTier3())) {
                    break;
                } else {
                    swipeDown();
                }
            }
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkReturnBtnInTier3()),true);
            tier3LandingPage.clickReturnBtnInTier3();
            WaitForMobileElement(tier3LandingPage.checkCheckoutBtnInTier3());
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3()),true);
            tier3LandingPage.clickCheckoutBtnInTier3();

        }
    }

    @And("user should be able to view related or suggested title carousel based on the configuration in drupal")
    public void userShouldBeAbleToViewRelatedSuggestedTitleCarouselBasedOnTheConfigurationInDrupal() {
    	for(int i = 0;i<=5;i++) {
			if(isElementPresent(tier3LandingPage.checkTitleSeriesInTier3())) {
				swipeDown();
				break;
			}
			else {
				swipeDown();
			}
		}
        if(isElementPresent(tier3LandingPage.checkTitleSeriesInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkTitleSeriesInTier3()),true);
        }
    }


    @Then("user should be able to view the VBook Title detail page with Title Heading, Title Image, VBook Icon and Description")
    public void userShouldBeAbleToViewTheVBookTitleDetailPageWithTitleHeadingTitleImageVBookIconAndDescription() {
        Assert.assertEquals(isElementPresent(tier3LandingPage.checkTier3TitleHeader()),true);
        Assert.assertEquals(isElementPresent(tier3LandingPage.checkvBookTitleImageInTier3()),true);
        Assert.assertEquals(isElementPresent(tier3LandingPage.checkvBookTitleIconInTier3()),true);
    }

    @And("user should be able to view title details based on metadata")
    public void userShouldBeAbleToViewVBookTitleDetailsBasedOnMetadata() {
        swipeDown();
        waitFor(1000);
        if(isElementPresent(tier3LandingPage.checkAuthortextInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkAuthortextInTier3()), true);
            waitFor(2000);
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkAuthorValueInTier3()), true);
        }
        if(isElementPresent(tier3LandingPage.checkNarratortextInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkNarratortextInTier3()), true);
        }
        if(isElementPresent(tier3LandingPage.checkEditiontextInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkEditiontextInTier3()), true);
        }
        if(isElementPresent(tier3LandingPage.checkVideoLengthtextInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkVideoLengthtextInTier3()), true);
        }
        if(isElementPresent(tier3LandingPage.checkFileSizetextInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkFileSizetextInTier3()), true);
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkFileSizeValueInTier3()), true);
        }
        if(isElementPresent(tier3LandingPage.checkAttributetextInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkAttributetextInTier3()), true);
        }
        if(isElementPresent(tier3LandingPage.checkAudienceTypetextInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkAudienceTypetextInTier3()), true);
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkAudienceTypeValueInTier3()),true);
        }
        if(isElementPresent(tier3LandingPage.checkSeriestextInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkSeriestextInTier3()), true);
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkSeriesValueInTier3()),true);
        }
        if(isElementPresent(tier3LandingPage.checkFormattextInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkFormattextInTier3()), true);
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkFormatValueInTier3()),true);
        }
        if(isElementPresent(tier3LandingPage.checkLanguageCodetextInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkLanguageCodetextInTier3()), true);
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkLanguageCodeValueInTier3()),true);
        }
        if(isElementPresent(tier3LandingPage.checkISBNtextInTier3())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkISBNtextInTier3()), true);
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkISBNValueInTier3()),true);
        }
    }

    @And("user should not be able to view list details if there is no response from API")
    public void userShouldNotBeAbleToViewListDetailsIfThereIsNoResponseFromAPI() {
        logger.info("user should not be able to view list details if there is no response from API");
    }

    @And("user should be able to view the list of VBook titles based on the configuraion in drupal")
    public void userShouldBeAbleToViewTheListOfVBookTitlesBasedOnTheConfiguraionInDrupal() {
        logger.info("user should be able to view the list of VBook titles based on the configuraion in drupal");
    }

    @And("user tap on see all CTA in VBook carousel")
    public void userTapOnSeeAllCTAInVBookCarousel() {
    	swipeDown();
        if(isElementPresent(tier3LandingPage.checkvBookSeeAllCTAInTier3())) {
            tier3LandingPage.clickvBookSeeAllCTAInTier3();
        }
    }

    @Then("user should be able to navigate to VBook title list screen")
    public void userShouldBeAbleToNavigateToVBookTitleListScreen() {
        if(isElementPresent(tier3LandingPage.tier3VideoHeadingListMore())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.tier3VideoHeadingListMore()),true);
        }
        if(isElementPresent(tier3LandingPage.tier3VideoHeadingListTitle())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.tier3VideoHeadingListTitle()),true);
        }
    }

    @And("user tap on see all CTA in video carousel")
    public void userTapOnSeeAllCTAInVideoCarousel() {
//    	swipeDown();
//    	swipeDown();
        if(isElementPresent(tier3LandingPage.checkVideoSeeAllCTAInTier3())) {
            tier3LandingPage.clickVideoSeeAllCTAInTier3();
        }
    }

    @Then("user should be able to navigate to video title list screen")
    public void userShouldBeAbleToNavigateToVideoTitleListScreen() {
    	if(isElementPresent(tier3LandingPage.tier3VideoHeadingListMore())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.tier3VideoHeadingListMore()),true);
         }
        if(isElementPresent(tier3LandingPage.tier3VideoHeadingListTitle())) {
        	Assert.assertEquals(isElementPresent(tier3LandingPage.tier3VideoHeadingListTitle()),true);
         }
    }

    @And("user should be able to view the list of video titles based on the configuraion in drupal")
    public void userShouldBeAbleToViewTheListOfVideoTitlesBasedOnTheConfiguraionInDrupal() {
        logger.info("user should be able to view the list of video titles based on the configuraion in drupal");
    }

    @And("user navigates to related or suggested title section in title{int}")
    public void userNavigatesToRelatedOrSuggestedTitleSectionInTitle(int arg0) {
            Assert.assertEquals(tier3LandingPage.checkTitle3RelatedCarouselHeader(),true);
    }
    
    @And("user clicks on the product title")
    public void user_clicks_on_the_product_title() {
    	Tier2_TitlelistPage.getvBook_icon().click();
    }

    @And("user tap on the VBook title in the VBook carousel in tier {int} screen")
    public void userTapOnTheVBookTitleInTheVBookCarouselInTierScreen(int arg0) {
        tier3LandingPage.verifyTitle3RelatedVBook();
    }

    @Then("user should be able to navigate VBook title detail screen")
    public void userShouldBeAbleToNavigateVBookTitleDetailScreen() {
        Assert.assertEquals(isElementPresent(tier3LandingPage.checkTier3TitleHeader()),true);
    }

    @And("user should be able to view the details for the specific title")
    public void userShouldBeAbleToViewTheDetailsForTheSpecificTitle() {
        logger.info("Able to view the details for the specific title");
    }

    @And("user tap on the video title in the video carousel in tier {int} screen")
    public void userTapOnTheVideoTitleInTheVideoCarouselInTierScreen(int arg0) {
        tier3LandingPage.verifyTitle3RelatedVBook();

    }

    @Then("user should be able to navigate video title detail screen")
    public void userShouldBeAbleToNavigateVideoTitleDetailScreen() {
        Assert.assertEquals(isElementPresent(tier3LandingPage.checkTier3TitleHeader()),true);
    }

    @And("user not started watching the checkout VBook title")
    public void userNotStartedWatchingTheCheckoutVBookTitle() {
        logger.info("user not started watching the checkout VBook title");
    }

    @Then("user should able to view play action CTA for that VBook title")
    public void userShouldAbleToViewPlayActionCTAForThatVBookTitle() {
        logger.info("user should able to view play action CTA for that VBook title");
    }

    @And("user should able to view bottom drawer by clicking secondary CTA for that VBook title")
    public void userShouldAbleToViewBottomDrawerByClickingSecondaryCTAForThatVBookTitle() {
        logger.info("user should able to view bottom drawer by clicking secondary CTA for that VBook title");
    }

    @Then("user should be able to view the video title icon")
    public void userShouldBeAbleToViewTheVideoTitleIcon() {
        Assert.assertEquals(isElementPresent(tier3LandingPage.checkvideoTitleIconInTier3()),true);
    }

    @Then("user should be able to view the VBook carousel for the related or suggested title")
    public void user_should_be_able_to_view_the_vbook_carousel_for_the_related_or_suggested_title() throws Throwable {
        if(isElementPresent(tier3LandingPage.checkTier3TitleInThisSeriesText())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkTier3TitleInThisSeriesText()), true);
        }
        if(isElementPresent(tier3LandingPage.checkTier3TMoreLikeThisText())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkTier3TMoreLikeThisText()), true);
        }
    }

    @Then("user should be able to view the VBook title icon in tier{int} screen")
    public void userShouldBeAbleToViewTheVBookTitleIconInTierScreen(int arg0) {
        Assert.assertEquals(isElementPresent(tier3LandingPage.checkvBookTitleIconInTier3()),true);
    }

    @Then("user should be able to view the video carousel for the related or suggested title")
    public void user_should_be_able_to_view_the_video_carousel_for_the_related_or_suggested_title() throws Throwable {
        if (isElementPresent(tier3LandingPage.checkTier3TitleInThisSeriesText())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkTier3TitleInThisSeriesText()), true);
            if(isElementPresent(tier3LandingPage.verifyTier3TitleInThisSeeAllLink())) {
                tier3LandingPage.clickTier3TitleInThisSeeAllLink();
                tier3LandingPage.clickBackIcon();
            }
        }
        if (isElementPresent(tier3LandingPage.checkTier3TMoreLikeThisText())) {
            Assert.assertEquals(isElementPresent(tier3LandingPage.checkTier3TMoreLikeThisText()), true);
            if(isElementPresent(tier3LandingPage.verifyTier3MoreLikeThisSeeAllLink())) {
                tier3LandingPage.clickTier3MoreLikeThisSeeAllLink();
                tier3LandingPage.clickBackIcon();
            }
        }
    }

    @And("user should be able to view see all CTA in the carousel if title count is more than or equal to 10")
    public void user_should_be_able_to_view_see_all_cta_in_the_carousel_if_title_count_is_more_than_or_equal_to_10() throws Throwable {
        logger.info("user should be able to view see all CTA in the carousel if title count is more than or equal to 10");
    }

    @And("user clicks on the video title")
    public void userClicksOnTheVideoTitle() {
        Tier2_TitlelistPage.getvideo_icon().click();
    }

    @And("user should be able to click on play or resume in the tier{int} screen")
    public void userShouldBeAbleToClickOnPlayOrResumeInTheTierScreen(int arg0) {
        if(isElementPresent(tier3LandingPage.checkCheckoutBtnInTier3())) {
            tier3LandingPage.clickCheckoutBtnInTier3();
            waitFor(5000);
            if(isElementPresent(tier3LandingPage.checkPlayBtnInTier3())) {
                tier3LandingPage.clickPlayBtnInTier3();
            }
            else {
                tier3LandingPage.clickResumeBtnInTier3();
            }
        }
        else {
            if(isElementPresent(tier3LandingPage.checkPlayBtnInTier3())) {
                tier3LandingPage.clickPlayBtnInTier3();
            }
            else {
                tier3LandingPage.clickResumeBtnInTier3();
            }
        }
    }

    @And("user should be able to validate the player")
    public void userShouldBeAbleToValidateThePlayer() throws InterruptedException {
    	tier3LandingPage.videoPasue();
    	if(System.getProperty("platform").equalsIgnoreCase("Android")) {
    		Assert.assertEquals(isElementPresent(tier3LandingPage.getSkip_Backward()), true);
        	Assert.assertEquals(isElementPresent(tier3LandingPage.getSkip_Forward()), true);	
    	}
    	Assert.assertEquals(isElementPresent(tier3LandingPage.getFull_ScreenButton()), true);
    	Assert.assertEquals(isElementPresent(tier3LandingPage.getMute_Unmute()), true);
    	Assert.assertEquals(isElementPresent(tier3LandingPage.getSkip_Backward()), true);
    	Assert.assertEquals(isElementPresent(tier3LandingPage.getSkip_Forward()), true);
    	Assert.assertEquals(isElementPresent(tier3LandingPage.getElapsed_Time()), true);
    	Assert.assertEquals(isElementPresent(tier3LandingPage.getRemaining_Time()), true);
    	tier3LandingPage.clickBackIcon();
    	
    }
}
