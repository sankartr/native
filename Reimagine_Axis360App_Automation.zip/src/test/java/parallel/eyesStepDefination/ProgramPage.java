package parallel.eyesStepDefination;

import com.applitools.eyes.selenium.Eyes;
import eyesmanager.EyesManager;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;

public class ProgramPage {

    Eyes eyes = EyesManager.getEyes();

    //197352

    @Given("Capture the screenshot for user joined recent program")
    public void Capture_the_screenshot_for_user_joined_recent_program() {
        eyes.checkWindow("JoinedProgram");
    }

    @And("Capture the screenshot for user leave milestone program")
    public void captureTheScreenshotForUserLeaveMilestoneProgram() {
        eyes.checkWindow("Leave Milestone Program");
    }

    @And("Capture the screenshot for start date, end date, program title, program description and Title image in milestone")
    public void captureTheScreenshotForStartDateEndDateProgramTitleProgramDescriptionAndTitleImageInMilestone() {
        eyes.checkWindow("date_title");
    }

    @And("Capture the screenshot for reading list suggested by admin")
    public void captureTheScreenshotForReadingListSuggestedByAdmin() {
        eyes.checkWindow("Reading list");
    }

    @And("Capture the screenshot for remove e-reading titles")
    public void captureTheScreenshotForRemoveEReadingTitles() {
        eyes.checkWindow("Remove e-reading titles");
    }

    @And("Capture the screenshot for Edit Reading List CTA")
    public void captureTheScreenshotForEditReadingListCTA() {
        eyes.checkWindow("Edit Reading List CTA");
    }

    @And("Capture the screenshot for Add a Title CTA")
    public void captureTheScreenshotForAddATitleCTA() {
        eyes.checkWindow("Add a Title CTA");
    }

    @And("Capture the screenshot for alert message with click and Ok CTA")
    public void captureTheScreenshotForAlertMessageWithClickAndOkCTA() {
        eyes.checkWindow("Alert message");
    }

    @And("Capture the screenshot for added ebook title in the program")
    public void captureTheScreenshotForAddedEbookTitleInTheProgram() {
        eyes.checkWindow("Added ebook title");
    }

    @And("Capture the screenshot for added eaudio title in the program")
    public void captureTheScreenshotForAddedEaudioTitleInTheProgram() {
        eyes.checkWindow("Added eaudio title");
    }

    @And("Capture the screenshot for Add your own title  option")
    public void captureTheScreenshotForAddYourOwnTitleOption() {
        eyes.checkWindow("Add your own title  option");
    }

    @And("Capture the screenshot for title type as mandatory field with drop down options")
    public void captureTheScreenshotForTitleTypeAsMandatoryFieldWithDropDownOptions() {
        eyes.checkWindow("Title type as mandatory field with drop down options");
    }

    @And("Capture the screenshot for view {string} CTA once the user is done updating the details for the external title")
    public void captureTheScreenshotForViewCTAOnceTheUserIsDoneUpdatingTheDetailsForTheExternalTitle(String arg0) {
        eyes.checkWindow("View Add CTA once the user is done updating the details");
    }

    @And("Capture the screenshot for view Checkout as the primary CTA")
    public void captureTheScreenshotForViewCheckoutAsThePrimaryCTA() {
        eyes.checkWindow("View Checkout as the primary CTA");
    }

    @And("Capture the screenshot for view the progress if insights and badges are enabled")
    public void captureTheScreenshotForViewTheProgressIfInsightsAndBadgesAreEnabled() {
        eyes.checkWindow("View the progress if insights and badges are enabled");
    }

    @And("user navigated to title list screen")
    public void userNavigatedToTitleListScreen() {
        eyes.checkWindow("Program titles list page");
    }

    @And("user view the completed status")
    public void userViewTheCompletedStatus() {
        eyes.checkWindow("verify completed program");
    }

    @And("user verify add title disabled")
    public void userVerifyAddTitleDisabled() {
        eyes.checkWindow("Add title disabled");
    }

    @And("user should see the badges")
    public void userShouldSeeTheBadges() {
        eyes.checkWindow("First read badge displayed");
    }

    @And("user joined the program")
    public void userJoinedTheProgram() {
        eyes.checkWindow("Program joined page");
    }

    @And("user see the joined program name on notifications")
    public void userSeeTheJoinedProgramNameOnNotifications() {
        eyes.checkWindow("Program joined notification page");
    }

    @And("user see the notifications page")
    public void userSeeTheNotificationsPage() {
        eyes.checkWindow("Multiple notification page");
    }

    @And("user navigated to the advanced search screen will all options visible")
    public void userNavigatedToTheAdvancedSearchScreenWillAllOptionsVisible() {
        eyes.checkWindow("Advanced search options");
    }

    @And("user navigated to the advanced search screen will all options visible for teen")
    public void userNavigatedToTheAdvancedSearchScreenWillAllOptionsVisibleForTeen() {
        eyes.checkWindow("Advanced search options Teen");
    }

    @And("libray bottom tray visible")
    public void librayBottomTrayVisible() {
        eyes.checkWindow("Library bottom tray");
    }

    @And("myshelf bottom tray visible")
    public void myshelfBottomTrayVisible() {
        eyes.checkWindow("Myshelf bottom tray");
    }

    @And("browse bottom tray visible")
    public void browseBottomTrayVisible() {
        eyes.checkWindow("Browse bottom tray");
    }

    @And("program page bottom tray visible")
    public void programPageBottomTrayVisible() {
        eyes.checkWindow("Programs bottom tray");
    }

    @And("Menu bottom tray visible")
    public void menuBottomTrayVisible() {
        eyes.checkWindow("Menu bottom tray");
    }

    @And("tier one bottom tray visible")
    public void tierOneBottomTrayVisible() {
        eyes.checkWindow("Tier 1 bottom tray");
    }

    @And("tier two bottom tray visible")
    public void tierTwoBottomTrayVisible() {
        eyes.checkWindow("Tier 2 bottom tray");
    }

    @And("tier three bottom tray visible")
    public void tierThreeBottomTrayVisible() {
        eyes.checkWindow("Tier 3 bottom tray");
    }

    @And("resource hub bottom tray visible")
    public void resourceHubBottomTrayVisible() {
        eyes.checkWindow("Resource hub bottom tray");
    }

    @And("preference bottom tray not visible")
    public void preferenceBottomTrayNotVisible() {
        eyes.checkWindow("Preference page no bottom tray");
    }

    @And("help screen bottom tray not visible")
    public void helpScreenBottomTrayNotVisible() {
        eyes.checkWindow("Help page no bottom tray");
    }

    @And("patron help bottom tray not visible")
    public void patronHelpBottomTrayNotVisible() {
        eyes.checkWindow("Patron help no bottom tray");
    }

    @And("About us bottom tray not visible")
    public void aboutUsBottomTrayNotVisible() {
        eyes.checkWindow("About us no bottom tray");
    }

    @And("Privacy policy bottom tray not visible")
    public void privacyPolicyBottomTrayNotVisible() {
        eyes.checkWindow("Privacy policy no bottom tray");
    }

    @And("Terms and condition bottom tray not visible")
    public void termsAndConditionBottomTrayNotVisible() {
        eyes.checkWindow("Terms conditions no bottom tray");
    }

    @And("user is on the browse result page")
    public void userIsOnTheBrowseResultPage() {
        eyes.checkWindow("Browse result page");
    }

    @And("user navigates to result screen")
    public void userNavigatesToResultScreen() {
        eyes.checkWindow("Refiner result page");
    }

    @And("user is on the browse result page teen")
    public void userIsOnTheBrowseResultPageTeen() {
        eyes.checkWindow("Browse result page teen");
    }

    @And("user navigates to result screen teen")
    public void userNavigatesToResultScreenTeen() {
        eyes.checkWindow("Refiner result page teen");
    }

    @And("user is on the browse result page kid")
    public void userIsOnTheBrowseResultPageKid() {
        eyes.checkWindow("Browse result page kid");
    }

    @And("user navigates to result screen kid")
    public void userNavigatesToResultScreenKid() {
        eyes.checkWindow("Refiner result page kid");
    }

    @And("user navigate to profile options page")
    public void userNavigateToProfileOptionsPage() {
        eyes.checkWindow("Profile create page");
    }

    @And("user is on profile settings page teen")
    public void userIsOnProfileSettingsPageTeen() {
        eyes.checkWindow("Profile settings page teen");
    }

    @And("user is on the popup screen")
    public void userIsOnThePopupScreen() {
        eyes.checkWindow("Profile popup");
    }

    @And("user is on add profile screen")
    public void userIsOnAddProfileScreen() {
        eyes.checkWindow("Add profile page");
    }

    @And("user is on profile settings page kid")
    public void userIsOnProfileSettingsPageKid() {
        eyes.checkWindow("Profile settings page kid");
    }

    @And("user is on the search results page")
    public void userIsOnTheSearchResultsPage() {
        eyes.checkWindow("Search results page");
    }

    @And("user is on the search results page of invalid search data")
    public void userIsOnTheSearchResultsPageOfInvalidSearchData() {
        eyes.checkWindow("Invalid search results page");
    }

    @And("user is on the search results page through advanced search")
    public void userIsOnTheSearchResultsPageThroughAdvancedSearch() {
        eyes.checkWindow("Search results page advanced");
    }

    @And("user is on the search results page of invalid search data through advanced search")
    public void userIsOnTheSearchResultsPageOfInvalidSearchDataThroughAdvancedSearch() {
        eyes.checkWindow("Invalid search results advanced");
    }

    @And("user is on the refine screen")
    public void userIsOnTheRefineScreen() {
        eyes.checkWindow("Refine screen");
    }

    @And("user is on no results page")
    public void userIsOnNoResultsPage() {
        eyes.checkWindow("No results page");
    }

    @And("user is on the no filter page with results")
    public void userIsOnTheNoFilterPageWithResults() {
        eyes.checkWindow("No filter pills");
    }

    @And("user is on the program details page")
    public void userIsOnTheProgramDetailsPage() {
        eyes.checkWindow("Program details page");
    }

    @And("user is on registration screen")
    public void userIsOnRegistrationScreen() {
        eyes.checkWindow("Registration screen");
    }

    @And("user is on profile addition page")
    public void userIsOnProfileAdditionPage() {
        eyes.checkWindow("Profile addition");
    }

    @And("user able to view created adult profile")
    public void userAbleToViewCreatedAdultProfile() {
        eyes.checkWindow("Profile Adult created");
    }

    @And("user is on the page with selected refiners")
    public void userIsOnThePageWithSelectedRefiners() {
        eyes.checkWindow("Refiners selected");
    }

    @And("user is on the page with no refiner pills")
    public void userIsOnThePageWithNoRefinerPills() {
        eyes.checkWindow("No refiner pills");
    }

    @And("user is on the page with selected refiners vBook")
    public void userIsOnThePageWithSelectedRefinersVBook() {
        eyes.checkWindow("Refiners selected vBook");
    }

    @And("user is on the page with selected refiners thirdparty")
    public void userIsOnThePageWithSelectedRefinersThirdparty() {
        eyes.checkWindow("Refiners selected thirdparty");
    }

    @And("user is on the page with selected refiners eBooks")
    public void userIsOnThePageWithSelectedRefinersEBooks() {
        eyes.checkWindow("Refiners selected eBooks");
    }

    @And("user view ISBN and Author disabled resource hub")
    public void userViewISBNAndAuthorDisabledResourceHub() {
        eyes.checkWindow("resource hub disabled");
    }

    @And("user view ISBN and Author disabled web resources")
    public void userViewISBNAndAuthorDisabledWebResources() {
        eyes.checkWindow("web resources disabled");
    }

    @And("user view ISBN and Author disabled thirdparty")
    public void userViewISBNAndAuthorDisabledThirdparty() {
        eyes.checkWindow("Thirdparty disabled");
    }

    @And("user view resource hub and web resources disabled using ISBN")
    public void userViewResourceHubAndWebResourcesDisabledUsingISBN() {
        eyes.checkWindow("web resource hub disabled");
    }

    @And("user view resource hub and Author disabled")
    public void userViewResourceHubAndAuthorDisabled() {
        eyes.checkWindow("web resource Author disabled");
    }

    @And("user view ISBN and Author disabled web resources teen")
    public void userViewISBNAndAuthorDisabledWebResourcesTeen() {
        eyes.checkWindow("web resources disabled Teen");
    }

    @And("user view resource hub and web resources disabled using Author")
    public void userViewResourceHubAndWebResourcesDisabledUsingAuthor() {
        eyes.checkWindow("web resource hub disabled");
    }

    @And("user view resource hub and web resources disabled using ISBN Teen")
    public void userViewResourceHubAndWebResourcesDisabledUsingISBNTeen() {
        eyes.checkWindow("web resource hub disabled Teen");
    }

    @And("user view resource hub and web resources disabled using Author Teen")
    public void userViewResourceHubAndWebResourcesDisabledUsingAuthorTeen() {
        eyes.checkWindow("web resource hub disabled Teen");
    }

    @And("user view ISBN and Author disabled kid")
    public void userViewISBNAndAuthorDisabledKid() {
        eyes.checkWindow("ISBN Author disabled kid");
    }

    @And("user view ISBN and Author disabled web resources kid")
    public void userViewISBNAndAuthorDisabledWebResourcesKid() {
        eyes.checkWindow("ISBN Author disabled kid");
    }

    @And("user view resource hub and web resources disabled kid")
    public void userViewResourceHubAndWebResourcesDisabledKid() {
        eyes.checkWindow("web resource hub disabled kid");
    }

    @And("user view resource hub and web resources disabled Author kid")
    public void userViewResourceHubAndWebResourcesDisabledAuthorKid() {
        eyes.checkWindow("web resource hub disabled kid");
    }
}
