package parallel.eyesStepDefination;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HoldWithoutEmail {

	Eyes eyes = EyesManager.getEyes();
	
	@When("capture the screenshot of primary and secondary CTA")
	public void capture_the_screenshot_of_primary_and_secondary_cta() {
	    eyes.checkWindow("PrimaryAndSecondaryCta");
	}

	@Then("capture the screenshot of email id popup")
	public void capture_the_screenshot_of_email_id_popup() {
	    eyes.checkWindow("EmailIdPopup");
	}

	@When("capture the screenshot of primary CTA")
	public void capture_the_screenshot_of_primary_cta() {
	    eyes.checkWindow("PrimaryCta");
	}

	@Then("capture the screenshot of hold message")
	public void capture_the_screenshot_of_hold_message() {
	    eyes.checkWindow("HoldMessage");
	}

	@When("capture the screenshot of open programs screen")
	public void capture_the_screenshot_of_open_programs_screen() {
	    eyes.checkWindow("OpenProgramsScreen");
	}
}
