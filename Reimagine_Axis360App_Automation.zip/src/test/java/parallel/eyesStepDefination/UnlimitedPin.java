package parallel.eyesStepDefination;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class UnlimitedPin {

	Eyes eyes = EyesManager.getEyes();
	
	//197370
	
	@Then("capture the screenshot of profile pin popup")
	public void capture_the_screenshot_of_profile_pin_popup() {
	    eyes.checkWindow("ProfilePinPopup");
	}

	@Then("capture the screenshot of inline error popup stating PIN not valid.Please try again")
	public void capture_the_screenshot_of_inline_error_popup_stating_pin_not_valid_please_try_again() {
	    eyes.checkWindow("InlineError-PinNotValidPleaseTryAgain");
	}

	@Then("capture the screenshot of forgot pin CTA")
	public void capture_the_screenshot_of_forgot_pin_cta() {
	    eyes.checkWindow("ForgotPinCta");
	}

	@When("capture the screenshot of adult profile details page")
	public void capture_the_screenshot_of_adult_profile_details_page() {
	    eyes.checkWindow("AdultProfileDetailsPage");
	}

	@When("capture the screenshot of teen profile details page")
	public void capture_the_screenshot_of_teen_profile_details_page() {
	    eyes.checkWindow("TeenProfileDetailsPage");
	}

	@When("capture the screenshot of kid profile details page")
	public void capture_the_screenshot_of_kid_profile_details_page() {
	    eyes.checkWindow("KidProfileDetailsPage");
	}
}
