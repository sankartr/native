package parallel.eyesStepDefination;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class RemoveProfile {

	Eyes eyes = EyesManager.getEyes();
	public static final Logger logger = LoggerFactory.getLogger(RemoveProfile.class);
	
	
	@Then("capture the screenshot of registration screen")
	public void capture_the_screenshot_of_registration_screen() {
	    eyes.checkWindow("RegistrationScreen");
	}
}
