package parallel.eyesStepDefination;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DisableProfilePin {

	Eyes eyes = EyesManager.getEyes();
	
	//197378
	
	@Then("capture the screenshot of Profile PIN popup")
	public void capture_the_screenshot_of_profile_pin_popup() {
	    eyes.checkWindow("ProfilePINPopup");
	}

	@Then("capture the screenshot of Enable Profile PIN toggle in enabled state")
	public void capture_the_screenshot_of_enable_profile_pin_toggle_in_enabled_state() {
	    eyes.checkWindow("EnableProfilePINToggleIsON");
	}

	@Then("capture the screenshot of Profile detail page with Enable Profile PIN toggle in disabled state")
	public void capture_the_screenshot_of_profile_detail_page_with_enable_profile_pin_toggle_in_disabled_state() {
	    eyes.checkWindow("ProfilePINToggleIsOFF");
	}

	@When("capture the screenshot of prompt message stating Add mandatory data Email and Security question before they can set a PIN")
	public void capture_the_screenshot_of_prompt_message_stating_add_mandatory_data_email_and_security_question_before_they_can_set_a_pin() {
	    eyes.checkWindow("PromptMessage-AddMandatoryDataEmailAndSecurityQuestion");
	}

	@When("capture the screenshot of success prompt toast message")
	public void capture_the_screenshot_of_success_prompt_toast_message() {
	    eyes.checkWindow("SuccessToastMessage");
	}

	@Then("capture the screenshot of Send Email option in Profile PIN popup")
	public void capture_the_screenshot_of_send_email_option_in_profile_pin_popup() {
	    eyes.checkWindow("SendEmailOptionInProfilePinPopup");
	}
}
