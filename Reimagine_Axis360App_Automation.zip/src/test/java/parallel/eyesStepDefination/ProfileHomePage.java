package parallel.eyesStepDefination;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ProfileHomePage {

	Eyes eyes = EyesManager.getEyes();
	
	//197352
	
	@Given("capture the screenshot of adult profile in manage profile screen")
	public void capture_the_screenshot_of_adult_profile_in_manage_profile_screen() {
	    eyes.checkWindow("AdultProfileInManageProfileScreen");
	}

	@Then("capture the screenshot of library screen")
	public void capture_the_screenshot_of_library_screen() {
	    eyes.checkWindow("LibraryScreen");
	}

	@Given("capture the screenshot of Teen profile in manage profile screen")
	public void capture_the_screenshot_of_teen_profile_in_manage_profile_screen() {
	    eyes.checkWindow("TeenProfileInManageProfileScreen");
	}

	@Given("capture the screenshot of Kid profile in manage profile screen")
	public void capture_the_screenshot_of_kid_profile_in_manage_profile_screen() {
	    eyes.checkWindow("KidProfileInManageProfileScreen");
	}

	@When("capture the screenshot of general adult,Teen,kid profiles")
	public void capture_the_screenshot_of_general_adult_teen_kid_profiles() {
	    eyes.checkWindow("GeneralAdultTeenKidProfiles");
	}

	@Then("capture the screenshot of Add icon")
	public void capture_the_screenshot_of_add_icon() {
	    eyes.checkWindow("AddIcon");
	}
	
	//197357
	
	@When("capture the screenshot of Tooltip for the Enable CTA")
	public void capture_the_screenshot_of_tooltip_for_the_enable_cta() {
	    eyes.checkWindow("TooltipForEnableCTA");
	}

	@Then("capture the screenshot of profile details screen without Enable profile pin toggle CTA")
	public void capture_the_screenshot_of_profile_details_screen_without_enable_profile_pin_toggle_cta() {
	    eyes.checkWindow("WithoutEnableProfilePinToggleCta");
	}
}
