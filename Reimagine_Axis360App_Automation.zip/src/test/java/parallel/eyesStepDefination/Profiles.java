package parallel.eyesStepDefination;

import com.applitools.eyes.selenium.Eyes;
import com.reusableMethods.CommonActions;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Profiles extends CommonActions{

	Eyes eyes = EyesManager.getEyes();
	
	//192264
	
	@Then("capture the screenshot of update verbiage as Auto checkout available holds")
	public void capture_the_screenshot_of_update_verbiage_as_auto_checkout_available_holds() {
	    eyes.checkWindow("AutoCheckoutAvailableHoldsVerbiage");
	}
	
	//192267
	
	@Then("capture the screenshot of update verbiage as Set My Shelf as my home page")
	public void capture_the_screenshot_of_update_verbiage_as_set_my_shelf_as_my_home_page() {
	    eyes.checkWindow("SetMyShelfAsMyHomePageVerbiage");
	}
	
	//192478
	
	@Then("capture the screenshot of Enable Profile Pin")
	public void capture_the_screenshot_of_enable_profile_pin() {
		swipeDown();
	    eyes.checkWindow("EnableProfilePinToggle");
	}
	
	//196801
	
	@Given("capture the screenshot of Inline Error message as Enter the valid email")
	public void capture_the_screenshot_of_inline_error_message_as_enter_the_valid_email() {
	    eyes.checkWindow("EnterTheValidEmail");
	}

	@Given("capture the screenshot of popup message as Please add your email to enable Profile PIN")
	public void capture_the_screenshot_of_popup_message_as_please_add_your_email_to_enable_profile_pin() {
	    eyes.checkWindow("PleaseAddYourEmailToEnableProfilePin");
	}
	
	//197225
	
	@Then("capture the screenshot of Add to Wishlist CTA as primary CTA")
	public void capture_the_screenshot_of_add_to_wishlist_cta_as_primary_cta() {
	    eyes.checkWindow("AddToWishlistCta");
	}
	
	//197349
	
	@Then("capture the screenshot of profile page without close or back CTA")
	public void capture_the_screenshot_of_profile_page_without_close_or_back_cta() {
	    eyes.checkWindow("CloseOrBackCta");
	}

	@Then("capture the screenshot of Learn more about profiles popup message")
	public void capture_the_screenshot_of_learn_more_about_profiles_popup_message() {
	    eyes.checkWindow("LearnMoreAboutProfiles");
	}
}
