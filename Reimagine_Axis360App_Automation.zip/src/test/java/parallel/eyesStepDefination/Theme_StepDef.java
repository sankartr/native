package parallel.eyesStepDefination;

import org.junit.Assert;

import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import eyesmanager.EyesManager;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.MyLibrary;

public class Theme_StepDef extends CommonActions {

	MyLibrary library = new MyLibrary(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());
	Eyes eyes = EyesManager.getEyes();

	@When("user is on library page")
	public void user_is_on_library_page() throws Throwable {
		login.clickmylibrary();
	}

	@Then("user should be able to view eBook as card carousel")
	public void user_should_be_able_to_view_ebook_as_card_carousel() throws Throwable {
		library.clickFormat_Dropdown();
		library.click_eBook_BottomDrawer();
		waitFor(3000);
		for (int i = 0; i <= 5; i++) {
			if (isElementPresent(library.geteBook_Carousel_title())) {
//				swipeDown();
				break;
			} else {
				swipeDown();
			}
		}
		Assert.assertEquals(library.geteBook_Carousel_title().isDisplayed(), true);
	}

	@And("user should be able to view eAudio as card carousel")
	public void user_should_be_able_to_view_eaudio_as_card_carousel() throws Throwable {
		library.clickFormat_Dropdown();
		library.check_eAudio__DropDown();
		waitFor(3000);
		for (int i = 0; i <= 5; i++) {
			if (isElementPresent(library.geteAudio_Carousel_title())) {
//				swipeDown();
				break;
			} else {
				swipeDown();
			}
		}
		Assert.assertEquals(library.geteAudio_Carousel_title().isDisplayed(), true);
	}

	@And("user should be able to view video as card carousel")
	public void user_should_be_able_to_view_video_as_card_carousel() throws Throwable {
	
	}

    @Then("user capture the screenshot of title list page")
    public void user_capture_the_screenshot_of_title_list_page() {
    	eyes.checkWindow("Title list page");
    }
    
    @Then("user capture the screenshot of the refiner section")
    public void user_capture_the_screenshot_of_the_refiner_section() {
    	eyes.checkWindow("Refiner Section");
    }

	@And("user should be able to view vBook as card carousel")
	public void user_should_be_able_to_view_vbook_as_card_carousel() throws Throwable {
		library.clickFormat_Dropdown();
		library.click_vBook_BottomDrawer();
		waitFor(3000);
		for (int i = 0; i <= 5; i++) {
			if (isElementPresent(library.vBook_Titles())) {
//				swipeDown();
				break;
			} else {
				swipeDown();
			}
		}
		Assert.assertEquals(library.vBook_Titles().isDisplayed(), true);
	}

	@And("^capture the screenshot of view eBook as card carousel$")
	public void capture_the_screenshot_of_view_ebook_as_card_carousel() throws Throwable {
		eyes.checkWindow("eBookCardcarousel");
	}

	@And("^capture the screenshot of view vBook as card carousel$")
	public void capture_the_screenshot_of_view_vbook_as_card_carousel() throws Throwable {
		eyes.checkWindow("vBookCardcarousel");
	}

	@And("^capture the screenshot of view video as card carousel$")
	public void capture_the_screenshot_of_view_video_as_card_carousel() throws Throwable {
		eyes.checkWindow("videoCardcarousel");
	}

	@And("^capture the screenshot of view eAudio as card carousel$")
	public void capture_the_screenshot_of_view_eaudio_as_card_carousel() throws Throwable {
		eyes.checkWindow("eAudioCardcarousel");
	}

	@Then("capture the screenshot of title list page")
	public void capture_the_screenshot_of_title_list_page() {
		eyes.checkWindow("Titlelistpage");
	}

	@Then("capture the screenshot of the refiner section")
	public void capture_the_screenshot_of_the_refiner_section() {
		eyes.checkWindow("Refiner Section");
	}

	@And("user should view the my library background color with adult theme")
	public void userShouldViewTheMyLibraryBackgroundColorWithAdultTheme() {

	}

	@And("Navigate to eBook title pages")
	public void Navigate_to_eBook_title_pages() {
		library.navigatetoLibraryPage();
	}

	@And("capture the screenshot of titles details page")
	public void capture_the_screenshot_of_titles_details_page() {
		eyes.checkWindow("TitleDetailsPage");
	}

	@When("^user is library search page$")
	public void user_is_library_search_page() throws Throwable {
		logger.info("user is library page");
	}

	@Then("capture the screenshot of find my library$")
	public void capture_the_screenshot_of_find_my_library() throws Throwable {
		eyes.checkWindow("FindLibrary");
	}

	@Then("^user should be able to view error message as login failed$")
	public void user_should_be_able_to_view_error_message_as_login_failed() throws Throwable {
		if (isElementPresent(login.getError_Login_Page())) {
			logger.info("Error msg displayed");
		}
	}

	@And("^capture the screenshot login failed$")
	public void capture_the_screenshot_login_failed() throws Throwable {
		eyes.checkWindow("LognFailed");
	}

	@Then("^capture the screenshot registration page$")
	public void capture_the_screenshot_registration_page() throws Throwable {
		eyes.checkWindow("RegistrationPage");
	}
	@Then("capture the screenshot library page")
	public void capture_the_screenshot_library_page() throws Throwable {
		swipeDown();
		swipeDown();
		eyes.checkWindow("libraryPage");
	}
	
	@When("user capture the screenshot of the checkout titles on myshelf page")
	public void user_capture_the_screenshot_of_the_checkout_titles_on_myshelf_page() {
		eyes.checkWindow("CheckoutsOnMystuffPage");
	}
	
	@Then("user capture the screenshot of the hold titles on myshelf page")
	public void user_capture_the_screenshot_of_the_hold_titles_on_myshelf_page() {
		eyes.checkWindow("HoldsOnMystuffPage");
	}

	@Then("user capture the screenhshot of the wishlist titles on myshelf page")
	public void user_capture_the_screenhshot_of_the_wishlist_titles_on_myshelf_page() {
		eyes.checkWindow("WishlistOnMystuffPage");
	}
	
	@Then("user capture the screenshot of the history titles on myshelf page")
	public void user_capture_the_screenshot_of_the_history_titles_on_myshelf_page() {
		eyes.checkWindow("HistoryOnMystuffPage");
	}

    @Then("capture the screenshot of the newspaper & magazine in Tier{int} screen")
    public void captureTheScreenshotOfTheNewspaperMagazineInTierScreen(int arg0) {
		eyes.checkWindow("Newspaper&Magzine Tier 2 Screen");
    }


	@And("user is navigated to the Main Menu screen")
	public void userIsNavigatedToTheMainMenuScreen() {
		eyes.checkWindow("Reader - Main Menu Screen");
	}

	@Then("capture the screenshot of the myshelf screen")
	public void captureTheScreenshotOfTheMyshelfScreen() {
		eyes.checkWindow("My Shelf Screen");
	}

	@Then("user capture the screenshot of the eBook Reader")
	public void userCaptureTheScreenshotOfTheEBookReader() {
		eyes.checkWindow("eBook Reader Screen");
	}

	@Then("capture the screenshot in the library screen")
	public void captureTheScreenshotInTheLibraryScreen() {
		eyes.checkWindow("My Library Screen");
	}

	@Then("user capture the screenshot of the program info on the program details page")
	public void user_capture_the_screenshot_of_the_program_info_on_the_program_details_page() {
		eyes.checkWindow("ProgramInfoOnProgramDetailsPage");
	}
	
	@Then("user capture the screenshot of the reading list on the program details page")
	public void user_capture_the_screenshot_of_the_reading_list_on_the_program_details_page() {
		eyes.checkWindow("TitleListOnProgramDetailsPage");
	}
	
	@Then("user capture the screenshot of the ongoing and upcoming programs on the open programs tab")
	public void user_capture_the_screenshot_of_the_ongoing_and_upcoming_programs_on_the_open_programs_tab() {
		eyes.checkWindow("OngoingAndUpcomingProgramsOnOpenProgramsTab");
	}
	
	@Then("user capture the screenshot of the browse by subject options")
	public void user_capture_the_screenshot_of_the_browse_by_subject_options() {
		eyes.checkWindow("BrowseOptionsOnBrowsePages");
	}
	
	@Then("user capture the screenshot of the titles listed")
	public void user_capture_the_screenshot_of_the_titles_listed() {
		eyes.checkWindow("TitlesListedAndRefinerButton");
	}
	
	@Then("user capture the screenshot of the refiner sections")
	public void user_capture_the_screenshot_of_the_refiner_sections() {
		eyes.checkWindow("RefinerSectionsOnRefinerPage");
	}
	
	@Then("user capture the screenshot of the profile details page")
	public void user_capture_the_screenshot_of_the_profile_details_page() {
		eyes.checkWindow("ProfileDetailsPageTop");
		swipeDown();
		eyes.checkWindow("ProfileDetailsPageBottom");
	}
	
	@When("user capture the screenshot of the reading interest top section")
	public void user_capture_the_screenshot_of_the_reading_interest_top_section() {
		eyes.checkWindow("ReadingInterestPageTop");
	}
	
	@When("user capture the screenshot of the selected interest")
	public void user_capture_the_screenshot_of_the_selected_interest() {
		eyes.checkWindow("ReadingInterestPageTopicsSelected");
		swipeDown();
	}
	
	@When("user capture the screenshot of the reading interest bottom section")
	public void user_capture_the_screenshot_of_the_reading_interest_bottom_section() {
		swipeDown();
		swipeDown();
		eyes.checkWindow("ReadingInterestPageTopicsSelected");
	}
	
	@Then("user capture the screenshot of the reading interest")
	public void user_capture_the_screenshot_of_the_reading_interest() {
		eyes.checkWindow("ReadingInterestAgeClick");
	}
	
	@Then("user capture the screenshot of the Menu page")
	public void user_capture_the_screenshot_of_the_menu_page() {
		eyes.checkWindow("MenuPage");
	}
	
	@Then("user captures the screenshot of the search results page")
	public void user_captures_the_screenshot_of_the_search_results_page() {
		eyes.checkWindow("SearchResultsPage");
	}
	
	@Then("user captures the refiner section page")
	public void user_captures_the_refiner_section_page() {
		eyes.checkWindow("RefinerFromSearchResultsPage");
	}
	
	@Then("user capture the screenshot of the advance search page")
	public void user_capture_the_screenshot_of_the_advance_search_page() {
		eyes.checkWindow("AdvanceSearchPage");
	}
	
	@Then("user capture the screenshot of the active and closed programs")
	public void user_capture_the_screenshot_of_the_active_and_closed_programs() {
		eyes.checkWindow("MyProgramsPage");
	}

	@Then("capture the screenshot login successful")
	public void capture_the_screenshot_login_successful() {
		eyes.checkWindow("Login screen capture");
	}
	@Then("user navigated to the Reader screen")
    public void userNavigatedToTheReaderScreen() {
		eyes.checkWindow("eAudio Reader Screen");
    }
	@And("user capture the screenshot of the Recommended titles in my shelf screen")
	public void userCaptureTheScreenshotOfTheRecommendedTitlesInMyShelfScreen() {
		eyes.checkWindow("My Shelf-Recommended Screen");
	}
	@And("user capture the screenshot of the Download titles in my shelf screen")
	public void userCaptureTheScreenshotOfTheDownloadTitlesInMyShelfScreen() {
		eyes.checkWindow("My Shelf - Download Screen");
	}
}
