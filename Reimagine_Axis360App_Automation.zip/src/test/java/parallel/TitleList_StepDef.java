package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.*;

public class TitleList_StepDef extends CommonActions {
    LoginPage login = new LoginPage(DriverManager.getDriver());
    SearchPage search = new SearchPage(DriverManager.getDriver());
    MyShelf myshelf = new MyShelf(DriverManager.getDriver());
    InterestSurvey interest = new InterestSurvey(DriverManager.getDriver());
    Navigationbars navigation = new Navigationbars(DriverManager.getDriver());
    MenuList menu = new MenuList(DriverManager.getDriver());
    MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
    GoalsandInsights goals = new GoalsandInsights(DriverManager.getDriver());
    ManageProfile manage = new ManageProfile(DriverManager.getDriver());
    ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
    MyCheckouts checkout = new MyCheckouts(DriverManager.getDriver());
    Holds holds = new Holds(DriverManager.getDriver());
    TitleList titleslist = new TitleList(DriverManager.getDriver());
    BoundlessLogo boundless = new BoundlessLogo(DriverManager.getDriver());
    TitleDetails details = new TitleDetails(DriverManager.getDriver());
    MyProgram program=new MyProgram(DriverManager.getDriver());

    public static final Logger logger = LoggerFactory.getLogger(TitleList_StepDef.class);

    @When("user clicks on See All CTA for the carousel")
    public void user_clicks_on_see_all_cta_for_the_carousel() throws Throwable {
        mylibrary.clickMylibrary();
        titleslist.click_seeAllCarousel();
    }

    @When("user clicks on Level 1 Subject CTA")
    public void user_clicks_on_level_1_subject_cta() throws Throwable {
        titleslist.navigatetoYoungAdult_Fictionlevel1();
    }

    @And("user profile type is teen")
    public void user_profile_type_is_teen() {
        logger.info("user profile type is teen");
    }

    @Then("user should be navigated to titles list screen")
    public void user_should_be_navigated_to_titles_list_screen() throws Throwable {

        if (isElementPresent(titleslist.getYoungAdult_fiction_level2_lbl())) {
            Assert.assertEquals(isElementPresent(titleslist.getYoungAdult_fiction_level2_lbl()), true);
        }

        if (isElementPresent(titleslist.getRefineIcon_btn())) {
            Assert.assertEquals(isElementPresent(titleslist.getRefineIcon_btn()), true);
        }
    }

    @Given("user clicks on Browse option")
    public void user_clicks_on_browse_option() {
        titleslist.clickBrowse_btn();
    }

    @And("user lands on listing screen of browse results")
    public void user_lands_on_listing_screen_of_browse_results() {
        Assert.assertEquals(isElementPresent(titleslist.getResult_Count()), true);
    }
    @And("user navigate to program screen")
    public void user_navigate_to_program_screen()
    {
        program.clikMenuProgram();
    }

    @When("user is lands on Browser screen with fiction level {int}")
    public void user_is_lands_on_browser_screen_with_fiction_level(Integer int1) {
        titleslist.clickFriction_level1_btn();
    }

    @Then("user should be able to view the level {int} subject list for the level {int} subject fiction")
    public void user_should_be_able_to_view_the_level_subject_list_for_the_level_subject_fiction(Integer int1,
                                                                                                 Integer int2) {
        if (isElementPresent(titleslist.getTitle_list_level2())) {
            Assert.assertEquals(isElementPresent(titleslist.getTitle_list_level2()), true);
        }
    }

    @Then("user should be able to view top {int} level {int} subjects for fiction listed first in the level {int} category section")
    public void user_should_be_able_to_view_top_level_subjects_for_fiction_listed_first_in_the_level_category_section(
            Integer int1, Integer int2, Integer int3) {
        if (isElementPresent(titleslist.getRefineIcon_btn())) {
            Assert.assertEquals(isElementPresent(titleslist.getRefineIcon_btn()), true);
        }
    }

    @And("user should be able to navigate back to last screen by clicking back CTA")
    public void user_should_be_able_to_navigate_back_to_last_screen_by_clicking_back_cta() throws Throwable {
        profile.clickBackbutton();
//		waitFor(1000);
    }

    @Then("user should be able to view remaining level {int} subjects for fiction listed after top {int} in alphabetical order")
    public void user_should_be_able_to_view_remaining_level_subjects_for_fiction_listed_after_top_in_alphabetical_order(
            Integer int1, Integer int2) {
        logger.info(
                "user should be able to view remaining level 2 subjects for fiction listed after top 20 in alphabetical order");
    }

    @Then("user should be able to view header {string} for top {int} level {int} subjects group")
    public void user_should_be_able_to_view_header_for_top_level_subjects_group(String string, Integer int1,
                                                                                Integer int2) {
        logger.info("user should be able to view header top20 for top 20 level 2  subjects group");
    }

    @Then("user should be able to view header {string} for top {int} level {int} subjects")
    public void user_should_be_able_to_view_header_for_top_level_subjects(String string, Integer int1, Integer int2) {
        logger.info("user should be able to view header Featured Categories for top 20 level 2  subjects group");
        titleslist.clickRefineIcon_btn();
    }

    @When("user is lands on Browser screen with fiction Level {int} refiners screen")
    public void user_is_lands_on_browser_screen_with_fiction_level_refiners_screen(Integer int1) {
        Assert.assertEquals(isElementPresent(titleslist.getFriction_level1_btn()), true);
        titleslist.clickFriction_level1_btn();
    }

    @Given("user profile type is kid")
    public void user_profile_type_is_kid() {
        logger.info("user profile type is kid");
    }

    @Then("user should not be able to view the category in the more fiction type section if already displays in the top {int}")
    public void user_should_not_be_able_to_view_the_category_in_the_more_fiction_type_section_if_already_displays_in_the_top(
            Integer int1) {
//		titleslist.clickFriction_level1_btn();
//		titleslist.clickFriction_level2_btn();
    }

    @When("user is lands on Browser screen and select the category in the fiction")
    public void user_is_lands_on_browser_screen_and_select_the_category_in_the_fiction() throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getBrowsePage()), true);
        titleslist.clickFriction_level1_btn();
    }

    @Then("user should be able to view the category section with in header Featured Lists")
    public void user_should_be_able_to_view_the_category_section_with_in_header_featured_lists() throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getCategoriesPage()), true);
    }

    @And("user is on refiners screen for the curated list")
    public void user_is_on_refiners_screen_for_the_curated_list() throws Throwable {
        titleslist.clickRefineIcon_btn();
        Assert.assertEquals(isElementPresent(titleslist.getRefinePage()), true);
    }

    @And("user should be able to view Curated list selected below the header")
    public void user_should_be_able_to_view_curated_list_selected_below_the_header() throws Throwable {
        swipeDown();
        swipeDown();
        swipeDown();
        titleslist.clickViewResult();
    }

    @And("user should be able to view list of enabled curated lists for that library")
    public void user_should_be_able_to_view_list_of_enabled_curated_lists_for_that_library() throws Throwable {
        if (isElementPresent(titleslist.getCuratedListEnabled())) {
            Assert.assertEquals(isElementPresent(titleslist.getCuratedListEnabled()), true);
        }
    }

    @And("user should be able to view the curated lists in order defined in admin portal")
    public void user_should_be_able_to_view_the_curated_lists_in_order_defined_in_admin_portal() throws Throwable {
        logger.info("user should be able to view the curated lists in order");
    }

    @And("user should be able to view Curated list selected by default on landing")
    public void user_should_be_able_to_view_curated_list_selected_by_default_on_landing() throws Throwable {
        logger.info("user should be able to view Curated list selected by default");
    }

    @And("user should be able to select Curated list and view the titles listed and refiners updated based on the selection")
    public void user_should_be_able_to_select_curated_list_and_view_the_titles_listed_and_refiners_updated_based_on_the_selection()
            throws Throwable {
        titleslist.clickCuratedList();
    }

    @And("user is on list screen and select the refiners option for the titles lists screen")
    public void user_is_on_list_screen_and_select_the_refiners_option_for_the_titles_lists_screen() throws Throwable {
        titleslist.clickRefineIcon_btn();
        Assert.assertEquals(isElementPresent(titleslist.getRefinePage()), true);
    }

    @Then("user should be able to view sort option in the refiner section option")
    public void user_should_be_able_to_view_sort_option_in_the_refiner_section() throws Throwable {
        if (isElementPresent(titleslist.getSortBy())) {
            Assert.assertEquals(isElementPresent(titleslist.getSortBy()), true);
        }
    }

    @And("user should be able to view and select a sort option for the titles listed")
    public void user_should_be_able_to_view_and_select_a_sort_option_for_the_titles_listed() throws Throwable {
        titleslist.selectSortOption();
        swipeDown();
        swipeDown();
        swipeDown();
        titleslist.clickViewResult();
    }

    @And("user should be able view the titles sorted based on selection option")
    public void user_should_be_able_view_the_titles_sorted_based_on_selection_option() throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getCuratedList()), true);
    }

    @And("user should be able to view the titles sorted based on publication date by default")
    public void user_should_be_able_to_view_the_titles_sorted_based_on_publication_date_by_default() throws Throwable {
        titleslist.clickRefineIcon_btn();
        titleslist.selectPublicationDate();
        swipeDown();
        swipeDown();
        swipeDown();
        titleslist.clickViewResult();
    }

    @And("user should be able to expand and collapse the sort section option")
    public void user_should_be_able_to_expand_and_collapse_the_sort_section_option() throws Throwable {
        titleslist.collapseSortBy();
        titleslist.expandSortBy();
    }

    @And("user should be able to view title list screen with old theme")
    public void user_should_be_able_to_view_title_list_screen_with_old_theme() throws Throwable {
        logger.info("theme check");
    }

    @When("user clicks on See All CTA for the Curated list")
    public void user_clicks_on_see_all_cta_for_the_curated_list() throws Throwable {
        mylibrary.clickMylibrary();
        swipeDown();
        swipeDown();
        Assert.assertEquals(isElementPresent(titleslist.getSeeAll_carousel()), true);
        titleslist.click_seeAllCarousel();
    }

    @When("user clicks on Level 2 Subject CTA")
    public void user_clicks_on_level_2_subject_cta() throws Throwable {
        titleslist.navigatetoYoungAdult_Fictionlevel1();
        titleslist.navigatetoLevel2();

    }

    @When("user lands on titles list screen")
    public void user_lands_on_titles_list_screen() throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getYoungAdult_fiction_level1_btn()), true);
    }

    @Then("user should be able to view the title list page header with number of results based on navigation from Level 1 Subject")
    public void user_should_be_able_to_view_the_title_list_page_header_with_number_of_results_based_on_navigation_from_level_1_subject()
            throws Throwable {
        titleslist.navigatetoYoungAdult_Fictionlevel1();
    }

    @And("user should be able to view each title as a card and titles listed as grid view")
    public void user_should_be_able_to_view_each_title_as_a_card_and_titles_listed_as_grid_view() throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getTitle_list_level2()), true);
    }

    @And("user should be able to view 10 titles")
    public void user_should_be_able_to_view_10_titles() throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getTitle_list_level2()), true);
    }

    @And("System should lazy load next 10 titles per carousel as user browses towards the bottom of the titles displayed")
    public void system_should_lazy_load_next_10_titles_per_carousel_as_user_browses_towards_the_bottom_of_the_titles_displayed()
            throws Throwable {
        logger.info("lazy load check cannot be validated in Automation");
    }

    @And("user should be able to view category section for Level 1 subjects")
    public void user_should_be_able_to_view_category_section_for_level_1_subjects() throws Throwable {
        titleslist.cancelRefine();
        Assert.assertEquals(isElementPresent(titleslist.getTitle_list_level2()), true);
    }

    @And("user should be able to click on refine icon and navigate to category and refiners screen")
    public void user_should_be_able_to_click_on_refine_icon_and_navigate_to_category_and_refiners_screen()
            throws Throwable {
        titleslist.clickRefineIcon_btn();

    }

    @And("user should be able to view category section expanded and filter options collapsed by default")
    public void user_should_be_able_to_view_category_section_expanded_and_filter_options_collapsed_by_default()
            throws Throwable {
        if (isElementPresent(titleslist.getCategoryList_toggle())) {
            Assert.assertEquals(isElementPresent(titleslist.getCategoryList_toggle()), true);
        }
    }

    @And("user should be able to click on to expand and collapse the category section and filter options")
    public void user_should_be_able_to_click_on_to_expand_and_collapse_the_category_section_and_filter_options()
            throws Throwable {
//		titleslist.clickRefineIcon_btn();
		titleslist.collapseCategory();
	}

	@Then("user should be able to view the title list page header with number of results based on navigation from Level 3 Subject")
	public void user_should_be_able_to_view_the_title_list_page_header_with_number_of_results_based_on_navigation_from_level_3_subject()
			throws Throwable {
		titleslist.navigatetoYoungAdult_Fictionlevel1();
		titleslist.navigateLevel3Bookdetails();
		titleslist.clickBacktoMenu();

	}

	@And("user should be able to view category section for Level 3 subjects")
	public void user_should_be_able_to_view_category_section_for_level_3_subjects() throws Throwable {
	}

	@Then("user should be able to view the title list page header with number of results based on navigation from Level 2 Subject")
	public void user_should_be_able_to_view_the_title_list_page_header_with_number_of_results_based_on_navigation_from_level_2_subject()
			throws Throwable {
		titleslist.navigatetoYoungAdult_Fictionlevel1();
		// titleslist.navigatetoLevel2();
		Assert.assertEquals(isElementPresent(titleslist.getTitleLevel2()), true);

	}

	@And("user should be able to view title list screen with theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_title_list_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type()
			throws Throwable {
		if (isElementPresent(titleslist.getTitle_share_btn())) {
			Assert.assertEquals(isElementPresent(titleslist.getTitle_share_btn()), true);
		}
	}

	@Then("user should be able to view the title list page header with number of results based on navigation from Curated List")
	public void user_should_be_able_to_view_the_title_list_page_header_with_number_of_results_based_on_navigation_from_curated_list()
			throws Throwable {
		titleslist.navigatetoYoungAdult_Fictionlevel1();
	}

	@And("user should be able to view category section for Level 2 subjects")
	public void user_should_be_able_to_view_category_section_for_level_2_subjects() throws Throwable {
	}

	@And("user should be able to view category section for Curated list")
	public void user_should_be_able_to_view_category_section_for_curated_list() throws Throwable {
	}

	@Then("user should be able to view the titles listed for the Level 1 subject on the title list screen when user has navigated from Level 1 Subject")
	public void user_should_be_able_to_view_the_titles_listed_for_the_level_1_subject_on_the_title_list_screen_when_user_has_navigated_from_level_1_subject()
			throws Throwable {
		Assert.assertEquals(isElementPresent(titleslist.getYoungAdult_fiction_level1_btn()), true);
	}

	@Then("user should be able to view the titles listed for the Level 2 subject on the title list screen when user has navigated from Level 2 Subject")
	public void user_should_be_able_to_view_the_titles_listed_for_the_level_2_subject_on_the_title_list_screen_when_user_has_navigated_from_level_2_subject()
			throws Throwable {
		titleslist.navigatetoYoungAdult_Fictionlevel1();
		Assert.assertEquals(isElementPresent(titleslist.getRefineIcon_btn()), true);

	}

	@Then("user should be able to view the titles listed for the Level 3 subject on the title list screen when user has navigated from Level 3 Subject")
	public void user_should_be_able_to_view_the_titles_listed_for_the_level_3_subject_on_the_title_list_screen_when_user_has_navigated_from_level_3_subject()
			throws Throwable {
	}

	@And("user should be able to view the titles listed for the curated list on the title list screen when user has navigated from curated List")
	public void user_should_be_able_to_view_the_titles_listed_for_the_curated_list_on_the_title_list_screen_when_user_has_navigated_from_curated_list()
			throws Throwable {
		mylibrary.clickMylibrary();
		if (isElementPresent(titleslist.getSeeAll_carousel())) {
			Assert.assertEquals(isElementPresent(titleslist.getSeeAll_carousel()), true);
		}

	}

	@Then("user should be able to view the titles listed for the carousel on the title list screen when user has navigated from Carousel See All CTA")
	public void user_should_be_able_to_view_the_titles_listed_for_the_carousel_on_the_title_list_screen_when_user_has_navigated_from_carousel_see_all_cta()
			throws Throwable {
		mylibrary.clickMylibrary();
		swipeDown();
		swipeDown();
		swipeDown();

		swipeDown();
		if (isElementPresent(titleslist.getAlwaysAvilable_hdr())) {
			Assert.assertEquals(isElementPresent(titleslist.getAlwaysAvilable_hdr()), true);

		}
	}

	@When("user clicks on browse by subject in bottom navigation bar")
	public void user_clicks_on_browse_by_subject_in_bottom_navigation_bar() {
		titleslist.clickBrowse_btn();
	}

	@Then("user should be able to view Fiction as level {int} subjects list for Kids")
	public void user_should_be_able_to_view_fiction_as_level_subjects_list_for_kids(Integer int1) {
		titleslist.clickFriction_level1_btn();
	}

	@Then("user should be able to view Juvenile Fiction listed as Fiction for Kids")
	public void user_should_be_able_to_view_juvenile_fiction_listed_as_fiction_for_kids() {
		titleslist.clickRefineIcon_btn();
		Assert.assertEquals(isElementPresent(titleslist.getTop20()), true);
	}

	@Then("user should be able to select level {int} subject and navigate to titles list screen for that level {int} subject")
	public void user_should_be_able_to_select_level_subject_and_navigate_to_titles_list_screen_for_that_level_subject(
			Integer int1, Integer int2) {
		if (isElementPresent(titleslist.getTitle_list_level2())) {
			Assert.assertEquals(isElementPresent(titleslist.getTitle_list_level2()), true);
		}
	}

	@Given("user profile type is Adult")
	public void user_profile_type_is_adult() {
		logger.info("user profile type is Adult");
	}

	@Then("user should be able to view list of level {int} subjects")
	public void user_should_be_able_to_view_list_of_level_subjects(Integer int1) {
		titleslist.clickFriction_level1_btn();
	}

	@Then("user should be able to view Non Fiction as level {int} subjects list for teen")
	public void user_should_be_able_to_view_non_fiction_as_level_subjects_list_for_teen(Integer int1) {
		titleslist.clickFriction_level1_btn();
	}

	@Then("user should be able to view Young Adult Non Fiction listed as Non Fiction for teens")
	public void user_should_be_able_to_view_young_adult_non_fiction_listed_as_non_fiction_for_teens() {
		titleslist.clickFriction_level1_btn();
	}

	@Then("user should be able to view Non Fiction as level {int} subjects list for Kids")
	public void user_should_be_able_to_view_non_fiction_as_level_subjects_list_for_kids(Integer int1) {
		titleslist.clickFriction_level1_btn();
	}

	@Then("user should be able to view Juvenile Non Fiction listed as Non Fiction for Kids")
	public void user_should_be_able_to_view_juvenile_non_fiction_listed_as_non_fiction_for_kids() {
		titleslist.clickFriction_level1_btn();
	}

	@Then("user should be able to view Fiction as level {int} subjects list for teen")
	public void user_should_be_able_to_view_fiction_as_level_subjects_list_for_teen(Integer int1) {
		titleslist.clickFriction_level1_btn();
	}

	@Then("user should be able to view Young Adult Fiction listed as Fiction for teens")
	public void user_should_be_able_to_view_young_adult_fiction_listed_as_fiction_for_teens() {
		titleslist.clickFriction_level1_btn();
	}

	@And("user should be able to view the titles from both General collection and Always Available collection listed by default")
	public void user_should_be_able_to_view_the_titles_from_both_general_collection_and_always_available_collection_listed_by_default()
			throws Throwable {
		if (isElementPresent(titleslist.getAlwaysAvilable_hdr())) {
			Assert.assertEquals(isElementPresent(titleslist.getAlwaysAvilable_hdr()), true);
		}
	}

	@And("user click on See all CTA for the carousel")
	public void user_click_on_see_all_cta_for_the_carousel() throws Throwable {
		mylibrary.clickMylibrary();
		swipeDown();
		swipeDown();
		titleslist.click_seeAllCarousel();

	}

	@And("user should be able to view the selected sort option below the sort section")
	public void user_should_be_able_to_view_the_selected_sort_option_below_the_sort_section() throws Throwable {
		logger.info("user able to view the selected sort option");
	}

	@And("user should be remain on refiners screen upon selecting and apply sort option")
	public void user_should_be_remain_on_refiners_screen_upon_selecting_and_apply_sort_option() throws Throwable {
		Assert.assertEquals(isElementPresent(titleslist.getRefinePage()), true);
	}

	@And("user should be able to click on 'view results' CTA to go back to title list screen to view the updated results based on subject selected")
	public void user_should_be_able_to_click_on_view_results_cta_to_go_back_to_title_list_screen_to_view_the_updated_results_based_on_subject_selected()
			throws Throwable {
		logger.info("user should be able to click on 'view results' CTA");
	}

	@Then("user should be to view refine options for the titles list")
	public void user_should_be_to_view_refine_options_for_the_titles_list() throws Throwable {
		Assert.assertEquals(isElementPresent(titleslist.getTittleList()), true);
	}

	@And("user should be able to view the each refine option collapsed by default")
	public void user_should_be_able_to_view_the_each_refine_option_collapsed_by_default() throws Throwable {
		logger.info("user able to view the each refine option collapsed by default");
	}

	@And("user should be able to expand and view sub options for each refine option available")
	public void user_should_be_able_to_expand_and_view_sub_options_for_each_refine_option_available() throws Throwable {
		titleslist.click_refineExpand();
	}

	@And("user should be able to select a refine option and system should update the results and refiners updated based on that refine option")
	public void user_should_be_able_to_select_a_refine_option_and_system_should_update_the_results_and_refiners_updated_based_on_that_refine_option()
			throws Throwable {

	}

	@And("user should be able to view the selected refine sub option below the refine option")
	public void user_should_be_able_to_view_the_selected_refine_sub_option_below_the_refine_option() throws Throwable {

	}

	@When("user is lands on browser screen")
	public void user_is_lands_on_browser_screen() throws Throwable {
		Assert.assertEquals(isElementPresent(titleslist.getBrowsePage()), true);
	}

	@Then("user should be able to view the selected refiners sub options on the screen as pills")
	public void user_should_be_able_to_view_the_selected_refiners_sub_options_on_the_screen_as_pills()
			throws Throwable {
		if (isElementPresent(titleslist.getAddedDate())) {
			Assert.assertEquals(isElementPresent(titleslist.getAddedDate()), true);
		}

	}

	@And("user is on titles list screen and has applied filters")
	public void user_is_on_titles_list_screen_and_has_applied_filters() throws Throwable {
		titleslist.navigatetoYoungAdult_Fictionlevel1();
		titleslist.clickRefineIcon_btn();
		titleslist.clickAddedDate();
		swipeDown();
		swipeDown();
		swipeDown();

		scrollandCheck(titleslist.General_btn);
		titleslist.clickGeneral();
		scrollandCheck(titleslist.ViewResult);
		titleslist.clickViewResult();
	}

	@And("user should be able to selected title to recommend and view titles listed from the Purchase Request collection")
	public void user_should_be_able_to_selected_title_to_recommend_and_view_titles_listed_from_the_purchase_request_collection()
			throws Throwable {
		titleslist.clickViewResult();
	}

	@When("user is lands on Browser screen with level 3 refiners screen")
	public void user_is_lands_on_browser_screen_with_level_3_refiners_screen() throws Throwable {
		titleslist.clickFriction_level1_btn();
		titleslist.clickRefineIcon_btn();
		titleslist.clickAddedDate();
		scrollandCheck(titleslist.General_btn);
		titleslist.clickGeneral();
		scrollandCheck(titleslist.ViewResult);
		titleslist.clickViewResult();
		if (isElementPresent(titleslist.getTop20())) {
			Assert.assertEquals(isElementPresent(titleslist.getTop20()), true);
		}
	}

	@When("user is lands on browser screen with fiction level 2")
	public void user_is_lands_on_browser_screen_with_fiction_level_2() throws Throwable {
		titleslist.clickFriction_level1_btn();
		titleslist.clickRefineIcon_btn();
		titleslist.clickAddedDate();
		scrollandCheck(titleslist.General_btn);
		titleslist.clickGeneral();
		scrollandCheck(titleslist.ViewResult);
		titleslist.clickViewResult();
		if (isElementPresent(titleslist.YoungAdult_fiction_level1_btn)) {
			Assert.assertEquals(isElementPresent(titleslist.getLevel2()), true);
		}

	}

	@And("system update the refiner section when refiners are removed")
	public void system_update_the_refiner_section_when_refiners_are_removed() throws Throwable {
		logger.info("system update the refiner section when refiners are removed");
	}

	@And("user should be able to view clear all option on the screen when more than one refiner is applied")
	public void user_should_be_able_to_view_clear_all_option_on_the_screen_when_more_than_one_refiner_is_applied()
			throws Throwable {
		titleslist.clickRefineIcon_btn();
		swipeDown();
		swipeDown();
		swipeDown();
		swipeDown();
		if (isElementPresent(titleslist.clearButton)) {
			Assert.assertEquals(isElementPresent(titleslist.clearButton), true);
		}
		titleslist.clickViewResult();
	}

	@And("user should be able to click on clear all CTA and clear all the refiners applied")
	public void user_should_be_able_to_click_on_clear_all_cta_and_clear_all_the_refiners_applied() throws Throwable {
		titleslist.reset();
	}

	@When("user is on refiners screen for the Level {int} subject")
	public void user_is_on_refiners_screen_for_the_level_subject(Integer int1) {
		Assert.assertTrue(titleslist.clickFooterBrowse());
		titleslist.clickFriction_level1_btn();

	}

	@Then("user should be able to view the category section for Level {int} subjects")
	public void user_should_be_able_to_view_the_category_section_for_level_subjects(Integer int1) {

		Assert.assertEquals(isElementPresent(titleslist.getRefineIcon_btn()), true);
	}

	@Then("user should be able to view Level {int} subject selected below the header")
	public void user_should_be_able_to_view_level_subject_selected_below_the_header(Integer int1) {
		Assert.assertEquals(isElementPresent(titleslist.getSelected_refine_list()), false);

	}

	@Then("user should be able to view list of Level {int} subjects for the library")
	public void user_should_be_able_to_view_list_of_level_subjects_for_the_library(Integer int1) {
		if (isElementPresent(titleslist.getTitle_list_level2())) {
			Assert.assertEquals(isElementPresent(titleslist.getTitle_list_level2()), true);
		}

	}

	@Then("user should be able to view {string} selected on landing")
	public void user_should_be_able_to_view_selected_on_landing(String string) {
		titleslist.verifyRefinerSelectedList();
	}

	@Then("user should be able to select level {int} subject and view the level {int} subjects and refiners")
	public void user_should_be_able_to_select_level_subject_and_view_the_level_subjects_and_refiners(Integer int1,
			Integer int2) {
		titleslist.clickRefineIcon_btn();
		Assert.assertTrue(titleslist.verifyCategories());
	}

	@Then("user clicks on back button")
	public void user_clicks_on_back_button() {
		titleslist.clickCancelbtn();
		Assert.assertTrue(titleslist.clickBacktoMenu());
	}

	@Then("system should reset the filters when user selects a new level {int} subjects to navigation")
	public void system_should_reset_the_filters_when_user_selects_a_new_level_subjects_to_navigation(Integer int1) {
		Assert.assertTrue(titleslist.clicktheSubject());
		Assert.assertTrue(titleslist.clickViewResults());

	}

	@Then("user should be able to view and select title sort option for the titles listed")
	public void user_should_be_able_to_view_and_select_title_sort_option_for_the_titles_listed() {
		Assert.assertEquals(isElementPresent(titleslist.getSelected_refine_list()), false);
		titleslist.searchResult();

	}

	@Then("user should be able to view the titles sorted based on publication date by descending order as default")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_publication_date_by_descending_order_as_default() {
		waitFor(1000);
		Assert.assertEquals(isElementPresent(titleslist.getSelected_refine_list()), true);
	}

	@Then("user should be able to view the most recent should be the first")
	public void user_should_be_able_to_view_the_most_recent_should_be_the_first() {
		logger.info("user able to view the most recent should be the first");
	}

	@Given("user select the category in the Fiction")
	public void user_select_the_category_in_the_fiction() {
        titleslist.collapseCategory();
    }

    @And("user should be able to remove refiners applied by clicking X on refiner sub option pill")
    public void user_should_be_able_to_remove_refiners_applied_by_clicking_x_on_refiner_sub_option_pill()
            throws Throwable {
        titleslist.removeDate();
    }

    @And("user is on title list screen for Level 1 or Level 2 subject")
    public void user_is_on_title_list_screen_for_level_1_or_level_2_subject() throws Throwable {
        titleslist.clickFriction_level1_btn();
    }

    @Then("user should be able to view the sub option Purchase Request under refiner option Collections")
    public void user_should_be_able_to_view_the_sub_option_purchase_request_under_refiner_option_collections()
            throws Throwable {
        titleslist.clickRefineIcon_btn();
        titleslist.clickColletionsExpandButton();
        scrollandCheck(titleslist.PurchaseRequest);
        Assert.assertEquals(isElementPresent(titleslist.getPurchaseRequest()), true);
    }


    @When("user clicks on filter option in the list screen")
    public void user_clicks_on_filter_option_in_the_list_screen() {
        titleslist.clickRefineIcon_btn();

    }

    @When("user is on refiners screen for the Level {int}")
    public void user_is_on_refiners_screen_for_the_level(Integer int1) {
        Assert.assertTrue(titleslist.verifyRefinerButton());
    }

    @Then("user should be able to select Level {int} and {int} subject and titles listed and Refiners should be updated based on selection")
    public void user_should_be_able_to_select_level_and_subject_and_titles_listed_and_refiners_should_be_updated_based_on_selection(
            Integer int1, Integer int2) {
        titleslist.cancelRefine();
    }

    @Then("system should reset the filters when user selects a new Level {int} or {int} subjects to navigation")
    public void system_should_reset_the_filters_when_user_selects_a_new_level_or_subjects_to_navigation(Integer int1,
                                                                                                        Integer int2) {
        titleslist.clickRefineIcon_btn();
        Assert.assertTrue(titleslist.clicktheSubject());
        Assert.assertTrue(titleslist.clickViewResults());
    }

    @Then("user should be able to view the category section with Level {int} and {int} subjects")
    public void user_should_be_able_to_view_the_category_section_with_level_and_subjects(Integer int1, Integer int2) {
        Assert.assertTrue(titleslist.verifyCategories());
    }

    @Then("user should be able to view Level {int} and {int} subject selected below the header")
    public void user_should_be_able_to_view_level_and_subject_selected_below_the_header(Integer int1, Integer int2) {
        Assert.assertTrue(titleslist.verifytheListedSubject());
    }

    @Then("user should be able to view list of Level {int} and {int} subjects for the Level {int} subject")
    public void user_should_be_able_to_view_list_of_level_and_subjects_for_the_level_subject(Integer int1, Integer int2,
                                                                                             Integer int3) {

    }

    @Then("user should be able to view All Level {int} subject selected by default on landing and first option in the list")
    public void user_should_be_able_to_view_all_level_subject_selected_by_default_on_landing_and_first_option_in_the_list(
            Integer int1) {

    }

    @When("user clicks on refine icon")
    public void user_clicks_on_refine_icon() throws Throwable {
        titleslist.clickRefineIcon_btn();
    }
	@When("user clicks on Suject")
	public void user_clicks_on_subject()
	{
		titleslist.clickCategory();
	}

	@Then("user is navigated to Category and refiners screen")
    public void user_is_navigated_to_category_and_refiners_screen() throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getSubject_list_1()), true);
    }

    @And("user should be able to view the selected refiners pre populated if refiners are already applied")
    public void user_should_be_able_to_view_the_selected_refiners_pre_populated_if_refiners_are_already_applied()
            throws Throwable {
//		titleslist.cancelRefine();
        logger.info("user should be able to view the selected refiners ");

    }

    @And("user should be able to click on CTA to go back to title list screen to view the updated results based on subject")
    public void user_should_be_able_to_click_on_cta_to_go_back_to_title_list_screen_to_view_the_updated_results_based_on_subject()
            throws Throwable {
        waitFor(1000);
        titleslist.cancelRefine();
        waitFor(1000);
        Assert.assertTrue(titleslist.verifyRefinerButton());
    }

    @And("user should be able to view clear CTA on refiner screen when refiners are applied by the user")
    public void user_should_be_able_to_view_clear_cta_on_refiner_screen_when_refiners_are_applied_by_the_user()
            throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getClear_all()), true);
    }

	@And("user should be able to click on Clear and reset the refiners applied")
	public void user_should_be_able_to_click_on_clear_and_reset_the_refiners_applied() throws Throwable {
		titleslist.reset();
	}


    @And("user should be able to view CTA 'view results'")
    public void user_should_be_able_to_view_cta_view_results() throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getResult_count()), true);
    }

    @And("user will be able to view the number of results based on refiners and level 1 subjects selected in list Page")
    public void user_will_be_able_to_view_the_number_of_results_based_on_refiners_and_level_1_subjects_selected_in_list_page()
            throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getResult_count()), true);
    }

    @And("user should be able to click on 'view results' CTA and go back to title list screen to view the updated results based on subject")
    public void user_should_be_able_to_click_on_view_results_cta_and_go_back_to_title_list_screen_to_view_the_updated_results_based_on_subject()
            throws Throwable {
        titleslist.clickBacktoMenu();
    }

    @Then("user should be able to view refines section for sort and filter Title List Screen")
    public void user_should_be_able_to_view_refines_section_for_sort_and_filter_title_list_screen() {
        Assert.assertTrue(titleslist.getSortTitleList().isDisplayed());
//		Assert.assertTrue(titleslist.getCollectionsTitleList().isDisplayed());
        Assert.assertTrue(titleslist.getAvailableTitleList().isDisplayed());
    }

    @And("user should be able to view level 2 Category section expanded and filter options collapsed by default")
    public void user_should_be_able_to_view_level_2_category_section_expanded_and_filter_options_collapsed_by_default()
            throws Throwable {
        swipeDown();
        swipeDown();
//		titleslist.clickViewResult();
    }

    @And("user should be able to click on CTA to go back to title list screen to view the updated results based on featured list")
    public void user_should_be_able_to_click_on_cta_to_go_back_to_title_list_screen_to_view_the_updated_results_based_on_featured_list()
            throws Throwable {
    }

    @And("user will be able to view the number of results based on refiners and level 2 subjects selected in list Page")
    public void user_will_be_able_to_view_the_number_of_results_based_on_refiners_and_level_2_subjects_selected_in_list_page()
            throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getResult_count()), true);
    }

    @And("user should be able to click on 'view results' CTA and go back to title list screen to view the updated results based on featured List")
    public void user_should_be_able_to_click_on_view_results_cta_and_go_back_to_title_list_screen_to_view_the_updated_results_based_on_featured_list()
            throws Throwable {
        titleslist.clickBacktoMenu();
    }

    @When("user clicks on search icon")
    public void user_clicks_on_search_icon() throws Throwable {
        hideMobileKeyboard();
        search.clickSearchBox();

    }

    @Then("user navigates to search result screen")
    public void user_navigates_to_search_result_screen() throws Throwable {
        waitFor(5000);
        Assert.assertEquals(isElementPresent(titleslist.getadvancedSearchResults()), true);
        titleslist.clickBack();
        titleslist.clickFooterLibrary();
        titleslist.selectEBookTitle();
        swipeDown();
        swipeDown();
        swipeDown();
        swipeDown();
        swipeDown();
        swipeDown();
        Assert.assertEquals(isElementPresent(titleslist.ageRangeInTitleDetils), true);
    }

    @And("user click the search bar and type keyword {string}")
    public void user_click_the_search_bar_and_type_keyword_something(String searchKeyword) throws Throwable {
		search.advanceSearch(searchKeyword);
    }

    @When("user click the search bar and type keyword to place hold in Teen Profile")
    public void user_click_the_search_bar_and_type_keyword_to_place_hold_in_teen_profile() {
//		titleslist.searchTitleinTeen();
        String titleName = titleslist.titleNAME.getText();
        String[] arr = titleName.split(" ");
        String[] titeNameetext = arr[1].split(" ");
        System.out.println("value" + titeNameetext[1]);
        waitFor(2000);
        ClickOnMobileElement(details.getBackButton());
        login.clickFooterMenu();
        login.clickMenuprofile();
        manage.teenprofileSelection();
        login.handleNothankspopup();
        waitFor(3000);
        if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
            search.advanceSearch(titeNameetext[1]);
        } else {
            search.advanceSearch(titleName);
        }

    }

    @When("^user select a CTA on the My Library Page$")
    public void user_select_a_cta_on_the_my_library_page() throws Throwable {
        swipeDown();
        swipeDown();
        swipeDown();
        swipeDown();
        swipeDown();
        swipeDown();
        if (isElementPresent(titleslist.getMagazineNewspaper())) {
            Assert.assertEquals(isElementPresent(titleslist.getMagazineNewspaper()), true);
        }
//		titleslist.clickMagazineNewspaper();
    }

    @Then("^user able to see Tier 1 Page$")
    public void user_able_to_see_tier_1_page() throws Throwable {
        if (isElementPresent(titleslist.getFeaturedContent())) {
            Assert.assertEquals(isElementPresent(titleslist.getFeaturedContent()), true);
        }
    }

    @And("teen user should be able to view audience level \"([\"]*)\" if age range is 5 to 6")
    public void teen_user_should_be_able_to_view_audience_level_something_if_age_range_is_5_to_6(String strArg1)
            throws Throwable {

    }

    @And("teen user should be able to view audience level \"([\"]*)\" if age range is 6 to 7")
    public void teen_user_should_be_able_to_view_audience_level_something_if_age_range_is_6_to_7(String strArg1)
            throws Throwable {

    }

    @And("teen user should be able to view audience level \"([\"]*)\" if age range is 7 to 8")
    public void teen_user_should_be_able_to_view_audience_level_something_if_age_range_is_7_to_8(String strArg1)
            throws Throwable {

    }

    @And("teen user should be able to view audience level \"([\"]*)\" if age range is 8 to 9")
    public void teen_user_should_be_able_to_view_audience_level_something_if_age_range_is_8_to_9(String strArg1)
            throws Throwable {

    }

    @And("teen user should be able to view audience level \"([\"]*)\" if age range is 9 to 11")
    public void teen_user_should_be_able_to_view_audience_level_something_if_age_range_is_9_to_11(String strArg1)
            throws Throwable {

    }

    @And("teen user should be able to view audience level \"([\"]*)\" if age range is 12 to 14")
    public void teen_user_should_be_able_to_view_audience_level_something_if_age_range_is_12_to_14(String strArg1)
            throws Throwable {

    }

    @And("teen user should be able to view audience level \"([\"]*)\" if age range is 15 to 18")
    public void teen_user_should_be_able_to_view_audience_level_something_if_age_range_is_15_to_18(String strArg1)
            throws Throwable {

    }

    @And("system should filter the titles or content for the teen profiles for the mapped age range")
    public void system_should_filter_the_titles_or_content_for_the_teen_profiles_for_the_mapped_age_range()
            throws Throwable {
        logger.info("Teen user should be able to view the titles based on the age range");
        titleslist.clickBack();
        titleslist.clickFooterMenu();
    }

    @When("user clicks on title availabe in library screen")
    public void user_clicks_on_title_availabe_in_library_screen() throws Throwable {
        logger.info("user clicks on title availabe in library screen");
    }

    @Then("user navigates to title details screen")
    public void user_navigates_to_title_details_screen() throws Throwable {
        titleslist.clickFooterLibrary();
        titleslist.selectEBookTitle();
        swipeDown();
        swipeDown();
        swipeDown();
        swipeDown();
        swipeDown();
        titleslist.titleDetails();
        swipeDown();
        swipeDown();
        Assert.assertEquals(isElementPresent(titleslist.ageRangeInTitleDetils), true);
    }

    @And("user click the library option from bottom navigation")
    public void user_click_the_library_option_from_bottom_navigation() throws Throwable {
        logger.info("user click the library option from bottom navigation");
    }

    @When("user clicks on title availabe in myshelf screen")
    public void user_clicks_on_title_availabe_in_myshelf_screen() throws Throwable {
        logger.info("user clicks on title availabe in myshelf screen");
    }

    @When("user clicks on title availabe in brows by subject result screen")
    public void user_clicks_on_title_availabe_in_brows_by_subject_result_screen() throws Throwable {

    }

    @When("user clicks on title availabe in program details screen")
    public void user_clicks_on_title_availabe_in_program_details_screen() throws Throwable {

    }

    @When("user clicks on title availabe in checkout screen")
    public void user_clicks_on_title_availabe_in_checkout_screen() throws Throwable {

    }

    @When("user clicks on title availabe in holds screen")
    public void user_clicks_on_title_availabe_in_holds_screen() throws Throwable {

    }

    @When("user clicks on title availabe in wishlist screen")
    public void user_clicks_on_title_availabe_in_wishlist_screen() throws Throwable {

    }

    @When("user clicks on title availabe in purchase request screen")
    public void user_clicks_on_title_availabe_in_purchase_request_screen() throws Throwable {

    }

    @When("user clicks on title availabe in history screen")
    public void user_clicks_on_title_availabe_in_history_screen() throws Throwable {

    }

    @And("user click the myshelf option from bottom navigation")
    public void user_click_the_myshelf_option_from_bottom_navigation() throws Throwable {

    }

    @And("user click the brows by subject option from bottom navigation")
    public void user_click_the_brows_by_subject_option_from_bottom_navigation() throws Throwable {

    }

    @And("user click the program option from bottom navigation and clicks on program card")
    public void user_click_the_program_option_from_bottom_navigation_and_clicks_on_program_card() throws Throwable {

    }

    @And("user clicks on myshelf option from bottom navigation")
    public void user_clicks_on_myshelf_option_from_bottom_navigation() throws Throwable {

    }

    @And("user click the checkout option from myshelf screen quick navigation")
    public void user_click_the_checkout_option_from_myshelf_screen_quick_navigation() throws Throwable {

    }

    @And("user click the holds option from myshelf screen quick navigation")
    public void user_click_the_holds_option_from_myshelf_screen_quick_navigation() throws Throwable {

    }

    @And("user click the wishlist option from myshelf screen quick navigation")
    public void user_click_the_wishlist_option_from_myshelf_screen_quick_navigation() throws Throwable {

    }

    @And("user click the purchase request option from myshelf screen quick navigation")
    public void user_click_the_purchase_request_option_from_myshelf_screen_quick_navigation() throws Throwable {

    }

    @And("user click the history option from myshelf screen quick navigation")
    public void user_click_the_history_option_from_myshelf_screen_quick_navigation() throws Throwable {

    }

    @And("teen user should not be able to view audience level and age range which is not defined in the Axis 360 system for teen user")
    public void teen_user_should_not_be_able_to_view_audience_level_and_age_range_which_is_not_defined_in_the_axis_360_system_for_teen_user()
            throws Throwable {

    }

    @And("system should not filter the titles for the irrespective of user profile type and age level or audience mapping for the features where defined otherwise")
    public void system_should_not_filter_the_titles_for_the_irrespective_of_user_profile_type_and_age_level_or_audience_mapping_for_the_features_where_defined_otherwise()
            throws Throwable {

    }

    @When("user click on hold CTA in title details screen if the titles is available to place on hold")
    public void user_click_on_hold_cta_in_title_details_screen_if_the_titles_is_available_to_place_on_hold()
            throws Throwable {
		waitFor(1000);
		swipeDown();
        titleslist.clickPlaceHoldCTA();
    }

    @Then("user should be able to view the popup for informing user that title has already been placed on hold by other mapped profile")
    public void user_should_be_able_to_view_the_popup_for_informing_user_that_title_has_already_been_placed_on_hold_by_other_mapped_profile()
            throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getViewPopup()), true);
    }

    @And("user clicks on title card")
    public void user_clicks_on_title_card() throws Throwable {

    }

    @And("user should able to view add to wishlist CTA in popup")
    public void user_should_able_to_view_add_to_wishlist_cta_in_popup() throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getAddtoWishlist()), true);
    }

    @And("user should be able to click on 'X' icon to dismiss the popup")
    public void user_should_be_able_to_click_on_x_icon_to_dismiss_the_popup() throws Throwable {
        titleslist.clickBack();
        logger.info("user navigated back to the title screen");
    }

    @And("user should navigate back to the title screen")
    public void user_should_navigate_back_to_the_title_screen() throws Throwable {

    }

    @And("user lands on library screen page")
    public void user_lands_on_library_screen_page() throws Throwable {
        login.handleNothankspopup();
        titleslist.clickFooterLibrary();

    }

    @When("user clicks checkout cta for ebook title in title details screen")
    public void user_clicks_checkout_cta_for_ebook_title_in_title_details_screen() throws Throwable {
        titleslist.clicktitleitem();
        titleslist.clickCheckout();
    }

    @Then("user should be able to view the popup for informing user that title has already been checked out by other mapped profile")
    public void user_should_be_able_to_view_the_popup_for_informing_user_that_title_has_already_been_checked_out_by_other_mapped_profile()
            throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getViewPopup()), true);
    }

    @And("user clicks on title card in always available carousal")
    public void user_clicks_on_title_card_in_always_available_carousal() throws Throwable {
        swipeDown();
        Assert.assertEquals(isElementPresent(titleslist.getAlwayAvailable()), true);
        titleslist.clickTitleCard();
    }

    @And("user should be able to view add to Wishlist CTA")
    public void user_should_be_able_to_view_add_to_wishlist_cta() throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getAddtoWishlist()), true);
    }

    @And("user should be able to click on 'Add to Wishlist' CTA to add the title to Wishlist for that profile")
    public void user_should_be_able_to_click_on_add_to_wishlist_cta_to_add_the_title_to_wishlist_for_that_profile()
            throws Throwable {
        titleslist.clickAddtoWishlist();
    }

    @And("user should be able to click on 'X' icon to dismiss the popup and navigate back to the title screen")
    public void user_should_be_able_to_click_on_x_icon_to_dismiss_the_popup_and_navigate_back_to_the_title_screen()
            throws Throwable {
        titleslist.clickBack();
        logger.info("user navigated back to the title screen");
    }

    @And("user logged out of the application page")
    public void user_logged_out_of_the_application_page() throws Throwable {
        titleslist.clickFooterMenu();
        titleslist.clickSignout();
        titleslist.clickSignoutYes();
    }

    @And("user clicks on title card in curated carousal")
    public void user_clicks_on_title_card_in_curated_carousal() throws Throwable {
        swipeDown();
        Assert.assertEquals(isElementPresent(titleslist.getAlwayAvailable()), true);
        titleslist.clickTitleCard();
    }

    @And("user clicks on myshelf option in bottom navigation")
    public void user_clicks_on_myshelf_option_in_bottom_navigation() throws Throwable {
        login.handleNothankspopup();
        titleslist.clickFooterMyShelf();
    }

    @And("user lands on myshelf screen")
    public void user_lands_on_myshelf_screen() throws Throwable {

    }

    @And("user clicks on any title card")
    public void user_clicks_on_any_title_card() throws Throwable {

    }

    @Then("general adult user should be able to browse all the titles or content Which is for the teen profiles")
    public void general_Adult_User_Should_Be_Able_To_Browse_All_The_Titles_Or_Content_Which_Is_For_The_Teen_Profiles() {
        logger.info("Adult user should be able to view the all the titles");
        titleslist.clickBack();
        titleslist.clickFooterMenu();
    }

    @And("Start to type your And step here user clicks on title available in library screen")
    public void start_To_Type_Your_And_Step_Here_User_Clicks_On_Title_Available_In_Library_Screen() {
        titleslist.getTeenTitle();
    }

    @When("user lands on title details screen")
    public void user_Lands_On_Title_Details_Screen() {
        logger.info("user lands on title details screen");
    }

    @Then("general adult user should be able to view titles or content Which is for the teen profiles in library screen")
    public void general_Adult_User_Should_Be_Able_To_View_Titles_Or_Content_Which_Is_For_The_Teen_Profiles_In_Library_Screen() {
        logger.info("Adult user should be able to view teen titles");
        titleslist.clickBack();
        titleslist.clickFooterMenu();
    }

    @And("user clicks on title available in myshelf screen")
    public void user_Clicks_On_Title_Available_In_Myshelf_Screen() {
        titleslist.myshelftitle();
    }

    @Then("general adult user should be able to view titles or content Which is for the teen profiles in myshelf screen")
    public void general_Adult_User_Should_Be_Able_To_View_Titles_Or_Content_Which_Is_For_The_Teen_Profiles_In_Myshelf_Screen() {
        logger.info("Adult user should be able to view teen titles");
        titleslist.clickBack();
        titleslist.clickFooterMenu();
    }

    @And("teen user should be able to view audience level {string} if age range is {int} to {int}")
    public void teen_User_Should_Be_Able_To_View_Audience_Level_If_Age_Range_IsTo(String arg0, int arg1, int arg2) {
        logger.info("Teen user should be able to view title based on the age of audience level");
    }

    @Then("user able to see Featured content in the Tier 1 page as card carousel")
    public void user_able_to_see_featured_content_in_the_tier_1_page_as_card_carousel() throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getFeaturedContent()), true);
    }

    @And("user navigates to my library screen")
    public void user_navigates_to_my_library_screen() throws Throwable {
        login.handleNothankspopup();
        titleslist.clickFooterLibrary();
    }

    @And("user should be able to select a cta on the my library page or tier 2 page")
    public void user_navigates_to_tier_2_page() throws Throwable {

        titleslist.clickTitleImage();

    }

    @And("user should be able to tap on 'See All' option and navigate to 'list page' Tier 2 for each carousel")
    public void user_should_be_able_to_tap_on_See_All_option() throws Throwable {

        if (isElementPresent(titleslist.getlistPageTier1())) {
            titleslist.clickNewsPaperSeeAllLink();
            waitFor(4000);
        }

    }

    @And("user should be able to view the tier 3 Page as defined in the cms")
    public void user_navigates_to_tier_3_page_as_defined_in_the_cms() throws Throwable {
        if (isElementPresent(titleslist.getThirdPartyDesc())) {
            Assert.assertEquals(isElementPresent(titleslist.getThirdPartyDesc()), true);
            logger.info(titleslist.getThirdPartyDesc().getText());
        }

    }

    @Then("user should be able to view the Newspaper from third party as 'Item carousel' on landing screen")
    public void user_should_be_able_view_newspaper_from_third_partu_as_item_carousel() throws Throwable {
        waitFor(10000);
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
//			MobileElement newsPapers = (MobileElement) DriverManager.getDriver()
//					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"NEWSPAPERS & MAGAZINES\")"));
            for (int i = 0; i <= 7; i++) {

                swipeDown();
            }
        }
        if (isElementPresent(titleslist.getMagazineNewspaper())) {
            Assert.assertEquals(isElementPresent(titleslist.getMagazineNewspaper()), true);
            logger.info(titleslist.getMagazineNewspaper().getText());
        }

    }

    @And("user should be able to tap on any category and should navigate to 'list page' Tier 1 for that category")
    public void user_should_be_able_tap_on_any_category_and_should_navigate_to_list_page_tier_1_for_category()
            throws Throwable {
        for (int i = 0; i <= 5; i++) {

            swipeDown();
        }
        titleslist.clickNewsPaperSeeAllLink();
        waitFor(4000);
        if (isElementPresent(titleslist.getlistPageTier1())) {
            Assert.assertEquals(isElementPresent(titleslist.getlistPageTier1()), true);
        }
    }

    @And("user should be able to view brief description for the learning resources and fun activities section")
    public void user_should_be_able_view_brief_description_for_the_learning_resources_and_fun_activities_section()
            throws Throwable {
        if (isElementPresent(titleslist.getThirdPartyDesc())) {
            Assert.assertEquals(isElementPresent(titleslist.getThirdPartyDesc()), true);
            logger.info(titleslist.getThirdPartyDesc().getText());
        }

    }

    @And("user should be able to view the title and thumbnail images of the titles in carousel")
    public void user_should_be_able_view_the_title_and_thumbail_images_of_the_title_in_carousel() throws Throwable {
        if (isElementPresent(titleslist.getThirdPartyTitle())) {
            Assert.assertEquals(isElementPresent(titleslist.getThirdPartyTitle()), true);
            Assert.assertEquals(isElementPresent(titleslist.getThirdPartyImage()), true);
        }
    }

    @And("user should be able to tap on any title image and should navigate to detailed page Tier 3")
    public void user_should_be_able_to_tap_on_any_title_image() throws Throwable {

        titleslist.clickTitleImage();
    }

    @And("user should be able to view download CTA to download the title")
    public void user_should_be_able_view_download_CTA_to_download_the_title() throws Throwable {
        if (isElementPresent(titleslist.getThirdPartyDownloadCTA())) {
            Assert.assertEquals(isElementPresent(titleslist.getThirdPartyDownloadCTA()), true);

        }
    }

    @And("user should be able to view download CTA to download the title and click on download CTA")
    public void user_should_be_able_view_download_CTA_to_download_the_title_and_click_on_download_CTA()
            throws Throwable {

        if (isElementPresent(titleslist.getThirdPartyDownloadCTA())) {
            Assert.assertEquals(isElementPresent(titleslist.getThirdPartyDownloadCTA()), true);
            titleslist.clickTitleDownloadCTA();
            waitFor(4000);
        }
    }

    @And("user should be able to view 'read now' and click 'read now' CTA to read the content")
    public void user_should_be_able_view_read_now_and_click_read_now_CTA_to_read_the_content() throws Throwable {
        if (isElementPresent(titleslist.getthirdPartyReadNowCTA())) {
            Assert.assertEquals(isElementPresent(titleslist.getthirdPartyReadNowCTA()), true);
        }
    }

    @And("User should be able to see Featured content in the 'Tier 1' page as 'card carousel'")
    public void user_should_be_able_see_featured_content_int_the_Tier_1_page_as_card_carousel() throws Throwable {

    }

    @Then("user able to navigate to Tier 2 list page")
    public void user_able_to_navigate_to_tier_2_list_page() throws Throwable {
        titleslist.clickMagazineSeeAll();
        logger.info("User is in the Tier-2 page");
    }

    @And("user able to view download CTA to download the title")
    public void user_able_to_view_download_cta_to_download_the_title() throws Throwable {
        Assert.assertEquals(isElementPresent(titleslist.getDownloadButton()), true);
    }

    @And("user able to view list of titles in download CTA")
    public void user_able_to_view_list_of_titles_in_download_cta() throws Throwable {
        for (int i = 1; i <= checkout.getCheckedout_titles_hdr().size(); i++) {
            if (i == 2)
                break;
            Assert.assertEquals(isElementPresent(checkout.getCheckedout_titles_hdr().get(i)), true);
        }
    }

    @When("user click on read now CTA to read the content")
    public void user_click_on_read_now_cta_to_read_the_content() throws Throwable {
        titleslist.clickContinue_Btn();
    }

    @And("user able to read the content")
    public void user_able_to_read_the_content() throws Throwable {
        logger.info("User able to read the content");
    }

    @And("user able to view the Newspaper from third party as Item carousel")
    public void user_able_to_view_the_newspaper_from_third_party_as_item_carousel() throws Throwable {
        titleslist.clickMagazineSeeAll();
        logger.info("user able to view the Newspaper");
    }

    @And("user select a News paper see all from Tier 1 Page")
    public void user_select_a_news_paper_see_all_from_tier_1_page() throws Throwable {

        if (isElementPresent(titleslist.getlistPageTier1())) {
            titleslist.clickNewsPaperSeeAllLink();
        }
    }

    @And("user selects a news paper")
    public void user_selects_a_news_paper() throws Throwable {

        titleslist.clickTitleImage();

    }

    @And("user navigated to Tier 3 page")
    public void user_navigated_to_tier_3_page() throws Throwable {
        if (isElementPresent(titleslist.getThirdPartyDownloadCTA())) {
            Assert.assertEquals(isElementPresent(titleslist.getThirdPartyDownloadCTA()), true);
        }
    }

    @And("Kid user should be able to view audience level {string} if age range is {int} to {int}")
    public void kid_User_Should_Be_Able_To_View_Audience_Level_If_Age_Range_IsTo(String arg0, int arg1, int arg2) {
        logger.info("Kid user should be able to view title based on the age of audience level");
    }

    @Given("user click the search bar and type keyword {string} to place hold in Adult Profile")
    public void user_click_the_search_bar_and_type_keyword_to_place_hold_in_adult_profile(String string) {

    }

    @And("system should filter the titles or content for the kid profiles for the mapped age range")
    public void system_Should_Filter_The_Titles_Or_Content_For_The_Kid_Profiles_For_The_Mapped_Age_Range() {
        logger.info("Kid user should be able to view the titles based on the age range");
        titleslist.clickBack();
        titleslist.clickFooterMenu();
    }

    @And("user clicks the title and navigate to the title details screen")
    public void user_Clicks_The_Title_And_Navigate_To_The_Title_Details_Screen() {
        titleslist.clicktitleitem();
    }

    @And("user checked out the magazine/newspaper")
    public void user_checked_out_the_magazinenewspaper() throws Throwable {
        for (int i = 1; i <= checkout.getCheckedout_titles_hdr().size(); i++) {
            if (i == 2)
                break;
            Assert.assertEquals(isElementPresent(checkout.getCheckedout_titles_hdr().get(i)), true);
        }
    }

    @And("user should view the download CTA in the newspaper carousel")
    public void user_should_click_the_download_CTA_in_the_newspaper_carousel() throws Throwable {
        if (isElementPresent(titleslist.getNewsPaperDownloadCTA())) {
            Assert.assertEquals(isElementPresent(titleslist.getNewsPaperDownloadCTA()), true);
            logger.info(titleslist.getNewsPaperDownloadCTA().getText());
        }
    }

    @And("user able to see the READ NOW CTA once after download is complete")
    public void user_able_to_see_the_list_of_magazinenewspaper_in_the_download_cta() throws Throwable {
        logger.info("Read Now CTA won't be displayed until we click on Download CTA in Automation");
    }

}
