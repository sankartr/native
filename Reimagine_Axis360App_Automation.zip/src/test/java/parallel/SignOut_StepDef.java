package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.AboutandLegel;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.SetParentPin;

public class SignOut_StepDef extends CommonActions {
	
	LoginPage login = new LoginPage(DriverManager.getDriver());
	SetParentPin setPin = new SetParentPin(DriverManager.getDriver());
	ManageProfile manageProf = new ManageProfile(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	
/************************124458******************************/
	
	@When("user clicks on signout cta")
    public void user_clicks_on_signout_cta() throws Throwable {
		menu.signout();
    }

    @Then("user should be able to see confirmation popup for sign")
    public void user_should_be_able_to_see_confirmation_popup_for_sign() throws Throwable {
            Assert.assertEquals(login.logoutConfirmationPop(), true);
    	}

    @And("user should remain on menu page if user clicks No on confirmation pop-up")
    public void user_should_remain_on_menu_page_if_user_clicks_no_on_confirmation_popup() throws Throwable {
    	waitFor(1000);
        login.clickSignOutNoBtn();
//        Assert.assertEquals(login.logoutClickOnNobtn(), true);
    }

    @And("user should be able to sign Out and navigate to login screen on confirmation")
    public void user_should_be_able_to_sign_out_and_navigate_to_login_screen_on_confirmation() throws Throwable {
        login.clickSignout();
        login.clickSignOutYesBtn();
        Assert.assertEquals(login.getSignIn_txt_libId().isDisplayed(), true);
        logger.info("User is on login page");
    }

}
