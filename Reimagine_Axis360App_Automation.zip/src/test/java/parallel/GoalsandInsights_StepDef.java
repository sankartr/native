package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.GoalsandInsights;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.MyShelf;
import pom.kidszone.ProfileCreation;
import pom.kidszone.SetParentPin;

public class GoalsandInsights_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	SetParentPin setPin = new SetParentPin(DriverManager.getDriver());
	ManageProfile manageProf = new ManageProfile(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	GoalsandInsights goals = new GoalsandInsights(DriverManager.getDriver());
	MyShelf myShelf = new MyShelf(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	ManageProfile manage =new ManageProfile(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	/************************ 124489 ******************************/

	@When("user navigates to my shelf screen")
	public void user_navigates_to_my_shelf_screen() throws Throwable {
		goals.clickOnMyshelfFooter();
	}
	
	@When("user navigates to my shelf screen after profile selection")
	public void user_navigates_to_my_shelf_screen_after_profile_selection() throws Throwable {
		login.handleNothankspopup();
		goals.clickOnMyshelfFooter();
	}

	@Then("user should be able to view insights and goals and badges with adult profile theme")
	public void user_should_be_able_to_view_insights_and_goals_and_badges_with_adult_profile_theme() throws Throwable {
		logger.info("Adult Theme validation");
	}

	@And("insights and badges are enabled for the library and user profile preferences")
	public void insights_and_badges_are_enabled_for_the_library_and_user_profile_preferences() throws Throwable {
//		setPin.parentPin();
	}

	@And("user should be able to view badges based on profile type")
	public void user_should_be_able_to_view_badges_based_on_profile_type() throws Throwable {
		Assert.assertEquals(isElementPresent(goals.getBadgesPg_lbl_header()), true);
		logger.info("user able to see badges");
	}

	@And("adult profile and teen profile will have badges with same art and kids badges will have badges different art")
	public void adult_profile_and_teen_profile_will_have_badges_with_same_art_and_kids_badges_will_have_badges_different_art()
			throws Throwable {
logger.info("dult profile and teen profile will have badges with same art and kids badges");
	}

	@And("user should be able to expand and collapse the insights and badges accordingly")
	public void user_should_be_able_to_expand_and_collapse_the_insights_and_badges_accordingly() throws Throwable {
		goals.hideGoalandInsight();
		goals.hideGoalandInsight();
		logger.info("user should be able to expand and collapse the insights and badges accordingly");
	}

	@And("system should remember the expand state set by the user")
	public void system_should_remember_the_expand_state_set_by_the_user() throws Throwable {
		logger.info("Goal display state is changed");
	}

	@And("system should load the insights and badges according in the state set by the user")
	public void system_should_load_the_insights_and_badges_according_in_the_state_set_by_the_user() throws Throwable {
		logger.info("system should load the insights and badges according");
	}

	@And("user should be able to scroll insights and goals and badges left and right as a carousel")
	public void user_should_be_able_to_scroll_insights_and_goals_and_badges_left_and_right_as_a_carousel()
			throws Throwable {
		if(isElementPresent(goals.getBadgesPg_icon_badges().get(0))) {
		horizontalSwipe(goals.getBadgesPg_icon_badges());
		}
	}

	@And("user should be able to view earned as well as not earned badges")
	public void user_should_be_able_to_view_earned_as_well_as_not_earned_badges() throws Throwable {
	//	Assert.assertTrue(goals.getBadgesPg_icon_badges().size()!=0);
		logger.info("user able to see all the badges");
	}

	@And("user should view not earned badges as greyed out")
	public void user_should_view_not_earned_badges_as_greyed_out() throws Throwable {
		logger.info("BG validation can not be done");
	}

	@Then("user should be able to view insights and goals and badges with teen profile theme")
	public void user_should_be_able_to_view_insights_and_goals_and_badges_with_teen_profile_theme() throws Throwable {
		logger.info("Themeing validation cannot be done");
	}

	@Then("user should be able to view insights and goals and badges with kid profile theme")
	public void user_should_be_able_to_view_insights_and_goals_and_badges_with_kid_profile_theme() throws Throwable {
		logger.info("Themeing validation cannot be done");		
	}

	/************************ 124490 ******************************/

	@Then("user should able to see drawer in mobile to set the goal")
	public void user_should_able_to_see_drawer_in_mobile_to_set_the_goal() throws Throwable {
		Assert.assertEquals(isElementPresent(goals.getSetGoalPg_lbl_Header()), true);
	}

	@And("insights goals and badges are enabled for the library")
	public void insights_goals_and_badges_are_enabled_for_the_library() throws Throwable {
		goals.clickOnMyshelfFooter();
//		Assert.assertEquals(isElementPresent(goals.getMyShelfPg_lbl_GoalsHeader()), true);		
	}

	@And("goal is not set for an insight")
	public void goal_is_not_set_for_an_insight() throws Throwable {
		swipeUp();
		goals.clickOnInsight("AverageRead");
		goals.removeGoal();
//		touchCenter();
		swipeDown();
	}

	@And("user should able to enter the input and set the goal for the insight")
	public void user_should_able_to_enter_the_input_and_set_the_goal_for_the_insight() throws Throwable {
		goals.setgoal();
	}

	@Then("user should able to view message as Goal Created! toast color should be green")
    public void user_should_able_to_view_message_as_goal_created_toast_color_should_be_green() throws Throwable {
       logger.info("should able to view message as Goal Created!");
    }

    @And("user should able to input and set the goal for the insight")
    public void user_should_able_to_input_and_set_the_goal_for_the_insight() throws Throwable {
        goals.setgoal();
    }
    
    @And("user should able to view metrics for the goals on the widget instead of insights once goal is set")
    public void user_should_able_to_view_metrics_for_the_goals_on_the_widget_instead_of_insights_once_goal_is_set() throws Throwable {
        logger.info("User able to see the metric in widget");
    }
    
    @And("user is in mins of reading per day goal drawer or popup screen")
    public void user_is_in_mins_of_reading_per_day_goal_drawer_or_popup_screen() throws Throwable {
    	myShelf.getMyShelf_lbl_footer().click();
    	goals.clickOnReadInsight();
    }
    
    @When("user is able to view metrics for the goals")
    public void user_is_able_to_view_metrics_for_the_goals() throws Throwable {
    	logger.info("user is able to view metrics for the goals");
    }
    
    @And("user enters input as 0 or more than 999")
    public void user_enters_input_as_0_or_more_than_999() throws Throwable {
        goals.enterWrongMetric();
    }

    @Then("user should able to view inline error message 'Please enter a whole number between 1 and 999' in red color")
    public void user_should_able_to_view_inline_error_message_please_enter_a_whole_number_between_1_and_999_in_red_color() throws Throwable {
        Assert.assertEquals(goals.getSetGoalPg_lbl_WrongMetricError().isDisplayed(), true);
        logger.info("User is able to see the wrong input error");
    }

    @And("user is in mins of listening per day goal drawer or popup screen")
    public void user_is_in_mins_of_listening_per_day_goal_drawer_or_popup_screen() throws Throwable {
    	login.handleNothankspopup();
    	myShelf.clickMyself();
    	goals.clickOnInsight("AverageListen");
    }

    @Then("user should able to view inline error message 'Please enter a whole number between 1 and 365' in red color")
    public void user_should_able_to_view_inline_error_message_please_enter_a_whole_number_between_1_and_365_in_red_color() throws Throwable {
    	 Assert.assertEquals(goals.getSetstreakGoalPg_lbl_WrongMetricError().isDisplayed(), true);
         logger.info("User is able to see the wrong input error");
    }
    @And("user is in streak goal drawer or popup screen")
    public void user_is_in_streak_goal_drawer_or_popup_screen() throws Throwable {
    	login.handleNothankspopup();
    	myShelf.clickMyself();
		waitFor(2000);
    	goals.clickOnInsight("Current Streak");
    }

    @And("user enters input as 0 or more than 365")
    public void user_enters_input_as_0_or_more_than_365() throws Throwable {
    	goals.enterWrongMetric();
    }
    
    @And("user is in monthly goal drawer or popup screen")
    public void user_is_in_monthly_goal_drawer_or_popup_screen() throws Throwable {
    	myShelf.clickMyself();
        goals.clickOnInsight("MonthlyGoal");
    }
    
    @Then("user should able to view inline error message in red color")
    public void user_should_able_to_view_inline_error_message_in_red_color() throws Throwable {
    	if(isElementPresent(goals.getSetyearlyGoalPg_lbl_WrongMetricError())) {
    	Assert.assertEquals(goals.getSetyearlyGoalPg_lbl_WrongMetricError().isDisplayed(), true);
    	}
        logger.info("User is able to see the wrong input error");
    }

    @And("user is in yearly goal drawer or popup screen")
    public void user_is_in_yearly_goal_drawer_or_popup_screen() throws Throwable {
    	goals.clickOnMyshelfFooter();
        goals.clickOnInsight("AverageRead");
    }

    @And("user enters input as 0 or more than 9999")
    public void user_enters_input_as_0_or_more_than_9999() throws Throwable {
        goals.enterWrongMetric();
    }
    
	/************************ 124491 ******************************/

	@Given("insights and goals and badges are enabled for the profile or library")
	public void insights_and_goals_and_badges_are_enabled_for_the_profile_or_library() {
		logger.info("Insights and goals are enabled for this library with this user");
		for(int i=0;i<4;i++)
		{
		swipeDown();	
		}

	}

	@And("insights and goals are enabled in the user profile preferences")
	public void insights_and_goals_are_enabled_in_the_user_profile_preferences() {
//		login.handleNothankspopup();
	//	profile.enableInsigihtandBadgesCheckbox();
		logger.info("goal is enabled for user from the backend");
	}

	@And("goal is set for an insight")
	public void goal_is_set_for_an_insight() throws Exception {
		goals.getHomePg_btn_myLibFooter();
		goals.clickOnMyshelfFooter();
		goals.clickOnInsight("Average Read");
	}

	@When("user clicks on insights widget")
	public void user_clicks_on_insights_widget() {
		goals.clickOnInsight();
	}

	@Then("user should be able to see drawer or pop-up to update the goal")
	public void user_should_be_able_to_see_drawer_or_pop_up_to_update_the_goal() {
		Assert.assertEquals(goals.setGoalsDrawerCheck(), true);
	}

	@Then("user should be able to input and set new goal")
	public void user_should_be_able_to_input_and_set_new_goal() throws Exception {
		goals.setgoal();
	}

	@Then("user should be able to view metrics for the new goal set")
	public void user_should_be_able_to_view_metrics_for_the_new_goal_set() {
		Assert.assertEquals(isElementPresent(goals.getMyShelfPg_lbl_GoalTrackNum()), true);
		logger.info("User is able to see the metric");
	}

	@Then("application should display the confirmation toast message for successful goal set")
	public void application_should_display_the_confirmation_toast_message_for_successful_goal_set() {
		logger.info("Goal set successfully");
	}

	@Then("user should able to view error message for invalid input")
	public void user_should_able_to_view_error_message_for_invalid_input() throws Exception {
		goals.enterWrongMetric();
		Assert.assertEquals(isElementPresent(goals.getSetGoalPg_lbl_WrongMetricError()), true);
		logger.info("User is able to see the error msg");
	}

	@Then("user should able to view the entered inputs along with Remove Goal cta")
	public void user_should_able_to_view_the_entered_inputs_along_with_remove_goal_cta() {
		Assert.assertEquals(goals.getSetGoalPg_btn_RemoveGoal().isDisplayed(), true);
		Assert.assertEquals(goals.getSetGoalPg_txt_setGoal().getText() != null, true);
		logger.info("User is on set goal page");
	}

	@Then("user click on Remove Goal cta")
	public void user_click_on_remove_goal_cta() {
		goals.clickOnRemoveGoalBtn();
	}

	@Then("system should able to remove the goal")
	public void system_should_able_to_remove_the_goal() {
		goals.clickOnInsight();
	}

	@Then("user should able to view the entered inputs")
	public void user_should_able_to_view_the_entered_inputs() {
	//	Assert.assertEquals(goals.getSetGoalPg_txt_setGoal().getText() != null, true);
	}

	@Then("user should able to reenter the value")
	public void user_should_able_to_reenter_the_value() throws Exception {
		goals.setgoal();
	}

	@Then("system should able to update the goal value")
	public void system_should_able_to_update_the_goal_value() {
		System.out.println("able to update the goal value");
	}

	@Then("user should able to view the goal drawer")
	public void user_should_able_to_view_the_goal_drawer() {
	//	Assert.assertEquals(goals.setGoalsDrawerCheck(), true);
	}

	@Then("user click on out side of the goal drawer")
	public void user_click_on_out_side_of_the_goal_drawer() {
		//swipeDown();
	}

	@Then("system should close the goal drawer")
	public void system_should_close_the_goal_drawer() {
	//	Assert.assertEquals(goals.setGoalsDrawerCheck(), false);
	}

	/************************ 124728 ********************************/

	@Then("user should be able to see popup with remove goal cta")
	public void user_should_be_able_to_see_popup_with_remove_goal_cta() throws Throwable {
		logger.info("user should be able to see popup");
	}

	@And("user should be able to click on the remove goal cta to remove the goal set and view insight metrics on the widget")
	public void user_should_be_able_to_click_on_the_remove_goal_cta_to_remove_the_goal_set_and_view_insight_metrics_on_the_widget()
			throws Throwable {
		goals.clickOnRemoveGoalBtn();
	}

	@And("application should display the confirmation toast message for successful removal of goal")
	public void application_should_display_the_confirmation_toast_message_for_successful_removal_of_goal()
			throws Throwable {
		logger.info("user able to see toast message");
	}

	@When("insights and goals are disabled for the kid profile")
	public void insights_and_goals_are_disabled_for_the_kid_profile() throws Throwable {
		manageProf.clickProfileImage();
		profile.disableAllOptionsinMyProfilePg();
		logger.info("goals and insights is disabled for this specific user");
	}

	@When("insights and goals are disabled for the teen profile")
	public void insights_and_goals_are_disabled_for_the_teen_profile() throws Throwable {
		manageProf.clickProfileImage();
		profile.disableAllOptionsinMyProfilePg();
		logger.info("goals and insights is disabled for this specific user");
	}
	
	@When("insights and goals are disabled for the adult profile")
	public void insights_and_goals_are_disabled_for_the_adult_profile() throws Throwable {
		logger.info("goals and insights is disabled for this specific user");
	}
	
	@Then("user should not be able to view the insights and goals section")
	public void user_should_not_be_able_to_view_the_insights_and_goals_section() throws Throwable {
		myShelf.clickMyself();
		logger.info("User not able to see goals and insights");
	}

	@Then("user clicks outside the popup")
	public void user_clicks_outside_the_popup() throws Throwable {
		swipeDown();;
		logger.info("user tapped on center");
	}

	@And("user clicks on any of the insights")
	public void user_clicks_on_any_of_the_insights() throws Throwable {
		goals.clickOnInsight();
	}

	@And("remove popup is displayed")
	public void remove_popup_is_displayed() throws Throwable {
		logger.info("User able to see set/remove goal popup");
	}

	@And("user should able to view the popup closed when user click outside the remove goal popup")
	public void user_should_able_to_view_the_popup_closed_when_user_click_outside_the_remove_goal_popup()
			throws Throwable {
		Assert.assertEquals(isElementPresent(goals.getSetGoalPg_lbl_Header()), false);
		logger.info("User not able to see set/remove goal popup");
	}
	 @When("user tap on my shelf from bottom navigation bar")
	    public void user_tap_on_my_shelf_from_bottom_navigation_bar() throws Throwable {
	       myShelf.clickMyself();
	    }

	    @Then("user should be able to view average listened badge")
	    public void user_should_be_able_to_view_average_listened_badge() throws Throwable {
	    	Assert.assertEquals(isElementPresent(goals.getBadgesPg_lbl_header()), true);
	    }

	    @And("user should enable 'Insights & Badges' from the profile detail screen")
	    public void user_should_enable_insights_badges_from_the_profile_detail_screen() throws Throwable {
	       profile.clickBackbutton();
			swipeDown();
			swipeDown();
	       profile.enableInsight();
	       
	    }

	    @And("user should be able to view current streak badge")
	    public void user_should_be_able_to_view_current_streak_badge() throws Throwable {
	    Assert.assertTrue(goals.checkstreak());
	    }

	    @And("user should be able to view books listened this month badge")
	    public void user_should_be_able_to_view_books_listened_this_month_badge() throws Throwable {
	    	Assert.assertTrue(goals.checkMonthygoal());  
	    }

	    @And("user should be able to view books listened this year badge")
	    public void user_should_be_able_to_view_books_listened_this_year_badge() throws Throwable {
	    	Assert.assertTrue(goals.checkyearlyGoal());
	    }
	    @Then("user should not be able to view  Books read this year badge")
	    public void user_should_not_be_able_to_view_books_read_this_year_badge() throws Throwable {
	    	Assert.assertEquals(isElementPresent(goals.getMyShelfPg_btn_AvgReadInsight()), false);
	    }

	    @And("user should not be able to view Books read This month badge")
	    public void user_should_not_be_able_to_view_books_read_this_month_badge() throws Throwable {
	    	Assert.assertEquals(isElementPresent(goals.getMyShelfPg_btn_AvgReadInsight()), false);
	    }


	    @And("user should disabled 'Insights & Badges' from the profile detail screen")
	    public void user_should_disabled_insights_badges_from_the_profile_detail_screen() throws Throwable {
	    	profile.clickBackbutton();
			profile.disableInsight();
	    }


}
