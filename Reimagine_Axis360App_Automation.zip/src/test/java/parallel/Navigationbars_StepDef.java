package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.GoalsandInsights;
import pom.kidszone.LoginPage;
import pom.kidszone.MyShelf;
import pom.kidszone.Navigationbars;
import pom.kidszone.Preference;

public class Navigationbars_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	Navigationbars navigation = new Navigationbars(DriverManager.getDriver());
	Preference preference = new Preference(DriverManager.getDriver());
	GoalsandInsights goals= new GoalsandInsights(DriverManager.getDriver());
	MyShelf myself=new MyShelf(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	@When("user lands on my library screen")
	public void user_lands_on_my_library_screen() {
	//	waitFor(2000);
		navigation.click_NavmyshelfScreen();
		navigation.getNavigation_bottommenu_Library().click();
	}

	@Then("user should be able to view search bar and input keyword to initiate the search")
	public void user_should_be_able_to_view_search_bar_and_input_keyword_to_initiate_the_search() {
		navigation.titleSearch();
	}

	@Then("Verify the cancel cta should be available when user input keyword in search bar")
	public void verify_the_cancel_cta_should_be_available_when_user_input_keyword_in_search_bar() {
		Assert.assertTrue(navigation.verify_closeCTA());
	}

	@When("user lands on home screen")
	public void user_lands_on_home_screen() throws Throwable {
		Assert.assertEquals(login.homePgNav(), true);
	}

	@Then("user should be able to view updated bottom navigation bar")
	public void user_should_be_able_to_view_updated_bottom_navigation_bar() throws Throwable {
		login.handleNothankspopup();
		WaitForMobileElement(navigation.getNavigation_bottommenu_myshelf());
		Assert.assertTrue(navigation.getNavigation_bottommenu_myshelf().isDisplayed());
		Assert.assertTrue(navigation.getNavigation_bottommenu_Library().isDisplayed());
		Assert.assertTrue(navigation.getNavigation_bottommenu_Browse().isDisplayed());
		Assert.assertTrue(navigation.getNavigation_bottommenu_programs().isDisplayed());
		Assert.assertTrue(navigation.getNavigation_bottommenu_menu().isDisplayed());
		logger.info("user should be able to view bottom navigationbar");
	}

	@And("user should be able to view my shelf option")
	public void user_should_be_able_to_view_my_shelf_option() throws Throwable {
		Assert.assertTrue(navigation.getNavigation_bottommenu_myshelf().isDisplayed());
		logger.info("user should be able to view My shelf bottom navigation bar");
	}

	@And("user should be able to click on my shelf and navigate to my shelf screen")
	public void user_should_be_able_to_click_on_my_shelf_and_navigate_to_my_shelf_screen() throws Throwable {
		navigation.click_NavmyshelfScreen();
	}

	@And("user should be able to view library option")
	public void user_should_be_able_to_view_library_option() throws Throwable {
		Assert.assertTrue(navigation.getNavigation_bottommenu_Library().isDisplayed());
	}

	@And("user should be able to click on library and navigate to library screen")
	public void user_should_be_able_to_click_on_library_and_navigate_to_library_screen() throws Throwable {
		navigation.click_NavLibraryscreen();
		Assert.assertEquals(navigation.click_NavLibraryscreen(), true);
	}

    @And("user should be able to view library name in the top header")
    public void user_should_be_able_to_view_library_name_in_the_top_header() throws Throwable {
    	goals.clickOnMyshelfFooter();
       Assert.assertTrue(navigation.getNavigation_txt_Libraryname().isDisplayed());
    }
    
    
	@And("user should be able to view browse option")
	public void user_should_be_able_to_view_browse_option() throws Throwable {
		Assert.assertTrue(navigation.getNavigation_bottommenu_Browse().isDisplayed());
	}

	@And("user should be able to click on browse and navigate to browse screen")
	public void user_should_be_able_to_click_on_browse_and_navigate_to_browse_screen() throws Throwable {
		navigation.click_NavBrowsescreen();
	}

	@And("user should be able to view programs option")
	public void user_should_be_able_to_view_programs_option() throws Throwable {
		Assert.assertTrue(navigation.getNavigation_bottommenu_programs().isDisplayed());
	}

	@And("user should be able to click on programs and navigate to programs screen")
	public void user_should_be_able_to_click_on_programs_and_navigate_to_programs_screen() throws Throwable {
		navigation.click_Navprogramsscreen();
	}

	@And("user should be able to view menu option")
	public void user_should_be_able_to_view_menu_option() throws Throwable {
		Assert.assertTrue(navigation.getNavigation_bottommenu_menu().isDisplayed());
	}

	@And("user should be able to click on menu and navigate to menu screen")
	public void user_should_be_able_to_click_on_menu_and_navigate_to_menu_screen() throws Throwable {
		navigation.click_NavMenuscreen();
	}

	@Then("user should be able to view updated top navigation bar")
	public void user_should_be_able_to_view_updated_top_navigation_bar() throws Throwable {
		myself.getMyShelf_lbl_footer().click();
		logger.info("user able to see updated top naviagtion menu");
	}

	
	@And("user should be able to view user avatar")
	public void user_should_be_able_to_view_user_avatar() throws Throwable {
		if(isElementPresent(navigation.getNavigation_img_avatarimg())){
		Assert.assertEquals(isElementPresent(navigation.getNavigation_img_avatarimg()), true);
		}
	}

	@And("user should be able to click on avatar and navigate to my profile screen")
	public void user_should_be_able_to_click_on_avatar_and_navigate_to_my_profile_screen() throws Throwable {
		navigation.clickAvatar_navProfilescreen();
	}
	
	@And("user able to click on avatar and navigate to my profile screen")
	public void user_able_to_click_on_avatar_and_navigate_to_my_profile_screen() throws Throwable {
		navigation.clickonAvatar_navProfilescreen();
	}

	@And("user should be able to view default image if avatar image is not set by the user")
	public void user_should_be_able_to_view_default_image_if_avatar_image_is_not_set_by_the_user() throws Throwable {
		logger.info("Default image can be validated manually");
	}

	@Then("user should be able to view the search bar")
	public void user_should_be_able_to_view_the_search_bar() throws Throwable {
		myself.getMyShelf_lbl_footer().click();
		logger.info("user should be able to view search bar");
	}

	@And("user able to click in notifications icon and navigate to notification center")
	public void user_able_to_click_in_notifications_icon_and_navigate_to_notification_center() throws Throwable {
		navigation.view_notificationicon();
	}

	@And("user should give input keyword to initiate search")
	public void user_should_give_input_keyword_to_initiate_search() throws Throwable {
	//	navigation.titleSearch();
	}

	@And("user should be able to view notifications")
	public void user_should_be_able_to_view_notifications() throws Throwable {
		navigation.view_notificationicon();
	}

}
