package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.*;

import java.util.NoSuchElementException;

public class SearchAdvance_StepDef extends CommonActions {

	public static final Logger logger = LoggerFactory.getLogger(SearchAdvance_StepDef.class);
	SearchPage search = new SearchPage(DriverManager.getDriver());
	InterestSurvey interest = new InterestSurvey(DriverManager.getDriver());
	MyLibrary library = new MyLibrary(DriverManager.getDriver());
	Preference preference = new Preference(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());

	MyShelf myShelf = new MyShelf(DriverManager.getDriver());
	TitleDetails details = new TitleDetails(DriverManager.getDriver());

	String searchedTitle;

	@When("user taps on the 'See All' cta for a category")
	public void user_taps_on_the_see_all_cta_for_a_category() throws Throwable {
		search.clickseeAll();
	}

	@Then("user should be able to view expanded results for the category they selected")
	public void user_should_be_able_to_view_expanded_results_for_the_category_they_selected() throws Throwable {
		Assert.assertEquals(isElementPresent(search.pillsSelection_result().get(0)), true);
	}

	@And("user landing on home screen")
	public void user_landing_on_home_screen() throws Throwable {

		if (isElementPresent(search.getSearch_txt_box())) {
			Assert.assertEquals(isElementPresent(search.getSearch_txt_box()), true);
		} else if(isElementPresent(search.getOld_search_txt_box())){
			Assert.assertEquals(isElementPresent(search.getOld_search_txt_box()), true);
		} else if(isElementPresent(search.getOld_search_txt_box())){
			Assert.assertEquals(isElementPresent(search.getSearch_txt_box1()), true);
		}
	}

	@And("user search for a keyword {string}")
	public void search_keyword(String keyword)
	{
		search.advanceSearch(keyword);
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			hideMobileKeyboard();
		} else if(isElementPresent(search.iosKeyboardDone())){
			search.clickIOSKeyboardDone();
		} else{
			search.clickSearchKeyboard();
		}
	}
	@And("user searches for a keyword {string} in the search bar or advanced search bar option")
	public void user_searches_for_a_keyword_in_the_search_bar_or_advanced_search_bar_option(String keyword)
			throws Throwable {
		search.globalSearch(keyword);
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			hideMobileKeyboard();
		} else if(isElementPresent(search.iosKeyboardDone())){
			search.clickIOSKeyboardDone();
		} else{
			search.clickSearchKeyboard();
		}
		search.clickSearchIcon();

	}

	@Given("user searches for keyword {string} in advanced Search")
	public void user_searches_for_keyword_in_advanced_search(String keyword) {
		search.clickAdvanceSearch();
		search.advanceSearch(keyword);
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			hideMobileKeyboard();
		}
		Assert.assertEquals(isElementPresent(search.checkNewspapersAndMagazinesCollections()), true);
//		Assert.assertEquals(isElementPresent(search.checkArticlesCollections()), true);
		search.clickNewspapersAndMagazinesCollections();

	}

	@And("user should not be able to view the 'See All' cta if already selected")
	public void user_should_not_be_able_to_view_the_see_all_cta_if_already_selected() throws Throwable {
	}

	@When("user clicks on refine filter icon and selects the category from the refiner screen under the 'Category' title")
	public void user_clicks_on_refine_filter_icon_and_selects_the_category_from_the_refiner_screen_under_the_category_title()
			throws Throwable {
		search.clickrefineFilter();
	}

	@Then("user should be able to view the cta Clear so system can clear all selections the user made on the refiner screen and auto select 'All' category")
	public void user_should_be_able_to_view_the_cta_clear_so_system_can_clear_all_selections_the_user_made_on_the_refiner_screen_and_auto_select_all_category()
			throws Throwable {
		Assert.assertEquals(isElementPresent(search.getClear_icon()), true);
	}

	@And("user should not be able to view the cta 'Clear' and 'Search' if 'All' is highlighted")
	public void user_should_not_be_able_to_view_the_cta_clear_and_search_if_all_is_highlighted() throws Throwable {
		search.click_All();
		Assert.assertEquals(isElementPresent(search.getSearch_clear()), false);
		search.closerefiner();
		search.navigateBack();
	}

	@And("user should be able to view expanded results for the category they selected by selecting the 'Search' cta")
	public void user_should_be_able_to_view_expanded_results_for_the_category_they_selected_by_selecting_the_search_cta()
			throws Throwable {
		logger.info("expanded results for the category");
	}

	@When("user clicks on refine filter icon and not selects the category from the refiner screen under the 'Category' title")
	public void user_clicks_on_refine_filter_icon_and_not_selects_the_category_from_the_refiner_screen_under_the_category_title()
			throws Throwable {
		search.clickRefiner();
	}

	@Then("system should dynamically refine results in the background as and when user makes selection in refiner screen irrespective if user selects 'Search' cta")
	public void system_should_dynamically_refine_results_in_the_background_as_and_when_user_makes_selection_in_refiner_screen_irrespective_if_user_selects_search_cta()
			throws Throwable {
		logger.info("refine results in the background as and when user makes selection");
	}

	@Then("user should be able to view 'All' highlighted by default after search has been initiated")
	public void user_should_be_able_to_view_all_highlighted_by_default_after_search_has_been_initiated()
			throws Throwable {
		logger.info("view the selected category highlighted");
	}

	@Then("user should be able to view the selected category highlighted in the refiner screen")
	public void user_should_be_able_to_view_the_selected_category_highlighted_in_the_refiner_screen() throws Throwable {
		logger.info("view the selected category highlighted");
	}

	@And("user should be able to view 'Please select a category to refine' text under Refine if no category is selected")
	public void user_should_be_able_to_view_please_select_a_category_to_refine_text_under_refine_if_no_category_is_selected()
			throws Throwable {

	}

	@And("user should be able to go back to refiner screen to select other categories to see the respective expanded results")
	public void user_should_be_able_to_go_back_to_refiner_screen_to_select_other_categories_to_see_the_respective_expanded_results()
			throws Throwable {
		search.clickrefineFilter();
	}

	@When("user searches in search bar or advanced search option and the keyword has no results across all categories")
	public void user_searches_in_search_bar_or_advanced_search_option_and_the_keyword_has_no_results_across_all_categories()
			throws Throwable {
		logger.info("keyword has no results across all categories");
	}

	@Then("user should be able to view screen with 0 search results")
	public void user_should_be_able_to_view_screen_with_0_search_results() throws Throwable {
		Assert.assertEquals(isElementPresent(search.getZeroSearchResult()), true);
		logger.info("user should be able to view screen with 0 search results");
	}

	@And("user should be able to view the title '0 Results for 'Keyword'")
	public void user_should_be_able_to_view_the_title_0_results_for_keyword() throws Throwable {
		logger.info("user should be able to view the title '0 Results");
	}

	@And("user should be able to view all the categories on the refiner screen non-clickable and 'All' category highlighted")
	public void user_should_be_able_to_view_all_the_categories_on_the_refiner_screen_nonclickable_and_all_category_highlighted()
			throws Throwable {
		logger.info("user searches in search bar or advanced search");
	}

	@And("user should be able to view the text 'No results in any category found at this library. Please enter a new search.'")
	public void user_should_be_able_to_view_the_text_no_results_in_any_category_found_at_this_library_please_enter_a_new_search()
			throws Throwable {

	}

	@And("user should be able to view the text 'Not finding what you’re looking for? Search our Suggest To Purchase content.' in addition to 'No results in any category found at this library. Please enter a new search.'")
	public void user_should_be_able_to_view_the_text_not_finding_what_youre_looking_for_search_our_suggest_to_purchase_content_in_addition_to_no_results_in_any_category_found_at_this_library_please_enter_a_new_search()
			throws Throwable {
	}

	@And("user should be able to view  the cta 'Search' for only those libraries that enabled the 'Request to Purchase' flag and will be redirected to 'Request to purchase' screen where they can search and perform necessary action")
	public void user_should_be_able_to_view_the_cta_search_for_only_those_libraries_that_enabled_the_request_to_purchase_flag_and_will_be_redirected_to_something_screen_where_they_can_search_and_perform_necessary_action(
			String strArg1) throws Throwable {
		Assert.assertEquals(isElementPresent(search.getExpand_result()), true);
		search.navigateBack();
	}

	@When("user types a keyword {string} in the search bar or advanced search bar")
	public void user_types_a_keyword_in_the_search_bar_or_advanced_search_bar(String searchKeyword) {
		waitFor(4000);
		search.globalSearch(searchKeyword);
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			hideMobileKeyboard();
		} else if(isElementPresent(search.iosKeyboardDone())){
			search.clickIOSKeyboardDone();
		} else{
			search.clickSearchKeyboard();
		}
		search.clickSearchIcon();
	}

	@When("taps on search icon on the search bar")
	public void taps_on_search_icon_on_the_search_bar() {
		search.clickSearchIcon();
	}

	@Then("user should be able to view number of search results for individual category")
	public void user_should_be_able_to_view_number_of_search_results_for_individual_category() {
		Assert.assertEquals(isElementPresent(search.getSearch_result_page()), true);
	}

	@Then("user should be able to view the count is less than {int} should be number format")
	public void user_should_be_able_to_view_the_count_is_less_than_should_be_number_format(Integer int1) {
		logger.info("user should be able to view the count is less than should be number format");
	}

	@Then("if any number more than {int} will be in {string} and {string} format")
	public void if_any_number_more_than_will_be_in_and_format(Integer int1, String string, String string2) {
		logger.info("Format validation not feasibile");
		search.navigateBack();


	}

	@Then("user should be able to view the category pills as a carousel")
	public void user_should_be_able_to_view_the_category_pills_as_a_carousel() {
		Assert.assertEquals(isElementPresent(search.getSearch_result()), true);
		search.navigateBack();

	}

	@Given("adult user has search bar in static header and advanced search bar option")
	public void adult_user_has_search_bar_in_static_header_and_advanced_search_bar_option() {
		Assert.assertEquals(isElementPresent(search.getSearch_box()), true);
	}

	@Then("user should be able to view the sub-title indicating total number of results for search keyword")
	public void user_should_be_able_to_view_the_sub_title_indicating_total_number_of_results_for_search_keyword() {
		Assert.assertEquals(isElementPresent(search.getSearch_result_page()), true);
	}

	@Then("user should be able to view following categories results based on the keyword searched in a carousel format")
	public void user_should_be_able_to_view_following_categories_results_based_on_the_keyword_searched_in_a_carousel_format() {
		search.clickRefiner();
		logger.info(
				"user should be able to view following categories results based on the keyword searched in a carousel format");
	}

	@Then("user should be able to view priority {string} and {string} and {string} and {string}")
	public void user_should_be_able_to_view_priority_and_and_and(String string, String string2, String string3,
																 String string4) {
		Assert.assertEquals(isElementPresent(search.getActivityresource_item()), true);
		Assert.assertEquals(isElementPresent(search.getWebresource_item()), true);
	}

	@Then("user should be able to view the number of results for each category in parenthesis")
	public void user_should_be_able_to_view_the_number_of_results_for_each_category_in_parenthesis() {
		logger.info("user should be able to view the number of results for each category in parenthesis");
		search.closerefiner();
		Assert.assertEquals(isElementPresent(search.getSearch_result_page()), true);
	}

	@Then("user should not be able to view {string} and {string}")
	public void user_should_not_be_able_to_view_and(String string, String string2) {
		search.closerefiner();
		search.navigateBack();

	}

	@Then("user should be able to view {string} cta as a link to expand on all results for each category")
	public void user_should_be_able_to_view_cta_as_a_link_to_expand_on_all_results_for_each_category(String string) {
		if (isElementPresent(search.getSearchseeAll().get(0))) {
			Assert.assertEquals(isElementPresent(search.getSearchseeAll().get(0)), true);
		} else {
			logger.info("see all not displayed");
		}

	}

	@Then("user should be able to view refiners icon")
	public void user_should_be_able_to_view_refiners_icon() {
		Assert.assertEquals(isElementPresent(search.getRefine_Icon()), true);
	}

	@Then("user should be able to view refiners icon and click")
	public void user_should_be_able_to_view_refiners_icon_and_click() throws Throwable {
		search.clickRefiner();
	}

	@Then("user should be able to view {string} category highlighted on the refiner screen when refine icon is selected")
	public void user_should_be_able_to_view_category_highlighted_on_the_refiner_screen_when_refine_icon_is_selected(
			String string) {
		search.clickRefiner();
		Assert.assertEquals(isElementPresent(search.getRefine_All()), true);
		search.closerefiner();
		search.navigateBack();
	}

	@Then("user should be able to view card details and {string} based on the type of content")
	public void user_should_be_able_to_view_card_details_and_based_on_the_type_of_content(String string) {
		logger.info("user should be able to view card details and CTA based on the type of content");
		search.navigateBack();

	}

	@When("taps on search cta on the advanced search modal")
	public void taps_on_search_cta_on_the_advanced_search_modal() {
		search.clickSearchBox();

	}

	@Given("user click on login button after user enter kidszone and axis360 subscription only {string} and {string}")
	public void user_click_on_login_button_after_user_enter_kidszone_and_axis360_subscription_only_and(String string,
																									   String string2) {

	}

	@Given("user searches for a keyword in the search bar or advanced search bar option")
	public void user_searches_for_a_keyword_in_the_search_bar_or_advanced_search_bar_option() {

	}

	@When("user clicks on refine filter icon and selects the category from the refiner screen under the {string} title")
	public void user_clicks_on_refine_filter_icon_and_selects_the_category_from_the_refiner_screen_under_the_title(
			String string) {
		search.clickRefiner();
	}

	@Then("user should be able to view the cta {string} so system can clear all selections the user made on the refiner screen and auto select {string} category")
	public void user_should_be_able_to_view_the_cta_so_system_can_clear_all_selections_the_user_made_on_the_refiner_screen_and_auto_select_category(
			String string, String string2) {
		search.clickebook();
		Assert.assertEquals(isElementPresent(search.getSearch_clear()), true);

	}

	@Then("user should be able to view expanded results for the category they selected by selecting the {string} cta")
	public void user_should_be_able_to_view_expanded_results_for_the_category_they_selected_by_selecting_the_cta(
			String string) {
		search.viewResult();

	}

	@Then("system should dynamically refine results in the background as and when user makes selection in refiner screen irrespective if user selects {string} cta")
	public void system_should_dynamically_refine_results_in_the_background_as_and_when_user_makes_selection_in_refiner_screen_irrespective_if_user_selects_cta(
			String string) {

	}

	@Then("user should be able to view {string} highlighted by default after search has been initiated")
	public void user_should_be_able_to_view_highlighted_by_default_after_search_has_been_initiated(String string) {

	}

	@Then("user should be able to view {string} text under Refine if no category is selected")
	public void user_should_be_able_to_view_text_under_refine_if_no_category_is_selected(String string) {

	}

	@Given("user click on search icon and enter keyword to search")
	public void user_click_on_search_icon_and_enter_keyword_to_search() {
		search.clickSearchBox();
	}

	@When("user searches in search bar and navigates to search results screen")
	public void user_searches_in_search_bar_and_navigates_to_search_results_screen() {
		logger.info("user should be able to navigate to search results");
	}

	@When("user able to view {string} selected as default in refine left panel and user selects a category from refiner screen")
	public void user_able_to_view_selected_as_default_in_refine_left_panel_and_user_selects_a_category_from_refiner_screen(
			String string) {
		search.clickRefiner();
		Assert.assertEquals(isElementPresent(search.getRefine_All()), true);
		search.clickActivatityResource();


	}

	@Then("user should be able to view only those refiner drawers based on the category selected")
	public void user_should_be_able_to_view_only_those_refiner_drawers_based_on_the_category_selected() {
		if(isElementPresent(search.getRefineFilter_sub_Category())) {
			Assert.assertEquals(isElementPresent(search.getRefineFilter_sub_Category()), true);
		}
	}

	@Then("user should be able to view the sub- categories under each main category and refiner")
	public void user_should_be_able_to_view_the_sub_categories_under_each_main_category_and_refiner() {
		Assert.assertEquals(isElementPresent(search.getAvailabilityCategory()), true);
		Assert.assertEquals(isElementPresent(search.getCollectionsCategory()), true);
	}

	@Then("user should be able to select the category {string} and able to view the following")
	public void user_should_be_able_to_select_the_category_and_able_to_view_the_following(String string) {
		search.clickebook();
	}

	@Then("user should be able to view refiner {string}")
	public void user_should_be_able_to_view_refiner(String string) {
		swipeDown();
		Assert.assertEquals(isElementPresent(search.getSortBy()), true);

	}

	@Then("user should be able to make only one selection within one refiner drawer")
	public void user_should_be_able_to_make_only_one_selection_within_one_refiner_drawer() {
		search.Expand_Subject();
	}

	@Then("user should be able to view the previous drawer automatically close when they open another drawer and make a selection")
	public void user_should_be_able_to_view_the_previous_drawer_automatically_close_when_they_open_another_drawer_and_make_a_selection() {
		search.clickCollection();
		Assert.assertEquals(isElementPresent(search.getSubject_option1()), false);
	}

	@Then("system should display refined results when user makes selections on the refiner screen and select {string} CTA")
	public void system_should_display_refined_results_when_user_makes_selections_on_the_refiner_screen_and_select_cta(
			String string) {
		Assert.assertEquals(isElementPresent(search.getSearchCTA()), true);
	}

	@Then("system should clear all refiners when user selects {string} CTA")
	public void system_should_clear_all_refiners_when_user_selects_cta(String string) {

		search.clickClearCTA();
	}

	@Then("user should be able to clear all refiners when they select another category from the refiner screen")
	public void user_should_be_able_to_clear_all_refiners_when_they_select_another_category_from_the_refiner_screen() {
		logger.info("user should be able to clear all refiners when they select another category");
		search.clickCancel();
		search.clickBack();
	}

	@Then("user should be able to select the category {string} and able to view the following refiner {string}")
	public void user_should_be_able_to_select_the_category_and_able_to_view_the_following_refiner(String string,
																								  String string2) {
		logger.info("user should be able to select category");
	}

	@Then("user should be able to select the category {string}")
	public void user_should_be_able_to_select_the_category(String string) {

	}

	@Then("user should be able to view placeholder only")
	public void user_should_be_able_to_view_placeholder_only() {

	}

	@When("user able to view {string} selected as default in refine left panel and user selects a category from left hand panel")
	public void user_able_to_view_selected_as_default_in_refine_left_panel_and_user_selects_a_category_from_left_hand_panel(
			String string) {

	}

	@Then("user should be able to view the sub- refiner under each main refiner")
	public void user_should_be_able_to_view_the_sub_refiner_under_each_main_refiner() {
		search.clickSubCategory();
		search.clickEBook();
	}

	@Then("user should be able to view {string}")
	public void user_should_be_able_to_view(String string) {
		swipeDown();
		Assert.assertEquals(isElementPresent(search.getSortBy()), true);
	}

	@And("user should be able to view grade Level {string}")
	public void user_should_be_able_to_view_grade_level (String string) throws Throwable {
		search.clickCancel();
		search.clickBack();
	}

	@Then("user should not able to view the category {string} and {string}")
	public void user_should_not_able_to_view_the_category_and(String string, String string2) {

	}

	@When("user selects a category from left hand panel")
	public void user_selects_a_category_from_left_hand_panel() {

	}

	@Then("user should be able to view third party intergation in category")
	public void user_should_be_able_to_view_third_party_intergation_in_category() {

	}

	@Then("user should be able to view the title {int} Results for Keyword")
	public void user_should_be_able_to_view_the_title_results_for(Integer int1) {
		Assert.assertEquals(isElementPresent(search.getNo_resultFound()), true);
	}

	@Then("user should be able to view all the categories on the refiner screen non-clickable and {string} category highlighted")
	public void user_should_be_able_to_view_all_the_categories_on_the_refiner_screen_non_clickable_and_category_highlighted(
			String string) {
		logger.info("user should be able to view all the categories on the refiner");
	}

	@Then("user should be able to view the text {string}")
	public void user_should_be_able_to_view_the_text(String string) {
		Assert.assertEquals(isElementPresent(search.getNo_resultFound()), true);
		search.navigateBack();
	}

	@Then("user should be able to view the text {string} in addition to {string}")
	public void user_should_be_able_to_view_the_text_in_addition_to(String string, String string2) {
		Assert.assertEquals(isElementPresent(search.getNo_resultFound()), true);
	}

	@Given("user launch the app")
	public void user_launch_the_app() {

	}

	@Given("logged in user and library has axis and kidszone subscription {string} and {string}")
	public void logged_in_user_and_library_has_axis_and_kidszone_subscription_and(String string, String string2) {

	}

	@When("user has search bar in static header and advanced search bar option")
	public void user_has_search_bar_in_static_header_and_advanced_search_bar_option() {
		login.handleNothankspopup();
	}

	@When("user is in category refiner screen and select a web resource refiner option")
	public void user_is_in_category_refiner_screen_and_select_a_web_resource_refiner_option() {
		search.clickRefiner();
		search.clickWebresource();
	}

	@When("user is in the study site tab")
	public void user_is_in_the_study_site_tab() {
		Assert.assertEquals(isElementPresent(search.getStudySite()), true);
	}

	@Then("user should be able to view the option in the category and clicking on the Web resource refine options will be updated based on the category selected")
	public void user_should_be_able_to_view_the_option_in_the_category_and_clicking_on_the_web_resource_refine_options_will_be_updated_based_on_the_category_selected() {
		search.web_resources();
	}

	@Then("user should not see any refiner drawers until a category is selected")
	public void user_should_not_see_any_refiner_drawers_until_a_category_is_selected() {
		Assert.assertEquals(isElementPresent(search.getRefineFilter_subject()), false);
		Assert.assertEquals(isElementPresent(search.getRefineFilter_source()), false);
		Assert.assertEquals(isElementPresent(search.getRefineFilter_sub_Category()), false);
		logger.info("user should not see any refiner drawers until a category is selected");
	}

	@Then("user should be able to view the following category in the refine section {string},{string},{string},{string},{string} and {string}")
	public void user_should_be_able_to_view_the_following_category_in_the_refine_section_and(String string,
																							 String string2, String string3, String string4, String string5, String string6) {
		search.clicktoggle();
		Assert.assertEquals(isElementPresent(search.getRefineFilter_subject()), true);
		Assert.assertEquals(isElementPresent(search.getRefineFilter_source()), true);
		if(isElementPresent(search.getRefineFilter_sub_Category())) {
			Assert.assertEquals(isElementPresent(search.getRefineFilter_sub_Category()), true);
		}
	}

	@Then("user should be able to view sub category when they expand the each category")
	public void user_should_be_able_to_view_sub_category_when_they_expand_the_each_category() {
		search.Expand_Subject();
	}

	@Then("user will be redirected to search screen upon clicking back button from the header and page will be reset to zero state")
	public void user_will_be_redirected_to_search_screen_upon_clicking_back_button_from_the_header_and_page_will_be_reset_to_zero_state() {
		search.closerefiner();
		search.navigateBack();
		Assert.assertEquals(isElementPresent(search.getSearch_txt_box1()), true);
	}

	@Given("flag has been enabled in the admin")
	public void flag_has_been_enabled_in_the_admin() {
		logger.info("flag has been enabled in the admin");
	}

	@When("user is on web resources list screen")
	public void user_is_on_web_resources_list_screen() {
		search.clickRefiner();
		search.clickWebresource();
	}

	@Then("user should be able to view expanded results for the web Resources category in a list view")
	public void user_should_be_able_to_view_expanded_results_for_the_web_resources_category_in_a_list_view() {
		Assert.assertEquals(isElementPresent(search.getExpand_search()), true);
		swipeDown();
		search.viewResult();
	}

	@Then("user should be able to view the web resource card title and weblink")
	public void user_should_be_able_to_view_the_web_resource_card_title_and_weblink() {
		waitFor(5000);
		Assert.assertEquals(isElementPresent(search.getWebsource_cardTitle()), true);
	}

	@Then("user should be able to view description and subjects")
	public void user_should_be_able_to_view_description_and_subjects() {
		Assert.assertEquals(isElementPresent(search.getWebsource_cardTitle()), true);
	}

	@Then("user should be language and interest level and a display image")
	public void user_should_be_language_and_interest_level_and_a_display_image() {
		Assert.assertEquals(isElementPresent(search.getWebsource_cardTitle()), true);
	}

	@Then("user should be able to view web resources results through web path express")
	public void user_should_be_able_to_view_web_resources_results_through_web_path_express() {
		Assert.assertEquals(isElementPresent(search.getWebsource_cardTitle()), true);
	}

	@Then("user should be able to view the sort order for the results based on relevance")
	public void user_should_be_able_to_view_the_sort_order_for_the_results_based_on_relevance() {
		Assert.assertEquals(isElementPresent(search.getRefiners_Screen()), true);
	}

	@Then("user should be able to view the results lazy load as user scrolls down")
	public void user_should_be_able_to_view_the_results_lazy_load_as_user_scrolls_down() {
		logger.info("lazy load as user scrolls down");
		search.viewResult();
		if(isElementPresent(search.checkEBookTitles())) {
			Assert.assertEquals(isElementPresent(search.checkEBookTitles()), true);
		}
		if(isElementPresent(search.checkEBookPills())) {
			Assert.assertEquals(isElementPresent(search.checkEBookPills()), true);
		}
		if(isElementPresent(search.checkActivityResourcePills())) {
			Assert.assertEquals(isElementPresent(search.checkActivityResourcePills()), true);
		}
	}

	@Then("user should be able to view Web Resources as a category only if library has enabled the flag for its patrons")
	public void user_should_be_able_to_view_web_resources_as_a_category_only_if_library_has_enabled_the_flag_for_its_patrons() {
		logger.info("user should be able to view Web Resources as a category only if library has enabled");
		search.navigateBack();
	}

	@When("user is on activity resources list screen")
	public void user_is_on_activity_resources_list_screen() {
		search.clickRefiner();
		search.clickActivatityResource();

	}

	@Then("user should be able to view expanded results for the activity resources category in a list view")
	public void user_should_be_able_to_view_expanded_results_for_the_activity_resources_category_in_a_list_view() {
		search.viewResult();
	}

	@Then("user should be able to view the activity resource card title")
	public void user_should_be_able_to_view_the_activity_resource_card_title() {
		Assert.assertEquals(isElementPresent(search.getRefiners_Screen()), true);

	}

	@Then("user should be able to view activity Resources as a category only if library has enabled the flag for its patrons")
	public void user_should_be_able_to_view_activity_resources_as_a_category_only_if_library_has_enabled_the_flag_for_its_patrons() {
		logger.info("user should be able to view activity Resources as a category");
	}

	@Given("user is on the search result screen")
	public void user_is_on_the_search_result_screen() {
		Assert.assertEquals((search.search()), true);
	}

	@Given("flag has been disabled in the admin")
	public void flag_has_been_disabled_in_the_admin() {
		logger.info("flag has been disabled");
	}

	@When("user navigates to web reasource page")
	public void user_navigates_to_web_reasource_page() {
		search.clickRefiner();
		search.clickWebresource();
		search.viewResult();
		search.navigateBack();
	}

	@Then("user should not be able to view activity resources option in the advance search if library has disabled the web resource flag for its patrons")
	public void user_should_not_be_able_to_view_activity_resources_option_in_the_advance_search_if_library_has_disabled_the_web_resource_flag_for_its_patrons() {
		logger.info("advance search if library has disabled the web resource flag");
	}

	@Given("user is in my library page")
	public void user_is_in_my_library_page() {
		library.clickMylibrary();
	}

	@When("user initiates the search {string}")
	public void user_initiates_the_search(String searchKeyword) {
		search.searchBar(searchKeyword);
	}

	@Then("user will land on search result page")
	public void user_will_land_on_search_result_page() {
		logger.info("user will land on search result page");
	}

	@Then("user expands the activity reasource category")
	public void user_expands_the_activity_reasource_category() {
		search.clickRefiner();
		search.clickActivatityResource();
		search.viewResult();
	}


	@Then("system should auto filter the search results based on teen profile")
	public void system_should_auto_filter_the_search_results_based_on_teen_profile() {
		logger.info("system should auto filter the search results based on teen profile");
		search.navigateBack();
	}

	@Then("system should auto filter the search results based on kid profile")
	public void system_should_auto_filter_the_search_results_based_on_kid_profile() {
		logger.info("system should auto filter the search results based on kid profile");
		search.navigateBack();
	}

	@When("user taps on the category pills under the static header")
	public void user_taps_on_the_category_pills_under_the_static_header() {
		search.selectcategorypills();
	}

	@Then("user should be able to view only those refiners in the refiners screen for the category they selected")
	public void user_should_be_able_to_view_only_those_refiners_in_the_refiners_screen_for_the_category_they_selected() {
		Assert.assertEquals(isElementPresent(search.getRefiners_Screen()), true);
	}

	@When("user is on ebooks list screen")
	public void user_is_on_ebooks_list_screen() {
		Assert.assertEquals(isElementPresent(search.getebooks_Screen()), true);
		search.selecteook();

	}

	@Then("user should be able to toggle between all other categories to see the respective expanded results")
	public void user_should_be_able_to_toggle_between_all_other_categories_to_see_the_respective_expanded_results() {
		search.clickRefiner();
		Assert.assertEquals(isElementPresent(search.newspaperRefinerOption()), true);
		search.clickActivatityResourceRefiner();
		Assert.assertEquals(isElementPresent(search.getRefineText()),true);
		search.clickCloseRefiner();
		search.navigateBack();
		search.navigateBack();
	}

	@Then("user should be able to view expanded results for the eBooks category in a list view")
	public void user_should_be_able_to_view_expanded_results_for_the_e_books_category_in_a_list_view() {
//		Assert.assertEquals(isElementPresent(search.checkEBookTitles().get(0)),true);
		search.selectsubcategory();
	}

	@Then("user should be able to view category pills for ebook sub category")
	public void user_should_be_able_to_view_category_pills_for_ebook_sub_category() {
		if(isElementPresent(search.getEbook_sucategory())) {
			Assert.assertEquals(isElementPresent(search.getEbook_sucategory()), true);
		}
//		Assert.assertEquals(isElementPresent(search.checkEBookPills()),true);
//		Assert.assertEquals(isElementPresent(search.checkActivityResourcePills()),true);
	}

	@Then("user should be able to view the search results for the titles from general collection and always available collection")
	public void user_should_be_able_to_view_the_search_results_for_the_titles_from_general_collection_and_always_available_collection() {
		search.clickCollection();
		Assert.assertEquals(isElementPresent(search.getGeneral_Collections()), true);
	}

	@Then("user should be able to view the search results for video collection and book collections")
	public void user_should_be_able_to_view_the_search_results_for_video_collection_and_book_collections() {
		Assert.assertEquals(isElementPresent(search.getGeneral_Collections()), true);
	}

	@Then("user should be able to view the sort order for the results based on popularity")
	public void user_should_be_able_to_view_the_sort_order_for_the_results_based_on_popularity() {
		Assert.assertEquals(isElementPresent(search.getSearch_Sort()), true);
		search.clickSort();
	}

	@When("user is on audio book list screen")
	public void user_is_on_audio_book_list_screen() {
		search.selecteook();
	}

	@Then("user should be able to view expanded results for the audiobook category in a list view")
	public void user_should_be_able_to_view_expanded_results_for_the_audiobook_category_in_a_list_view() {
		search.selectsubcategory();
	}

	@Then("user should be able to view category pills for audiobook sub category")
	public void user_should_be_able_to_view_category_pills_for_audiobook_sub_category() {
		Assert.assertEquals(isElementPresent(search.geteAudio_sucategory()), true);
	}

	@When("user is on video list screen")
	public void user_is_on_video_list_screen() {
		search.clickRefiner();
		search.selecteook();
	}

	@Then("user should be able to view expanded results for the video category in a 322222th glist view")
	public void user_should_be_able_to_view_expanded_results_for_the_video_category_in_a_list_view() {
		search.selectsubcategory();
	}

	@When("user is on vbooks list screen")
	public void user_is_on_vbooks_list_screen() {
		search.clickRefiner();
		search.selecteook();
	}

	@Then("user should be able to view expanded results for the vbooks category in a list view")
	public void user_should_be_able_to_view_expanded_results_for_the_vbooks_category_in_a_list_view() {
		search.selectsubcategory();
	}

	@Then("user should be able to view category pills for vbooks sub category")
	public void user_should_be_able_to_view_category_pills_for_vbooks_sub_category() {
		Assert.assertEquals(isElementPresent(search.geteAudio_sucategory()), true);
	}

	@When("user types a keyword in the search bar or advanced search bar")
	public void user_types_a_keyword_in_the_search_bar_or_advanced_search_bar() {

	}

	@Then("user should be able to view clickable category pills under the static header")
	public void user_should_be_able_to_view_clickable_category_pills_under_the_static_header() {
		if(isElementPresent(search.getEBookCategory_pills())) {
			Assert.assertTrue(search.getEBookCategory_pills().isDisplayed());
			//search.selectcategorypills();
		}
		else {
			Assert.assertTrue(search.getEContentCategory_pills().isDisplayed());
		}
	}

	@Then("user logout of the application")
	public void user_logout_of_the_application() {
		search.navigateBack();
		login.clickFooterMenu();
		preference.click_SignOut();
	}
	@Then("logout of the application")
	public void logout_the_application() {
		//search.clickBack();
		login.clickFooterMenu();
		preference.click_SignOut();

	}
	@When("^user selects the advanced search option under the search bar$")
	public void user_selects_the_advanced_search_option_under_the_search_bar() throws Throwable {
		search.advancedSearchOption();
	}
	@Then("^user should be able to view search bar within the advanced search screen$")
	public void user_should_be_able_to_view_search_bar_within_the_advanced_search_screen() throws Throwable {
		Assert.assertEquals(isElementPresent(search.getAdvancedSearchBar()), true);
	}

	@And("^user should be able to refine their search using advanced search options under the category type and collection$")
	public void user_should_be_able_to_refine_their_search_using_advanced_search_options_under_the_category_type_and_collection() throws Throwable {
		search.searchBar("comic");
	}

	@And("^user should be able to refine their search using advanced search options under the availability and format and attributes$")
	public void user_should_be_able_to_refine_their_search_using_advanced_search_options_under_the_availability_and_format_and_attributes() throws Throwable {
		search.clickrefineFilter();
	}

	@And("^user should be able to select only one option within type and collection category$")
	public void user_should_be_able_to_select_only_one_option_within_type_and_collection_category() throws Throwable {
		search.clickEBookEAudio();
		search.clickCollection();
	}

	@And("^user should be able to multi select within availability and Format and attributes refiners$")
	public void user_should_be_able_to_multi_select_within_availability_and_format_and_attributes_refiners() throws Throwable {
		logger.info("user should be able to multi select within availability");
	}

	@And("^user should be able to view 'Clear' cta to clear all selections$")
	public void user_should_be_able_to_view_clear_cta_to_clear_all_selections() throws Throwable {
		Assert.assertEquals(isElementPresent(search.getClearCTA()), true);
	}

	@And("^user should be able to view 'Search' cta to generate results for keyword$")
	public void user_should_be_able_to_view_search_cta_to_generate_results_for_keyword() throws Throwable {
		Assert.assertEquals(isElementPresent(search.getSearchCTA()), true);
	}

	@And("^user should be able to view 'Cancel icon' to close the advanced search modal at any time$")
	public void user_should_be_able_to_view_cancel_icon_to_close_the_advanced_search_modal_at_any_time() throws Throwable {
		Assert.assertEquals(isElementPresent(search.getCancelIcon()), true);
	}

	@And("^user should be able to view search results based on options selected in Advance search$")
	public void user_should_be_able_to_view_search_results_based_on_options_selected_in_advance_search() throws Throwable {
		search.clickSearchBox();
		search.clickBack();
		search.clickCancel();
	}

	@And("user able to view Newspaper and Magazines results as carousel in search result landing page")
	public void user_Able_To_View_Newspaper_and_Magazines_As_Carousel_In_Search_Result_Landing_Page() {
		search.clickSearch();
		waitFor(10000);
		if(isElementPresent(search.verifyNewspaperAndMagzinesseeAllCTA()))
		{
			Assert.assertEquals(isElementPresent(search.verifyNewspaperAndMagzinesseeAllCTA()),true);
		}else
		{
			Assert.assertEquals(isElementPresent(search.verifyNewspaperAndMagzinesseeAllCTA1()),true);
		}
	}

	@And("User should be able to view the title card with Image Country Date Title and Download CTA")
	public void user_Should_Be_Able_To_View_The_Title_Card_With_Image_Country_Date_Title_And_Download_CTA() {
		logger.info("User should be able to view the title card with Image Country Date Title and Download CTA");
	}

	@And("user click on any card displayed in third party results")
	public void user_Click_On_Any_Card_Displayed_In_Third_Party_Results() {
		Assert.assertEquals(isElementPresent(search.clickNewspaperAndMagzinesTitle()),true);
	}

	@And("user should redirect to extenal site in a new tab")
	public void user_Should_Redirect_To_Extenal_Site_In_A_New_Tab() {
		search.clickBack();
		waitFor(2000);
//		search.clickBack();
	}

	@And("user clicks on the see All CTA of the Newspaper and Magazines")
	public void user_Clicks_On_The_See_All_CTA_Of_The_Newspaper_And_Magazines() {
		search.clickNewspaperAndMagzinesseeAllCTA();
	}

	@And("user is should be redirected to the list page of Newspaper and Magazines")
	public void user_Is_Should_Be_Redirected_To_The_List_Page_Of_Newspaper_And_Magazines() {
		search.verifyNewspaperAndMagzinesListPage();
		waitFor(3000);
		//search.clickBack();
	}

	@And("user clicks on the see All CTA of the Articles")
	public void user_Clicks_On_The_See_All_CTA_Of_The_Articles() {
//		scrollandCheck(search.verifyArticlesHeader());
		swipeDown();
		waitFor(1000);
		swipeDown();
		waitFor(1000);
		swipeDown();
		waitFor(1000);
		Assert.assertEquals(isElementPresent(search.verifyArticlesseeAllCTA()),true);
		search.clickArticlesseeAllCTA();
	}

	@And("user is should be redirected to the list page of Articles")
	public void user_Is_Should_Be_Redirected_To_The_List_Page_Of_Articles() {
		search.verifyNewspaperAndMagzinesListPage();
		search.clickBack();
	}
	@And("user should be able to view the Newspaper and Articles in the Advanced Search option")
	public void user_Should_Be_Able_To_View_The_Newspaper_And_Articles_In_The_Advanced_Search_Option() {
		search.clickAdvanceSearch();
		Assert.assertEquals(isElementPresent(search.checkNewspapersAndMagazinesCollections()), true);
		search.clickNewspapersAndMagazinesCollections();
		//search.advanceSearch("cat");

	}

	@Then("user should not able to view Newspaper and Articles results as carousel in search result landing page")
	public void user_Should_Not_Able_To_View_Newspaper_And_Articles_Results_As_Carousel_In_Search_Result_Landing_Page() {
		search.clickSearch();
		logger.info("Since we are checking the enabled configuration in drupal.We can't check the disabled configuration at same time");
	}

	@And("user should not be able to view the Newspaper and Articles in the Advanced Search option")
	public void user_Should_Not_Be_Able_To_View_The_Newspaper_And_Articles_In_The_Advanced_Search_Option() {
		search.clickAdvanceSearch();
		logger.info("Since we are checking the enabled configuration in drupal.We can't check the disabled configuration at same time");
	}

	@And("user is able to view all the category in the Refiner popup")
	public void user_Is_Able_To_View_All_The_Category_In_The_Refiner_Popup() {
		search.clickRefiner();
		Assert.assertEquals(isElementPresent(search.verifyAllRefinerOption()), true);
		Assert.assertEquals(isElementPresent(search.verifyEBooksRefinerOption()), true);
		Assert.assertEquals(isElementPresent(search.verifyActivityResourcesRefinerOption()), true);
		Assert.assertEquals(isElementPresent(search.verifyWebResourcesRefinerOption()), true);
		Assert.assertEquals(isElementPresent(search.verifyNewspapersAndMaganizesRefinerOption()), true);
		search.clickCancel();
	}

	@Then("user should be able to view advanced search options popup screen")
	public void user_Should_Be_Able_To_View_Advanced_Search_Options_Popup_Screen() {
		search.clickAdvanceSearch();
	}


	@And("user should be able to view general, title to purchase request options in popup after enable patron recommendations in BTadmin portal")
	public void user_Should_Be_Able_To_View_General_Title_To_Purchase_Request_Options_In_Popup_After_Enable_Patron_Recommendations_In_BTadmin_Portal() {
		Assert.assertEquals(isElementPresent(search.verifyGeneralCollection()),true);
		Assert.assertEquals(isElementPresent(search.verifyPurchaseRequestCollection()),false);
	}

	@And("user should not be able to see always available option in popup for kidszone subscribed only library")
	public void user_Should_Not_Be_Able_To_See_Always_Available_Option_In_Popup_For_Kidszone_Subscribed_Only_Library() {
		Assert.assertEquals(isElementPresent(search.verifyAlwaysAvailableCollection()),false);
		search.clickCancelIcon();
	}

	@And("user should not be able to view title to purchase request options in popup")
	public void user_Should_Not_Be_Able_To_View_Title_To_Purchase_Request_Options_In_Popup() {
		Assert.assertEquals(isElementPresent(search.verifyPurchaseRequestCollection()),false);
		search.clickCancelIcon();
	}

	@And("user should be able to view Clear and Search cta to clear all selections")
	public void user_Should_Be_Able_To_View_Clear_And_Search_Cta_To_Clear_All_Selections() {
		Assert.assertEquals(isElementPresent(search.getSearchCTAInAdvancepopup()),true);
	}

	@And("user enters keyword in the search bar")
	public void userEntersKeywordInTheSearchBar() {
		search.advancedSearchOption();
		search.searchBar("the");
	}

	@When("user clicks search cta")
	public void userClicksSearchCta() {
		search.clickSearch();
	}

	@And("user searches for the hold titles and navigate to title details page")
	public void userSearchesForTheHoldTitlesAndNavigateToTitleDetailsPage() {
		search.advancedSearchOption();
		waitFor(2000);
		search.clickPurchaseRequest();
		waitFor(2000);
		search.clickSearch();
	}

	@And("user clicks on the search selection")
	public void userClicksOnTheCategorySelection() {
		search.clickCategorSearch();
		waitFor(2000);
	}

	@Then("user should be able to view format section with radio button and option as All")
	public void userShouldBeAbleToViewFormatSectionWithRadioButtonAndOptionAsAll() {
		swipeDown();
		swipeDown();
		Assert.assertEquals(isElementPresent(search.verifyGeneralCollection()),true);
	}

	@And("user should be able to view format section with radio button and option as eBooks")
	public void userShouldBeAbleToViewFormatSectionWithRadioButtonAndOptionAsEBooks() {
		Assert.assertEquals(isElementPresent(search.verifyeBooksCollections()),true);
	}

	@And("user should be able to view format section with radio button and option as eAudios")
	public void userShouldBeAbleToViewFormatSectionWithRadioButtonAndOptionAsEAudios() {
		Assert.assertEquals(isElementPresent(search.verifyeAudiosCollections()),true);
	}

	@And("user should be able to view format section with radio button and option as Resource Hub")
	public void userShouldBeAbleToViewFormatSectionWithRadioButtonAndOptionAsResourceHub() {
		Assert.assertEquals(isElementPresent(search.verifyResourceHubCollections()),true);
	}

	@And("user should be able to view format section with radio button and option as Web Resources")
	public void userShouldBeAbleToViewFormatSectionWithRadioButtonAndOptionAsWebResources() {
		swipeDown();
		Assert.assertEquals(isElementPresent(search.verifyWebResourceCollections()),true);
	}

	@And("user should not able to view format section with radio button and option as Videobooks")
	public void userShouldNotAbleToViewFormatSectionWithRadioButtonAndOptionAsVideobooks() {
		Assert.assertEquals(isElementPresent(search.verifyvBooksCollections()),false);

	}

	@And("user should not able to view format section with radio button and option as Checkers library TV")
	public void userShouldNotAbleToViewFormatSectionWithRadioButtonAndOptionAsCheckersLibraryTV() {
		Assert.assertEquals(isElementPresent(search.verifyVideosCollections()),false);
	}

	@And("user should be able to view Advanced search options screen")
	public void userShouldBeAbleToViewAdvancedSearchOptionsScreen() {
	}

	@And("user should be able to view format section with radio button and option as Videobooks")
	public void userShouldBeAbleToViewFormatSectionWithRadioButtonAndOptionAsVideobooks() {
		Assert.assertEquals(isElementPresent(search.verifyvBooksCollections()),true);
	}

	@And("user should be able to view format section with radio button and option as Checkers library TV")
	public void userShouldBeAbleToViewFormatSectionWithRadioButtonAndOptionAsCheckersLibraryTV() {
		Assert.assertEquals(isElementPresent(search.verifyVideosCollections()),true);
	}


	@And("user should be able to view format section with radio button and o ption as Videobooksbooks")
	public void userShouldBeAbleToViewFormatSectionWithRadioButtonAndOPtionAsVideobooksbooks() {
	}

	@When("user tap resource hub under format section")
	public void user_tap_resource_hub_under_format_section() {
		waitFor(1000);
		search.clickResourceHub();
	}

	@Then("user should be able to view ISBN and Author as disabled under type section")
	public void user_should_be_able_to_view_isbn_and_author_as_disabled_under_type_section() {
		Assert.assertEquals(search.authorRadio().isEnabled(), false);
		Assert.assertEquals(search.ISBNRadio().isEnabled(), false);
	}

	@Then("user should be able to get resource hub result based on keyword by tap search cta")
	public void user_should_be_able_to_get_resource_hub_result_based_on_keyword_by_tap_search_cta() {
		search.click_Search_btn();
		Assert.assertEquals(isElementPresent(search.resourceHubResults()),true);
	}

	@When("user tap web resources under format section")
	public void user_tap_web_resources_under_format_section() {
		search.clickWebResources();
	}

	@Then("user should be able to web resource result based on keyword by tap search cta")
	public void user_should_be_able_to_web_resource_result_based_on_keyword_by_tap_search_cta() {
		search.click_Search_btn();
		Assert.assertEquals(isElementPresent(search.webResourcesResults()),true);
	}

	@When("user tap newspaper under format section")
	public void user_tap_newspaper_under_format_section() {
		waitFor(1000);
		search.clickNewspaperMagazine();
	}

	@Then("user should be able to get newspaper result based on keyword by tap search cta")
	public void user_should_be_able_to_get_newspaper_result_based_on_keyword_by_tap_search_cta() {
		search.click_Search_btn();
		Assert.assertEquals(isElementPresent(search.newspapersResults()),true);
	}

	@When("user tap magazine under format section")
	public void user_tap_magazine_under_format_section() {
		search.clickMagazine();
	}

	@Then("user should be able to get magazine result based on keyword by tap search cta")
	public void user_should_be_able_to_get_magazine_result_based_on_keyword_by_tap_search_cta() {
		search.click_Search_btn();
		Assert.assertEquals(isElementPresent(search.magazineResults()),true);
	}

	@When("user tap ISBN under type section")
	public void user_tap_isbn_under_type_section() {
		search.clickISBNRadio();
	}

	@When("User enter the number {string} in the search box")
	public void user_enter_the_number_in_the_search_box(String ISBN) {
		search.ISBNSearch(ISBN);
		if (System.getProperty("platform").equalsIgnoreCase("android")) {
			hideMobileKeyboard();
		} else  {
			search.clickIOSKeyboardDone();
		}
	}

	@Then("user should be able to view resource hub and web resources as disabled under format section")
	public void user_should_be_able_to_view_resource_hub_and_web_resources_as_disabled_under_format_section() {
		Assert.assertEquals(search.resourceHubRadio().isEnabled(), false);
		Assert.assertEquals(search.webResourcesRadio().isEnabled(), false);
	}

	@Then("user should be able to get the title of that isbn number by tap search cta")
	public void user_should_be_able_to_get_the_title_of_that_isbn_number_by_tap_search_cta() {
		search.click_Search_btn();
		waitFor(2000);
		Assert.assertEquals(isElementPresent(search.ISBNResults()),true);
	}

	@When("User enter the author name {string} in the search box")
	public void user_enter_the_author_name_in_the_search_box(String author) {
		search.authorSearch(author);
	}

	@When("user tap Author under type section")
	public void user_tap_author_under_type_section() {
		search.clickAuthorRadio();
	}

	@Then("user should be able to get the author's titles by tap search cta")
	public void user_should_be_able_to_get_the_author_s_titles_by_tap_search_cta() {
		search.click_Search_btn();
		Assert.assertEquals(isElementPresent(search.ISBNResults()),true);
	}

	@And("user should be able to view format section with radio button and option as Newspaper and Magazines")
	public void userShouldBeAbleToViewFormatSectionWithRadioButtonAndOptionAsNewspaper() {
		Assert.assertEquals(isElementPresent(search.verifyNewspaperAndMagzinesCollections()),true);
	}


	@And("user should not be able to view format section with radio button and option as Newspaper and Magazines")
	public void userShouldNotBeAbleToViewFormatSectionWithRadioButtonAndOptionAsNewspaper() {
		Assert.assertEquals(isElementPresent(search.verifyNewspaperAndMagzinesCollections()),false);
	}

	@And("user should able to view the results respective to the initiated keyword")
	public void userShouldAbleToViewTheResultsRespectiveToTheInitiatedKeyword() {
		Assert.assertEquals(isElementPresent(search.verifyRespectiveKeyword()),false);
	}

	@Then("user should able to initiate a search with a invalid Keyword {string} and search")
	public void userShouldAbleToInitiateASearchWithAInvalidKeywordAndSearch(String invalid_arg) {
		waitFor(4000);
		search.advanceSearch(invalid_arg);
		hideMobileKeyboard();
		waitFor(1000);
		search.clickSearchIcon();
	}

	@And("user should be able to navigate to search results screen with no result verbiage")
	public void userShouldBeAbleToNavigateToSearchResultsScreenWithNoResultVerbiage() {
		Assert.assertEquals(isElementPresent(search.verifyNoResultVerbiage()),true);
	}

	@And("user should able to view the suggest to purchase content with search CTA")
	public void userShouldAbleToViewTheSuggestToPurchaseContentWithSearchCTA() {
		Assert.assertEquals(isElementPresent(search.verifyViewSuggestToPurchase()),true);
	}

	@And("user click the back CTA in the Search results page")
	public void userClickTheBackCTAInTheSearchResultsPage() {
		search.clickBackButton();
	}

	@When("user types a keyword {string} in the global search bar")
	public void userTypesAKeywordInTheGlobalSearchBar(String search_text) {
		waitFor(4000);
		search.globalSearch(search_text);
		hideMobileKeyboard();
		waitFor(1000);
		search.clickSearchIcon();
	}

	@And("user should able to tap on refine CTA")
	public void userShouldAbleToTapOnRefineCTA() {
		search.clickRefineCTA();
	}

	@Then("user should able to initiate a search with a invalid Keyword {string} in the global search bar")
	public void userShouldAbleToInitiateASearchWithAInvalidKeywordInTheGlobalSearchBar(String search_text) {
		waitFor(4000);
		search.globalSearch(search_text);
		hideMobileKeyboard();
		waitFor(1000);
		search.clickSearchIcon();
		waitFor(2000);
	}

	@And("user should able to navigate to search refine popup")
	public void userShouldAbleToNavigateToSearchRefinePopup() {
		Assert.assertEquals(isElementPresent(search.verifyRefinePopup()),true);
	}

	@And("user should able to select any refiner for the formats and apply")
	public void userShouldAbleToSelectAnyRefinerForTheFormatsAndApply() {
		search.click_ebook_Format();
		search.clickAvailability();
		search.selectAvailableNow();
		search.clickAvailability();
		waitFor(1000);
		search.clickSearchIcon();
	}

	@And("user should able to view the refine pills for the selected refine")
	public void userShouldAbleToViewTheRefinePillsForTheSelectedRefine() {
		Assert.assertEquals(isElementPresent(search.verifySelectedRefine()),true);
	}

	@And("user should able to view clear all pill to remove all the filters")
	public void userShouldAbleToViewClearAllPillToRemoveAllTheFilters() {
		Assert.assertEquals(isElementPresent(search.verifyClearAllPill()),true);
	}

	@And("user should able to tap on clear all pill")
	public void userShouldAbleToTapOnClearAllPill() {
		search.clickClearAllPill();
	}

	@And("user should able to view the results without any filter")
	public void userShouldAbleToViewTheResultsWithoutAnyFilter() {
		search.clickCloseRefine();
		Assert.assertEquals(isElementPresent(search.getSearch_result_page()), true);
	}

	@And("user should be able to view Videos and Checkers Library TV in Advanced search")
	public void userShouldBeAbleToViewVideosCheckersLibraryTVInAdvancedSearch() {
		swipeDown();
		Assert.assertEquals(isElementPresent(search.verifyvBooksCollections()),true);
		swipeDown();
		Assert.assertEquals(isElementPresent(search.verifyVideosCollections()),true);
	}

	@And("user should be able to select Videobooks format for the search and perform search")
	public void userShouldBeAbleToSelectVideobooksFormatForTheSearchAndPerformSearch() {
		search.verifyvBooksCollections().click();
	}

	@And("user should be able to view the results of Videobooks")
	public void userShouldBeAbleToViewTheResultsOfVideobooks() {
		search.verifyvBookSearchResult();
	}

	@And("user should be able to select Checkers Library TV format for the search and perform search")
	public void userShouldBeAbleToSelectCheckersLibraryTVFormatForTheSearchAndPerformSearch() {
		search.verifyVideosCollections().click();
	}

	@And("user should be able to view the results of Checkers Library TV")
	public void userShouldBeAbleToViewTheResultsOfCheckersLibraryTV() {
		search.verifyVideoSearchResult();
	}

	@And("user select the Title from search results screen and tap on wishlist cta")
	public void userSelectTheTitleFromSearchResultsScreenAndTapOnWislistCta() {
		try{
			ClickOnMobileElement(search.selectSearchedTitle());
			searchedTitle = search.geteBookTitle();
			details.clickWishList();
		}catch (NoSuchElementException e){
			logger.info("Title Already wishlisted");
		}
	}

	@And("user verify added titles in wishlist and tap on checkout cta")
	public void userVerifyAddedTitlesInWishlistAndTapOnCheckoutCta() {
		try {
			search.tapWishlistTitle();
			Assert.assertTrue(search.geteBookTitle().equals(searchedTitle));
			ClickOnMobileElement(details.getCheckoutCTA());
		}catch (NoSuchElementException e){
			logger.info("No titles in wishlist");
		}

	}

	@And("user should not be able to view this title in the myshelf wishlist")
	public void userShouldNotBeAbleToViewThisTitleInTheMyshelfWishlist() {
		try {
			Assert.assertTrue(search.getNoDataTitle().isDisplayed());
			logger.info("No titles in wishlist");
		}catch (NoSuchElementException e){

			logger.info("No titles in wishlist");
		}
	}

	@And("user select the eBook Title from search results screen and tap on checkout cta")
	public void userSelectTheEBookTitleFromSearchResultsScreenAndTapOnCheckoutCta() {
		try{
			search.clickTitleCover();
			swipeDown();
			ClickOnMobileElement(details.getCheckoutCTA());
		}catch (NoSuchElementException e){
			logger.info("Title Already checked out");
			e.printStackTrace();
		}
	}

	@And("user select the eAudio Title from search results screen and tap on checkout cta")
	public void userSelectTheEAudioTitleFromSearchResultsScreenAndTapOnCheckoutCta() {
		try{
			ClickOnMobileElement(search.selectEAudioTitle());
			if (isElementPresent(details.getSecondaryDropdownCTA()))
			{
				swipeDown();
				ClickOnMobileElement(details.getCheckoutCTA());
			}else {
				swipeDown();
				ClickOnMobileElement(details.getCheckoutCTA());
			}

		}catch (NoSuchElementException e){
			logger.info("Title Already checked out");
			e.printStackTrace();
		}
	}

	@And("user searches for a keyword {string} in the search bar for eBook title")
	public void userSearchesForAKeywordInTheSearchBarForEBookTitle(String title) {
		search.advanceSearch(title);
		hideMobileKeyboard();
		search.tapAvailableNowRadio();
		search.clickEbooksRadio();
		search.click_Search_btn();
	}

	@And("user searches for a keyword {string} in the search bar for eAudio title")
	public void userSearchesForAKeywordInTheSearchBarForEAudioTitle(String title) {
		search.advanceSearch(title);
		hideMobileKeyboard();
		search.tapAvailableNowRadio();
		search.clickEaudioRadio();
		search.click_Search_btn();
	}
}
