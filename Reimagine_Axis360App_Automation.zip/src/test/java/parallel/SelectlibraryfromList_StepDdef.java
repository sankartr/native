package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.SelectLibrary;

public class SelectlibraryfromList_StepDdef {

	SelectLibrary select = new SelectLibrary(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(SelectlibraryfromList_StepDdef.class);

	@When("no matching search results are found for the searched keyword")
	public void no_matching_search_results_are_found_for_the_searched_keyword() {
		login.viewNomatchingresults();
	}

	@Then("user should be able to view no search results screen message")
	public void user_should_be_able_to_view_no_search_results_screen_message() {

		Assert.assertTrue(login.viewNomatchingresults());
	}

	@When("user should be able to select the branch library from the results")
	public void user_should_be_able_to_select_the_branch_library_from_the_results() {
		login.select_library();
	}

	@When("system should be able to map the branch library name to main library name for library identification")
	public void system_should_be_able_to_map_the_branch_library_name_to_main_library_name_for_library_identification()
			throws InterruptedException {
		Thread.sleep(3000);
	}

	@Then("system should be redirected to the login page upon selecting result based on authentication method defined for the library in the B&T admin portal")
	public void system_should_be_redirected_to_the_login_page_upon_selecting_result_based_on_authentication_method_defined_for_the_library_in_the_b_t_admin_portal() {
//		Assert.assertTrue(login.logo_txt_libId.isDisplayed());
		logger.info("user is on login page after lib selection");
	}

	@Given("user is on search results screen")
	public void user_is_on_search_results_screen() throws Throwable {
		Assert.assertEquals(login.getLogo_txt_Welcome().isDisplayed(), true);
	}

	@Then("user should be able to select the library name")
	public void user_should_be_able_to_select_the_library_name() throws Throwable {
	}

	@And("user should be navigated to login screen upon selecting library")
	public void user_should_be_navigated_to_login_screen_upon_selecting_library() throws Throwable {
		Assert.assertEquals(login.getLogo_btn_login().isDisplayed(), true);

	}

}
