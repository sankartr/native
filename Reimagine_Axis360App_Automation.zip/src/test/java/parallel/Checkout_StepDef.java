package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.InterestSurvey;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.MyCheckouts;
import pom.kidszone.MyShelf;
import pom.kidszone.Navigationbars;
import pom.kidszone.SetParentPin;

public class Checkout_StepDef extends CommonActions {

    LoginPage login = new LoginPage(DriverManager.getDriver());
    SetParentPin setPin = new SetParentPin(DriverManager.getDriver());
    ManageProfile manageProf = new ManageProfile(DriverManager.getDriver());
    MenuList menu = new MenuList(DriverManager.getDriver());
    MyShelf myShelf = new MyShelf(DriverManager.getDriver());
    MyCheckouts checkout = new MyCheckouts(DriverManager.getDriver());
    InterestSurvey interest = new InterestSurvey(DriverManager.getDriver());
    Navigationbars navigation = new Navigationbars(DriverManager.getDriver());

    ManageProfile manage = new ManageProfile(DriverManager.getDriver());

    public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

    @When("user navigates to My shelf bottom navigation and navigates to Checkout screen")
    public void user_navigates_to_my_shelf_bottom_navigation_and_navigates_to_checkout_screen() throws Throwable {
        myShelf.getMyShelf_lbl_footer().click();
        checkout.navigateCheckout();
        logger.info("User lands on MyShelf page");

    }

	@When("user navigates to My shelf bottom navigation and navigates to purchaseRequest screen")
	public void user_navigates_to_my_shelf_bottom_navigation_and_navigates_to_PurchaseRequest_screen() throws Throwable {
		myShelf.getMyShelf_lbl_footer().click();
		waitFor(1000);
		myShelf.clickwishlist();
		myShelf.clickrecommendation();
		logger.info("User lands on MyShelf page");

	}
	@When("user navigates to My shelf bottom navigation and navigates to CheckoutHistory screen")
	public void user_navigates_to_my_shelf_bottom_navigation_and_navigates_to_checkoutHistory_screen() throws Throwable {
		myShelf.getMyShelf_lbl_footer().click();
		myShelf.clickwishlist();
        myShelf.clickPurchaseHistory();
		myShelf.clickdownload();
		myShelf.clickhistory();
		logger.info("User lands on MyShelf page");

	}
    @Then("user is able to view checkouts screen with theme rendered based on library subscription and user profile type")
    public void user_is_able_to_view_checkouts_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type()
            throws Throwable {
        logger.info("theaming check");
    }

    @And("user should be able to view quick navigation CTAs as a carousel on top with Checkouts highlighted and number of titles checked out")
    public void user_should_be_able_to_view_quick_navigation_ctas_as_a_carousel_on_top_with_checkouts_highlighted_and_number_of_titles_checked_out()
            throws Throwable {
        logger.info("user should be able to view quick navigation CTAs as a carousel");
//		Assert.assertEquals(isElementPresent(checkout.getMyShelf_lbl_checkouts()), true);

    }

    @And("user should be able to view titles checked out by that user only")
    public void user_should_be_able_to_view_titles_checked_out_by_that_user_only() throws Throwable {
        for (int i = 1; i <= checkout.getCheckedout_titles_hdr().size(); i++) {
            if (i == 1)
                break;
            Assert.assertEquals(isElementPresent(checkout.getCheckedout_titles_hdr().get(i)), true);
        }
    }

	@And("user should be able to view titles sorted by latest title purchaseRequest first by default")
	public void user_should_be_able_to_view_titles_sorted_by_latest_title_purchaseRequest_first_by_default()
			throws Throwable {
		logger.info("titles sorted by latest title checked out first by default");
	}
	@And("user should be able to view titles sorted by latest title checkedhistory out first by default")
	public void user_should_be_able_to_view_titles_sorted_by_latest_title_checked_history_out_first_by_default()
			throws Throwable {
		logger.info("titles sorted by latest title checked out first by default");
	}

    @And("user should be able to view filter and sort option for the titles")
    public void user_should_be_able_to_view_filter_and_sort_option_for_the_titles() throws Throwable {
        Assert.assertEquals(isElementPresent(checkout.getCheckout_title_sort()), true);
        Assert.assertEquals(isElementPresent(checkout.getCheckout_Filter()), true);
        logger.info("user should be able to view filter and sort option for the titles");
    }

    @And("user should be able to view option to view titles as list view and grid view")
    public void user_should_be_able_to_view_option_to_view_titles_as_list_view_and_grid_view() throws Throwable {
//		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()), true);
//		checkout.clickCheckoutView();
//		Assert.assertEquals(isElementPresent(checkout.getCheckout_gridView()), true);

    }

    @And("user should be able to view option to view titles as list view and grid view for Holds")
    public void user_should_be_able_to_view_option_to_view_titles_as_list_view_and_grid_view_for_Holds()
            throws Throwable {
//		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()), true);
//		checkout.clickCheckoutView();
        Assert.assertEquals(isElementPresent(checkout.getCheckout_gridView()), true);
    }

    @And("user should be able to view titles listed as list view by default")
    public void user_should_be_able_to_view_titles_listed_as_list_view_by_default() throws Throwable {
//		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()), false);
    }

    @And("user should be able to click on List and Grid view icon to switch between list view and grid view")
    public void user_should_be_able_to_click_on_list_and_grid_view_icon_to_switch_between_list_view_and_grid_view()
            throws Throwable {
//		Assert.assertEquals(isElementPresent(checkout.getCheckout_listView()), true);
//		checkout.clickCheckoutView();
//		Assert.assertEquals(isElementPresent(checkout.getCheckout_gridView()), true);

    }

    @And("user should be able to click on back CTA to navigate back to last screen")
    public void user_should_be_able_to_click_on_back_cta_to_navigate_back_to_last_screen() throws Throwable {
        interest.closeButton();
    }

    @When("user navigates to My stuff bottom navigation and navigates to Checkout screen")
    public void user_navigates_to_my_stuff_bottom_navigation_and_navigates_to_checkout_screen() throws Throwable {
        myShelf.clickMyself();
        checkout.clickcheckout();
    }

    @Then("user is able to view Checkouts screen without theme rendered based on library subscription and user profile type")
    public void user_is_able_to_view_checkouts_screen_without_theme_rendered_based_on_library_subscription_and_user_profile_type()
            throws Throwable {
        logger.info("Checkouts screen without theme rendered based on library");
    }

    @And("user is not able to view the checked out titles for these users in checkout screen")
    public void user_is_not_able_to_view_the_checked_out_titles_for_these_users_in_checkout_screen() throws Throwable {
        interest.closeButton();
    }

    @When("user lands in My Shelf screen and navigates to Checkout screen")
    public void user_lands_in_my_shelf_screen_and_navigates_to_checkout_screen() throws Throwable {
        myShelf.clickMyself();
        myShelf.clickCheckout();
    }

    @When("user navigates to checkouts screen$")
    public void user_navigates_to_checkouts_screen() throws Throwable {
        Assert.assertEquals(isElementPresent(checkout.getMyShelf_lbl_checkouts()), true);
        checkout.navigateCheckout();
    }

    @And("no title is checked out")
    public void no_title_is_checked_out() throws Throwable {
        login.handleNothankspopup();
        myShelf.clickMyself();
        logger.info("no title is checked out");

    }

    @And("user should be able to view no titles in checkouts screen")
    public void user_should_be_able_to_view_no_titles_in_checkouts_screen() throws Throwable {
        Assert.assertEquals(isElementPresent(checkout.getCheckout_title_notfound()), true);
        interest.closeButton();
    }

	@Then("user is able to click on sort to view sort options")
	public void user_is_able_to_click_on_sort_to_view_sort_options() throws Throwable {
		checkout.clickSort();
		Assert.assertEquals(isElementPresent(checkout.getCheckout_title_atoz()), true);
        Assert.assertEquals(isElementPresent(checkout.getCheckout_Ratings()), true);
		Assert.assertEquals(isElementPresent(checkout.getCheckout_title_latest()), true);
	}

    @And("user has checked out titles")
    public void user_has_checked_out_titles() throws Throwable {
        logger.info("user has checked out titles");
    }

	@And("user should be able to view sort options: Latest Checkout, Due Date, A-Z")
	public void user_should_be_able_to_view_sort_options_latest_checkout_due_date_az() throws Throwable {
		checkout.clickSort();
		Assert.assertEquals(isElementPresent(checkout.getCheckout_title_atoz()), true);
		Assert.assertEquals(isElementPresent(checkout.getCheckout_Ratings()), true);
		Assert.assertEquals(isElementPresent(checkout.getCheckout_title_latest()), true);
	}

    @And("user should view the titles sorted with latest checked out title first by default")
    public void user_should_view_the_titles_sorted_with_latest_checked_out_title_first_by_default() throws Throwable {
        checkout.hidepopup();
        interest.closeButton();
        logger.info("user should view the titles sorted with latest checked out title first by default");
    }

    @And("user should be able to sort options by {string} and titles are sorted based on due date")
    public void user_should_be_able_to_sort_options_by_due_date_and_titles_are_sorted_based_on_due_date(String options)
            throws Throwable {
        checkout.clickSort();
        checkout.sort(options);
    }

	@And("user should be able to sort options by {string} and titles are sorted based on name order from a-z")
	public void user_should_be_able_to_sort_options_by_az_and_titles_are_sorted_based_on_name_order_from_az(
			String options) throws Throwable {
		checkout.clickSort();
		checkout.sort(options);
	}

}
