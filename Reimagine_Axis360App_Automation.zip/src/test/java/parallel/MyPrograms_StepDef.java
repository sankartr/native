package parallel;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import pom.kidszone.*;

public class MyPrograms_StepDef extends CommonActions {

    MyProgramScreen program = new MyProgramScreen(DriverManager.getDriver());
    RegisterScreen register = new RegisterScreen(DriverManager.getDriver());
    LoginPage login = new LoginPage(DriverManager.getDriver());
    SearchPage search = new SearchPage(DriverManager.getDriver());
    ProfilePage profile = new ProfilePage(DriverManager.getDriver());
    ManageProfile manage = new ManageProfile(DriverManager.getDriver());
    MyProgram myprogram=new MyProgram(DriverManager.getDriver());



    @And("^user tap menu from bottom navigation bar$")
    public void user_tap_menu_from_bottom_navigation_bar() throws Throwable {
        program.clickBottom_Menu();
    }

    @And("^user switch to kid profile in manage profile screen$")
    public void user_switch_to_kid_profile_in_manage_profile_screen() throws Throwable {
        program.clickProfile_from_Menu();
    }

    @And("^user has enabled \"Insights & Badges\" for the user profile$")
    public void user_has_enabled_something_for_the_user_profile(String strArg1) throws Throwable {
        logger.info("Enabled Insights & Badges");
    }
    @And("programs are enabled for the library")
    public void programs_are_enabled_for_the_library() throws Throwable {
        login.handleNothankspopup();
        logger.info("programs are enabled for the library");
    }
    @And("programs are enabled for the user profile type")
    public void programs_are_enabled_for_the_user_profile_type() throws Throwable {
        logger.info("programs are enabled for the user profile type");
    }
    @And("user clicks on Open program tab and navigate to the Open Program screen")
    public void user_clicks_on_open_program_tab_and_navigate_to_the_open_program_screen() throws Throwable {
        myprogram.clickOpenProgram();
        logger.info("user lands on open Program screen");

    }
    @And("user has not enrolled in any active program")
    public void user_has_not_enrolled_in_any_active_program() throws Throwable {
        logger.info("user has not enrolled in any active program");
    }

    @And("^user select the program tab from bottom navigation bar$")
    public void user_select_the_program_tab_from_bottom_navigation_bar() throws Throwable {
        program.clickBottom_Programs();
    }

    @And("user navigate to milestone program from active program")
    public void user_navigate_to_milestone_program_from_active_program() throws Throwable {
        program.clickMileStoneProgram();
    }

    @And("verify the title is completed")
    public void verify_the_title_is_completed() {

        for (int i = 0; i < 4; i++) {
            if (isElementPresent(program.programCompleted)) {
                break;
            } else {
                swipeDown();
            }
        }
        Assert.assertEquals(isElementPresent(program.programCompleted), true);

    }


    @And("^user select the open program tab$")
    public void user_select_the_open_program_tab() throws Throwable {
        program.clickOpenPrograms();
    }

    @Given("user should be in program tab from bottom navigation bar")
    public void user_should_be_in_program_tab_from_bottom_navigation_bar() {
        program.clickBottom_Programs();
    }

    @When("user is on milestone program that he joined")
    public void user_is_on_milestone_program_that_he_joined() {
        program.selectMilestone_Program_Title();
    }

    @Then("user should be able to view a milestone program details such as Program title, program description, Milestone Goal, Milestone start date, Join date ,end date")
    public void user_should_be_able_to_view_a_milestone_program_details_such_as_program_title_program_description_milestone_goal_milestone_start_date_join_date_end_date() {
        Assert.assertEquals(isElementPresent(program.milestone_program_title()), true);
        Assert.assertEquals(isElementPresent(program.milestone_program_description()), true);
        Assert.assertEquals(isElementPresent(program.milestone_start_date()), true);
        Assert.assertEquals(isElementPresent(program.milestone_join_date()), true);
        Assert.assertEquals(isElementPresent(program.milestone_end_date()), true);
        Assert.assertEquals(isElementPresent(program.milestone_title_goal()), true);
    }

    @Then("user should be able to view Add title option for the first time and NO default titles already added")
    public void user_should_be_able_to_view_add_title_option_for_the_first_time_and_no_default_titles_already_added() {
        Assert.assertEquals(isElementPresent(program.view_Add_Title_CTA()), true);
    }

    @Then("user should be able to view see all CTA if more than one title has been added")
    public void user_should_be_able_to_view_see_all_cta_if_more_than_one_title_has_been_added() {
        Assert.assertEquals(isElementPresent(program.viewMilestone_Program_SeeAll()), true);
    }

    @Then("user should be able to view Completed status that shows how many titles are completed out of the maximum number defined")
    public void user_should_be_able_to_view_completed_status_that_shows_how_many_titles_are_completed_out_of_the_maximum_number_defined() {
        logger.info("user should be able to view Completed status that shows how many titles are completed out of the maximum number");
    }

    @Then("user should be able to view the Edit Reading List CTA on the program detail page when one title has been added")
    public void user_should_be_able_to_view_the_edit_reading_list_cta_on_the_program_detail_page_when_one_title_has_been_added() {
        Assert.assertEquals(isElementPresent(program.viewEdit_Reading_List_CTA()), true);
    }

    @Then("user should be able to view Leave program CTA on the program detail page upon confirming the user will be removed from the program and will lose all data")
    public void user_should_be_able_to_view_leave_program_cta_on_the_program_detail_page_upon_confirming_the_user_will_be_removed_from_the_program_and_will_lose_all_data() {
        Assert.assertEquals(isElementPresent(program.view_LeaveProgram_CTA()), true);
    }

    @Then("user should be able to view reading list count updated every time new title is added")
    public void user_should_be_able_to_view_reading_list_count_updated_every_time_new_title_is_added() {
        logger.info("user should be able to view reading list count updated");
    }

    @Then("user should be able to view Titles in the order of adding, first one being the most recent addition")
    public void user_should_be_able_to_view_titles_in_the_order_of_adding_first_one_being_the_most_recent_addition() {
        program.click_Add_Title_CTA();
        Assert.assertEquals(isElementPresent(program.view_First_Title()), true);
    }

    @Then("user should be able to view title cropped at the end of screen indicating a right scroll")
    public void user_should_be_able_to_view_title_cropped_at_the_end_of_screen_indicating_a_right_scroll() {
        logger.info("user should be able to view title cropped at the end of screen");
    }

    @Then("user should be be able to view the Add a Title CTA  disabled if the maximum number of titles have been reached.But should see it appear again if user deletes any from the maximum title number")
    public void user_should_be_be_able_to_view_the_add_a_title_cta_disabled_if_the_maximum_number_of_titles_have_been_reached_but_should_see_it_appear_again_if_user_deletes_any_from_the_maximum_title_number() {
        Assert.assertEquals(isElementPresent(program.view_Add_Title_CTA()), true);
    }

    @Then("edit option should also be in disabled condition once all books completed with {int} percent progress")
    public void edit_option_should_also_be_in_disabled_condition_once_all_books_completed_with_percent_progress(Integer int1) {
        Assert.assertEquals(isElementPresent(program.viewEdit_Reading_List_CTA()), true);
    }

    @When("user has a milestone upcoming program from open program section which has end date")
    public void user_has_a_milestone_upcoming_program_from_open_program_section_which_has_end_date() {
        program.clickOpenPrograms();
        program.clickMileStoneProgram();
        Assert.assertEquals(isElementPresent(program.milestone_end_date()), true);
//        program.clickJoinProgram();
    }

    @When("user add more than one e-reading titles that are physically read to the program")
    public void user_add_more_than_one_e_reading_titles_that_are_physically_read_to_the_program() {
        program.add_ereading_Title_To_Program();
        program.click_Success_Ok();
    }

    @When("user remove e-reading titles that are physically read to the program")
    public void user_remove_e_reading_titles_that_are_physically_read_to_the_program() {
        program.ereading_Title_Remove();
        program.click_Remove_Program();
        program.click_Remove_Ok();
        program.click_Remove_Ok();
        waitFor(2000);
    }

    @Given("user add more than one titles from the library")
    public void user_add_more_than_one_titles_from_the_library() {
        logger.info("Based on the e-reading titles availability need to add");
    }

    @Given("user navigate to {string} section in my programs")
    public void user_navigate_to_section_in_my_programs(String string) {
        program.clickBack_Btn();
        program.clickMyPrograms();
    }

    @When("user selects program in the program section")
    public void user_selects_program_in_the_program_section() {
        program.clickMileStoneProgram();
    }

    @When("user select the See All CTA")
    public void user_select_the_see_all_cta() {
        waitFor(2000);
        swipeUp();
        swipeUp();
        program.clickMilestone_Program_SeeAll();
    }

    @Then("user navigates to {string} section")
    public void user_navigates_to_section(String string) {
        Assert.assertEquals(isElementPresent(program.edit_Reading_List()), true);
    }

    @And("user select the Edit Reading List CTA")
    public void user_select_the_edit_reading_list_cta() {
        program.clickEdit_Reading_List_CTA();
    }

    @Then("user navigates to Edit Reading List section")
    public void user_navigates_to_edit_reading_list_section() {
        Assert.assertEquals(isElementPresent(program.edit_Reading_List()), true);
    }

    @When("user select the Added by you option from bottom filtered tray menu")
    public void user_select_the_added_by_you_option_from_bottom_filtered_tray_menu() {
        program.clickMilestone_Program_SeeAll();
        program.clickFilter_Icon();
        program.clickAddedByYou_Option();
    }

    @When("user select the ebook option from bottom filtered tray menu")
    public void user_select_the_ebook_option_from_bottom_filtered_tray_menu() {
        program.clickMilestone_Program_SeeAll();
        program.clickFilter_Icon();
        program.clickEbook_Option();
    }

    @When("user select the audio option from bottom filtered tray menu")
    public void user_select_the_audio_option_from_bottom_filtered_tray_menu() {
        program.clickMilestone_Program_SeeAll();
        program.clickFilter_Icon();
        program.clickAudio_Option();
    }

    @When("user select the vbook option from bottom filtered tray menu")
    public void user_select_the_vbook_option_from_bottom_filtered_tray_menu() {
        program.clickMilestone_Program_SeeAll();
        program.clickFilter_Icon();
        program.clickVbook_Option();
    }

    @When("user select the video option from bottom filtered tray menu")
    public void user_select_the_video_option_from_bottom_filtered_tray_menu() {
        program.clickMilestone_Program_SeeAll();
        program.clickFilter_Icon();
        program.clickVideo_Option();
    }

    @When("user select the A-Z option from bottom sorted tray menu")
    public void user_select_the_a_z_option_from_bottom_sorted_tray_menu() {
        program.clickMilestone_Program_SeeAll();
        program.clickSort_Option();
        program.clickAtoZ_Option();
    }

    @When("user select the Rating option from bottom sorted tray menu")
    public void user_select_the_rating_option_from_bottom_sorted_tray_menu() {
        program.clickMilestone_Program_SeeAll();
        program.clickSort_Option();
        program.clickRating_Option();
    }

    @When("user select the Due Date option from bottom sorted tray menu")
    public void user_select_the_due_date_option_from_bottom_sorted_tray_menu() {
        program.clickMilestone_Program_SeeAll();
        program.clickSort_Option();
        program.clickDue_Date();
    }

    @When("user select the latest checkout option from bottom sorted tray menu")
    public void user_select_the_latest_checkout_option_from_bottom_sorted_tray_menu() {
        program.clickMilestone_Program_SeeAll();
        program.selectCheckout();
    }

    @Then("user should be able to view all titles sorted")
    public void user_should_be_able_to_view_all_titles_sorted() {
        Assert.assertEquals(isElementPresent(program.milestone_All_Titles_Sorted()), true);
    }

    @Then("user should be able to view all titles filtered")
    public void user_should_be_able_to_view_all_titles_filtered() {
        Assert.assertEquals(isElementPresent(program.milestone_All_Titles_Filtered()), true);
    }

    @When("user selects {string} in the program section")
    public void user_selects_in_the_program_section(String string) {
        program.selectMilestone_Program_Title();
        program.clickEdit_Reading_List_CTA();
    }

    @Then("user should be able to view a page with all the titles added in a list view")
    public void user_should_be_able_to_view_a_page_with_all_the_titles_added_in_a_list_view() {
        Assert.assertEquals(isElementPresent(program.milestone_All_Titles_Filtered()), true);
    }

    @Then("user should be able to view all the external titles that can be only sorted based on A-Z with eBooks and AudioBooks")
    public void user_should_be_able_to_view_all_the_external_titles_that_can_be_only_sorted_based_on_a_z_with_e_books_and_audio_books() {
        logger.info("Titles sorted");
    }

    @Then("user should be able to view delete option and upon selecting this option user should see cancel icons on the title to delete individual titles")
    public void user_should_be_able_to_view_delete_option_and_upon_selecting_this_option_user_should_see_cancel_icons_on_the_title_to_delete_individual_titles() {
        program.selectDelete_Option();
    }

    @Then("user should be able to delete all titles irrespective of completion,once all the books are completed with {int} percent , then those cannot be deleted from program")
    public void user_should_be_able_to_delete_all_titles_irrespective_of_completion_once_all_the_books_are_completed_with_percent_then_those_cannot_be_deleted_from_program(Integer int1) {
        logger.info("user should be able to delete all titles");
    }

    @Then("user should be able to view the CTAs {string} and {string}")
    public void user_should_be_able_to_view_the_ct_as_and(String string, String string2) {
        Assert.assertEquals(isElementPresent(program.view_Cancel_CTA()), true);
        Assert.assertEquals(isElementPresent(program.view_Save_CTA()), true);
    }

    @Then("user should be able to confirm the deleted titles by selecting {string} and confirming the deletion")
    public void user_should_be_able_to_confirm_the_deleted_titles_by_selecting_and_confirming_the_deletion(String string) {
        program.selectSave_CTA();
    }

    @Then("user should be able to view pop up if user selects cancel CTA if they did delete titles but didn’t select save CTA instead")
    public void user_should_be_able_to_view_pop_up_if_user_selects_cancel_cta_if_they_did_delete_titles_but_didn_t_select_save_cta_instead() {
        Assert.assertEquals(isElementPresent(program.view_Cancel_Popup()), true);
    }

    @Then("user should be able to cancel and go back to non-edit mode if they select {string} cta")
    public void user_should_be_able_to_cancel_and_go_back_to_non_edit_mode_if_they_select_cta(String string) {
        program.selectCancel_CTA();
    }

    @Then("user should be able to be redirected to edit reading list page via two ways {int} by selecting the {string} CTA on program detail page or the {string} CTA")
    public void user_should_be_able_to_be_redirected_to_edit_reading_list_page_via_two_ways_by_selecting_the_cta_on_program_detail_page_or_the_cta(Integer int1, String string, String string2) {
        Assert.assertEquals(isElementPresent(program.viewEdit_Reading_List_CTA()), true);
    }

    @When("user selects the individual title")
    public void user_selects_the_individual_title() {
        program.selectIndividual_Title();
    }

    @When("user select the {string} option for the title")
    public void user_select_the_option_for_the_title(String string) {
        program.selectDelete_Option();
    }

    @When("user select the Save CTA")
    public void user_select_the_save_cta() {
        program.selectSave_CTA();
    }

    @Then("user should not able to view that title in program")
    public void user_should_not_able_to_view_that_title_in_program() {
        Assert.assertEquals(isElementPresent(program.title_Not_Found()), true);
    }

    @When("user select the cancel cta")
    public void user_select_the_cancel_cta() {
        program.selectCancel_CTA();
    }

    @Then("user should able to view pop-up")
    public void user_should_able_to_view_pop_up() {
        Assert.assertEquals(isElementPresent(program.cancel_CTA_Popup()), true);
    }

    @Then("user should go back to non-edit mode")
    public void user_should_go_back_to_non_edit_mode() {
        Assert.assertEquals(isElementPresent(program.non_Edit_Mode()), true);
    }

    @Then("user should able view confirmation message having Cancel and Save CTA")
    public void user_should_able_view_confirmation_message_having_cancel_and_save_cta() {

    }

    @When("user select the delete title in program screen")
    public void user_select_the_delete_title_in_program_screen() {
        program.clickDelete_Title();
    }

    @Then("user should be able to view the Cancel CTA")
    public void user_should_be_able_to_view_the_cancel_cta() {
        Assert.assertEquals(isElementPresent(program.view_Cancel_CTA()), true);
    }

    @And("user should be able to view the Save CTA")
    public void user_should_be_able_to_view_the_save_cta() {
        Assert.assertEquals(isElementPresent(program.view_Save_CTA()), true);
    }

    @Then("user should be able to view a screen with all the titles added in a list view")
    public void user_should_be_able_to_view_a_screen_with_all_the_titles_added_in_a_list_view() {
        Assert.assertEquals(isElementPresent(program.view_Titles_List().get(1)), true);
    }

    @Then("user should be able to view sort option")
    public void user_should_be_able_to_view_sort_option() {
        Assert.assertEquals(isElementPresent(program.view_Sort_Option()), true);
    }

    @Then("user should be able to view filter option")
    public void user_should_be_able_to_view_filter_option5() {
        Assert.assertEquals(isElementPresent(program.view_Filter_Option()), true);
    }

    @Then("user should be able to view delete option")
    public void user_should_be_able_to_view_delete_option() {
        Assert.assertEquals(isElementPresent(program.view_Delete_Option()), true);
    }

    @Then("user should not be able to view all the external titles that can be sorted based")
    public void user_should_not_be_able_to_view_all_the_external_titles_that_can_be_sorted_based() {
        logger.info("all the external titles that can be sorted based");
    }

    @When("user also add more than one titles from the library")
    public void user_also_add_more_than_one_titles_from_the_library() {
        logger.info("Based on the titles availability need to add more than one titles from the library");
    }

    @Given("user select the milestone upcoming program from open program section")
    public void user_select_the_milestone_upcoming_program_from_open_program_section() {
        program.clickOpenPrograms();
        program.clickMileStoneProgram();
    }

    @When("user is on milestone program details screen")
    public void user_is_on_milestone_program_details_screen() {
        waitFor(1000);
        Assert.assertEquals(isElementPresent(program.milestone_Program_Details_Screen()), true);
    }

    @Then("user should be able to click on Join Program CTA")
    public void user_should_be_able_to_click_on_join_program_cta() {
        program.clickJoinProgram();
        Assert.assertEquals(isElementPresent(program.joinMilestoneAlertMsg()), true);
        program.clickMilestoneJoinOk();
        waitFor(1000);
        if (isElementPresent(program.confirmationPopup())) {
            program.joinConfirmationYesBtn().click();
        }
        //program.clickjoinConfirmationYes();
    }

    @Then("user should be able to view the leave program CTA indicating the user has successfully joined the program")
    public void user_should_be_able_to_view_the_leave_program_cta_indicating_the_user_has_successfully_joined_the_program() {
        Assert.assertEquals(isElementPresent(program.view_LeaveProgram_CTA()), true);
    }

    @When("user should be able to view the milestone program be a part of Active programs tab once they join the program")
    public void user_should_be_able_to_view_the_milestone_program_be_a_part_of_active_programs_tab_once_they_join_the_program() {
        program.clickBack_Btn();
        program.clickMyPrograms();
        waitFor(1000);
        Assert.assertEquals(isElementPresent(program.active_Programs()), true);
        program.clickMileStoneProgram();
        Assert.assertEquals(isElementPresent(program.milestone_Program_Details_Screen()), true);
    }

    @When("user should be able to view reading list suggested by admin to add in that particular program with ADD CTA , this will be completely optional")
    public void user_should_be_able_to_view_reading_list_suggested_by_admin_to_add_in_that_particular_program_with_add_cta_this_will_be_completely_optional() {
        Assert.assertEquals(isElementPresent(program.view_Suggested_Titles_Reading_List()), true);
        swipeUp();
        waitFor(2000);
        program.clickLeave_Program();
        waitFor(2000);
        program.clickOkButton();
    }

    @When("user should be able to view book in the reading list if they click on ADD from the suggested list")
    public void user_should_be_able_to_view_book_in_the_reading_list_if_they_click_on_add_from_the_suggested_list() {
        program.click_Add_Title_CTA();
        Assert.assertEquals(isElementPresent(program.view_Book_Reading_List()), true);
    }

    @Then("user should be able to view the Join Program CTA")
    public void user_should_be_able_to_view_the_join_program_cta() {
        Assert.assertEquals(isElementPresent(program.milestone_Join_Program_CTA()), true);
    }

    @Then("user should be able to view a milestone program details such as Program title, program description, milestone start date, join date , end date and milestone title goal")
    public void user_should_be_able_to_view_a_milestone_program_details_such_as_program_title_program_description_milestone_start_date_join_date_end_date_and_milestone_title_goal() {
        Assert.assertEquals(isElementPresent(program.milestone_program_title()), true);
        Assert.assertEquals(isElementPresent(program.milestone_start_date()), true);
        Assert.assertEquals(isElementPresent(program.milestone_join_date()), true);
        Assert.assertEquals(isElementPresent(program.milestone_end_date()), true);
        Assert.assertEquals(isElementPresent(program.milestone_title_goal()), true);
    }

    @And("user joins a milestone upcoming program from open program section")
    public void user_joins_a_milestone_upcoming_program_from_open_program_section() throws Throwable {
        program.clickOpenPrograms();
//        program.clickMileStoneProgram();
        waitFor(2000);
//        swipeDown();
        program.clickMileStoneUpcomingProgram();
        program.clickJoinProgram();
        if (isElementPresent(program.confirmationPopup())) {
            program.joinConfirmationYesBtn().click();
        }
        waitFor(2000);
        program.clickOkButton();
    }

    @When("user joins a milestone upcoming program from open program section which has no default title")
    public void userJoinsAMilestoneUpcomingProgramFromOpenProgramSectionWhichHasNoDefaultTitle() {
        program.clickOpenPrograms();
        program.clickMileStoneProgram();
        program.clickJoinProgram();
        waitFor(2000);
        program.clickOkButton();
    }

    @When("user add more than one library titles that are physically read to the program")
    public void user_add_more_than_one_library_titles_that_are_physically_read_to_the_program() {
        logger.info("Based on the physically read titles availability need to add");
    }

    @When("user add maximum external titles that are physically read to the program with done status")
    public void user_add_maximum_external_titles_that_are_physically_read_to_the_program_with_done_status() {
        logger.info("Based on the external titles availability need to add");
    }

    @Then("user should be not be able to view the Add a Title CTA")
    public void user_should_be_not_be_able_to_view_the_add_a_title_cta() {
        Assert.assertEquals(program.viewAdd_Title_CTA().isEnabled(), false);
    }

    @When("user add more than one e-reading titles that are physically read to the program with done status")
    public void user_add_more_than_one_e_reading_titles_that_are_physically_read_to_the_program_with_done_status() {
        logger.info("Based on the e-reading titles availability need to add");
    }

    @Then("user should be able to view see all CTA")
    public void user_should_be_able_to_view_see_all_cta() {
        Assert.assertEquals(isElementPresent(program.viewMilestone_Program_SeeAll()), false);
    }

    @Then("user should be able to view the Edit Reading List CTA on the program detail page")
    public void user_should_be_able_to_view_the_edit_reading_list_cta_on_the_program_detail_page() {
        Assert.assertEquals(isElementPresent(program.viewEdit_Reading_List_CTA()), true);
    }

    @When("user navigate to my program screen")
    public void user_navigate_to_my_program_screen() throws Throwable {
        program.clickBack_Btn();
        waitFor(2000);
        program.clickMyPrograms();
    }

    @Then("user should able view Joined as status in program tile for joined upcoming program")
    public void user_should_able_view_joined_as_status_in_program_tile_for_joined_upcoming_program() {
        Assert.assertEquals(isElementPresent(program.viewJoined_Program()), true);
    }

    @Then("user should able view Joined as status in program tile for joined milestone upcoming program")
    public void user_should_able_view_joined_as_status_in_program_tile_for_joined_milestone_upcoming_program() throws Throwable {
        waitFor(2000);
    //    program.scrollToMileStoneUpcomingProgram();
        Assert.assertEquals(isElementPresent(program.joined_Title()), true);
    }

    @And("user joins a milestone upcoming program for which start date has already passed")
    public void user_joins_a_milestone_upcoming_program_for_which_start_date_has_already_passed() throws Throwable {
        program.clickOpenPrograms();
        program.clickMileStoneProgram();
        program.clickJoinProgram();
        waitFor(2000);
        program.clickOkButton();
    }

    @Then("user should able view started as status in program tile")
    public void user_should_able_view_started_as_status_in_program_tile() throws Throwable {
        Assert.assertEquals(isElementPresent(program.started_Title()), true);
    }

    @And("user should able to leave upcoming milestone program")
    public void user_should_able_to_leave_upcoming_milestone_program() throws Throwable {
        program.clickMileStoneUpcomingProgram();
        program.clickLeave_Program();
        waitFor(2000);
        program.clickOkButton();
    }

    @And("user should able to leave milestone program")
    public void user_should_able_to_leave_milestone_program() throws Throwable {
        program.clickMileStoneProgram();
        program.clickLeave_Program();
        waitFor(2000);
        program.clickOkButton();
        waitFor(2000);
    }

    @When("user checkouts and read the titles from joined program one by one and completes the reading list for that program to reach milestone")
    public void user_checkouts_and_read_the_titles_from_joined_program_one_by_one_and_completes_the_reading_list_for_that_program_to_reach_milestone() throws Throwable {
        logger.info("Reading not possible option");
    }

    @When("program end date has been passed for that program")
    public void program_end_date_has_been_passed_for_that_program() throws Throwable {
        logger.info("program end date has been passed for that program");
    }

    @Then("user should able to view {string} as status in program tile under closed programs section")
    public void user_should_able_to_view_as_status_in_program_tile_under_closed_programs_section(String string) throws Throwable {
        Assert.assertEquals(isElementPresent(program.completed_Title()), true);
    }

    @When("user checkouts and read the titles from joined program one by one and partially completes the reading list")
    public void user_checkouts_and_read_the_titles_from_joined_program_one_by_one_and_partially_completes_the_reading_list() throws Throwable {
        logger.info("Reading not possible option");
    }

    @When("user navigate to my program screen by selecting the my program tab")
    public void user_navigate_to_my_program_screen_by_selecting_the_my_program_tab() throws Throwable {
        program.clickMyPrograms();
    }

    @Then("user should able to view {string} as a status in program tile under closed programs section")
    public void user_should_able_to_view_as_a_status_in_program_tile_under_closed_programs_section(String string) throws Throwable {
        Assert.assertEquals(isElementPresent(program.notCompleted_Title()), true);
    }

    @When("user is on program screen")
    public void user_is_on_program_screen() throws Throwable {
        Assert.assertEquals(isElementPresent(program.myProgram()), true);
    }

    @Given("user joins a upcoming program from open program section")
    public void user_joins_a_upcoming_program_from_open_program_section() {
        program.clickOpenPrograms_from_Menu_Programs();
        program.selectOngoingPrograms_from_OpenPrograms();
        program.clickJoinProgram();
    }

    @Given("user add titles that are physically read to the program")
    public void user_add_titles_that_are_physically_read_to_the_program() {
//    	program.clickMyPrograms_from_Menu_Programs();
//    	program.add_Titles_to_the_Programs();
        Assert.assertEquals(isElementPresent(program.addTitleProgram()), true);
    }

    @When("user reads the title in joined program one by one and completes the reading list for that program to reach milestone")
    public void user_reads_the_title_in_joined_program_one_by_one_and_completes_the_reading_list_for_that_program_to_reach_milestone() {
        logger.info("Manual process - user reads the title in joined program");
    }

    @When("user navigate to my programs in program section")
    public void user_navigate_to_my_programs_in_program_section() {
        program.clickMyPrograms_from_Menu_Programs();
    }

    @Then("user able to view program completed in closed program")
    public void user_able_to_view_program_completed_in_closed_program() {
        Assert.assertEquals(isElementPresent(program.programCompleted()), true);
        program.view_Program_Completed();
    }

    @When("user select the completed program in closed program")
    public void user_select_the_completed_program_in_closed_program() {
        program.clickMyPrograms_from_Menu_Programs();
        program.clickClosedPrograms();
        program.selectCompletedPrograms();
    }

    @Then("user navigate to program detail screen")
    public void user_navigate_to_program_detail_screen() {
        program.clickClosedPrograms();
        Assert.assertEquals(isElementPresent(program.checkProgramDetails()), true);
    }

    @Then("user should not be able to add a title from closed program")
    public void user_should_not_be_able_to_add_a_title_from_closed_program() {
        swipeDown();
        Assert.assertEquals(program.addTitleProgram().isEnabled(), false);
    }

    @Then("user should not be able to delete a title closed program")
    public void user_should_not_be_able_to_delete_a_title_closed_program() {
        program.deleteTitle_Closed_Program();
    }

    @Then("user able to view done status as n of n")
    public void user_able_to_view_done_status_as_n_of_n() {
        Assert.assertEquals(program.completedCount().getText(), "1  of 1 Titles");
    }

    @When("user navigate to my stuff by select the program tab from bottom navigation bar")
    public void user_navigate_to_my_stuff_by_select_the_program_tab_from_bottom_navigation_bar() {
        program.clickMyShelf_from_Menu();
    }

    @Then("user should be able to view the badges associated with that milestone program in their my stuff page")
    public void user_should_be_able_to_view_the_badges_associated_with_that_milestone_program_in_their_my_stuff_page() {
        Assert.assertEquals(isElementPresent(program.firstReadBadge()), true);
    }

    @Given("user switch to adult profile in manage profile screen")
    public void user_switch_to_adult_profile_in_manage_profile_screen() {
        logger.info("By default user is in adult profile");
    }

    @Given("user joins a milestone program from open program section")
    public void user_joins_a_milestone_program_from_open_program_section() {
        program.clickOpenPrograms();
        waitFor(2000);
//        swipeDown();
        program.selectOngoingPrograms_from_OpenPrograms();
        program.clickJoinProgram();
        waitFor(1000);
        program.clickOkButton();
        waitFor(1000);
        if (isElementPresent(program.confirmationPopup())) {
            program.joinConfirmationYesBtn().click();
        }
    }

    @When("user should be able to view titles for that program in the details screen")
    public void user_should_be_able_to_view_titles_for_that_program_in_the_details_screen() {
        Assert.assertEquals(isElementPresent(program.checkProgramDetails()), true);
    }

    @Then("user should be able to view titles have a progress bar for each title added from library")
    public void user_should_be_able_to_view_titles_have_a_progress_bar_for_each_title_added_from_library() {
        Assert.assertEquals(isElementPresent(program.checkProgress_Bar()), true);
    }

    @Then("user should be able to view CTAs from the last know status such as {string} but when the status is on {string} the progress bar should be {int}%")
    public void user_should_be_able_to_view_ct_as_from_the_last_know_status_such_as_but_when_the_status_is_on_the_progress_bar_should_be(String string, String string2, Integer int1) {
        Assert.assertEquals(isElementPresent(program.viewCheckout_CTA()), true);
    }

    @When("user tap on the chcekout cta for the titles in the details screen")
    public void user_tap_on_the_chcekout_cta_for_the_titles_in_the_details_screen() {
        program.clickCheckout_CTA();
        waitFor(2000);
    }

    @When("user should be able to make some progress of the titles in the details screen")
    public void user_should_be_able_to_make_some_progress_of_the_titles_in_the_details_screen() {
        Assert.assertEquals(isElementPresent(program.viewTitle_Details()), true);
    }

    @Then("user should be able to view the progress percentage update every time they make some progress with the title")
    public void user_should_be_able_to_view_the_progress_percentage_update_every_time_they_make_some_progress_with_the_title() {
        Assert.assertEquals(isElementPresent(program.viewProgress_Percentage()), true);
    }

    @Given("user joins a upcoming program from open program section having both library and own title")
    public void user_joins_a_upcoming_program_from_open_program_section_having_both_library_and_own_title() {
        program.clickUpcomingProgram();
    }

    @When("user select the Add a Title in a program detail screen")
    public void user_select_the_in_a_program_detail_screen() {
        waitFor(1000);
        swipeDown();
        program.addTitle();
    }

    @Then("user should be able to view a model with option to {string} and {string}")
    public void user_should_be_able_to_view_a_model_with_option_to_and(String string, String string2) {
        //Assert.assertEquals(isElementPresent(program.add_A_Title_Popup_Text()),true);
        Assert.assertEquals(isElementPresent(program.search_Your_Library()), true);
        Assert.assertEquals(isElementPresent(program.add_Own_Title()), true);

    }

    @Then("user should be able to select {string} option")
    public void user_should_be_able_to_select_option(String string) {
        program.click_add_Own_Title();
    }

    @Then("user should be able to view the {string}")
    public void user_should_be_able_to_view_the(String string) {
        Assert.assertEquals(isElementPresent(program.viewAdd_Title_CTA()), true);
    }

    @Then("user enter the mandatory and optional fields on search")
    public void user_enter_the_mandatory_and_optional_fields_on_search() {
        program.add_Title_Values();
        program.selectTitle_Type();
    }

    @Then("user tap on the {string} cta")
    public void user_tap_on_the_cta(String string) {
        program.click_Add_Title_CTA();
    }

    @Then("user should able to select {string} option")
    public void user_should_able_to_select_option(String string) {
        program.click_Add_YourOwn_TitleOption();
    }

    @Then("user should be able to select {string} option and upon selecting this they will be redirected to Add a Title page")
    public void user_should_be_able_to_select_option_and_upon_selecting_this_they_will_be_redirected_to_add_a_title_page(String string) {
        Assert.assertEquals(isElementPresent(program.add_Own_Title()), true);
    }

    @Then("user select {string} option in the modal popup")
    public void user_select_option_in_the_modal_popup(String string) {
        program.click_Add_YourOwn_TitleOption();
    }

    @Then("user navigates into the {string} screen")
    public void user_navigates_into_the_screen(String string) {
        Assert.assertEquals(isElementPresent(program.titleName()), true);
        Assert.assertEquals(isElementPresent(program.authorName()), true);
        Assert.assertEquals(isElementPresent(program.titleType()), true);
    }

    @Then("user should be able to view Title name as mandatory")
    public void user_should_be_able_to_view_title_name_as_mandatory() {
        Assert.assertEquals(isElementPresent(program.titleName()), true);
        Assert.assertEquals(program.addButton().isEnabled(), false);
        program.sendKeysAuthorName();
        hideMobileKeyboard();
        program.clickTitleTypeBox();
        program.clickTitleTypeOptionEbook();
        Assert.assertEquals(program.addButton().isEnabled(), false);
    }

    @Then("user should be able to view authors name as optional")
    public void user_should_be_able_to_view_authors_name_as_optional() {
        Assert.assertEquals(isElementPresent(program.authorName()), true);
    }

    @Then("user should be able to view title type as mandatory field with drop down options eBook Print Book and eAudio Audiobook")
    public void user_should_be_able_to_view_title_type_as_mandatory_field_with_drop_down_options() {
        program.clickBack_Btn();
        program.addTitle();
        program.click_Add_YourOwn_TitleOption();
        Assert.assertEquals(program.addButton().isEnabled(), false);
        program.sendKeysTitleName();
        hideMobileKeyboard();
        Assert.assertEquals(program.addButton().isEnabled(), false);
        logger.info("Manual process - unable to inspect the info's on Iphone");
    }

    @Then("user enter mandatory fields and tap on Add CTA and enters {string} and {string}")
    public void user_enter_mandatory_fields_and_tap_on_Add_cta_and_enters(String userName, String password) {
        program.enter_Values_Mandatory(userName, password);

    }

    @Then("user should be able to view default title cover image added with the title name specified by user")
    public void user_should_be_able_to_view_default_title_cover_image_added_with_the_title_name_specified_by_user() {
        Assert.assertEquals(isElementPresent(program.view_Title_Name()), true);
    }

    @Then("user should be able to view {string} CTA once the user is done updating the details for the external title")
    public void user_should_be_able_to_view_cta_once_the_user_is_done_updating_the_details_for_the_external_title(String string) {
        swipeDown();
        swipeDown();
        Assert.assertEquals(isElementPresent(program.addTitleProgram()), true);
    }

    @Then("user should be able to view the manually added external title be added to the program detail page")
    public void user_should_be_able_to_view_the_manually_added_external_title_be_added_to_the_program_detail_page() {
        logger.info("Manual process - able to view the manually added external title");
    }

    @When("user select the {string} in a program detail page")
    public void userSelectTheAddATitleInAProgramDetailPage() {
        program.click_Add_Title_CTA();
    }

    @And("user should be able to select {string} option and upon selecting this they will be redirected to advance search screen with a search bar and various filtering options")
    public void userShouldBeAbleToSelectOptionAndUponSelectingThisTheyWillBeRedirectedToAdvanceSearchScreenWithASearchBarAndVariousFilteringOptions(String arg0) {
        program.click_search_Your_Library();
    }

    @Then("user enter the {string} keyword for ebook and tap on search")
    public void user_enter_the_keyword_and_tap_on_search(String title) {
        search.searchkeyWord(title);
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            hideMobileKeyboard();
        } else {
            search.clickIOSKeyboardDone();
        }
        waitFor(1000);
        search.clickEbooksRadio();
        search.clicksearchResultButton();
    }

    @Then("user should be able to view close icon to close the advance search page and go back to program details page")
    public void user_should_be_able_to_view_close_icon_to_close_the_advance_search_page_and_go_back_to_program_details_page() {
        Assert.assertEquals(program.verifyClose_Icon(), true);
        program.clickCloseAdvanceSearch();

    }

    @And("user should be able to view keyword results in a list view")
    public void userShouldBeAbleToViewKeywordResultsInAListView() {
        Assert.assertEquals(program.verifyTitleSearchResultsScreen(), true);
    }

    @Then("user tap on the filter icon and update the filters")
    public void user_tap_on_the_filter_icon_and_update_the_filters() {
        program.clickFilter_Icon();
    }

    @Then("user tap on the search cta")
    public void user_tap_on_the_search_cta() {
        search.clicksearchResultButton();
    }

    @Then("user should be able to view the search results based on the applied filters")
    public void user_should_be_able_to_view_the_search_results_based_on_the_applied_filters() {
        Assert.assertEquals(program.verifyTitleSearchResultsScreen(), true);
    }

    @And("user should be able to tap on Add title one at a time")
    public void userShouldBeAbleToTapOnAddTitleOneAtATime() {
        program.addTitleFromSearchResultsScreen();
        program.clickAddTitleSuccessPopupOk();
    }

    @And("user should be able to view the added ebook title in the program in the details screen")
    public void userShouldBeAbleToViewTheAddedTitleInTheProgramInTheDetailsScreen() {
        waitFor(2000);
        swipeDown();
        Assert.assertEquals(isElementPresent(program.view_Book_Reading_List()), true);
    }

    @And("user should be able  to select ebook in the advance search category")
    public void userShouldBeAbleToSelectEbookInTheAdvanceSearchCategory() {
        program.selecteBookInAdvanceSearch();
    }

    @When("user add maximum library titles that are read to the program with done status")
    public void user_add_maximum_library_titles_that_are_read_to_the_program_with_done_status() {
        logger.info("User add maximum library titles that are read to the program with done status");
    }

    @When("user navigate to milestone program detail be a part of Active programs tab")
    public void user_navigate_to_milestone_program_detail_be_a_part_of_active_programs_tab() {
        program.navigate_To_Program_Details();
    }

    @Given("user tap on the any one milestone program")
    public void user_tap_on_the_any_one_milestone_program() {
        program.selectMilestone_Program_Title();
    }

    @When("user should be able to navigates into the program detail page")
    public void user_should_be_able_to_navigates_into_the_program_detail_page() {
        Assert.assertEquals(isElementPresent(program.checkProgramDetails()), true);
    }

    @Then("user should be able to view the updated details of the milestone program such as start date and end date suggest titles for the program")
    public void user_should_be_able_to_view_the_updated_details_of_the_milestone_program_such_as_start_date_and_end_date_suggest_titles_for_the_program() {
        Assert.assertEquals(isElementPresent(program.milestone_start_date()), true);
    }

    @Given("user add title1 then observes the reading list count")
    public void user_add_title1_then_observes_the_reading_list_count() {
        program.click_Add_Title_CTA();
        logger.info("Observed the reading list count increased");
    }

    @Then("user should be able to view Add title option for the first time")
    public void user_should_be_able_to_view_add_title_option_for_the_first_time() {
        Assert.assertEquals(isElementPresent(program.view_Add_Title_CTA()), true);
    }

    @Then("user add title then observes the reading list count")
    public void user_add_title_then_observes_the_reading_list_count() {
        program.click_Add_Title_CTA();
        logger.info("Observed the reading list count increased");
    }

    @Then("user add one more title then observes the difference in reading list count")
    public void user_add_one_more_title_then_observes_the_difference_in_reading_list_count() {
        program.click_Add_Title_CTA();
        logger.info("Observed the reading list count increased");
    }

    @Then("user should be able to view Leave program CTA on the program detail page")
    public void user_should_be_able_to_view_leave_program_cta_on_the_program_detail_page() {
        Assert.assertEquals(isElementPresent(program.view_Leave_Program_CTA()), true);
    }

    @When("user select the Leave program in program detail page")
    public void user_select_the_leave_program_in_program_detail_page() {
        program.clickLeave_Program();
    }

    @Then("user should able to view confirmation message Are you sure you want to leave the program, Program Name? Cancel / OK")
    public void user_should_able_to_view_confirmation_message_are_you_sure_you_want_to_leave_the_program_program_name_cancel_ok() {
        Assert.assertEquals(isElementPresent(program.view_Confirmation_Message()), true);
    }

    @When("user navigate to edit reading list screen by selecting the Edit Reading List CTA")
    public void user_navigate_to_edit_reading_list_screen_by_selecting_the_edit_reading_list_cta() {
        program.clickEdit_Reading_List_CTA();
    }

    @Then("user should be able to view Done status that shows how many titles are completed out of the maximum number defined")
    public void user_should_be_able_to_view_done_status_that_shows_how_many_titles_are_completed_out_of_the_maximum_number_defined() {
        Assert.assertEquals(isElementPresent(program.view_Done_Status_Title()), true);
    }

    @Then("user should be able to view Titles in the order of adding")
    public void user_should_be_able_to_view_titles_in_the_order_of_adding() {
        Assert.assertEquals(isElementPresent(program.view_Titles_Order()), true);
    }

    @Then("user should be able to view titles added from e-content")
    public void user_should_be_able_to_view_titles_added_from_e_content() {
        Assert.assertEquals(isElementPresent(program.view_Titles_eContent()), true);
    }

    @Then("user should be able to view titles added from external titles")
    public void user_should_be_able_to_view_titles_added_from_external_titles() {
        Assert.assertEquals(isElementPresent(program.view_Titles_External()), true);
    }

    @Then("user should able to view program title")
    public void user_should_able_to_view_program_title() {
        Assert.assertEquals(isElementPresent(program.milestone_program_title()), true);
    }

    @Then("user should able to view program description")
    public void user_should_able_to_view_program_description() {
        Assert.assertEquals(isElementPresent(program.milestone_program_description()), true);
    }

    @Then("user should able to view milestone start date")
    public void user_should_able_to_view_milestone_start_date() {
        Assert.assertEquals(isElementPresent(program.milestone_start_date()), true);
    }

    @Then("user should able to view milestone end date")
    public void user_should_able_to_view_milestone_end_date() {
        Assert.assertEquals(isElementPresent(program.milestone_end_date()), true);
    }

    @Then("user should able view {string} as status in program tile for joined milestone ongoing program")
    public void user_should_able_view_as_status_in_program_tile_for_joined_milestone_ongoing_program(String string) {
        Assert.assertEquals(isElementPresent(program.joined_Title()), true);
    }

    @Then("user should be able to view the milestone program in active program section based on  program status")
    public void user_should_be_able_to_view_the_milestone_program_in_active_program_section_based_on_program_status() {
        program.clickMyPrograms();
        Assert.assertEquals(isElementPresent(program.active_Programs()), true);
    }

    @Then("user should be able to view the program status say {string}")
    public void user_should_be_able_to_view_the_program_status_say(String string) {
        Assert.assertEquals(isElementPresent(program.completed_Title()), true);
    }

    @Then("user should be able to view the milestone program in closed program section")
    public void user_should_be_able_to_view_the_milestone_program_in_closed_program_section() {
        program.clickMyPrograms();
        Assert.assertEquals(isElementPresent(program.closed_Programs()), true);
    }

    @And("user should be able to view start date, end date, program title, program description and Title image in milestone snap shot")
    public void user_should_be_able_to_view_start_date_end_date_program_title_program_description_and_title_image_in_milestone_snap_shot() throws Throwable {
        Assert.assertEquals(isElementPresent(program.label_Start_Date()), true);
        Assert.assertEquals(isElementPresent(program.label_End_Date()), true);
        Assert.assertEquals(isElementPresent(program.label_Milestone_Program_Title()), true);
    }

    @And("user should be able to view program detail page if they select the milestone program tile")
    public void user_should_be_able_to_view_program_detail_page_if_they_select_the_milestone_program_tile() {
//        program.clickMileStoneProgram();
        Assert.assertEquals(isElementPresent(program.checkProgramDetails()), true);
    }

    @When("user reads the title in joined program one by one and partially completes the reading list for that program to reach milestone")
    public void user_reads_the_title_in_joined_program_one_by_one_and_partially_completes_the_reading_list_for_that_program_to_reach_milestone() {
        logger.info("Manual process - reading the book");
    }

    @Then("user should be able to view a milestone program tile in open program section based on the start date of program")
    public void user_should_be_able_to_view_a_milestone_program_tile_in_open_program_section_based_on_the_start_date_of_program() {
        program.clickOpenPrograms();
        Assert.assertEquals(isElementPresent(program.milestone_Program()), true);
    }

    @And("user should be able to view a milestone program tile in milestone upcoming program section based on the start date of program")
    public void user_should_be_able_to_view_a_milestone_program_tile_in_milestone_upcoming_program_section_based_on_the_start_date_of_program() {
        program.clickMyPrograms();
        Assert.assertEquals(isElementPresent(program.milestone_Program()), true);
    }

    @Then("user should be able to view the milestone based programs in My programs section")
    public void user_should_be_able_to_view_the_milestone_based_programs_in_section() {
        program.clickMyPrograms();
        Assert.assertEquals(isElementPresent(program.milestone_Program()), true);
    }

    @Then("user should be able to view the milestone program snap shot details as a tile")
    public void user_should_be_able_to_view_the_milestone_program_snap_shot_details_as_a_tile() {
        logger.info("Image validation");
    }

    @When("user clicks the adult profile and cancels the interest")
    public void user_clicks_the_adult_profile_and_cancels_the_interest() {
        register.adultprofileSelection();
        login.cancelViewInterest();
    }

    @When("user selects the program joined from my programs section")
    public void user_selects_the_program_joined_from_my_programs_section() {
        program.clickBack_Btn();
        waitFor(2000);
        program.clickMyPrograms();
//    	program.clickMileStoneProgram();
        program.clickMileStoneUpcomingProgram();
    }

    @Then("user clicks a program from the MY programs tab")
    public void user_clicks_a_program_from_the_my_programs_tab() {
        program.selectOngoingPrograms_from_OpenPrograms();
    }

    @Then("user scrolls down for the reading list")
    public void user_scrolls_down_for_the_reading_list() {
        swipeDown();
    }

    @When("user selects the open programs page")
    public void user_selects_the_open_programs_page() {
        program.clickOpenPrograms();
    }

    @When("user should be able to read the titles {int}% in the details screen")
    public void user_should_be_able_to_read_the_titles_in_the_details_screen(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("user should be able to view the Read primary CTA at all time even when the they finish the titled and only change will be the progress bar will say {int}%")
    public void user_should_be_able_to_view_the_read_primary_cta_at_all_time_even_when_the_they_finish_the_titled_and_only_change_will_be_the_progress_bar_will_say(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("user should be able to view  Read which will have options to download and return and renew if primary CTA is Read when they go to the title details page")
    public void user_should_be_able_to_view_read_which_will_have_options_to_download_and_return_and_renew_if_primary_cta_is_read_when_they_go_to_the_title_details_page() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @When("user should be able to listen the titles {int}% in the details screen")
    public void user_should_be_able_to_listen_the_titles_in_the_details_screen(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("user should be able to view the Listen primary CTA at all time even when the they finish the titled and only change will be the progress bar will say {int}%")
    public void user_should_be_able_to_view_the_listen_primary_cta_at_all_time_even_when_the_they_finish_the_titled_and_only_change_will_be_the_progress_bar_will_say(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("user should be able to view Listen which will have options to download and return and renew if primary CTA is listen when they go to the title details page")
    public void user_should_be_able_to_view_listen_which_will_have_options_to_download_and_return_and_renew_if_primary_cta_is_listen_when_they_go_to_the_title_details_page() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("user should not be able to view Read CTA if they didn't checkout the title")
    public void user_should_not_be_able_to_view_read_cta_if_they_didn_t_checkout_the_title() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @When("user should be able to view Place hold titles in the details screen")
    public void user_should_be_able_to_view_place_hold_titles_in_the_details_screen() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("user should be able to view the {string} cta for the same title once available for checkout which will have option to add to Wishlist when they go to the title details page")
    public void user_should_be_able_to_view_the_cta_for_the_same_title_once_available_for_checkout_which_will_have_option_to_add_to_wishlist_when_they_go_to_the_title_details_page(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("user should be able to view {string} cta which will have option to add to Wishlist when they go to the title details page")
    public void user_should_be_able_to_view_cta_which_will_have_option_to_add_to_wishlist_when_they_go_to_the_title_details_page(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @When("user should be able to view Place hold cta")
    public void user_should_be_able_to_view_place_hold_cta() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("user should be able to view the {string} cta for the same title updated as a primary")
    public void user_should_be_able_to_view_the_cta_for_the_same_title_updated_as_a_primary(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("user should be able to view Remove Hold which will have options to Suspend Hold and Add to Wishlist when they go to the title details page")
    public void user_should_be_able_to_view_remove_hold_which_will_have_options_to_suspend_hold_and_add_to_wishlist_when_they_go_to_the_title_details_page() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("user should be able to view a modal with option to {string} and {string}")
    public void user_should_be_able_to_view_a_modal_with_option_to_and(String string, String string2) {
        Assert.assertEquals(isElementPresent(program.search_Your_Library()), true);
        Assert.assertEquals(isElementPresent(program.add_Own_Title()), true);
    }

    @Then("user should be able to view external titles with either Mark as done")
    public void user_should_be_able_to_view_external_titles_with_either_mark_as_done() {
    }

    @Then("user should be able to view progress as {int} % if user selected {string} option when creating the title and the primary CTA as {string}")
    public void user_should_be_able_to_view_progress_as_if_user_selected_option_when_creating_the_title_and_the_primary_cta_as(Integer int1, String string, String string2) {
    }

    @Then("user should be able to switch the completion status as many times as they want as long as the maximum title list is not fully completed")
    public void user_should_be_able_to_switch_the_completion_status_as_many_times_as_they_want_as_long_as_the_maximum_title_list_is_not_fully_completed() {
    }

    @Then("user should be able to view progress as {int} % if user  DID NOT select {string} option when creating the title and should see the primary CTA as {string}")
    public void user_should_be_able_to_view_progress_as_if_user_did_not_select_option_when_creating_the_title_and_should_see_the_primary_cta_as(Integer int1, String string, String string2) {
    }

    @Given("user launch the app and search {string} with KidsZone and axis Subscription")
    public void user_launch_the_app_and_search_with_kids_zone_and_axis_subscription(String string) {
    }

    @Given("user clicks login cta after enters {string} And {string}")
    public void user_clicks_login_cta_after_enters_and(String string, String string2) {
    }

    @Given("user selects adult profile in listing screen")
    public void user_selects_adult_profile_in_listing_screen() {
    }

    @Given("user has disabled {string} for the adult profile")
    public void user_has_disabled_for_the_adult_profile(String string) {
    }

    @Given("user tap on the program tab from bottom navigation bar")
    public void user_tap_on_the_program_tab_from_bottom_navigation_bar() {
    }

    @Given("user should be able to view the {string} icon for the program")
    public void user_should_be_able_to_view_the_icon_for_the_program(String string) {
    }

    @Given("user should be able to added titles successfully")
    public void user_should_be_able_to_added_titles_successfully() {
    }

    @Then("user should be able to view Checkout as the primary CTA")
    public void user_should_be_able_to_view_checkout_as_the_primary_cta() {
        swipeDown();
        waitFor(2000);
        Assert.assertEquals(isElementPresent(program.verifyPrimaryCTA()), true);
    }

    @Then("user should be able to view Not Done progress status for checkout at all time")
    public void user_should_be_able_to_view_not_done_progress_status_for_checkout_at_all_time() {
        Assert.assertEquals(program.verifyExternalTitleCTA(), true);
        if (isElementPresent(program.verifyMarkAsNotDoneCTA())) {
            program.verifyMarkAsNotDoneCTA().click();
            waitFor(2000);
            Assert.assertEquals(isElementPresent(program.verifyMarkAsDoneCTA()), true);
        } else {
            waitFor(2000);
            program.verifyMarkAsDoneCTA().click();
            Assert.assertEquals(isElementPresent(program.verifyMarkAsNotDoneCTA()), true);
        }
    }

    @Then("user should not be able to view Read online CTA if they didn't checkout the title")
    public void user_should_not_be_able_to_view_read_online_cta_if_they_didn_t_checkout_the_title() {
        logger.info("user should not be able to view Read online CTA if they didn't checkout the title");
    }

    @When("user tap on the checkout CTA for the titles")
    public void user_tap_on_the_checkout_cta_for_the_titles() {
    }

    @Then("user should be able to view Read online CTA and which will have options to download, return and renew if primary CTA is Read when they go to the title details page")
    public void user_should_be_able_to_view_read_online_cta_and_which_will_have_options_to_download_return_and_renew_if_primary_cta_is_read_when_they_go_to_the_title_details_page() {
        logger.info("user should be able to view Read online CTA and which will have options to download, return and renew if primary CTA is Read when they go to the title details page");
    }

    @When("user tap on the checkout CTA for the audio titles")
    public void user_tap_on_the_checkout_cta_for_the_audio_titles() {
    }

    @Then("user should be able to view {string} and which will have options to download, return and renew if primary CTA is Listen when they go to the title details page")
    public void user_should_be_able_to_view_and_which_will_have_options_to_download_return_and_renew_if_primary_cta_is_listen_when_they_go_to_the_title_details_page(String string) {
    }

    @When("user should be able to view Place on hold cta")
    public void user_should_be_able_to_view_place_on_hold_cta() {
    }

    @Then("user should be able to view Read only once user checks out")
    public void user_should_be_able_to_view_read_only_once_user_checks_out() {
    }

    @Then("user should be able to view progress update to {string} if they select {string}")
    public void user_should_be_able_to_view_progress_update_to_if_they_select(String string, String string2) {
    }

    @Then("user can reverse it if they select {string} the progress bar will switch to {string}")
    public void user_can_reverse_it_if_they_select_the_progress_bar_will_switch_to(String string, String string2) {
    }


    @Then("user should  be able to view {string} option and tap on the {string}")
    public void user_should_be_able_to_view_option_and_tap_on_the(String string, String string2) {
    }

    @Then("user should be able to view external titles with either Mark as done until reach the maximum title list is not fully completed")
    public void user_should_be_able_to_view_external_titles_with_either_mark_as_done_until_reach_the_maximum_title_list_is_not_fully_completed() {
    }

    @Then("user should  be able to view {string} option and tap on the {string} CTA")
    public void user_should_be_able_to_view_option_and_tap_on_the_cta(String string, String string2) {
    }

    @Then("user should be able to view {string} options and tap on the {string}")
    public void user_should_be_able_to_view_options_and_tap_on_the(String string, String string2) {
    }

    @Given("user selects teen profile in listing screen")
    public void user_selects_teen_profile_in_listing_screen() {
    }

    @Given("user should enable the insights and badges from my profile screen")
    public void user_should_enable_the_insights_and_badges_from_my_profile_screen() {
    }

    @Then("user should be able to view the Read primary CTA at all time even when the they finish the title , only change will be the progress bar will say {int}%")
    public void user_should_be_able_to_view_the_read_primary_cta_at_all_time_even_when_the_they_finish_the_title_only_change_will_be_the_progress_bar_will_say(Integer int1) {
    }

    @Then("user should be able to view  Read which will have options to download, return and renew if primary CTA is Read when they go to the title details page")
    public void user_should_be_able_to_view_read_which_will_have_options_to_download_return_and_renew_if_primary_cta_is_read_when_they_go_to_the_title_details_page() {
    }

    @Then("user should be able to view the Listen primary CTA at all time even when the they finish the title , only change will be the progress bar will say {int}%")
    public void user_should_be_able_to_view_the_listen_primary_cta_at_all_time_even_when_the_they_finish_the_title_only_change_will_be_the_progress_bar_will_say(Integer int1) {
    }

    @Then("user should be able to view Listen which will have options to download, return and renew if primary CTA is listen when they go to the title details page")
    public void user_should_be_able_to_view_listen_which_will_have_options_to_download_return_and_renew_if_primary_cta_is_listen_when_they_go_to_the_title_details_page() {
    }

    @Then("user should able to view confirmation message {string}")
    public void userShouldAbleToViewConfirmationMessageAreYouSureYouWantToLeaveTheProgramCancelOK(String arg0) {
        Assert.assertEquals(isElementPresent(program.milestone_Leave_Program_Alert()), true);
    }

    @And("user should be able to select Add your own title  option and upon selecting this they will be redirected to Add a Title page")
    public void userShouldBeAbleToSelectAddYourOwnTitleOptionAndUponSelectingThisTheyWillBeRedirectedToAddATitlePage() {
        Assert.assertEquals(isElementPresent(program.titleName()), true);
        Assert.assertEquals(isElementPresent(program.authorName()), true);
        Assert.assertEquals(isElementPresent(program.titleType()), true);
    }

    @And("user enter mandatory fields and tap on Add CTA")
    public void userEnterMandatoryFieldsAndTapOnAddCTA() {
        program.sendKeysTitleName();
        hideMobileKeyboard();
        program.sendKeysAuthorName();
        hideMobileKeyboard();
        program.clickTitleTypeBox();
        program.clickTitleTypeOptionEbook();
        program.clickAddButtonOwnTitle();
        if(isElementPresent(program.addTitleSuccessPopup())){
            Assert.assertEquals(isElementPresent(program.addTitleSuccessPopup()), true);
            program.clickAddTitleSuccessPopupOk();
        }
    }

    @And("user removes the added title from program")
    public void userRemovesTheAddedTitleFromProgram() {
        waitFor(1000);
        swipeDown();
        program.clickTitleSettingDots();
        program.clickRemoveTitle();
        program.clickTitleRemoveOkPopup();
        program.clickTitleRemoveOkPopup();
    }

    @And("user should be able to select Search Your Library option and upon selecting this they will be redirected to advance search screen with a search bar and various filtering options")
    public void userShouldBeAbleToSelectSearchYourLibraryOptionAndUponSelectingThisTheyWillBeRedirectedToAdvanceSearchScreenWithASearchBarAndVariousFilteringOptions() {
        program.click_search_Your_Library();
        Assert.assertEquals(isElementPresent(program.advanceSearchHeading()), true);
    }

    @And("user enter the {string} keyword for eaudio and tap on search")
    public void userEnterTheTheKeywordForEaudioAndTapOnSearch(String title) {
        search.searchkeyWord(title);
        hideMobileKeyboard();
        waitFor(1000);
        // search.clickEaudioRadio();
        // search.clickEaudioRadio();
        search.clicksearchResultButton();
    }

    @And("user should be able to view the added eaudio title in the program in the details screen")
    public void userShouldBeAbleToViewTheAddedEaudioTitleInTheProgramInTheDetailsScreen() {
        Assert.assertEquals(isElementPresent(program.eaudioTitle()), true);
    }

    @And("Checkout the title")
    public void Checkout_the_title() {
        for (int i = 0; i <= 4; i++) {
            if (isElementPresent(program.getCheckout_CTA())) {
                break;
            } else {
                swipeDown();
            }
        }
        program.getCheckout_CTA().click();
        program.getConfirm_OK();
    }

    @And("user should be able to view edit option")
    public void userShouldBeAbleToViewEditOption() {
        program.milestone_editIcon();
    }

    @And("user select edit option in the program screen")
    public void userSelectEditOptionInTheProgramScreen() {
        program.click_milestone_editIcon();
    }

    @Then("user should be able to view the cancel CTA")
    public void userShouldBeAbleToViewTheCancelCTA() {
        Assert.assertEquals(isElementPresent(program.verify_milestone_Program_CancelCTA()), true);
    }

    @And("user should be able to view the Remove CTA in disabled mode")
    public void userShouldBeAbleToViewTheRemoveCTAInDisabledMode() {
        Assert.assertEquals(program.verify_milestone_Program_RemoveCTA_Disabled(), true);
    }

    @And("user should be able to view checkbox in the title on top right corner")
    public void userShouldBeAbleToViewCheckboxInTheTitleOnTopRightCorner() {
        Assert.assertEquals(isElementPresent(program.verify_milestone_Program_TitlesCheckbox()), true);
    }

    @And("user select the checkbox in the program details screen")
    public void userSelectTheCheckboxInTheProgramDetailsScreen() {
        program.click_milestone_Program_TitlesCheckbox();
    }

    @And("user should be able to view the {string} CTA in enabled mode")
    public void userShouldBeAbleToViewTheRemoveCTAInEnabledMode() {
        Assert.assertEquals(program.verify_milestone_Program_RemoveCTA_Enabled(), true);
    }

    @And("user clicks on the Remove CTA")
    public void userClicksOnTheRemoveCTA() {
        program.click_milestone_Program_RemoveCTA();
    }

    @And("user is able to view alert message with click and Ok CTA")
    public void userIsAbleToViewAlertMessageWithClickAndOkCTA() {
        if(System.getProperty("platform").equalsIgnoreCase("Android")) {
            Assert.assertEquals(program.verifyAlertMessagePopup(), "Are you sure you want to delete this title?");
        }else
        {
            Assert.assertEquals(program.verifyAlertMessagePopup(), "Are you sure you want to delete this title?Dialogue");
        }
        Assert.assertEquals(isElementPresent(program.verifyCancelCTA()), true);
        Assert.assertEquals(isElementPresent(program.verifyOKCTA()), true);
    }

    @And("clicks on the cancel CTA in the alert message popup")
    public void clicksOnTheCancelCTAInTheAlertMessagePopup() {
        program.clickCancelCTA();
    }

    @And("user clicks on the cancel CTA in program details screen")
    public void userClicksOnTheCancelCTAInProgramDetailsScreen() {
        program.click_milestone_Program_CancelCTA();
    }

    @And("user should not be able to view checkbox in the title on top right corner")
    public void userShouldNotBeAbleToViewCheckboxInTheTitleOnTopRightCorner() {
        Assert.assertEquals(isElementPresent(program.verify_milestone_Program_TitlesCheckbox()), false);
    }

    @And("clicks on the ok CTA in the alert message popup")
    public void clicksOnTheOkCTAInTheAlertMessagePopup() {
        program.clickOkCTA();
    }

    @And("user should be able to view successful title removal popup")
    public void userShouldBeAbleToViewSuccessfulTitleRemovalPopup() {
        Assert.assertEquals(program.verifyAlertMessagePopup(), "You have removed title from Milestone program 1 Program successfully");
        Assert.assertEquals(isElementPresent(program.verifyOKCTA()), true);

    }

    @And("user should be able to view sort options")
    public void userShouldBeAbleToViewSortOptions() {
        Assert.assertEquals(isElementPresent(program.verifyAtoZ_Option()), true);
        Assert.assertEquals(isElementPresent(program.verifyZtoA_Option()), true);
        program.clickAtoZ_Option();
    }

    @And("user clicks on the sort option")
    public void userClicksOnTheSortOption() {
        program.clickSort_Option();
    }

    @And("user clicks on the filter option")
    public void userClicksOnTheFilterOption() {
        program.click_view_Filter_Option();
    }

    @And("user should be able to view the filter options")
    public void userShouldBeAbleToViewTheFilterOptions() {
        Assert.assertEquals(isElementPresent(program.verify_All_FilterOption()), true);
        Assert.assertEquals(isElementPresent(program.verify_eAudio_FilterOption()), true);
        Assert.assertEquals(isElementPresent(program.verify_eBook_FilterOption()), true);
        Assert.assertEquals(isElementPresent(program.verify_externalTitle_FilterOption()), true);
    }

    @And("user enter the {string} keyword for video and tap on search")
    public void userEnterTheTheKeywordForVideoAndTapOnSearch(String title) {
        search.searchkeyWord(title);
        hideMobileKeyboard();
        waitFor(1000);
        search.clickVideoRadio();
        search.clicksearchResultButton();
    }

    @And("user enter the {string} keyword for vbook and tap on search")
    public void userEnterTheTheKeywordForVbookAndTapOnSearch(String title) {
        search.searchkeyWord(title);
        hideMobileKeyboard();
        waitFor(1000);
        search.clickVbookRadio();
        search.clicksearchResultButton();
    }

    @Given("user joins an upcoming program from open program section")
    public void userJoinsAnUpcomingProgramFromOpenProgramSection() {
        logger.info("Joined a upcoming program manually");
    }

    @And("user add title that are physically read to the program")
    public void userAddTitleThatArePhysicallyReadToTheProgram() {
        logger.info("Added a title to the program");

    }

    @Then("user should not be able to view the progress progress if insights and badges are disabled")
    public void userShouldNotBeAbleToViewTheProgressProgressIfInsightsAndBadgesAreDisabled() {
        Assert.assertEquals(isElementPresent(program.verifyProgressBar()), false);
    }

    @Then("user should be able to view the progress progress if insights and badges are enabled")
    public void userShouldBeAbleToViewTheProgressProgressIfInsightsAndBadgesAreEnabled() {
        if (isElementPresent(program.verifyProgressBar())) {
            Assert.assertEquals(isElementPresent(program.verifyProgressBar()), true);
        } else {
            program.verifyMarkAsDoneCTA().click();
            Assert.assertEquals(isElementPresent(program.verifyProgressBar()), true);
        }
    }

    @And("user have reading program enabled for library")
    public void userHaveReadingProgramEnabledForLibrary() {
        program.clickBack_Btn();
        profile.clickEdit_Option();
        manage.adultprofileSelection();
        waitFor(2000);
        swipeDown();
        swipeDown();
        swipeDown();
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            Assert.assertTrue(program.verifyInsightsBadgesCheckboxEnabled().getAttribute("checked"), true);
        } else {
            Assert.assertTrue(program.verifyInsightsBadgesCheckboxEnabled().isEnabled());
        }
        program.clickprofileDetailClose();
    }

    @And("user have reading program disabled for library")
    public void userHaveReadingProgramDisabledForLibrary() {
        program.clickBack_Btn();
        profile.clickEdit_Option();
        manage.adultprofileSelection();
        waitFor(2000);
        swipeDown();
        swipeDown();
        swipeDown();
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            Assert.assertFalse(program.verifyInsightsBadgesCheckboxEnabled().getAttribute("checked"), false);
        } else {
            Assert.assertTrue(program.verifyInsightsBadgesCheckboxEnabled().isEnabled());
        }
        program.clickprofileDetailClose();
    }

    @Given("user should be able to navigates into the open program screen")
    public void userShouldBeAbleToNavigatesIntoTheOpenProgramScreen() {
        program.clickOpenPrograms_from_Menu_Programs();
    }

    @When("user can able to join the upcoming milestone program")
    public void userCanAbleToJoinTheUpcomingMilestoneProgram() {
        program.joinUpcomingProgram();
    }

    @Then("user clicks on the join program cta")
    public void userClicksOnTheJoinProgramCta() {
        program.clickJoinProgram();
        program.clickMilestoneJoinOk();
        if (isElementPresent(program.confirmationPopup())) {
            program.joinConfirmationYesBtn().click();
        }
    }

    @And("user will receive the joined notification from message center")
    public void userWillReceiveTheJoinedNotificationFromMessageCenter() {
        program.clickNotificationBellIcon();
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            Assert.assertTrue(program.notificationProgramJoined().getAttribute("content-desc").contains("Automation_upcoming"));
        } else {
            Assert.assertTrue(program.notificationProgramJoined().getAttribute("label").contains("Automation_upcoming"));
        }
    }

    @And("user delete the notifications")
    public void userDeleteTheNotifications() {
        program.clickNotificationEdit();
        program.clickBack_Btn();
        waitFor(1000);
        program.clickNotificationDelete();
        program.clickNotificationDeleteYes();
//        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
//            Assert.assertFalse(program.notificationProgramJoined().getAttribute("content-desc").contains("Automation_upcoming"));
//        } else {
            Assert.assertFalse(isElementPresent(program.notificationProgramJoined()));
//        }
        program.clickBack_Btn();
    }

    @And("user delete the notifications for add and remove title")
    public void userDeleteTheNotification() {
        program.clickNotificationEdit();
        program.clickBack_Btn();
        program.clickNotificationDelete();
        program.clickNotificationDeleteYes();
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            Assert.assertFalse(program.titleAddedNotification().getAttribute("content-desc").contains("New Title Added"));
            Assert.assertFalse(program.titleRemoveNotification().getAttribute("content-desc").contains("Title Removed"));
        } else {
//            Assert.assertFalse(program.titleAddedNotification().getAttribute("label").contains("New Title Added"));
//            Assert.assertFalse(program.titleRemoveNotification().getAttribute("label").contains("Title Removed"));
        }
        program.clickBack_Btn();
    }

    @And("user leaves the joined program")
    public void userLeavesTheJoinedProgram() {
        waitFor(2000);
        swipeUp();
        swipeUp();
        program.clickLeave_Program();
        program.clickOkButton();
    }

    @And("user add the title into the program")
    public void userAddTheTitleIntoTheProgram() {
        waitFor(3000);
        swipeDown();
        swipeDown();
        program.clickSuggestedTitleAdd();
        program.clickAddTitleSuccessPopupOk();
//        program.clickBack_Btn();
    }

    @And("user will receive the notification add title")
    public void userWillReceiveTheNotificationAddTitle() {
        program.clickNotificationBellIcon();
        Assert.assertTrue(program.titleAddedNotification().getAttribute("content-desc").contains("New Title Added"));
    }

    @Then("user remove the title from the program")
    public void userRemoveTheTitleFromTheProgram() {
        swipeDown();
        program.clickTitleSettingDots();
        program.clickRemoveTitle();
        program.clickTitleRemoveOkPopup();
        waitFor(1000);
        program.clickOkCTA();

    }

    @And("user will receive the notification remove")
    public void userWillReceiveTheNotificationRemove() {
        program.clickNotificationBellIcon();
        if (System.getProperty("platform").equalsIgnoreCase("Android")) {
            Assert.assertTrue(program.titleAddedNotification().getAttribute("content-desc").contains("New Title Added"));
            Assert.assertTrue(program.titleRemoveNotification().getAttribute("content-desc").contains("Title Removed"));
        } else {
            Assert.assertTrue(program.titleAddedNotification().getAttribute("label").contains("New Title Added"));
            Assert.assertTrue(program.titleRemoveNotification().getAttribute("label").contains("Title Removed"));
        }
    }

    @When("user can able to join the ongoing milestone program")
    public void userCanAbleToJoinTheOngoingMilestoneProgram() {
        program.joinOngoingProgram();
    }

    @And("user should be able to view the added video title in the program in the details screen")
    public void userShouldBeAbleToViewTheAddedVideoTitleInTheProgramInTheDetailsScreen() {
        Assert.assertEquals(isElementPresent(program.videoTitle()), true);
    }

    @And("user should be able to view the added vbook title in the program in the details screen")
    public void userShouldBeAbleToViewTheAddedVbookTitleInTheProgramInTheDetailsScreen() {
        Assert.assertEquals(isElementPresent(program.vbookTitle()), true);
    }
}
