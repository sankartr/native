package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.AboutandLegel;
import pom.kidszone.InterestSurvey;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.Preference;
import pom.kidszone.ProfileCreation;
import pom.kidszone.RegisterScreen;
import pom.kidszone.MenuList;

public class Preference_StepDef extends CommonActions{
	
	RegisterScreen register = new RegisterScreen(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	ManageProfile manageProf = new ManageProfile(DriverManager.getDriver());
	Preference preference = new Preference(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	InterestSurvey interest = new InterestSurvey(DriverManager.getDriver());
	ManageProfile manage =new ManageProfile(DriverManager.getDriver());
	
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
	
	@Given("user launch the application and select the login with username and password library {string}")
	public void user_launch_the_application_and_select_the_login_with_username_and_password_library(String libraryName) {
		if (isElementPresent(login.boundlessAllow())) {
			login.clickBoundlessAllow();
		}
		login.searchLibrary(libraryName);
		login.initiateSearch();
		login.select_library();
	}
	@When("user clicks preferences")
	public void user_clicks_preferences() throws Throwable {
		waitFor(1000);
	login.clickFooterMenu();
	menu.clickonPreference();
		
	}
//	@When("user clicks preference")
//	public void user_clicks_preference() {
//		try {
//			Thread.sleep(2000);
//			menu.clickonPreference();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//	}
	
	@Then("user should be able to view preferences screen with option auto play title")
	public void user_should_be_able_to_view_preferences_screen_with_option_auto_play_title() throws Throwable {
		Assert.assertTrue(preference. getPreference_txt_autoplaytitle().isDisplayed());
		logger.info("user able to see the audioPlay option under preferences");
	}

//	@Then("user should be able to view save option to save the updated settings")
//	public void user_should_be_able_to_view_save_option_to_save_the_updated_settings() {
//	    Assert.assertTrue(preference.getPreference_btn_save().isDisplayed());
//	}

//	@Then("save cta should be enabled only when user has updated any preference setting")
//	public void save_cta_should_be_enabled_only_when_user_has_updated_any_preference_setting() {
//		Assert.assertTrue(preference.getPreference_btn_preferenceoptions().get(0).isEnabled());
//		
//	}
	
//	@Then("save cta should be disable only when user has updated any preference setting")
//	public void save_cta_should_be_disable_only_when_user_has_updated_any_preference_setting() {
//		preference.disable_autoplayAudiobook();
//		
//	}

	@Then("user should be able to enable option to auto play title")
	public void user_should_be_able_to_enable_option_to_auto_play_title() {	 
		preference.enable_autoplayAudiobook();
		
	}
	
	@Then("user should be able to disable option to auto play tittle")
	public void user_should_be_able_to_disable_option_to_auto_play_tittle() {
		preference.disable_autoplayAudiobook();
	}

	@Then("user should be able to view preferences screen with option automatically delete expired items")
	public void user_should_be_able_to_view_preferences_screen_with_option_automatically_delete_expired_items() {
		Assert.assertTrue(preference.getPreference_txt_deleteExpried().isDisplayed());	
		logger.info("user able to see the deleteExpired option under preferences");
	}

	@Then("user should be able to enable option to automatically delete expired items")
	public void user_should_be_able_to_enable_option_to_automatically_delete_expired_items() {
		preference.enable_deleteExpireditems();
	}

	@Then("user should be able to disable option to automatically delete expired items")
	public void user_should_be_able_to_disable_option_to_automatically_delete_expired_items() {
		preference.disable_deleteExpireditems();
	}

	@Given("user click on login button after user enter kidszone subscription and axis360 {string}")
	public void user_click_on_login_button_after_user_enter_kidszone_subscription_and_axis360(String libraryid) {
	   register.enterLibraryId(libraryid);
//	   if (System.getProperty("platform").equalsIgnoreCase("Android")) {
//			manage.adultprofileSelection();
//		}
//		login.handleNothankspopup();
	}

	@Then("user should be able to view save option to save the updated settings")
	public void user_should_be_able_to_view_save_option_to_save_the_updated_settings() {
		logger.info("user able to see save button under preferences");
	}

	@Then("save cta should be enabled only when user has updated any preference setting")
	public void save_cta_should_be_enabled_only_when_user_has_updated_any_preference_setting() {
		 preference.confirmpopup();
		 Assert.assertTrue(preference.getPreference_btn_save().isEnabled());
		 preference.preference_savebtn();
	}
	
	@Then("save cta should be disable only when user has updated any preference setting")
	public void save_cta_should_be_disable_only_when_user_has_updated_any_preference_setting() {
		 Assert.assertTrue(!preference.getPreference_btn_save().isEnabled());
		 preference.preference_savebtn();
	}

	@Then("save cta should be enabled only when user has updated delete expired items")
	public void save_cta_should_be_enabled_only_when_user_has_updated_delete_expired_items() {
		 Assert.assertTrue(preference.getPreference_btn_save().isEnabled());
	}

	@Then("save cta should be disable only when user has updated delete expired items")
	public void save_cta_should_be_disable_only_when_user_has_updated_delete_expired_items() {
		 Assert.assertTrue(!preference.getPreference_btn_save().isEnabled());
	}
	
	@Given("user click on login button after user enter kidszone subscription library id and pin {string} and {string}")
	public void user_click_on_login_button_after_user_enter_kidszone_subscription_library_id_and_pin_and(String libraryid, String pin) {
		login.loginwithidandPin(libraryid, pin);
		login.handleNothankspopup();
	}
	
	@When("user update and save delete expired items setting")
	public void user_update_and_save_delete_expired_items_setting() {
	   preference.enable_deleteExpireditems();
	}
	
	@When("user disable and save delete expired items setting")
	public void user_disable_and_save_delete_expired_items_setting() {
	    preference.disable_deleteExpireditems();
	}

	@Then("system should save the updated settings for the user")
	public void system_should_save_the_updated_settings_for_the_user() {
	   preference.preference_savebtn();
	   logger.info("user save the updated settings");	   
	}

	@Then("system should show a success toast message on successful save of settings")
	public void system_should_show_a_success_toast_message_on_successful_save_of_settings() {
		if(isElementPresent(preference.getPreference_toast_successfulToastmsg()))
		{
	    Assert.assertTrue(preference.save_successfultoastmsg());
		}
	}

	@Then("system should auto delete downloaded title on expiry when user has enabled the setting")
	public void system_should_auto_delete_downloaded_title_on_expiry_when_user_has_enabled_the_setting() {
		logger.info("system should not auto delete downloaded title"); 
	}
	
	@Then("system should not auto delete downloaded title on expiry when user has disabled the setting")
	public void system_should_not_auto_delete_downloaded_title_on_expiry_when_user_has_disabled_the_setting() {
		logger.info("system should not auto delete downloaded title");
	}

	@Then("logout the application")
	public void logout_the_application() {
		login.clickFooterMenu();
		preference.click_SignOut();
		
	}

	@When("user update and save Use cellular data when downloading files setting")
	public void user_update_and_save_use_cellular_data_when_downloading_files_setting() {
	    preference.enable_cellulardata();
	}

	@When("user clicks on download button for titles")
	public void user_clicks_on_download_button_for_titles() {
		logger.info("Download tiltle check");
	}
	@When("user disable and save Use cellular data when downloading files setting")
	public void user_disable_and_save_use_cellular_data_when_downloading_files_setting() {
	    preference.disable_cellulardata();
	}
	
	@Then("system should download the title on cellular data when user has enabled the setting")
	public void system_should_download_the_title_on_cellular_data_when_user_has_enabled_the_setting() {
		logger.info("Download tiltle check enable setting");
	}

	@Then("system should not download the title on cellular data when user has disabled the setting")
	public void system_should_not_download_the_title_on_cellular_data_when_user_has_disabled_the_setting() {
		logger.info("Download tiltle check enable setting");
	}
	
	@Then("user should be able to view preferences screen with option use Cellular data when downloading files")
	public void user_should_be_able_to_view_preferences_screen_with_option_use_cellular_data_when_downloading_files() {
	    if(isElementPresent(preference.getPreference_txt_cellularData())) {
		Assert.assertEquals(preference.getPreference_txt_cellularData().isDisplayed(), true);
	    }
		logger.info("user able to see the cellular Data option under preferences");
	}

	@Then("user should be able to enable option to use cellular data when downloading files")
	public void user_should_be_able_to_enable_option_to_use_cellular_data_when_downloading_files() {
	    preference.enable_cellulardata();
	}
	
	@Then("user should be able to disable option to use cellular data when downloading files")
	public void user_should_be_able_to_disable_option_to_use_cellular_data_when_downloading_files() {
	   preference.disable_cellulardata();
	}

}
