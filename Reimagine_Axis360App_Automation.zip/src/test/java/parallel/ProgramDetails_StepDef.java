package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.AboutandLegel;
import pom.kidszone.FeaturedPrg;
import pom.kidszone.LearningActivity;
import pom.kidszone.LoginPage;
import pom.kidszone.ManageProfile;
import pom.kidszone.MenuList;
import pom.kidszone.MyCheckouts;
import pom.kidszone.MyProgram;
import pom.kidszone.MyShelf;
import pom.kidszone.ProfileCreation;

public class ProgramDetails_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	AboutandLegel about = new AboutandLegel(DriverManager.getDriver());
	ProfileCreation profile = new ProfileCreation(DriverManager.getDriver());
	MenuList menu = new MenuList(DriverManager.getDriver());
	MyShelf myShelf = new MyShelf(DriverManager.getDriver());
	MyProgram myprogram = new MyProgram(DriverManager.getDriver());
	MyCheckouts checkout = new MyCheckouts(DriverManager.getDriver());
	FeaturedPrg featuredPrg =new FeaturedPrg(DriverManager.getDriver());
	LearningActivity learning = new LearningActivity(DriverManager.getDriver());
	ManageProfile manage =new ManageProfile(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	@When("user is on home page and click on program tab")
	public void user_is_on_home_page_and_click_on_program_tab() throws Throwable {
		login.handleNothankspopup();
		myprogram.clikMenuProgram();
	}

	@Then("user should  be able to view program details screen in with adult theme rendered based on user profile")
	public void user_should_be_able_to_view_program_details_screen_in_with_adult_theme_rendered_based_on_user_profile()
			throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getjoin_program()), true);

	}

	@And("user select open programs tab and select ongoing program")
	public void user_select_open_programs_tab_and_select_ongoing_program() throws Throwable {
		myprogram.clickOpenProgram();
		myprogram.navigateprgDetails();

	}

	@And("user lands on ongoing program details screen that user has not enrolled in")
	public void user_lands_on_ongoing_program_details_screen_that_user_has_not_enrolled_in() throws Throwable {
		myprogram.ClickOnprogram();
		Assert.assertEquals(isElementPresent(myprogram.getjoin_program()), true);

	}

	@And("user should be able to view program name and program description if available and program start date and program end date and program type")
	public void user_should_be_able_to_view_program_name_and_program_description_if_available_and_program_start_date_and_program_end_date_and_program_type()
			throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getOpen_prg_startDate()), true);
		Assert.assertEquals(isElementPresent(myprogram.getOpen_prg_endDate()), true);
	}

	@And("user should be able to view list of titles as reading list for the reading program with the total title count")
	public void user_should_be_able_to_view_list_of_titles_as_reading_list_for_the_reading_program_with_the_total_title_count()
			throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getReading_list_title()), true);
	}

	@And("user should be able to view join program cta")
	public void user_should_be_able_to_view_join_program_cta() throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getjoin_program()), true);
	}

	@And("if reading list titles more than 10 and user should be able to view see all cta for the title list")
	public void if_reading_list_titles_more_than_10_and_user_should_be_able_to_view_see_all_cta_for_the_title_list()
			throws Throwable {
		logger.info("if reading list titles more than 10 and user should be able to view see all");
	}

	@And("click on cta to navigate to title list screen")
	public void click_on_cta_to_navigate_to_title_list_screen() throws Throwable {
		myprogram.bookTitleDetails();
	}

	@And("programs are enabled for the library​")
	public void programs_are_enabled_for_the_library() throws Throwable {
		logger.info("program enabled for library");
	}

	@And("user select open programs tab and select upcoming program")
	public void user_select_open_programs_tab_and_select_upcoming_program() throws Throwable {
		myprogram.clickOpenProgram();
		myprogram.navigateupcommingPrg();
		myprogram.ClickOnprogram();
//		myprogram.navigateupcomingPrg();
	}

	@And("user lands on upcoming program details screen that user has not enrolled in")
	public void user_lands_on_upcoming_program_details_screen_that_user_has_not_enrolled_in() throws Throwable {
		logger.info("user lands on upcoming program details screen");
	}

	@And("if reading list titles less or equal to 10 and user should not able to able to view see all cta for the title list")
	public void if_reading_list_titles_less_or_equal_to_10_and_user_should_not_able_to_able_to_view_see_all_cta_for_the_title_list()
			throws Throwable {
		logger.info("reading list titles less or equal to 10 and user should not able to able to view see all");
	}

	@Then("user should be able to view the confirmation screen for joining the program")
	public void user_should_be_able_to_view_the_confirmation_screen_for_joining_the_program() throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getConfirm_alert_msg()), false);
	}

	@And("user taps on the 'join program' cta")
	public void user_taps_on_the_join_program_cta() throws Throwable {
		myprogram.navigateJoin_program();
	}

	@And("user should be able to click on the 'X' icon and navigate to the open programs screen")
	public void user_should_be_able_to_click_on_the_x_icon_and_navigate_to_the_open_programs_screen() throws Throwable {
		myprogram.cancel_join_prg();
		Assert.assertEquals(isElementPresent(myprogram.getjoin_program()), true);
	}

	@And("user should not be able to view the program card on open programs screen after joining the program")
	public void user_should_not_be_able_to_view_the_program_card_on_open_programs_screen_after_joining_the_program()
			throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getjoin_program()), true);
	}

	@Then("user should be able to get an confirmation pop up")
	public void user_should_be_able_to_get_an_confirmation_pop_up_something() throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getConfirm_alert_msg()), true);
	}

	@And("user has never joined any program before")
	public void user_has_never_joined_any_program_before() throws Throwable {
		logger.info("user never joined program");
	}

	@And("user should be able to get two options 'No and Yes'")
	public void user_should_be_able_to_get_two_options_no_and_yes() throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getConfirm_ok()), true);
		Assert.assertEquals(isElementPresent(myprogram.getConfirm_cancel()), true);
	}

	@And("user tap on 'yes' cta")
	public void user_tap_on_yes_cta() throws Throwable {
		myprogram.join_prg();
		myprogram.confirmOK();
	}

	@And("Navigate to My program")
	public void Navigate_to_My_program()
	{
		manage.clickProfileImage();
		myprogram.clickmyProgram();

	}
	@And("Leave the program from joined program")
	public void Leave_the_program_from_joined_program()
	{
		myprogram.clickActiveProgram();
		myprogram.clickLeavePrg();
	}

	@And("user tap on 'no' cta")
	public void user_tap_on_no_cta() throws Throwable {
		myprogram.cancel_join_prg();
	}

	@And("user should be able to view insights and badges tracking enabled in the user setting")
	public void user_should_be_able_to_view_insights_and_badges_tracking_enabled_in_the_user_setting()
			throws Throwable {
		logger.info("user should be able to view insights and badges tracking enabled");
	}

	@And("user should be able to see welcome program screen after selecting any option")
	public void user_should_be_able_to_see_welcome_program_screen_after_selecting_any_option() throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getStarted_button()), true);
		myprogram.start_joinProgram();
	}

	@And("percentage progress will be shown when clicked on yes")
	public void percentage_progress_will_be_shown_when_clicked_on_yes() throws Throwable {
		logger.info("percentage progress shown when clicked on yes");
	}

	@And("percentage progress will not be shown when clicked on no")
	public void percentage_progress_will_not_be_shown_when_clicked_on_no() throws Throwable {
		// Assert.assertEquals(isElementPresent(myprogram.getProgress_bar()), false);
		logger.info("percentage progress not shown when clicked on no");
	}

	@Then("user should not able to view confirmation popup")
	public void user_should_not_able_to_view_confirmation_popup() throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getConfirm_alert_msg()), true);
	}

	@And("display insight and badges should be enabled under my profile screen")
	public void display_insight_and_badges_should_be_enabled_under_my_profile_screen() throws Throwable {
		logger.info("display insight and badges should be enabled under my profile screen");
	}

	@Then("user should be able to view program details screen in with adult theme")
	public void user_should_be_able_to_view_program_details_screen_in_with_adult_theme() throws Throwable {
		logger.info("theme check");
	}

	@And("programs are enabled for the library​ and programs are enabled for the user profile type")
	public void programs_are_enabled_for_the_library_and_programs_are_enabled_for_the_user_profile_type()
			throws Throwable {
		logger.info("programs are enabled for the library​ and for the user");
	}

	@And("user has enrolled in program")
	public void user_has_enrolled_in_program() throws Throwable {
		logger.info("user has enrolled program");
	}

	@And("user lands on my programs tab and select books in order program")
	public void user_lands_on_my_programs_tab_and_select_books_in_order_program() throws Throwable {

		myprogram.clickmyProgram();
		myprogram.navigateactiveProgram();

	}

	@And("user lands on program details screen")
	public void user_lands_on_program_details_screen() throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getjoin_program()), true);
	}

	@And("if 10 or more than 10 titles and user should be able to able to view 'see all' cta for the title list")
	public void if_10_or_more_than_10_titles_and_user_should_be_able_to_able_to_view_see_all_cta_for_the_title_list()
			throws Throwable {
		if (isElementPresent(myprogram.getSeeAll_btn())) {
			Assert.assertEquals(isElementPresent(myprogram.getSeeAll_btn()), true);
		}
		logger.info("if 10 or more than 10 titles and user should be able to able to view 'see all");
	}

	@And("click on 'see all' cta to navigate to title list screen")
	public void click_on_see_all_cta_to_navigate_to_title_list_screen() throws Throwable {
		if (isElementPresent(myprogram.getSeeAll_btn())) {
			Assert.assertEquals(isElementPresent(myprogram.getSeeAll_btn()), true);
		}
		logger.info("if 10 or more than 10 titles and user should be able to able to view 'see all");

	}

	@And("user should be able to view 'leave program' cta")
	public void user_should_be_able_to_view_leave_program_cta() throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getjoin_program()), true);
	}

	@Then("system should be prompted with leave program confirmation message")
	public void system_should_be_prompted_with_leave_program_confirmation_message() throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getConfirm_alert_msg()), true);
	}

	@And("user lands on programs tab and select active programs")
	public void user_lands_on_programs_tab_and_select_active_programs() throws Throwable {
		myprogram.clickmyProgram();
		myprogram.navigateactiveProgram();
	}

	@And("user is on active program details screen")
	public void user_is_on_active_program_details_screen() throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getjoin_program()), true);
	}

	@And("user taps on leave program cta")
	public void user_taps_on_leave_program_cta() throws Throwable {
		myprogram.clickLeavePrg();
	}

	@And("user should tap 'ok' cta")
	public void user_should_tap_ok_cta() throws Throwable {
		myprogram.join_prg();
	}

	@And("user should be able to receive leave success toast message and navigate to my programs screen")
	public void user_should_be_able_to_receive_leave_success_toast_message_and_navigate_to_my_programs_screen()
			throws Throwable {
//		 Assert.assertEquals(myprogram.leaveconfirmMsg(),true);
	}

	@And("user should be able to view the checked out books for the reading program left in the checkouts section")
	public void user_should_be_able_to_view_the_checked_out_books_for_the_reading_program_left_in_the_checkouts_section()
			throws Throwable {
		logger.info("user should be able to view the checked out books for the reading program");
	}

	@And("system should retain and navigated the last reading or listening point in ereader or player for the titles")
	public void system_should_retain_and_navigated_the_last_reading_or_listening_point_in_ereader_or_player_for_the_titles()
			throws Throwable {
		logger.info("system should retain and navigated the last reading");
	}

	@And("user should be able to view title progress for the checked out titles​ from the reading program")
	public void user_should_be_able_to_view_title_progress_for_the_checked_out_titles_from_the_reading_program()
			throws Throwable {
		logger.info("user should be able to view title progress for the checked");
	}

	@And("user should tap 'cancel' cta")
	public void user_should_tap_cancel_cta() throws Throwable {
		myprogram.cancel_join_prg();
	}

	@And("user should stay on program overview screen by clicking cancel")
	public void user_should_stay_on_program_overview_screen_by_clicking_cancel() throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getjoin_program()), true);
	}

	@Then("user should be able to view reading list for the titles in books in order program in program details screen with the total title count")
	public void user_should_be_able_to_view_reading_list_for_the_titles_in_books_in_order_program_in_program_details_screen_with_the_total_title_count()
			throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getReading_list_title()), true);
	}

	@And("user should be able to view the titles in order in the reading list with order number displayed for each title")
	public void user_should_be_able_to_view_the_titles_in_order_in_the_reading_list_with_order_number_displayed_for_each_title()
			throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getReading_list_title()), true);
	}

	@And("user should be able to view title cover image for the titles in the list with title format icon")
	public void user_should_be_able_to_view_title_cover_image_for_the_titles_in_the_list_with_title_format_icon()
			throws Throwable {
		logger.info("theme check");
	}

	@And("user should be able to view default image with title name and author name and title format icon if title cover image is not available")
	public void user_should_be_able_to_view_default_image_with_title_name_and_author_name_and_title_format_icon_if_title_cover_image_is_not_available()
			throws Throwable {
		logger.info("theme check");
	}

	@And("user should be able to click on title and navigate to title details screen")
	public void user_should_be_able_to_click_on_title_and_navigate_to_title_details_screen() throws Throwable {
		myprogram.bookTitleDetails();
	}

	@And("user should be able to view primary action for the title as cta")
	public void user_should_be_able_to_view_primary_action_for_the_title_as_cta() throws Throwable {
		Thread.sleep(4000);
		Assert.assertEquals(isElementPresent(myprogram.getPrimary_btn()), true);
	}

	@Then("user should be able to view the action cta for the title on program details screen only once program has started")
	public void user_should_be_able_to_view_the_action_cta_for_the_title_on_program_details_screen_only_once_program_has_started()
			throws Throwable {
		logger.info("user should not view title action cta for checked out titles");
	}

	@And("user should be able to view see all cta for the title list")
	public void user_should_be_able_to_view_see_all_cta_for_the_title_list() throws Throwable {
		if (isElementPresent(myprogram.getSeeAll_btn())) {
			Assert.assertEquals(isElementPresent(myprogram.getSeeAll_btn()), true);
		}
		logger.info("if 10 or more than 10 titles and user should be able to able to view 'see all");
	}

	@And("User should be able to view default image for title not available if title is expired for the library users")
	public void user_should_be_able_to_view_default_image_for_title_not_available_if_title_is_expired_for_the_library_users()
			throws Throwable {
		logger.info("theme check");
	}

	@And("User should be able to view default image for title not available if title is removed from inventory for the library users")
	public void user_should_be_able_to_view_default_image_for_title_not_available_if_title_is_removed_from_inventory_for_the_library_users()
			throws Throwable {
		logger.info("theme check");
	}

	@And("user should be able to click on cta to navigate to title list screen")
	public void user_should_be_able_to_click_on_cta_to_navigate_to_title_list_screen() throws Throwable {
		myprogram.bookTitleDetails();
	}

	@And("user should not view title action cta for checked out titles if previous title was incomplete")
	public void user_should_not_view_title_action_cta_for_checked_out_titles_if_previous_title_was_incomplete()
			throws Throwable {
		logger.info("user should not view title action cta for checked out titles");
	}

	@And("use should be navigated to the titles list screen")
	public void use_should_be_navigated_to_the_titles_list_screen() throws Throwable {
		myprogram.bookTitleDetails();
	}

	@And("user should be able to view reading list titles as a grid view")
	public void user_should_be_able_to_view_reading_list_titles_as_a_grid_view() throws Throwable {
		Assert.assertEquals(isElementPresent(myprogram.getReading_list_title()), true);
	}

	@And("user should be able to click on close and navigate back to program details screen")
	public void user_should_be_able_to_click_on_close_and_navigate_back_to_program_details_screen() throws Throwable {
		myprogram.navigateBackCTA();
	}

	@And("user should be able to view the reading progress for the titles checked out and title completed as progress bar")
	public void user_should_be_able_to_view_the_reading_progress_for_the_titles_checked_out_and_title_completed_as_progress_bar()
			throws Throwable {
		logger.info("prograss check");
	}

	@And("user should be able to view default image with title name, author name and title format icon if title cover image is not available")
	public void user_should_be_able_to_view_default_image_with_title_name_author_name_and_title_format_icon_if_title_cover_image_is_not_available()
			throws Throwable {
		logger.info("theme check");
	}

	@And("user should be able to view default image for title not available if title is not longer available for the library users that is expired title")
	public void user_should_be_able_to_view_default_image_for_title_not_available_if_title_is_not_longer_available_for_the_library_users_that_is_expired_title()
			throws Throwable {
		logger.info("theme check");
	}
	
	@When("user is able to view home screen")
    public void user_is_able_to_view_home_screen() throws Throwable {
       Assert.assertEquals(isElementPresent(featuredPrg.homePageCheck()), true);
    }

    @Then("user should be able to view program banner on home screen")
    public void user_should_be_able_to_view_program_banner_on_home_screen() throws Throwable {
    	Assert.assertEquals(isElementPresent(featuredPrg.getFeaturePrg_panner()), true);
    }

    @And("user is enabled the programs in library using admin tool")
    public void user_is_enabled_the_programs_in_library_using_admin_tool() throws Throwable {
    	menu.clickMyLibrary();
    }

    @And("user should be able to view featured programs on top of the home screen")
    public void user_should_be_able_to_view_featured_programs_on_top_of_the_home_screen() throws Throwable {
		featuredPrg.navigatetoprogram();
//    	Assert.assertEquals(isElementPresent(featuredPrg.getFeaturePrg_panner()), true); 
    }

    @And("user should be able to tap anywhere on the banner area")
    public void user_should_be_able_to_tap_anywhere_on_the_banner_area() throws Throwable {
    	featuredPrg.clickFeaturedprogramBanner();
    }

    @And("user should be able to navigate program detail page")
    public void user_should_be_able_to_navigate_program_detail_page() throws Throwable {
		waitFor(3000);
    	Assert.assertEquals(isElementPresent(featuredPrg.getFeaturePrg_program_title()), true);
    }

    @And("user should be able to tap see all programs CTA")
    public void user_should_be_able_to_tap_see_all_programs_cta() throws Throwable {
    	Assert.assertEquals(isElementPresent(featuredPrg.getFeaturePrg_program_title()), true);
//    	profile.clickBackbutton();
    }

    @And("user should be able to navigate to open programs")
    public void user_should_be_able_to_navigate_to_open_programs() throws Throwable {
    	featuredPrg.navigatetoprogram();
    }
    @And("user should be able to navigate to the featurted program as existing behavior")
    public void user_should_be_able_to_navigate_to_the_featurted_program_as_existing_behavior() throws Throwable {
    	Assert.assertEquals(isElementPresent(featuredPrg.verifyOpenProgramSection()),true);
    }


    @When("user clicks on the Title in the Featured Reading Program")
    public void userClicksOnTheTitleInTheFeaturedReadingProgram() {
		featuredPrg.clickTitlesInFeaturedReadingProgram();
    }

	@Then("user should navigate to Featured Program Details Page")
	public void userShouldNavigateToFeaturedProgramDetailsPage() {
		Assert.assertEquals(isElementPresent(featuredPrg.verifyProgramDetailsScreen()),true);
	}
}
