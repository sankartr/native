package parallel;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.LoginPage;
import pom.kidszone.RegisterScreen;

public class RegisterwithTempPassword_StepDef extends CommonActions{
	public static final Logger logger = LoggerFactory.getLogger(RegisterwithTempPassword_StepDef.class);

	RegisterScreen register = new RegisterScreen(DriverManager.getDriver());
	LoginPage login = new LoginPage(DriverManager.getDriver());

	@When("user taps on Enter your Library password click here link in the login page")
	public void user_taps_on_enter_your_library_password_click_here_link_in_the_login_page() throws Throwable {
		register.clickPasswordLink();
	}

	@Then("user is redirected to the register page")
	public void user_is_redirected_to_the_register_page() throws Throwable {
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			Assert.assertEquals(register.getLibrary_btn_Register().isDisplayed(), true);
		} else {
			Assert.assertEquals(register.getLib_btn_Register().isDisplayed(), true);
		}
	}

	@And("user should be able to enter the {string} provided by the library")
	public void user_should_be_able_to_enter_the_something_provided_by_the_library(String password) throws Throwable {
		register.enterLibraryPassword(password);
	}

	@And("user should be able to view and taps on Register cta")
	public void user_should_be_able_to_view_and_taps_on_register_cta() throws Throwable {
		if (System.getProperty("platform").equalsIgnoreCase("iOS")) {
			Assert.assertEquals(register.getLibrary_btn_Register().isDisplayed(), true);
		} else {
			Assert.assertEquals(register.getLib_btn_Register().isDisplayed(), true);
		}
		register.clickRegister();
	}

	@And("user should be able to enter the invalid {string}")
	public void user_should_be_able_to_enter_the_invalid_something(String password) throws Throwable {
		register.enterinvalidLibraryPassword(password);
	}

	@And("user should be able to view the error message")
	public void user_should_be_able_to_view_the_error_message() throws Throwable {
		Assert.assertEquals(register.getReg_lbl_invalidlibraryPassword().isDisplayed(), true);
	}

	@When("user is click on login cta")
	public void user_is_click_on_login_cta() throws Throwable {
		register.clicksigin();
	}

	@Then("user should be able view the error messages")
	public void user_should_be_able_view_the_error_messages() throws Throwable {
		Assert.assertEquals(register.getReg_lbl_invalidlibraryPassword().isDisplayed(), true);
	}

	@And("user should be enter {string}")
	public void user_should_be_enter_something(String username) throws Throwable {
		login.enterUserName(username);
	}

	@And("user should be enter invalid Password {string}")
	public void user_should_be_enter_invalid_password_something(String password) throws Throwable {
		login.enterPwd(password);
	}
	@Then("register button shoud be disabled")
	public void register_button_shoud_be_disabled() throws Throwable {
		swipeDown();
		Assert.assertEquals(!register.getLibrary_btn_Register().isEnabled(), true);
	}
}
