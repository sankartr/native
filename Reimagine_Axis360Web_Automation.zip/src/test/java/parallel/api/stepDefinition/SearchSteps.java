package parallel.api.stepDefinition;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import api.APIClient;
import api.searchTitlev8.SearchTitleResponse;
import api.searchTitlev8.Title;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchSteps {

	private SearchTitleResponse apiResponse;
	private List<String> extractedAudienceCodes = new ArrayList<>();

	@When("the API response is retrieved")
	public void retrieveAPIResponse() {
		apiResponse = APIClient.getSearchTitleResponse("science", "keyword", "publicationDate", "teen,children");
		assertNotNull("API response is null", apiResponse);
	}

	@Then("the API response result counts match the UI result")
	public void compareResultCounts() {
		assertNotNull("API response is null", apiResponse);

		String apiResultCount = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getResultCount();
		String ebookResultCount = apiResponse.getSearchTitleResponseData().getSearchTitleResult().geteBookCount();
		String audioResultCount = apiResponse.getSearchTitleResponseData().getSearchTitleResult().geteAudioBookCount();

		List<Title> titles = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getTitlesList().getTitles();
		for (Title title : titles) {
			String audienceCode = title.getAudienceCode();
			extractedAudienceCodes.add(audienceCode);
		}

		int apiResultCountInt = Integer.parseInt(apiResultCount);
		int uiResultCount = 2090;

		assertEquals("API result count doesn't match UI result", apiResultCountInt, uiResultCount);
		assertEquals("Ebook result count doesn't match", ebookResultCount, "25");
		assertEquals("Audio result count doesn't match", audioResultCount, "0");
	}

	@Given("the user searches for a title")
	public void the_user_searches_for_a_title() {
		System.out.println("step def for the user searches for a title");
	}
}
