package parallel;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import api.APIClient;
import api.enums.GenericEnum;
import api.enums.GenericEnum.Categories;
import api.enums.GenericEnum.SearchParams;
import api.searchTitlev8.SearchTitleResponse;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Checkouts;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Holds;
import pom.kidszone.LibrarySprint6B;
import pom.kidszone.MyLibrary_Guest;
import pom.kidszone.TitleAcrossProfile;
import pom.kidszone.TitleDetails;

public class LibrarySprint6BStepDef extends CommonAction {

	LibrarySprint6B library = new LibrarySprint6B(DriverManager.getDriver());
	TitleDetails title = new TitleDetails(DriverManager.getDriver());
	MyLibrary_Guest guest = new MyLibrary_Guest(DriverManager.getDriver());
	TitleAcrossProfile across = new TitleAcrossProfile(DriverManager.getDriver());
	Holds holds = new Holds(DriverManager.getDriver());
	Checkouts checkout = new Checkouts(DriverManager.getDriver());
	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());

	static int ThirdPartyresultCount;
	static int SearchCount;
	static int refinersResultcount;

	@Then("user should be able to view total number of pages for the ebook as attribute pages")
	public void user_should_be_able_to_view_total_number_of_pages_for_the_ebook_as_attribute_pages() {
		Assert.assertTrue(title.getPagesTotal().isDisplayed());
	}

	@When("user navigate to advance search pop up by clicking advance search under global search")
	public void user_navigate_to_advance_search_pop_up_by_clicking_advance_search_under_global_search() {
		guest.clickAdvanceSearch();
	}

	@When("enter {string} in global search and clicks search CTA")
	public void enter_in_global_search_and_clicks_search_cta(String keyWord) {
		library.searchWithKeyword(keyWord);
	}

	@When("Enter the {string} in global search and clicks search CTA")
	public void enter_the_in_global_search_and_clicks_search_cta(String keyword) {
		library.advanceSearchKeyword(keyword);
	}

	@When("user navigate to search result landing page")
	public void user_navigate_to_search_result_landing_page() {
//		int search_ResultCount = across.search_ResultCount();
		visibilityWait(across.getSearchResult());
		Assert.assertEquals(across.getSearchResult().isDisplayed(), true);
		String AllSearchCount = across.Search_TotalResultCount.getText();
		Logger.log("All Search Count :" + AllSearchCount);

	}

	@Then("user should be able to view {string} category in refine section")
	public void user_should_be_able_to_view_category_in_refine_section(String refineries) {
		library.searchCategory(refineries);
	}

	@Then("user should able to view {string} category selected in refine section by default")
	public void user_should_able_to_view_category_selected_in_refine_section_by_default(String string) {
		Logger.log("User able to view All category selected by default");
	}

	@Then("user should be able to view all category")
	public void user_should_be_able_to_view_all_category() {
		Logger.log("User able to view All category results");
	}

	@Then("user should be able to view the result that matches the API response")
	public void user_should_be_able_to_view_the_result_that_matches_the_api_response() {
		Logger.log("User able to view All category selected by default matches API Response");
	}

	@When("user clicks the {string} and {string} in refine section")
	public void user_clicks_the_and_in_refine_section(String newsMag, String articles) {
		library.clickCategory(newsMag);
	}

	@When("user clicks the {string},{string} and {string} in refine section")
	public void user_clicks_the_and_in_refine_section(String webRes, String comic, String actRes) {
		library.clickCategory(webRes);
		library.clickCategory(actRes);
	}

	@Then("user should be able to view {string} carousel with {string} CTA")
	public void user_should_be_able_to_view_carousel_with_cta(String string, String string2) {
	}

	@When("user clicks the {string} category in refine section")
	public void user_clicks_the_category_in_refine_section(String category) {
		library.clickCategory(category);
	}

	@Then("user should be able to view expanded result for the {string} category")
	public void user_should_be_able_to_view_expanded_result_for_the_category(String category) {
		Assert.assertTrue(library.getSearchResultCategory().getText().contains(category));
	}

	@Then("user should be able to view {string} newspaper carousel with {string} CTA")
	public void user_should_be_able_to_view_newspaper_carousel_with_cta(String string, String string2) {
		Assert.assertTrue(library.getNewsMagCarousel().isDisplayed());
		Assert.assertTrue(library.getNewsMagCarouselSeeAll().isDisplayed());
	}

	@Then("user should be able to view {string} web resources carousel with {string} CTA")
	public void user_should_be_able_to_view_web_resources_carousel_with_cta(String string, String string2) {
		javascriptScroll(library.getWebResCarousel());
		Assert.assertTrue(library.getWebResCarousel().isDisplayed());
//		Assert.assertTrue(library.getWebResCarouselSeeAll().isDisplayed());
	}

	@Then("user should be able to view {string} activity carousel with {string} CTA")
	public void user_should_be_able_to_view_activity_carousel_with_cta(String string, String string2) {
		Logger.log("There is no See All CTA, for only one activity available for Activity Resources");
	}

//	@Then("user should able to view expanded result for the {string} category")
//	public void user_should_able_to_view_expanded_result_for_the_category(String results) {
//		Assert.assertTrue(across.getSearchResult().getText().contains(results));
//	}

	@When("user clicks on {string} CTA for {string} books carousel")
	public void user_clicks_on_cta_for_books_carousel(String seeAll, String category) {
		library.clickSeeAll(library.getEbooksCarouselSeeAll());
	}

	@Then("user should able to view expanded result for the {string} books category")
	public void user_should_able_to_view_expanded_result_for_the_books_category(String category) {
		System.out.println(library.getSearchResultHeader().getText());
		Assert.assertTrue(library.getSearchResultHeader().getText().contains(category));
	}

	@When("user clicks on {string} CTA for {string} newspapers carousel")
	public void user_clicks_on_cta_for_newspapers_carousel(String seeAll, String category) {
		library.clickSeeAllNewsMag(library.getNewsMagCarouselSeeAll());
	}

	@Then("user should able to view expanded result for the {string} newspapers category")
	public void user_should_able_to_view_expanded_result_for_the_newspapers_category(String category) {
		Assert.assertTrue(library.getSearchResultCategoryThirdParty().getText().contains(category));
	}

	@When("user clicks on {string} CTA for {string} web resources carousel")
	public void user_clicks_on_cta_for_web_resources_carousel(String seeAll, String category) {
		library.clickSeeAll(library.getWebResCarouselSeeAll());
	}

	@Then("user should able to view expanded result for the {string} web resources category")
	public void user_should_able_to_view_expanded_result_for_the_web_resources_category(String category) {
		Assert.assertTrue(library.getSearchResultHeader().getText().contains(category));
	}

	@When("user clicks the advanced search CTA as a guest")
	public void user_clicks_the_advanced_search_cta_as_a_guest() {
		across.click_advanceSearch();
	}

	@Then("user should be able to view {string} radio button in collections")
	public void user_should_be_able_to_view_radio_button_in_collections(String string) {
		Assert.assertTrue(library.getAdvanceSearchpopup_newspaper_radiobtn().isDisplayed());
	}

	@When("user enter {string} in saerch field label")
	public void user_enter_in_saerch_field_label(String content) {
		library.enter_searchContent(content);
	}

	@When("user select the {string} radio button")
	public void user_select_the_radio_button(String string) {
		library.click_newspaperRadiobtn();
	}

	@When("user clicks {string} CTA")
	public void user_clicks_cta(String string) {
		library.click_searchCTA();
	}

	@Then("user should able to view only newpapers & magazines content")
	public void user_should_able_to_view_only_newpapers_magazines_content() {
		Assert.assertTrue(library.getBtn_searchContent().isDisplayed());
	}

	@Then("user should able to view the newpapers & magazines based on saerch keyword")
	public void user_should_able_to_view_the_newpapers_magazines_based_on_saerch_keyword() {
		library.verify_searchkeyword();
	}

	@When("user clicks {string} CTA in title card on the result page")
	public void user_clicks_cta_in_title_card_on_the_result_page(String string) {
		library.click_ReadnowCTA();
	}

	@Then("user should able to view login popup")
	public void user_should_able_to_view_login_popup() {
		Assert.assertTrue(isElementPresent(library.getLogin_popup()));
	}

	@When("user select the study sites radio button")
	public void user_select_the_study_sites_radio_button() {
		library.select_webresourceRadiobtn();
	}

	@Then("user should able to view only study sites content")
	public void user_should_able_to_view_only_study_sites_content() {
		Assert.assertTrue(library.getBtn_studysitecontent().isDisplayed());
	}

	@Then("user should able to view the study sites based on search keyword")
	public void user_should_able_to_view_the_study_sites_based_on_search_keyword() {
		library.verify_searchkeyword();
	}

	@Then("user should be able to view study sites radio button in collections")
	public void user_should_be_able_to_view_study_sites_radio_button_in_collections() {
		Assert.assertTrue(library.getRadiobtn_webREsource().isDisplayed());
	}

	// axis & kidszone user

	@When("axis and kidszone user clicks the advanced search CTA as a guest")
	public void axis_and_kidszone_user_clicks_the_advanced_search_cta_as_a_guest() {
		guest.clickAdvanceSearch();
		// library.click_oldAdvanceSearch();
	}

	@Then("axis and kidszone user should be able to view {string} radio button in collections")
	public void axis_and_kidszone_user_should_be_able_to_view_radio_button_in_collections(String string) {
		Assert.assertTrue(isElementPresent(library.getOld_newspaperRadiobtn()));
	}

	@When("users enter {string} in saerch field label")
	public void users_enter_in_saerch_field_label(String content) {
		library.enter_oldsearchContent(content);
	}

	@When("users select the {string} radio button")
	public void users_select_the_radio_button(String string) {
		library.click_oldnewspaperRadiobtn();
	}

	@When("users clicks {string} CTA")
	public void users_clicks_cta(String string) {
		library.click_OldsearchCTA();
	}

	@Then("users should able to view only newpapers & magazines content")
	public void users_should_able_to_view_only_newpapers_magazines_content() {
		Assert.assertTrue(library.getBtn_oldsearchContent().isDisplayed());
	}

	@Then("users should able to view the newpapers & magazines based on saerch keyword")
	public void users_should_able_to_view_the_newpapers_magazines_based_on_saerch_keyword() {
		library.verify_oldsearchkeyword();
	}

	@When("users clicks {string} CTA in title card on the result page")
	public void users_clicks_cta_in_title_card_on_the_result_page(String string) {
		library.click_oldReadnowCTA();
	}

	@Then("users should able to view login popup")
	public void users_should_able_to_view_login_popup() {
		Assert.assertTrue(library.getLogin_oldpopup().isDisplayed());
	}

	@When("users clicks the advanced search CTA as a guest")
	public void users_clicks_the_advanced_search_cta_as_a_guest() {
		library.click_oldAdvanceSearch();
	}

	@Then("users should able to view only study sites content")
	public void users_should_able_to_view_only_study_sites_content() {
		Assert.assertTrue(isElementPresent(library.getBtn_studysitessearchContent()));
	}

	@Then("users should able to view the study sites based on search keyword")
	public void users_should_able_to_view_the_study_sites_based_on_search_keyword() {
		library.verify_oldsearchkeyword();
	}

	@Then("users should be able to view study sites radio button in collections")
	public void users_should_be_able_to_view_study_sites_radio_button_in_collections() {
		Assert.assertTrue(isElementPresent(library.getBtn_Oldstudysites()));
	}

	@When("users select the study sites radio button")
	public void users_select_the_study_sites_radio_button() {
		library.select_studysitesRadiobtn();
	}

	// 178055

	@When("user navigates to library screen")
	public void user_navigates_to_library_screen() {
		visibilityWait(library.getNavigate_libscreen());
		Assert.assertTrue(library.getNavigate_libscreen().isDisplayed());
	}

	@Then("user should not view Always Available carousel")
	public void user_should_not_view_always_available_carousel() {
		Assert.assertEquals(isElementPresent(library.getLib_Alwaysavailable()), false);
	}

	@Then("user click on advance search")
	public void user_click_on_advance_search() {
		across.click_advanceSearch();
	}

	@Then("user able to view advance search popup")
	public void user_able_to_view_advance_search_popup() {
		Assert.assertTrue(library.getAdvanceSearch_popup().isDisplayed());
	}

	@Then("user should not be able to view Always Available in the advance search popup")
	public void user_should_not_be_able_to_view_always_available_in_the_advance_search_popup() {
		Assert.assertEquals(isElementPresent(library.getLib_Alwaysavailable()), false);
	}

	@Then("user enter {string} in advance search content and click on search")
	public void user_enter_in_advance_search_content_and_click_on_search(String content) {
		library.enter_searchContent(content);
		library.click_searchCTA();
	}

	@Then("user navigate to search results landing page")
	public void user_navigate_to_search_results_landing_page() {
		Assert.assertTrue(library.getBtn_searchContent().isDisplayed());
	}

	@Then("user should not be able to view Always Available option under the category collection refine option")
	public void user_should_not_be_able_to_view_always_available_option_under_the_category_collection_refine_option() {
		library.categorySection_notshownAlwaysAvailable();
	}

	// 178055_axis&kidszone

	@When("adult user lands on library page")
	public void adult_user_lands_on_library_page() {
		visibilityWait(library.navigate_oldlibscreen);
		Assert.assertTrue(library.navigate_oldlibscreen.isDisplayed());
	}

	@Then("user should able to view Always Available carousel")
	public void user_should_able_to_view_always_available_carousel() {
		Assert.assertTrue(library.view_AlwaysAvailableCarousel());
	}

	@Then("adult user click on advance search")
	public void adult_user_click_on_advance_search() {
		library.click_oldAdvanceSearch();
	}

	@Then("adult user able to view advance search popup")
	public void adult_user_able_to_view_advance_search_popup() {
		visibilityWait(library.oldadvanceSearch_popup);
		Assert.assertTrue(library.oldadvanceSearch_popup.isDisplayed());
	}

	@Then("user should able to view Always Available in the advance search popup")
	public void user_should_able_to_view_always_available_in_the_advance_search_popup() {
		// Assert.assertTrue(isElementPresent(library.Oldalwaysavailable_radiobtn));
		library.select_oldalwaysAvailable();
	}

	@Then("adult user enter {string} in advance search content and click on search")
	public void adult_user_enter_in_advance_search_content_and_click_on_search(String content) {
		library.enter_oldsearchContent(content);
		library.click_OldsearchCTA();
	}

	@Then("adult user navigate to search results landing page")
	public void adult_user_navigate_to_search_results_landing_page() {
		visibilityWait(library.Alwaysavailable_content);
		Assert.assertTrue(library.Alwaysavailable_content.isDisplayed());
	}

	@Then("user should able to view Always Available option under the category collection refine option")
	public void user_should_able_to_view_always_available_option_under_the_category_collection_refine_option() {
		Assert.assertTrue(library.Refiner_old.isDisplayed());
	}

	@Given("User is in Adult Profile")
	public void user_is_in_adult_profile() {
		Logger.log("User is in Adult Profile");
	}

	@Then("user able to see the list view by default and grid view by switching")
	public void user_able_to_see_the_list_view_by_default_and_grid_view_by_switching() {
		holds.listViewDisplayed();
		holds.clickGrid();
		holds.gridViewDisplayed();
	}

	@Then("user able to view sort icon and clicking able to view sort options as {string} {string} and {string}")
	public void user_able_to_view_sort_icon_and_clicking_able_to_view_sort_options_as_and(String string, String string2,
			String string3) {
		holds.clickSort();
//		holds.sortOptions();
		checkout.getSort_Latest_Checkout();
		checkout.click_AtoZ();
		// holds.clickSort();
		checkout.click_DueDate();
		holds.clickSort();
	}

	@Then("user should be able to view primary action and secondary action for the title as a button")
	public void user_should_be_able_to_view_primary_action_and_secondary_action_for_the_title_as_a_button() {
		// Assert.assertTrue(checkout.primaryCta_listenNow.isDisplayed());
		checkout.click_moreOption();
		Assert.assertTrue(checkout.return_option.isDisplayed());
		// Assert.assertTrue(checkout.addToWish.isDisplayed());

	}

	@Then("user should be able to view ebook primary action and secondary action for the title as a button")
	public void user_should_be_able_to_view_ebook_primary_action_and_secondary_action_for_the_title_as_a_button() {
		Assert.assertTrue(checkout.primaryCta_Read.isDisplayed());
		checkout.click_moreOption();
		Assert.assertTrue(checkout.return_option.isDisplayed());

	}

	@Then("user able to view search icon and by clicking user can perform search actions")
	public void user_able_to_view_search_icon_and_by_clicking_user_can_perform_search_actions() {
		checkout.click_SearchIcon();
		// checkout.sendTextFromSearchBar();
		Logger.log("user should be able to view the results based on search string from the titles checked out");
	}

	@When("user place the title on hold")
	public void user_place_the_title_on_hold() {
		title.clickHoldTitle();
		title.clickHoldCta();
	}

	@Then("user able to see the Hamburger menu with menu options Library,Browse by Subject,Featured List,Help with close Icon")
	public void user_able_to_see_the_hamburger_menu_with_menu_options_library_browse_by_subject_featured_list_help_with_close_icon() {
		Assert.assertTrue(ham.getNavigationMenu_btn_browseBySubject().isDisplayed());
		Assert.assertTrue(ham.getNavigationMenu_btn_featuredLists().isDisplayed());
		Assert.assertTrue(ham.getNavigationMenu_btn_library().isDisplayed());
		Assert.assertTrue(ham.getLink_Help().isDisplayed());
		Assert.assertTrue(ham.getNavigationMenu_btn_closeCTA().isDisplayed());
	}

	@Then("user should be able to Click on cta and navigate to titles list screen for the curated list")
	public void user_should_be_able_to_click_on_cta_and_navigate_to_titles_list_screen_for_the_curated_list() {
		guest.clickTitleCardList();
	}

	@Then("user able to see the Hamburger menu with menu options My Shelf, Programs,Checkouts,Holds")
	public void user_able_to_see_the_hamburger_menu_with_menu_options_my_shelf_programs_checkouts_holds() {
		Assert.assertTrue(ham.getLink_MyShelf().isDisplayed());
		Assert.assertTrue(ham.getNavigationMenu_btn_programs().isDisplayed());
		Assert.assertTrue(ham.getLink_Checkouts().isDisplayed());
		Assert.assertTrue(ham.getLink_Holds().isDisplayed());
	}

	@Then("user able to see the Hamburger menu with menu options Profiles,Patron Support and Sign Out")
	public void user_able_to_see_the_hamburger_menu_with_menu_options_profiles_patron_support_and_sign_out() {
		Assert.assertTrue(ham.getLink_Profiles().isDisplayed());
//		Assert.assertTrue(ham.getNavigationMenu_btn_patronSupport().isDisplayed());
		Assert.assertTrue(ham.getLink_SignOut().isDisplayed());
	}

	@When("User navigate to library screen and checkout the Audio titles")
	public void user_navigate_to_library_screen_and_checkout_the_audio_titles() {
		ham.click_HamburgerMenu();
		ham.click_library();
		title.searchAudiobook();
		checkout.click_checkout();
	}

	@Then("Navigate back to last screen")
	public void navigate_back_to_last_screen() {
		DriverManager.getDriver().navigate().back();
	}

	@When("user should be able to get the search results count for a {string} for a {string} search for {string} and sorted by {string}")
	public void user_should_be_able_to_get_the_search_results_count_for_a_for_a_search_for_and_sorted_by(
			String profileType, String searchType, String searchTerm, String sortBy) {
		int get_EbookSearchCount = across.get_EbookSearchCount();
		Logger.log("Ebook Search Count: " + get_EbookSearchCount);
		int get_EAudioSearchCount = across.get_EAudioSearchCount();
		Logger.log("EAudio Search Count: " + get_EAudioSearchCount);
		int get_VbookSearchCount = across.get_VbookSearchCount();
		Logger.log("Vbook Search Count: " + get_VbookSearchCount);
		int get_VideoSearchCount = across.get_VideoSearchCount();
		Logger.log("Video Search Count: " + get_VideoSearchCount);
		int get_ResourceHubSearchCount = across.get_ResourceHubSearchCount();
		Logger.log("ResourceHub Search Count: " + get_ResourceHubSearchCount);
		int get_WebResourceSearchCount = across.get_WebResourceSearchCount();
		Logger.log("WebResource Search Count: " + get_WebResourceSearchCount);

		int eBookCountFromAPI = 0;
		int eAudioCountFromAPI = 0;
		String collection = SearchParams.collection.getParams();
		String formatVideo = SearchParams.format.getVideo();
		String collectionIdVideo = SearchParams.collectionId.getVcollectionId();
		String formatVideoBooks = SearchParams.format.getVideobook();
		String collectionIdVideoBook = SearchParams.collectionId.getVbCollectionId();

//		Total number of Audiobook count matches only if we give collection param as PPC and without PPC in the request call.

		if (!(profileType.contains("teen") || profileType.contains("children"))) {
			SearchTitleResponse searchwithPPC = APIClient.getSearchTitleResponse("", searchTerm, searchType, sortBy, "",
					collection, "", "", profileType);
			eBookCountFromAPI = Integer
					.parseInt(searchwithPPC.getSearchTitleResponseData().getSearchTitleResult().geteBookCount());
			Logger.log("The count retrieved from API for eBook : " + eBookCountFromAPI);
			eAudioCountFromAPI = Integer
					.parseInt(searchwithPPC.getSearchTitleResponseData().getSearchTitleResult().geteAudioBookCount());
			Logger.log("The count retrieved from API for eAudios : " + eAudioCountFromAPI);

			Assert.assertEquals("Ebook count did not match", get_EbookSearchCount, eBookCountFromAPI);
			Assert.assertEquals("audio count did not match", get_EAudioSearchCount, eAudioCountFromAPI);

		}

		Logger.log("profileType: " + profileType);
		if (profileType.contains("teen") || profileType.contains("children")) {

			SearchTitleResponse searchwithoutPPC = APIClient.getSearchTitleResponse("", searchTerm, searchType, sortBy,
					profileType, "", "", "", profileType);
			eBookCountFromAPI = Integer
					.parseInt(searchwithoutPPC.getSearchTitleResponseData().getSearchTitleResult().geteBookCount());
			Logger.log("The count retrieved from API for eBook : " + eBookCountFromAPI);
			eAudioCountFromAPI = Integer.parseInt(
					searchwithoutPPC.getSearchTitleResponseData().getSearchTitleResult().geteAudioBookCount());
			Logger.log("The count retrieved from API for eAudios : " + eAudioCountFromAPI);

			Assert.assertEquals("Ebook count did not match", get_EbookSearchCount, eBookCountFromAPI);
			Assert.assertEquals("audio count did not match", get_EAudioSearchCount, eAudioCountFromAPI);

			SearchTitleResponse thirdPartySearchVideo = APIClient.getThirdPartySearchTitleResponse(formatVideo,
					collectionIdVideo, searchTerm, searchType, sortBy, profileType, "");

			int searchCountVideoFromAPI = Integer.parseInt(
					thirdPartySearchVideo.getSearchTitleResponseData().getSearchTitleResult().getResultCount());

			Logger.log("The count retrieved from API for VideoBooks : " + searchCountVideoFromAPI);
			Assert.assertEquals("video count did not match", get_VideoSearchCount, searchCountVideoFromAPI);

			SearchTitleResponse thirdPartySearchVbook = APIClient.getThirdPartySearchTitleResponse(formatVideoBooks,
					collectionIdVideoBook, searchTerm, searchType, sortBy, profileType, "");

			int searchCountVbookFromAPI = Integer.parseInt(
					thirdPartySearchVbook.getSearchTitleResponseData().getSearchTitleResult().getResultCount());

			Logger.log("The count retrieved from API for Vbooks : " + searchCountVbookFromAPI);
			Assert.assertEquals("vBook count did not match", get_VbookSearchCount, searchCountVbookFromAPI);
		}

	}

	@Then("user should be able to get the search results count for {string} for {string}")
	public void user_should_be_able_to_get_the_search_results_count_for_eBooks(String category, String profileType) {
		int SearchCount = user_should_be_able_to_view_the_results_if_user_clicks_on_category_title(category);
		Logger.log("Search Count for " + category + " : " + SearchCount);

		SearchTitleResponse search = APIClient.getSearchTitleResponse("EBT", "science", "keyword", "publicationDate",
				profileType, "", "", "", profileType);

		int searchCountEbookFromAPI = Integer
				.parseInt(search.getSearchTitleResponseData().getSearchTitleResult().geteBookCount());

		Assert.assertEquals("Ebook count did not match", SearchCount, searchCountEbookFromAPI);
	}

	@Then("user should be able to get the search results count for third party for {string} for {string} under {string} for a searchType {string} and sortType {string}")
	public void user_should_be_able_to_get_the_search_results_count_for_thirdParty_under_for_a_search_type_and_sort_type(
			String category, String profileType, String searchTerm, String searchType, String sortType) {
		int SearchCount = user_should_be_able_to_view_the_results_if_user_clicks_on_category_title(category);
		String formatType = "";
		String collectionId = "";
		Logger.log("Search Count for " + category + " : " + SearchCount);

		if (category.equalsIgnoreCase("videoBooks")) {
			formatType = SearchParams.format.getVideobook();
			collectionId = SearchParams.collectionId.getVbCollectionId();
		} else if (category.equalsIgnoreCase("Checkers Library TV")) {
			formatType = SearchParams.format.getVideo();
			collectionId = SearchParams.collectionId.getVcollectionId();
		}

		SearchTitleResponse thirdPartySearchVideo = APIClient.getThirdPartySearchTitleResponse(formatType, collectionId,
				searchTerm, searchType, sortType, profileType, "");
		int searchCountVideoFromAPI = Integer
				.parseInt(thirdPartySearchVideo.getSearchTitleResponseData().getSearchTitleResult().getResultCount());
		Assert.assertEquals("video count did not match", SearchCount, searchCountVideoFromAPI);

		SearchTitleResponse thirdPartySearchVbook = APIClient.getThirdPartySearchTitleResponse(formatType, collectionId,
				searchTerm, searchType, sortType, profileType, "");
		int searchCountVbookFromAPI = Integer
				.parseInt(thirdPartySearchVbook.getSearchTitleResponseData().getSearchTitleResult().getResultCount());
		Assert.assertEquals("vBook count did not match", SearchCount, searchCountVbookFromAPI);

	}

	@Then("user should be able to get the search results count for {string} for {string} under {string} for a searchType {string} and sortType {string}")
	public void user_should_be_able_to_get_the_search_results_count_for_for_under_for_a_search_type_and_sort_type(
			String category, String profileType, String searchTerm, String searchType, String sortType) {
		SearchCount = user_should_be_able_to_view_the_results_if_user_clicks_on_category_title(category);
		String formatType = "";
		String collection = "";
		Logger.log("Search Count: " + SearchCount);

		if (category.equalsIgnoreCase("eBooks")) {
			formatType = SearchParams.format.getEformatType();
		} else if (category.equalsIgnoreCase("eAudios")) {
			formatType = SearchParams.format.getAformatType();
		}

		if (profileType.equalsIgnoreCase("adult")) {
			collection = SearchParams.collection.getParams();
			profileType = "adult,teen,children";
		}

		SearchTitleResponse search = APIClient.getSearchTitleResponse(formatType, searchTerm, searchType, sortType,
				profileType, collection, "", "", profileType);

		if (category.equalsIgnoreCase("eBooks")) {
			int searchCountFromAPI = Integer
					.parseInt(search.getSearchTitleResponseData().getSearchTitleResult().geteBookCount());
			Logger.log("The count retrieved from API for eBooks is : " + searchCountFromAPI);
			Assert.assertEquals("Ebook count did not match", SearchCount, searchCountFromAPI);
		} else if (category.equalsIgnoreCase("eAudios")) {
			int searchCountFromAPI = Integer
					.parseInt(search.getSearchTitleResponseData().getSearchTitleResult().geteAudioBookCount());
			Logger.log("The count retrieved from API for eAudios is : " + searchCountFromAPI);
			Assert.assertEquals("audio book count did not match", SearchCount, searchCountFromAPI);
		}

	}

	@Then("user should be able to get the search results count for audioBooks for {string}")
	public void user_should_be_able_to_get_the_search_results_count_for_audioBooks(String profileType) {
		int get_EAudioSearchCount = across.get_EAudioSearchCount();
		Logger.log("Ebook Search Count: " + get_EAudioSearchCount);

		SearchTitleResponse search = APIClient.getSearchTitleResponse("ABT", "science", "keyword", "publicationDate",
				"", "", "", "", profileType);

		int searchCountAudioFromAPI = Integer
				.parseInt(search.getSearchTitleResponseData().getSearchTitleResult().geteAudioBookCount());

		Assert.assertEquals("audiobook count did not match", get_EAudioSearchCount, searchCountAudioFromAPI);
	}

	@Then("user should be able to get the search results count for videBooks for {string}")
	public void user_should_be_able_to_get_the_search_results_count_for_videoBooks(String profileType) {
		int get_VbookSearchCount = across.get_VbookSearchCount();
		Logger.log("Vbook Search Count: " + get_VbookSearchCount);
		SearchTitleResponse thirdPartySearchVbook = APIClient.getThirdPartySearchTitleResponse("videobook",
				"8c573edd-60c4-ed11-a8e0-000d3a4e28de", "science", "keyword", "publicationDate", profileType, "");
		int searchCountVbookFromAPI = Integer
				.parseInt(thirdPartySearchVbook.getSearchTitleResponseData().getSearchTitleResult().getResultCount());
		Assert.assertEquals("vBook count did not match", get_VbookSearchCount, searchCountVbookFromAPI);
	}

	@Then("user should be able to get the search results count for videos for {string}")
	public void user_should_be_able_to_get_the_search_results_count_for_videos(String profileType) {
		int get_VideoSearchCount = across.get_VideoSearchCount();
		Logger.log("Video Search Count: " + get_VideoSearchCount);
		SearchTitleResponse thirdPartySearchVideo = APIClient.getThirdPartySearchTitleResponse("video",
				"7ed395cc-61c4-ed11-a8e0-000d3a4e28de", "science", "keyword", "publicationDate", profileType, "");
		int searchCountVideoFromAPI = Integer
				.parseInt(thirdPartySearchVideo.getSearchTitleResponseData().getSearchTitleResult().getResultCount());
		Assert.assertEquals("video count did not match", get_VideoSearchCount, searchCountVideoFromAPI);
	}

//	@Then("user should be able to view the results if user clicks on category {string} title for a {string}")
	public int user_should_be_able_to_view_the_results_if_user_clicks_on_category_title(String category) {
		library.clickCategory(category);
		String text = "";
		if (category.equalsIgnoreCase("eBooks") || category.equalsIgnoreCase("eAudios")) {
			visibilityWait(across.categoryCount);
			text = across.categoryCount.getText();
		} else if (category.equalsIgnoreCase("Videobooks") || category.equalsIgnoreCase("Checkers Library TV")) {
			text = across.searchResultHeaderThirdParty.getText();
		}

		int resultCount = Integer.parseInt(text.replaceAll("[^0-9]", ""));
		return resultCount;
	}

	@Then("user clicks on the sortby option and select {string} as option and select Availability as {string} and click age level as {string} language as {string} and Attributes as {string}")
	public void user_clicks_on_the_sortby_option_and_select_as_option_and_select_availability_as_and_click_age_level_as_language_as_and_attributes_as(
			String sortByOption, String availability, String ageLevel, String language, String attributes) {
		library.clickSortByRefinerOption(sortByOption);
		waitForDocumentToLoad();
		library.clickAvailabilityRefinerOption(availability);
		library.clickAgeLevelRefinerOption(ageLevel);
		library.clickLanguage(language);
		waitForDocumentToLoad();
		if (attributes.equalsIgnoreCase("eRead-Along")) {
			javascriptScroll(library.refinerAttributes);
			library.clickAttributes();
		}
		refinersResultcount = library.getSearchResultAfterApplyingFilter();
		Logger.log("Result count after applying filter: " + refinersResultcount);
	}

//	@And("user clicks on the sortby option and select {string} as option and select Availability as {string} and click age level as {string} and language as {string} and Attributes as {string}")
//	public void user_clicks_on_the_sortby_option_and_select_as_option_and_select_availability_as_and_click_age_level_as_and_language_as_and_attributes_as(String sortByOption, String availability, String ageLevel, String language, String attributes) {
//		library.clickSortByRefinerOption(sortByOption);
//		library.clickAvailabilityRefinerOption(availability);
//		library.clickAgeLevelRefinerOption(ageLevel);
//		library.clickLanguage(language);
//		try {
//		library.clickAttributes();
//		} catch(Exception e) {
//			Logger.log("Attributes filter option is not present for the selected format type");
//		}
//		int result = library.getSearchResultAfterApplyingFilter();
//		Logger.log("Result count after applying filter: " + result);
//	}

	@When("user clicks on the sortby option and select {string} as option, and click age level as {string} and language as {string} for {string}")
	public void user_clicks_on_the_sortby_option_ad_select_as_option_and_click_age_level_as_and_language_as(
			String sortByOption, String ageLevel, String language, String category) {

		String count = "";
		library.clickSortByRefinerOption(sortByOption);
		library.clickAgeLevelRefinerOption(ageLevel);
		library.clickLanguage(language);
		if (category.equalsIgnoreCase("Videobooks") || category.equalsIgnoreCase("Checkers Library TV")) {
			library.clickSearchBtn();
			visibilityWait(across.searchResultHeaderThirdParty);
			count = across.searchResultHeaderThirdParty.getText();
			ThirdPartyresultCount = Integer.parseInt(count.replaceAll("[^0-9]", ""));
			Logger.info("The total count after doing a refiners with " + sortByOption + " for age level " + ageLevel
					+ " and language " + language + " is : " + ThirdPartyresultCount);
		}

	}

	@Then("user compares the results from api and ui with refiners options selected for a {string} for audienceDesc as {string}  in {string} searchType as {string} language as {string} Attributes as {string} and sortType {string}")
	public void user_compares_the_results_from_api_and_ui_with_refiners_options_selected_for_a_for_audeince_desc_as_in_search_type_as_language_as_and_sort_type(
			String category, String audienceDesc, String searchTerm, String searchType, String language,
			String attributes, String sortType) {
		String formatType = "";
		String collectionId = "";
		String axisattribute = "";
		String collection = SearchParams.collection.getParams();
		if (attributes.equalsIgnoreCase("eRead-Along")) {
			axisattribute = SearchParams.axisattribute.getParams();
		}
		if (category.equalsIgnoreCase("videoBooks")) {
			formatType = SearchParams.format.getVideobook();
			collectionId = SearchParams.collectionId.getVbCollectionId();

			SearchTitleResponse thirdPartySearchVbook = APIClient.getThirdPartySearchTitleResponse(formatType,
					collectionId, searchTerm, searchType, sortType, audienceDesc, language);
			int searchCountVbookFromAPI = Integer.parseInt(
					thirdPartySearchVbook.getSearchTitleResponseData().getSearchTitleResult().getResultCount());

			Logger.log("The count retrieved from API for videoBooks is : " + searchCountVbookFromAPI);
			Assert.assertEquals("vBook count did not match", ThirdPartyresultCount, searchCountVbookFromAPI);

		} else if (category.equalsIgnoreCase("Checkers Library TV")) {
			formatType = SearchParams.format.getVideo();
			collectionId = SearchParams.collectionId.getVcollectionId();

			SearchTitleResponse thirdPartySearchVideo = APIClient.getThirdPartySearchTitleResponse(formatType,
					collectionId, searchTerm, searchType, sortType, audienceDesc, language);
			int searchCountVideoFromAPI = Integer.parseInt(
					thirdPartySearchVideo.getSearchTitleResponseData().getSearchTitleResult().getResultCount());

			Logger.log("The count retrieved from API for Checkers Library TV is : " + searchCountVideoFromAPI);
			Assert.assertEquals("video count did not match", ThirdPartyresultCount, searchCountVideoFromAPI);

		} else if (category.equalsIgnoreCase("eBooks")) {
			formatType = SearchParams.format.getEformatType();
			SearchTitleResponse search = APIClient.getSearchTitleResponse(formatType, searchTerm, searchType, sortType,
					audienceDesc, collection, language, axisattribute, "");
			int searchCountFromAPI = Integer
					.parseInt(search.getSearchTitleResponseData().getSearchTitleResult().geteBookCount());

			Logger.log("The count retrieved from API for eBooks is : " + searchCountFromAPI);
			Assert.assertEquals("Ebook count did not match", refinersResultcount, searchCountFromAPI);

		} else if (category.equalsIgnoreCase("eAudios")) {
			formatType = SearchParams.format.getAformatType();
			SearchTitleResponse search = APIClient.getSearchTitleResponse(formatType, searchTerm, searchType, sortType,
					audienceDesc, collection, language, axisattribute, "");
			int searchCountFromAPI = Integer
					.parseInt(search.getSearchTitleResponseData().getSearchTitleResult().geteAudioBookCount());

			Logger.log("The count retrieved from API for eAudios is : " + searchCountFromAPI);
			Assert.assertEquals("audio book count did not match", refinersResultcount, searchCountFromAPI);
		}

	}
}
