package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Learning_Activities;

public class Learning_Activities_StepDef extends CommonAction {

	Learning_Activities learning = new Learning_Activities(DriverManager.getDriver());

	@When("user clicks on any of the available category in learning activities widget in my library page")
	public void user_clicks_on_any_of_the_available_category_in_learning_activities_widget_in_my_library_page() {
		WaitForWebElement(learning.getLearnActivities().get(0));
		waitFor(6000);
		activity = learning.getLearnActivities().get(0).getText();
		learning.clickActivities();
	}

	@Then("user should be navigated to learning activities list screen")
	public void user_should_be_navigated_to_learning_activities_list_screen() {
		Assert.assertEquals(learning.getActivitiesPage().isDisplayed(), true);
	}

	@Then("user should view the selected category as default in refine section")
	public void user_should_view_the_selected_category_as_default_in_refine_section() {
		Logger.log("User able to view the selected category as default in refine section");
	}

	@Then("user should view the only the learning resources related to that category")
	public void user_should_view_the_only_the_learning_resources_related_to_that_category() {
		learning.inspectActivity();
		Logger.log("User able to view only learning resources related to that category");
	}

	@Then("user should be able to view learning activities list screen with theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_learning_activities_list_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log(
				"User able to view activities list screen with theme rendered based on library subscription and user profile type");
	}

	public String activity;

	@Then("user should select the different category from the refine option to view learning resource pertianing to that category")
	public void user_should_select_the_different_category_from_the_refine_option_to_view_learning_resource_pertianing_to_that_category() {
		learning.selectActivityType();
	}

	@Then("user should be able to view the bread crumb as CTA and navigate from bread crumb")
	public void user_should_be_able_to_view_the_bread_crumb_as_cta_and_navigate_from_bread_crumb() {
		Assert.assertTrue(learning.getBreadCrumbLA().isDisplayed());
	}

	@Then("user should be able to view the learning activities list page header")
	public void user_should_be_able_to_view_the_learning_activities_list_page_header() {
		Assert.assertTrue(learning.getActivityPageTabs().isDisplayed());
	}

	@Then("user should be able to view each learning activities title as a card and titles listed as tile view")
	public void user_should_be_able_to_view_each_learning_activities_title_as_a_card_and_titles_listed_as_tile_view() {
		Logger.log("user able to view each learning activities title as a card and titles listed as tile view");
	}

	@Then("user should be able to view {string} number of learning activities titles loaded")
	public void user_should_be_able_to_view_number_of_learning_activities_titles_loaded(String string) {
		Logger.log("user able to view number of learning activities titles loaded");
	}

	@Then("system should lazy load next {string} number of learning activities titles as user browse towards bottom of the titles displayed")
	public void system_should_lazy_load_next_number_of_learning_activities_titles_as_user_browse_towards_bottom_of_the_titles_displayed(
			String string) {
		Logger.log("UI Verified Manually");
	}

	@Then("user should be able to click on to expand and collapse the refiner options")
	public void user_should_be_able_to_click_on_to_expand_and_collapse_the_refiner_options() {
		Logger.log("user able to click on to expand and collapse the refiner options");
	}

	@Then("user should be able to view page header and breadcrumb")
	public void user_should_be_able_to_view_page_header_and_breadcrumb() {
		Assert.assertTrue(learning.getBreadCrumbLA().isDisplayed());
	}

	@Then("user should be able to view the sort options in the refiner section")
	public void user_should_be_able_to_view_the_sort_options_in_the_refiner_section() {
		Assert.assertTrue(learning.getSortByRefSection().isDisplayed());
	}

	@Then("user should be able to view and select a sort option for the learning activities titles listed")
	public void user_should_be_able_to_view_and_select_a_sort_option_for_the_learning_activities_titles_listed() {
		learning.selectSortOptions();
	}

	@Then("user should be able to view the titles sorted based on the selection")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_selection() {
		Logger.log("user able to view the titles sorted based on the selection");
	}

	@Then("user should be able to view the titles sorted alphabetical by book title by default")
	public void user_should_be_able_to_view_the_titles_sorted_alphabetical_by_book_title_by_default() {
		Logger.log("User able to view the titles sorted alphabetical by book title by default");
	}

	@Then("user should be able to expand the sort section")
	public void user_should_be_able_to_expand_the_sort_section() {
		Assert.assertTrue(learning.getSortOptions().isDisplayed());
		Logger.log("User able to see the expanded the sort section");
	}

	@Then("user should be to view refine options for the Learning Activities titles listed")
	public void user_should_be_to_view_refine_options_for_the_learning_activities_titles_listed() {
		Assert.assertTrue(learning.getRefineSection().isDisplayed());
	}

	@Then("user should be able to view each refine option collapsed by default")
	public void user_should_be_able_to_view_each_refine_option_collapsed_by_default() {
		Logger.log("User able to view each refine option collapsed by default");
	}

	@Then("user should be able to expand and view sub options for each Refine Option available")
	public void user_should_be_able_to_expand_and_view_sub_options_for_each_refine_option_available() {
		learning.clickRefineOptions();
	}

	@Then("user should not view the refine option if no sub option is available for that")
	public void user_should_not_view_the_refine_option_if_no_sub_option_is_available_for_that() {
		learning.checkRefine();
	}

	@Then("user should be able to select a refine option and View the results Updated based on that Refine option")
	public void user_should_be_able_to_select_a_refine_option_and_view_the_results_updated_based_on_that_refine_option() {
		learning.inspectActivity();
		learning.selectActivityType();
	}

	@Then("user should be able to view the selected Refine Sub Option option below the refine option")
	public void user_should_be_able_to_view_the_selected_refine_sub_option_option_below_the_refine_option() {
		Logger.log("User able to view the selected Refine Sub Option option below the refine option");
	}

	@Then("user should be able to view the selected Sort Option below the sort section header")
	public void user_should_be_able_to_view_the_selected_sort_option_below_the_sort_section_header() {
		Logger.log("user able to view the selected Sort Option below the sort section header");
	}

	@Then("user should be able to view the selected refiners sub-options on the screen as pills")
	public void user_should_be_able_to_view_the_selected_refiners_sub_options_on_the_screen_as_pills() {
		Assert.assertEquals(learning.getRefinerPills().get(0).isDisplayed(), true);
		Logger.log("User able to see refiner " + learning.getRefinerPills().size() + " sub-options as pills");
	}

	@When("user should be able to remove refiners applied by clicking X on refiner sub-option pill")
	public void user_should_be_able_to_remove_refiners_applied_by_clicking_x_on_refiner_sub_option_pill() {
		learning.clickRefinerPills();
		Logger.log("User able to remove refiners applied by clicking X on refiner sub-option pill");
	}

	@When("system should update the refiner section when refiners are removed")
	public void system_should_update_the_refiner_section_when_refiners_are_removed() {
		Logger.log("Refiner section updated after refiners are removed");
	}

	@Then("user should be able to view clear all cta as a pill")
	public void user_should_be_able_to_view_clear_all_cta_as_a_pill() {
		learning.clearAllCTA();
	}

	@Then("clears the selected refiners and sort when user tap the clear all cta")
	public void clears_the_selected_refiners_and_sort_when_user_tap_the_clear_all_cta() {
		learning.inspectActivity();
		learning.selectActivityType();
		learning.clickclearAllCTA();
//		Assert.assertEquals(isElementPresent(learning.getRefinerPills1()), false);
	}

	@Then("user should be able each learning activity title listed as a card")
	public void user_should_be_able_each_learning_activity_title_listed_as_a_card() {
		Assert.assertTrue(learning.getActivityCards().get(0).isDisplayed());
		Logger.log("User able to see each learning activity title listed as a card");
	}

	@When("user should be able to view cover image for the learning activity title")
	public void user_should_be_able_to_view_cover_image_for_the_learning_activity_title() {
		Assert.assertTrue(learning.getActivityCardCoverImage().get(0).isDisplayed());
		Logger.log("User able to view cover image for the learning activity title");
	}

	@When("user should be able to view title of the learning activity title")
	public void user_should_be_able_to_view_title_of_the_learning_activity_title() {
		Assert.assertTrue(learning.getActivityCardTitle().get(0).isDisplayed());
		Logger.log("User able to view title for the learning activity title");
	}

	@When("user should be able to view learning activity title type")
	public void user_should_be_able_to_view_learning_activity_title_type() {
		Assert.assertTrue(learning.getActivityCardTitleType().get(0).isDisplayed());
		Logger.log("User able to view cover image for the learning activity title");
	}

	@When("user should be able to view title mapped to learning activity title")
	public void user_should_be_able_to_view_title_mapped_to_learning_activity_title() {
		Assert.assertTrue(learning.getActivityCardLinkedTitle().get(0).isDisplayed());
		Logger.log("User able to view title mapped to the learning activity title");
	}

	@When("user should be able to click on mapped title and navigate to title details screen")
	public void user_should_be_able_to_click_on_mapped_title_and_navigate_to_title_details_screen() {
		learning.clickLinkedTitle();
	}
}
