package parallel;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;

public class Login_Stepdef extends CommonAction {
	static ExcelReader reader = new ExcelReader();
	Login login = new Login(DriverManager.getDriver());

	/*******************************************************/

	@Given("User launch the {string} url")
	public void user_launch_the_url(String string) throws Exception {		
		login.Login_PrefixWithPin();
	}

	@Given("user launch the kids NYC {string} url with kidszone subscription")
	public void user_launch_the_kids_nyc_url_with_kidszone_subscription(String string) throws Exception {
		login.Login_PrefixWithoutPin();
		login.handle_dontRemindMePopup();
		login.click_loginPage();
	}

	@Given("user launches the AutoSI {string} with axis360 and KidsZone subscription")
	public void user_launches_the_auto_si_with_axis360_and_kids_zone_subscription(String string) throws Exception {
		login.Login_PrefixWithPin();
	}

	@Given("user launch the kids texas {string} url with kidszone subscription")
	public void user_launch_the_kids_texas_url_with_kidszone_subscription(String string) throws Exception {
		login.Login_texas();
		login.handle_dontRemindMePopup();
	}

	@Given("user clicks on login button")
	public void user_clicks_on_login_button() {
		login.click_loginPage();
	}

	@Given("user click on login button after user enter kidszone subscription only {string}")
	public void user_click_on_login_button_after_user_enter_kidszone_subscription_only(String id) {
		//login.readInAppClose();
		login.logInClick();
		login.idlogin(id);
	}

	@And("Already signed user enters the prefix {string} and pin {string} shared by the client")
	public void already_signed_user_enters_the_prefix_and_pin_shared_by_the_client(String loginid, String pin) {
		login.already_signeduser_prefixloginwithPin(loginid, pin);
		login.preferenceScreen_popup();
		login.readInAppClose();
	}

	@Given("user enters the {string} and click sign in button")
	public void user_enters_the_and_click_sign_in_button(String loginid) {
		login.login_withoutPin(loginid);
		login.preferenceScreen_popup();
	}

	@Given("user enters the {string} and {string} and click sign in button")
	public void user_enters_the_and_and_click_sign_in_button(String loginid, String pin) {
		login.already_signeduser_prefixloginwithPin(loginid, pin);
	}

	@Given("user switches teen profile via hamburger menu")
	public void user_switches_teen_profile_via_hamburger_menu() {
		login.click_HamburgerMenu();
		login.click_Profiles();
		login.select_Teenprofile();
		waitFor(2000);
		login.preferenceScreen_popup();
	}

	@Given("user select teen profile via hamburger menu")
	public void user_select_teen_profile_via_hamburger_menu() {

	}

	@Given("user switches teen profile for old UI")
	public void user_switches_teen_profile_for_old_ui() {
		login.click_MenuOnly();
		login.menu_adultProfile();
		login.select_Teenprofile();
		waitFor(2000);
	}

	@Given("user switches kid profile via hamburger menu")
	public void user_switches_kid_profile_via_hamburger_menu() {
		login.click_HamburgerMenu();
		login.click_Profiles();
		login.select_Kidprofile();
		waitFor(2000);
		login.preferenceScreen_popup();
	}

	@Given("user switches kid profile for old UI")
	public void user_switches_kid_profile_for_old_ui() {
		login.click_MenuOnly();
		login.menu_adultProfile();
		login.select_Kidprofile();
		waitFor(2000);
	}

	@Then("user should logout the application by clicking on signout button from hamburger menu")
	public void user_should_logout_the_application_by_clicking_on_signout_button_from_hamburger_menu() {
		login.sign_Out();
	}

	@When("user switches adult profile via hamburger menu")
	public void user_switches_adult_profile_via_hamburger_menu() {
		login.click_MenuOnly();
		login.menu_adultProfile();
		login.select_Adultprofile();
		waitFor(2000);
	}

	@Given("user is on profile screen old UI")
	public void user_is_on_profile_screen_old_ui() {
		login.click_MenuOnly();
		login.menu_adultProfile();
	}

	@Given("user launch the manual kids NYC {string} url with kidszone subscription")
	public void user_launch_the_manual_kids_nyc_url_with_kidszone_subscription(String string) throws Exception {
		login.login_manualnyc();
		login.click_loginPage();
	}

}
