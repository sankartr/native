package parallel;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.driverfactory.DriverManager;
import com.utilities.Logger;

import io.cucumber.java.en.Given;

public class Reviews_Stepdef {
	
	@Given("user launch the {string} url with kidszone subscription")
	public void user_launch_the_url_with_kidszone_subscription(String url) {
		DriverManager.getDriver().get(url);
		WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 10);
		try {
		    JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		    js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
		    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='See all reviews']/parent::button)")));
		    element.click();
		    Logger.log("see all reviews clicked");
		} catch (NoSuchElementException e) {
		    e.printStackTrace();
		}
        
     // Create data collection variables
        Map<String, String> reviewDetails = new HashMap<>();

        int scrollCount = 0;
        boolean moreContentAvailable = true;
        
        while (moreContentAvailable) {
            // Find all usernames and reviews on the current visible page
            List<WebElement> allUsernames = DriverManager.getDriver().findElements(By.xpath("//div[@class='gSGphe']/div"));
            List<WebElement> allReviews = DriverManager.getDriver().findElements(By.xpath("//div[@class='gSGphe']/div/parent::div/parent::div/parent::header/following-sibling::div[@class]"));

            // Iterate through elements to collect data
            for (int i = 0; i < allUsernames.size(); i++) {
                String username = allUsernames.get(i).getText();
                String review = allReviews.get(i).getText();
                reviewDetails.put(username, review);
//                System.out.println("Username: " + username);
//                System.out.println("Review: " + review);
            }
            
            WebElement elementToScroll = allReviews.get(allReviews.size() - 1);
            JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
            js.executeScript("arguments[0].scrollIntoView(true);", elementToScroll);
            
            // Scroll down to load more content
            scrollPageDown(DriverManager.getDriver());
//            WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='See all reviews']/parent::button)")));

            // Check if more content is loaded
            scrollCount++;
            if (scrollCount >= 10) { // Adjust the number of scrolls as needed
                moreContentAvailable = false;
            }
        }
        
        DriverManager.getDriver().quit();
        
     // Write the data from reviewDetails map to an Excel file
        writeDataToExcel(reviewDetails);
	}
	
    // Function to scroll down the page
    private void scrollPageDown(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
        try {
            Thread.sleep(2000); // Adjust the sleep duration as needed to allow content to load
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
 // Function to write data to Excel
    private static void writeDataToExcel(Map<String, String> reviewDetails) {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Review Details");

        // Create header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Username");
        headerRow.createCell(1).setCellValue("Review");

        // Iterate over the map and write data to Excel
        int rowNum = 1;
        for (Map.Entry<String, String> entry : reviewDetails.entrySet()) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(entry.getKey());     // Username
            row.createCell(1).setCellValue(entry.getValue());   // Review
        }

        // Write the workbook content to an Excel file
        try (FileOutputStream outputStream = new FileOutputStream("ReviewDetails.xlsx")) {
            workbook.write(outputStream);
            System.out.println("Excel file written successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Close the workbook
        try {
            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	

}
