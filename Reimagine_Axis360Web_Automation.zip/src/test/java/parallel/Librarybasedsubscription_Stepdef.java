package parallel;

import java.util.ArrayList;
import java.util.List;

import java.util.Map;

import com.driverfactory.DriverManager;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Adminconfiguration;
import pom.kidszone.Librarysubscription;
import pom.kidszone.Login;
import pom.kidszone.Loginpageview;
import pom.kidszone.Pagesourceview;
import pom.kidszone.Profilecreation;

public class Librarybasedsubscription_Stepdef {

	static ExcelReader reader = new ExcelReader();
	Librarysubscription library = new Librarysubscription(DriverManager.getDriver());
	Adminconfiguration admin = new Adminconfiguration(DriverManager.getDriver());
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());
	public static String categoryCarousel = "";
	public static String categoryISBN = "";
	public static int ListPageCount;

	Pagesourceview page = new Pagesourceview(DriverManager.getDriver());

	// 112826//

	@And("user click on library in menu")
	public void user_click_on_library_in_menu() throws Throwable {
		admin.library_settings();

	}

	@Given("user selecting {string} and choose kidszone only option")
	public void user_selecting_something_and_choose_kidszone_only_option(String strArg1) throws Throwable {
		library.kidsnyclibrary_search();
		library.verify_enable_kidszone();
		library.verify_disable_axis360();
		library.savelibrary_logoff();
	}

	@Given("user selecting {string} and choose axis360 only option")
	public void user_selecting_something_and_choose_axis360_only_option(String strArg1) throws Throwable {
		library.saleslibrary_search();
		admin.verify_disable_kidszone();
		library.verify_enable_axis360();
		library.savelibrary_logoff();
	}

	@Given("user selecting 'Magic Independent library' and choose kidszone and axis360 option")
	public void user_selecting_magic_independent_library_and_choose_kidszone_and_axis360_option() throws Throwable {
		library.magiclibrary_search();
		library.verify_enable_kidszone();
		library.verify_enable_axis360();
		library.savelibrary_logoff();
	}

	@When("user launch the kidszone newyork library url has kidszone subscription only")
	public void user_launch_the_kidszone_newyork_library_url_has_kidszone_subscription_only() throws Throwable {
		login.Login_PrefixWithoutPin();
	}

	@Then("user enters the prefix and click login cta")
	public void user_enters_the_prefix_and_click_login_cta() throws Throwable {
		profile.readInAppClose();
		page.regloginwithid();
	}

//	@And("user clicks on login button")
//	public void user_clicks_on_login_button() throws Throwable {
////		page.clickLogins();
//		profile.readInAppClose();
//		loginpageUpdatedui.click_loginPage(); 
//	}

	@And("user should be able to see profiles in register page")
	public void user_should_be_able_to_see_profiles_in_register_page() throws Throwable {
		library.profileavailability();

	}

	@When("user launch the Sales Demo QA Library url library has axis360 subscription only")
	public void user_launch_the_sales_demo_qa_library_url_library_has_axis360_subscription_only() throws Throwable {
		login.Login_ssoUrl();
	}

	@Then("user enters the username and password and click login cta")
	public void user_enters_the_username_and_password_and_click_login_cta() throws Throwable {
		page.regloginwith_password();
	}

	@And("user should not able to see profiles option in register page")
	public void user_should_not_able_to_see_profiles_option_in_register_page() throws Throwable {
		// library.profilenonavailability();
	}

	@When("user launch the Magic Independent library url library has axis360 and kidszone subscription")
	public void user_launch_the_magic_independent_library_url_library_has_axis360_and_kidszone_subscription()
			throws Throwable {
		login.Login_PrefixWithPin();
	}
//
//	@Given("user should be able to view library carousel")
//	public void user_should_be_able_to_view_library_carousel() {
//
//		List<String> verify_LibraryCarousel = library.verify_LibraryCarousel();
//		
//		for (String carousel : verify_LibraryCarousel) {
//			Logger.log("Library carousel heading for each carousel list:" + carousel);
//			System.out.println(carousel);
//
//		}
//
//	}

//	@Then("user is able to view titles in the library carousel")
//	public void user_is_able_to_view_titles_in_the_library_carousel() {
//		
//		List<String> isbListfromUI = new ArrayList<String>();
//		
//		isbListfromUI = library.get_LibCarouselTitlesISBN();
//		for (String isbn : isbListfromUI) {
//			Logger.log("ISBN's list from Carousel UI : " + isbn);
//			
//		}	
//	}

	@Then("User navigates to title list page if a user click on {string} see All Cta")
	public void user_navigates_to_title_list_page_if_a_user_click_on_see_all_cta(String componentName) {
		library.clickLibraryComponent(componentName);
		ListPageCount = login.get_CategoryCounts();
		Logger.log(componentName + "List page count : " + ListPageCount);
		
	}
	
//	@Then("User navigates to title list page if a user click on featured see All Cta")
//	public void user_navigates_to_title_list_page_if_a_user_click_on_featured_see_all_cta() {
//		library.clickfeaturedCarousel_TitleListPage();
//		ListPageCount = login.get_CategoryCounts();
//		Logger.log("Featured List page count : " + ListPageCount);
//		
//	}
//	
//	@Then("User navigates to title list page if a user click on Kids see All Cta")
//	public void user_navigates_to_title_list_page_if_a_user_click_on_Kids_see_all_cta() {
//		library.clickKidsCarousel_TitleListPage();
//		ListPageCount = login.get_CategoryCounts();
//		Logger.log("Kids List page count : " + ListPageCount);
//		
//	}

}
