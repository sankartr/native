package parallel;

import java.util.List;
import java.util.Map;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Adminconfiguration;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Login;
import pom.kidszone.Loginpageview;
import pom.kidszone.MyLibrary;
import pom.kidszone.Pagesourceview;
import pom.kidszone.Profilecreation;

public class Menus_Stepdef extends CommonAction {

	Adminconfiguration admin = new Adminconfiguration(DriverManager.getDriver());
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	Pagesourceview page = new Pagesourceview(DriverManager.getDriver());
	static ExcelReader reader = new ExcelReader();
	Login login = new Login(DriverManager.getDriver());
	
	@When("user clicks on menu option")
	public void user_clicks_on_menu_option() throws Throwable {
		hamburgerMenu.click_HamburgerMenu();
	}

	@And("user clicks on Axis 360 menu option")
	public void user_clicks_on_Axis_360_menu_option() throws Throwable {
		profile.click_MenuOnly();
	}

	@Then("user should be navigated to programs screen")
	public void user_should_be_navigated_to_programs_screen() throws Throwable {
		Assert.assertTrue(hamburgerMenu.getTxt_MyPrograms().isDisplayed());
	}

	@And("programs are enable for the library")
	public void programs_are_enable_for_the_library() throws Throwable {
		Logger.log("Programs are enabled for this libary from admin ");
	}

	@And("user clicks on programs from menu")
	public void user_clicks_on_programs_from_menu() throws Throwable {
		hamburgerMenu.click_Programs();
	}

	@And("user should logout from the application")
	public void user_should_logout_from_the_application() throws Throwable {
		Logger.log("User logout from the application");
//		profile.log_Out();
	}

	@Then("user should be navigated to checkout screen")
	public void user_should_be_navigated_to_checkout_screen() throws Throwable {
		Assert.assertTrue(hamburgerMenu.getTxt_CheckoutLandingPage().isDisplayed());
	}

	@And("programs are disabled for the library")
	public void programs_are_disabled_for_the_library() throws Throwable {
		Logger.log("Programs are disabled for the library");
	}

	@And("user clicks on checkout from menu")
	public void user_clicks_on_checkout_from_menu() throws Throwable {
		hamburgerMenu.click_Checkouts();
	}

	@Then("user should be able to navigate to profiles screen by entering correct pin")
	public void user_should_be_able_to_navigate_to_profiles_screen_by_entering_correct_pin() throws Throwable {
		Assert.assertTrue(profile.getAddprofile_txt_profile().isDisplayed());
	}

	@And("user clicks on my profile from menu")
	public void user_clicks_on_my_profile_from_menu() throws Throwable {
		hamburgerMenu.click_Profiles();
	}

	@And("user should be prompted to enter four digits profile management pin {string}")
	public void user_should_be_prompted_to_enter_four_digits_profile_management_pin_something(String Pin)
			throws Throwable {
		WaitForWebElement(profile.getTxt_profileManagementPin());
		profile.Enter_setPin(Pin);
		profile.clickSubmit();
	}

	@And("user should be able to view error message when the pin is not correct")
	public void user_should_be_able_to_view_error_message_when_the_pin_is_not_correct() throws Throwable {

		Logger.log("Wrong pin entered and toast message will be validated in other scenario");
	}

	@And("user should be able to click on close cta and navigate back to the last screen")
	public void user_should_be_able_to_click_on_close_cta_and_navigate_back_to_the_last_screen() throws Throwable {

		Assert.assertTrue(profile.getAddprofile_txt_profile().isDisplayed());
	}

	@And("profile option should not display")
	public void profile_option_should_not_display() throws Throwable {
		Assert.assertFalse(isElementPresent(hamburgerMenu.getLink_Profiles()));
	}

	@When("user clicks on holds in menu")
	public void user_clicks_on_holds_in_menu() throws Throwable {
		hamburgerMenu.click_Holds();
	}

	@Then("^user should be able to navigate to holds screen$")
	public void user_should_be_able_to_navigate_to_holds_screen() throws Throwable {
		Assert.assertTrue(hamburgerMenu.getTxt_HoldsPage().isDisplayed());
	}

	@When("user clicks on help in menu")
	public void user_clicks_on_help_in_menu() throws Throwable {
		hamburgerMenu.click_Help();
	}

	@Then("user should be able to navigate to axis360 help support portal")
	public void user_should_be_able_to_navigate_to_axis360_help_support_portal() throws Throwable {
		Logger.log("Currently this doesn't integrated with Kidzone application");
	}

	@When("user clicks on my shelf in menu")
	public void user_clicks_on_my_shelf_in_menu() throws Throwable {
		hamburgerMenu.click_MyShelf();
	}

	@Then("user should be able to navigate to my shelf screen")
	public void user_should_be_able_to_navigate_to_my_shelf_screen() throws Throwable {
		Assert.assertTrue(isElementPresent(hamburgerMenu.getLogo_ShelfPage()));
	}

	@And("user clicks on sign out")
	public void user_clicks_on_sign_out() throws Throwable {
		hamburgerMenu.click_SignOut();
	}

	@And("user should be able to signout and navigate to library screen on confirmation")
	public void user_should_be_able_to_signout_and_navigate_to_library_screen_on_confirmation() throws Throwable {
		Logger.log("User navigared to library screen on confirmation");
	}

	@Then("user should be able to view insights and goals with profile specific theme")
	public void user_should_be_able_to_view_insights_and_goals_with_profile_specific_theme() throws Throwable {
		Assert.assertTrue(isElementPresent(hamburgerMenu.getText_GoalsandInsgights()));
	}

	@And("user navigates to the my shelf screen")
	public void user_navigates_to_the_my_shelf_screen() throws Throwable {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_MyShelf();
		Assert.assertTrue(hamburgerMenu.getMyShelfTab().isDisplayed());
	}

	@And("user should be able to scroll insights and goals left or right as a carousel")
	public void user_should_be_able_to_scroll_insights_and_goals_left_or_right_as_a_carousel() throws Throwable {
		hamburgerMenu.click_accordion();
		hamburgerMenu.click_RightAccordion();
//		hamburgerMenu.click_LeftAccordion();
	}

	@And("user click on profiles icon")
	public void user_click_on_profiles_icon() throws Throwable {
		hamburgerMenu.click_AvatarIcon();
		hamburgerMenu.click_ProfileIcon();
	}

	@And("select View Settings")
	public void select_view_settings() throws Throwable {
		hamburgerMenu.click_ViewSettings();
	}

	@And("Uncheck the Insights and badges checkbox")
	public void uncheck_the_insights_and_badges_checkbox() throws Throwable {
		hamburgerMenu.select_CheckboxInsights();
	}

	@And("click on Update Settings")
	public void click_on_Update_Settings() throws Throwable {
		hamburgerMenu.click_UpdateSettings();
	}

	@Then("user should not be able to view insights and goals and badges in my shelf screen")
	public void user_should_not_be_able_to_view_insights_and_goals_and_badges_in_my_shelf_screen() throws Throwable {
		waitFor(2000);
		Assert.assertFalse(isElementPresent(hamburgerMenu.getText_GoalsandInsgights()));
		//hamburgerMenu.click_AvatarIcon();
		//hamburgerMenu.click_ProfileIcon();
		//hamburgerMenu.click_ViewSettings();
		//hamburgerMenu.select_CheckboxInsights();
		//hamburgerMenu.click_UpdateSettings();
	}

	@And("insights and badges are not enabled in user profile preferences")
	public void insights_and_badges_are_not_enabled_in_user_profile_preferences() throws Throwable {
		Logger.log("Disabled from user profile preferences");
	}

	@Then("user should see the alert message with Yes and No option")
	public void user_should_see_the_alert_message_with_Yes_No_option() throws Throwable {
		Assert.assertTrue(hamburgerMenu.getAlert_PopUpMessage().isDisplayed());

	}

	@And("user should click on Yes button")
	public void user_should_click_on_button() throws Throwable {
		hamburgerMenu.click_YesButton();
	}

	@And("user should be able to reamin on menu page if user clicks 'No' on confirmation popup")
	public void user_should_be_able_to_remain_on_menu_page_if_user_clicks_No_on_confirmation_popup() throws Throwable {
		hamburgerMenu.click_NoButton();
	}

	// 125282

	@When("user should be able to view library option")
	public void user_should_be_able_to_view_library_option() {
		hamburgerMenu.view_libraryOption();
	}

	@When("user should be able to close menu and navigate back to last screen")
	public void user_should_be_able_to_close_menu_and_navigate_back_to_last_screen() {
		hamburgerMenu.humbergerMenuclick_closeCTA();
		Assert.assertTrue(hamburgerMenu.getMagiclibraryscreen_txt().isDisplayed());
	}

	@When("my library set as default landing screen")
	public void my_library_set_as_default_landing_screen() {
		Assert.assertTrue(hamburgerMenu.getLibraryscreen_txt().isDisplayed());
		Logger.log("my library set as default landing screen");
	}

	@Then("user should be able to view my shelf")
	public void user_should_be_able_to_view_my_shelf() {
		hamburgerMenu.click_MyShelf();
		Assert.assertTrue(hamburgerMenu.getText_MyShelf_Page().isDisplayed());
	}

	@Then("user should be able to view browsebysubject")
	public void user_should_be_able_to_view_browsebysubject() {
		Assert.assertTrue(hamburgerMenu.View_browseBySubject());
	}

	@Then("user should be able to view featuredlist")
	public void user_should_be_able_to_view_featuredlist() {
		Assert.assertTrue(hamburgerMenu.View_featuredLists());
	}

	@Then("user should be able to view collections")
	public void user_should_be_able_to_view_collections() {
		Logger.log("User able to view collections");
	}

	@Then("user should be able to view programs")
	public void user_should_be_able_to_view_programs() {
		Assert.assertTrue(hamburgerMenu.View_programs());
	}

	@Then("user should be able to view checkouts")
	public void user_should_be_able_to_view_checkouts() {
		hamburgerMenu.view_checkout();
	}

	@Then("user should be able to view the number of checkouts")
	public void user_should_be_able_to_view_the_number_of_checkouts() {
		Logger.log("User able to view the number of checkouts");
	}

	@Then("user should be able to view holds")
	public void user_should_be_able_to_view_holds() {
		Assert.assertTrue(hamburgerMenu.getLink_Holds().isDisplayed());
	}

	@Then("user should be able to view the number of holds")
	public void user_should_be_able_to_view_the_number_of_holds() {
		System.out.println("user should be able to view number of holds");
	}

	@Then("user should be able to view profiles")
	public void user_should_be_able_to_view_profiles() throws Throwable {
		System.out.println("user should be able to view profiles");
	}

	@Then("user should be able to view help")
	public void user_should_be_able_to_view_help() {
		Assert.assertTrue(hamburgerMenu.getLink_Help().isDisplayed());
	}

	@Then("user should be able to view signout")
	public void user_should_be_able_to_view_signout() {
		Assert.assertTrue(hamburgerMenu.getLink_SignOut().isDisplayed());
	}

	@Then("user should not able to view profiles option in menu")
	public void user_should_not_able_to_view_profiles_option_in_menu() {
    	Assert.assertFalse(isElementPresent(hamburgerMenu.getLink_Profiles()));
//		Assert.assertNull(hamburgerMenu.getLink_Profiles());
	}

	@Then("user should not able to view profiles option in menu if user is standalone patron with profile type kid")
	public void user_should_not_able_to_view_profiles_option_in_menu_if_user_is_standalone_patron_with_profile_type_kid() {
//    	Assert.assertFalse(hamburgerMenu.getLink_Profiles().isDisplayed());
		Assert.assertFalse(isElementPresent(hamburgerMenu.getLink_Profiles()));
	}

	@Then("user should not able to view profiles option in menu if user is standalone patron with profile type teen")
	public void user_should_not_able_to_view_profiles_option_in_menu_if_user_is_standalone_patron_with_profile_type_teen() {
		Assert.assertFalse(isElementPresent(hamburgerMenu.getLink_Profiles()));
	}

	// 125284

	@Given("user click on menu option")
	public void user_click_on_menu_option() {
		hamburgerMenu.click_HamburgerMenu();
	}

	@When("user clicks on my library screen")
	public void user_clicks_on_my_library_screen() {
		hamburgerMenu.click_library();
	}

	@Then("user should be navigated to my library screen")
	public void user_should_be_navigated_to_my_library_screen() {
		Assert.assertEquals(mylibrary.getTxt_NavlibraryScreen().isDisplayed(), true);
		
	}

	@Then("user should be able to click on {string} cta and navigate back to last screen")
	public void user_should_be_able_to_click_on_cta_and_navigate_back_to_last_screen(String string) {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.humbergerMenuclick_closeCTA();
		Assert.assertTrue(hamburgerMenu.getLibraryscreen_txt().isDisplayed());
	}

	// 125285

	@When("user clicks browser by subject")
	public void user_clicks_browser_by_subject() {
		hamburgerMenu.click_oldBrowseBysubject();
	}

	@Then("user should be able to view level one subjects list in the sidebar based on adult profile type")
	public void user_should_be_able_to_view_level_one_subjects_list_in_the_sidebar_based_on_adult_profile_type() {
		visibilityWait(hamburgerMenu.browseBySubject_options);
		Assert.assertTrue(hamburgerMenu.browseBySubject_options.isDisplayed());
	}

	@When("user click browser by subject")
	public void user_click_browser_by_subject() {
		hamburgerMenu.click_browseBySubject();
//		hamburgerMenu.click_featuredList();
	}

	@Then("user should be able to navigate to level one subject list screen by clicking the subject")
	public void user_should_be_able_to_navigate_to_level_one_subject_list_screen_by_clicking_the_subject() {
		hamburgerMenu.click_level1Subject();
	}

	@Then("user should see the subjects highlighted based on cursor location")
	public void user_should_see_the_subjects_highlighted_based_on_cursor_location() {
		visibilityWait(hamburgerMenu.tilelist_youngAdultFiction);
		Assert.assertTrue(hamburgerMenu.tilelist_youngAdultFiction.isDisplayed());
	}

	@Then("user should be able to click close menu and navigate back to last screen")
	public void user_should_be_able_to_click_close_menu_and_navigate_back_to_last_screen() {
		hamburgerMenu.click_closeCTABrowseBysubject();
	}

	@Then("user should be able to view level one subjects list in the sidebar based on teen profile type")
	public void user_should_be_able_to_view_level_one_subjects_list_in_the_sidebar_based_on_teen_profile_type() {
		// Assert.assertTrue(hamburgerMenu.getTeenmenu_browsebysubject_submenu().isDisplayed());
		Logger.log("browseBySubject list not implemented");

	}

	@Then("user should be able to view level one subjects list in the sidebar based on kid profile type")
	public void user_should_be_able_to_view_level_one_subjects_list_in_the_sidebar_based_on_kid_profile_type() {
		Assert.assertTrue(hamburgerMenu.getTeenmenu_browsebysubject_submenu().isDisplayed());
	}

	@Then("user should be able to click close {string} menu and navigate back to last screen")
	public void user_should_be_able_to_click_close_menu_and_navigate_back_to_last_screen(String string) {
		hamburgerMenu.humbergerMenuclick_closeCTA();
	}

	/***********************************
	 * Holds
	 ***************************************************************/

	// 139195

	@Given("user launch the axis url")
	public void user_launch_the_axis_url() throws Exception {
		login.Login_Salesdemo();
	}

	@Given("user click on login button after user enter axis360 only {string}")
	public void user_click_on_login_button_after_user_enter_axis360_only(String libraryid) {
		page.clickLogins();
		loginpageUpdatedui.loginwithoutPinRegistration(libraryid);
	}

	@Given("user clicks on login button after user enter axis360 only {string}")
	public void user_clicks_on_login_button_after_user_enter_axis360_only(String libraryid) {
		page.click_SalesDemo_login();
		loginpageUpdatedui.loginwithoutPinRegistration(libraryid);

	}

	@Given("user logged in as adult user")
	public void user_logged_in_as_adult_user() {
		Logger.log("user logged in as adult user");
	}

	@Given("user as a new user land on set preferences page and click on {string} option")
	public void user_as_a_new_user_land_on_set_preferences_page_and_click_on_option(String string) {
		profile.preferenceScreen_popup();
	}

	@When("user lands on library page")
	public void user_lands_on_library_page() {
		hamburgerMenu.navigate_axislibrarylibraryPage();
	}

	@Then("user should not be able to view the {string} option in hamburger menu based on profile")
	public void user_should_not_be_able_to_view_the_option_in_hamburger_menu_based_on_profile(String string) {
		hamburgerMenu.click_HamburgerMenu();
		Assert.assertFalse(hamburgerMenu.notDisplayed_myshelfInaxisLib());
	}

	@Then("user should be able to view Holds screen with theme rendered based on library subscription and user profile type")
	public void user_should_be_able_to_view_holds_screen_with_theme_rendered_based_on_library_subscription_and_user_profile_type() {
		Logger.log("user should be able to view Holds screen");
	}

//	@Then("user should logout the application by clicking on signout button from hamburger menu")
//	public void user_should_logout_the_application_by_clicking_on_signout_button_from_hamburger_menu() {
//		hamburgerMenu.sign_Out();
//	}

}
