package parallel;

import static org.junit.Assert.assertNotNull;

import java.util.List;
import java.util.Map;

import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import api.APIClient;
import api.searchTitlev8.SearchTitleResponse;
import eyesmanager.EyesManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.Migration;
import pom.kidszone.MyLibrary_Vbooks;
import pom.kidszone.MyLibrary_Videobooks;
import pom.kidszone.MyshelfvideosVbooks;
import pom.kidszone.SearchResults_Vbooks;

import org.junit.Assert;

public class SearchResultsVbook_Stepdef extends CommonAction {
	static ExcelReader reader = new ExcelReader();
	Login login = new Login(DriverManager.getDriver());
	MyLibrary_Videobooks video = new MyLibrary_Videobooks(DriverManager.getDriver());
	MyLibrary_Vbooks vbook = new MyLibrary_Vbooks(DriverManager.getDriver());
	SearchResults_Vbooks search = new SearchResults_Vbooks(DriverManager.getDriver());
	MyshelfvideosVbooks myshelfpage = new MyshelfvideosVbooks(DriverManager.getDriver());
	Migration migration = new Migration(DriverManager.getDriver());
	private SearchTitleResponse apiResponse;
	
	Eyes eyes = EyesManager.getEyes();

	/*******************************************************/

	@Given("admin user is enabled videos and vbooks third party search flag and include in search flag in drupal")
	public void admin_user_is_enabled_videos_and_vbooks_third_party_search_flag_and_include_in_search_flag_in_drupal() {
		Logger.log(
				"uadmin user is enabled videos and vbooks third party search flag and include in search flag in drupal");
	}

	@Given("library should have subscription to video third party and video carousel enabled by library admin")
	public void library_should_have_subscription_to_video_third_party_and_video_carousel_enabled_by_library_admin() {
		Logger.log("library should have subscription to video third party and video carousel enabled by library admin");
	}

	@Given("user is able to view videos and vbooks third party option in advance search")
	public void user_is_able_to_view_videos_and_vbooks_third_party_option_in_advance_search() {
		search.click_AdvanceSearch();
		visibilityWait(search.getAdvancedSearch_video_radiobtn());
		Assert.assertTrue(search.getAdvancedSearch_video_radiobtn().isDisplayed());
		Assert.assertTrue(search. getAdvancedSearch_vbook_radiobtn().isDisplayed());
	}

	@Given("user is able click on advance search from my shelf page and enter any keyword {string} and select vbooks option in category")
	public void user_is_able_click_on_advance_search_from_my_shelf_page_and_enter_any_keyword_and_select_vbooks_option_in_category(
			String keyword) {
		search.AdvanceSesarch_EnterInput(keyword);
		search.click_vbooksInAdvancesearch();
		search.Click_Searchbtn();
	}

	@Given("user is able click on advance search from my shelf page and enter any keyword and select vbooks option in category")
	public void user_is_able_click_on_advance_search_from_my_shelf_page_and_enter_any_keyword_and_select_vbooks_option_in_category() {

	}

	@When("user is able to navigate search result landing page after click on search")
	public void user_is_able_to_navigate_search_result_landing_page_after_click_on_search() {
		visibilityWait(search.getSearch_Result());
		Assert.assertTrue(search.getSearch_Result().isDisplayed());
	}

	@Then("user should be able to view vbooks category as seperate carousel for the search keyword")
	public void user_should_be_able_to_view_vbooks_category_as_seperate_carousel_for_the_search_keyword() {
		search.SearchKeyword_SearchREsults();
	}

	@Then("user should be able to view vbooks come from third party resources")
	public void user_should_be_able_to_view_vbooks_come_from_third_party_resources() {
		Assert.assertTrue(search.vbooks_Resources.isDisplayed());
	}

	@Then("user should be able to view title with VBooks icon on the jacket image")
	public void user_should_be_able_to_view_title_with_v_books_icon_on_the_jacket_image() {
		Assert.assertTrue(search.view_jacketimgwithIcon());
	}

	@Then("user should be able to click on the vbooks title and navigate to vbooks detail page from vbooks list page")
	public void user_should_be_able_to_click_on_the_vbooks_title_and_navigate_to_vbooks_detail_page_from_vbooks_list_page() {
		search.ClickTitle_navDetailPage();
	}

	@When("user is able to navigate search result landing page and click see all cta")
	public void user_is_able_to_navigate_search_result_landing_page_and_click_see_all_cta() {
		search.click_SeeAllCTA();
	}

	@Then("user should be able to view expanded results for vbooks category in list view")
	public void user_should_be_able_to_view_expanded_results_for_vbooks_category_in_list_view() {
		Assert.assertTrue(search.vbooks_SearchResult_Tire2_Listview.isDisplayed());
		Logger.log("user is able to view expanded results for vbooks in list view");
	}

	@Then("user should be able to view vbooks cover image, title, dropdown menu and primary cta")
	public void user_should_be_able_to_view_vbooks_cover_image_title_dropdown_menu_and_primary_cta() {
		search.view_vbooksSearchResults();
	}

	@Then("user should be able to view sort order for the results based on relevance")
	public void user_should_be_able_to_view_sort_order_for_the_results_based_on_relevance() {
		search.verify_SortOrder_Relevence();
	}

	@Then("user should be able to view lazy load after scroll down more than {int} titles")
	public void user_should_be_able_to_view_lazy_load_after_scroll_down_more_than_titles(Integer int1) {
		Logger.log("user is able to view lazy load after scroll down more than 24 titles");
	}

	@Then("system should auto filter the results based on teen profile or kid profile")
	public void system_should_auto_filter_the_results_based_on_teen_profile_or_kid_profile() {
		Logger.log("system should auto filter the results based on teen profile or kid profile");
	}

	@Given("library should have VBook title without title image")
	public void library_should_have_v_book_title_without_title_image() {
		Logger.log("Library have VBook title without title image");
	}

	@When("user tap on title card from VBook carousel to navigate title detail page")
	public void user_tap_on_title_card_from_v_book_carousel_to_navigate_title_detail_page() {
		search.clickVBookTitleCard();
	}

	@When("user click on the VBook title in the VBook carousel in tier {int} page")
	public void user_click_on_the_v_book_title_in_the_v_book_carousel_in_tier_page(Integer int1) {
		Assert.assertTrue(video.getTitleDetailPage().isDisplayed());
	}

	@Then("user should be able to navigate VBook title detail page")
	public void user_should_be_able_to_navigate_v_book_title_detail_page() {
		Logger.log("User navigated to vBook title detail page");
	}

	@Then("user should be able to view the details for the specific title")
	public void user_should_be_able_to_view_the_details_for_the_specific_title() {
		Logger.log("User able to view the details for the specific title");
	}

	@Given("library should have Video title without title image")
	public void library_should_have_video_title_without_title_image() {
		Logger.log("Library have Video title without title image");
	}

	@When("user tap on title card from video carousel to navigate title detail page")
	public void user_tap_on_title_card_from_video_carousel_to_navigate_title_detail_page() {
		search.clickVideoTitleCard();
	}

	@Then("user should be able to navigate video title detail page")
	public void user_should_be_able_to_navigate_video_title_detail_page() {
		Logger.log("Library have Video title without title image");
	}

	@When("user click on the video title in the video carousel in tier {int} page")
	public void user_click_on_the_video_title_in_the_video_carousel_in_tier_page(Integer int1) {
		search.clickVideoTitleTier3();
	}

	@Then("user should be able to view VBook titles in the carousel format")
	public void user_should_be_able_to_view_v_book_titles_in_the_carousel_format() {
		Assert.assertTrue(vbook.view_vbookCarouselFormat());
		Logger.log("User able to view the Vbook titles in the carousel format");
	}

	@Then("user should be able to view specific number of VBooks in the carousel based on drupal configuration")
	public void user_should_be_able_to_view_specific_number_of_v_books_in_the_carousel_based_on_drupal_configuration() {
		Logger.log("User should be able to view specific number of VBooks in the carousel");
	}

	@Then("user selects any VBook title")
	public void user_selects_any_v_book_title() {
		search.clickVBookTitleCard();
	}

	@Then("user should able to land on details page Tier {int} page")
	public void user_should_able_to_land_on_details_page_tier_page(Integer int1) {
		Assert.assertTrue(video.getTitleDetailPage().isDisplayed());
	}

	@When("select eBook,eAudio,Video,vBooks option in category and vBooks from refiners section and click search")
	public void select_e_book_e_audio_video_v_books_option_in_category_and_v_books_from_refiners_section_and_click_search() {
		search.click_vbooksInRefinerSection();
	}

	@Then("user should be able to view video titles in the carousel format")
	public void user_should_be_able_to_view_video_titles_in_the_carousel_format() {
		Assert.assertTrue(video.view_videoCarouselFormat());
	}

	@Then("user should be able to view specific number of Videos in the carousel based on drupal configuration")
	public void user_should_be_able_to_view_specific_number_of_videos_in_the_carousel_based_on_drupal_configuration() {
		Logger.log("user able to view specific number of Videos in the carousel based on drupal configuration");
	}

	@Then("user selects any video title")
	public void user_selects_any_video_title() {
		search.clickVideoTitleCard();
	}

	@Then("user should be able to view See all option for the Tier {int} page carousels")
	public void user_should_be_able_to_view_see_all_option_for_the_tier_page_carousels(Integer int1) {
		visibilityWait(video.getVideoTier1CarouselSeeAll());
		javascriptScroll(video.getVideoTier1CarouselSeeAll());
		Assert.assertTrue(video.getVideoTier1CarouselSeeAll().isDisplayed());
	}

	@Then("user should be able to navigate to the Tier {int} page after clicking on see all")
	public void user_should_be_able_to_navigate_to_the_tier_page_after_clicking_on_see_all(Integer int1) {
		video.click_SeeAllTier1Video();
	}

	@Then("user should be able to click on any Title card")
	public void user_should_be_able_to_click_on_any_title_card() {
//		search.clickVideoTitleCard();
		video.click_TitleCardTier2VBook();
	}

	@Then("user navigate to tier {int} title details page")
	public void user_navigate_to_tier_title_details_page(Integer int1) {
		Assert.assertTrue(video.getTitleDetailPage().isDisplayed());
	}

	@When("user click see all CTA of 3rd party carousel in library page")
	public void user_click_see_all_cta_of_3rd_party_carousel_in_library_page() {
		visibilityWait(video.getLib_videoCarousel_seeAllCTA());
		javascriptScroll(video.getLib_videoCarousel_seeAllCTA());
		video.clickVideoSeeAll();
	}

	@When("user click see all CTA of 3rd party carousel in library page for VBook")
	public void user_click_see_all_cta_of_3rd_party_carousel_in_library_page_for_v_book() {
		visibilityWait(vbook.getLib_vbookCarousel_seeAllCTA());
		javascriptScroll(vbook.getLib_vbookCarousel_seeAllCTA());
		vbook.click_vbookSeeAllCTA();
	}

	@When("user click see all CTA of Video carousel in tier {int} page")
	public void user_click_see_all_cta_of_video_carousel_in_tier_page(Integer int1) {
		video.click_SeeAllTier1Video();
	}

	@Given("user navigate to title detail page by click on suggested video title card")
	public void user_navigate_to_title_detail_page_by_click_on_suggested_video_title_card() {
		search.Search_suggestedCarousel();
	}

	@When("user navigate to title detail page by click on video title card")
	public void user_navigate_to_title_detail_page_by_click_on_video_title_card() {
		video.click_videoTitleCard();
	}

	@When("user navigate to title detail page by click on play CTA in video title card")
	public void user_navigate_to_title_detail_page_by_click_on_play_cta_in_video_title_card() {
		video.click_videoTitleCardPlayCTA();
	}

	@When("user clicks on title card in my stuff page")
	public void user_clicks_on_title_card_in_my_stuff_page() {
		myshelfpage.clickTitleCoverImage();
	}

	@When("user navigate to title detail page by click on resume cta in video title card")
	public void user_navigate_to_title_detail_page_by_click_on_resume_cta_in_video_title_card() {
		login.click_HamburgerMenu();
		myshelfpage.click_MyshelfCTA();
		myshelfpage.click_checkoutMyshelfpage();
//		video.click_ResumeCTALibpage();
	}

	@Then("user navigate to title detail page by click on title with play cta in video title card")
	public void user_navigate_to_title_detail_page_by_click_on_title_with_play_cta_in_video_title_card() {
//		javascriptScroll(video.titleDetailPage);
//		waitFor(2000);
		login.click_HamburgerMenu();
		myshelfpage.click_MyshelfCTA();
		myshelfpage.click_checkoutMyshelfpage();
	}

	@Then("user should be able to view the Video Title detail page with Title Heading, Title Image, Video Icon and Description")
	public void user_should_be_able_to_view_the_video_title_detail_page_with_title_heading_title_image_video_icon_and_description() {
		visibilityWait(video.getTitleHeadingTier3());
		Assert.assertTrue(video.getTitleHeadingTier3().isDisplayed());
		Assert.assertTrue(video.getTitleImageTier3().isDisplayed());
		Assert.assertTrue(video.getVideoIconTier3().isDisplayed());
		// Assert.assertTrue(video.getTitleDescriptionTier3().isDisplayed());
	}

	@Then("user should be able to view the primary CTA and secondary CTA")
	public void user_should_be_able_to_view_the_primary_cta_and_secondary_cta() {
		Assert.assertTrue(video.getPrimaryCTATier3().isDisplayed());
	}

	@Then("user should be able to view video title details based on metadata")
	public void user_should_be_able_to_view_video_title_details_based_on_metadata() {
		Assert.assertTrue(video.getTitleDetailSection().isDisplayed());
	}

	@Then("user should be able to view related\\/suggested title carousel based on the configuration in drupal")
	public void user_should_be_able_to_view_related_suggested_title_carousel_based_on_the_configuration_in_drupal() {
		Assert.assertTrue(video.getTitleDetailSection().isDisplayed());
	}

	@Then("user should be able to view expanded results for vBooks category in list view")
	public void user_should_be_able_to_view_expanded_results_for_v_books_category_in_list_view() {
		visibilityWait(search.getSearch_Result());
		// WaitForWebElement(search.getSearch_Result());
		String apiSearchResultCount = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getResultCount();
		System.out.println("Search Result count from the UI: " + search.getSearch_Result());
		System.out.println("Search Result count from the API: " + apiSearchResultCount);
		Assert.assertTrue(search.getSearch_Result().isDisplayed());
	}

	@Then("user should be able to view vBooks carousel on search landing page")
	public void user_should_be_able_to_view_v_books_carousel_on_search_landing_page() {
		visibilityWait(search.getSearch_Result());
//		apiResponse = APIClient.getThirdPartySearchTitleResponse();
		String apiSearchResultCount = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getResultCount();
		Assert.assertTrue(search.getSearch_Result().isDisplayed());
		System.out.println("Search Result count from the UI: " + search.getSearch_Result());
		System.out.println("Search Result count from the API: " + apiSearchResultCount);
	}
	
	@Then("the third party search API response result counts match the UI result")
	public void the_third_party_search_api_response_result_counts_match_the_ui_result() {
		apiResponse = APIClient.getThirdPartySearchTitleResponse("vbk", "8c573edd-60c4-ed11-a8e0-000d3a4e28de", "science", "keyword", "publicationDate", "teen,children","");
		assertNotNull("API response is null", apiResponse);
		System.out.println("result count displayed: "
				+ apiResponse.getSearchTitleResponseData().getSearchTitleResult().getResultCount());
	}


	@Then("user should be able to view other carousels along with vBooks carousel for other search criteria")
	public void user_should_be_able_to_view_other_carousels_along_with_v_books_carousel_for_other_search_criteria() {
		search.click_AllRefiner();
	}

	@Given("user is able click on advance search from my shelf page and enter any keyword {string} and select videos option in category")
	public void user_is_able_click_on_advance_search_from_my_shelf_page_and_enter_any_keyword_and_select_videos_option_in_category(
			String keyword) {
		search.AdvanceSesarch_EnterInput(keyword);
		search.click_videosInAdvancesearch();
		search.Click_Searchbtn();
	}

	@Given("user is able click on advance search from my shelf page and enter any keyword {string}")
	public void user_is_able_click_on_advance_search_from_my_shelf_page_and_enter_any_keyword(String keyword) {
		search.AdvanceSesarch_EnterInput(keyword);
		search.Click_Searchbtn();
	}

	@Then("user should be able to view videos category as seperate carousel for the search keyword")
	public void user_should_be_able_to_view_videos_category_as_seperate_carousel_for_the_search_keyword() {
		search.SearchKeyword_SearchREsults();
	}

	@Then("user should be able to view videos come from third party resources")
	public void user_should_be_able_to_view_videos_come_from_third_party_resources() {
		visibilityWait(search.videos_Resources);
		Assert.assertTrue(search.videos_Resources.isDisplayed());
	}

	@Then("user should be able to view title with videos icon on the jacket image")
	public void user_should_be_able_to_view_title_with_videos_icon_on_the_jacket_image() {
		Assert.assertTrue(search.view_jacketimgwithIcon());
	}

	@Then("user should be able to click on the videos title and navigate to videos detail page from videos list page")
	public void user_should_be_able_to_click_on_the_videos_title_and_navigate_to_videos_detail_page_from_videos_list_page() {
		search.ClickTitle_navDetailPage();
	}

	@Then("user should be able to view expanded results for videos category in list view")
	public void user_should_be_able_to_view_expanded_results_for_videos_category_in_list_view() {
		visibilityWait(search.expandedResultsView);
		Assert.assertTrue(search.expandedResultsView.isDisplayed());
		Logger.log("user is able to view expanded results for vbooks in list view");
	}

	@Then("user should be able to view expanded results for videos category in list view in Tire2")
	public void user_should_be_able_to_view_expanded_results_for_videos_category_in_list_view_in_tire2() {
		visibilityWait(search.video_SearchResult_Tier2_Listview);
		Assert.assertTrue(search.video_SearchResult_Tier2_Listview.isDisplayed());
		Logger.log("user is able to view expanded results for vbooks in list view");
	}

	@Then("user should be able to view videos cover image, title, dropdown menu and primary cta")
	public void user_should_be_able_to_view_videos_cover_image_title_dropdown_menu_and_primary_cta() {
		search.view_vbooksSearchResults();
	}

	@Then("user should be able to view videos carousel on search landing screen")
	public void user_should_be_able_to_view_videos_carousel_on_search_landing_screen() {
		Assert.assertTrue(search.getSearch_Result().isDisplayed());
	}

	@Then("user should be able to view other carousels along with videos carousel for other search criteria")
	public void user_should_be_able_to_view_other_carousels_along_with_videos_carousel_for_other_search_criteria() {
		search.click_AllRefiner();
	}

	@Then("user should be able to view {string} selected under the category by default")
	public void user_should_be_able_to_view_selected_under_the_category_by_default(String string) {
		visibilityWait(search.All_Refiners);
		Assert.assertTrue(search.All_Refiners.isDisplayed());
	}

	@Then("user should be able to view categories {string}")
	public void user_should_be_able_to_view_categories(String string) {
		search.view_CategoriesInRefiners();
	}

	@Then("user should be able to view Videos & VBooks carousel with see all cta in search results page")
	public void user_should_be_able_to_view_videos_v_books_carousel_with_see_all_cta_in_search_results_page() {
		visibilityWait(search.vbooks_SearchResult_SeeAll);
		Assert.assertTrue(search.vbooks_SearchResult_SeeAll.isDisplayed());
	}

	@Then("user should be able to click see all and view expanded results for the Videos & VBooks category")
	public void user_should_be_able_to_click_see_all_and_view_expanded_results_for_the_videos_v_books_category() {
		search.click_SeeAllCTA();
	}

	@When("user click see all CTA of 3rd party vbook carousel in library page")
	public void user_click_see_all_cta_of_3rd_party_vbook_carousel_in_library_page() {
		javascriptScroll(vbook.getLib_vbookCarousel_seeAllCTA());
		Assert.assertTrue(vbook.getLib_vbookCarousel_seeAllCTA().isDisplayed());
	}

	@When("user click see all CTA of vbook carousel in tier {int} page")
	public void user_click_see_all_cta_of_vbook_carousel_in_tier_page(Integer int1) {
		vbook.click_vbookSeeAllCTA();
	}

	@When("user navigate to title detail page by click on vbook title card")
	public void user_navigate_to_title_detail_page_by_click_on_vbook_title_card() {
		vbook.click_vbookTitleCard();
	}

	@Then("user should able to view checkout action CTA for available vbook title")
	public void user_should_able_to_view_checkout_action_cta_for_available_vbook_title() {
		if (isElementPresent(video.checkoutButton)) {
			System.out.println("primary cta is checkout");
		}else {
			System.out.println("primary cta is not checkout");
		}
		
	}

	@When("user should be able to view VBooks categories in the carousel format")
	public void user_should_be_able_to_view_v_books_categories_in_the_carousel_format() {
		vbook.formatFilter.isDisplayed();
	}

	@When("user clicks the Vbook title with Checkout Cta")
	public void user_clicks_the_vbook_title_with_checkout_cta() {
		vbook.click_checkoutCTALibpage();
//		login.click_HamburgerMenu();
//		myshelfpage.click_MyshelfCTA();
//		myshelfpage.click_checkoutMyshelfpage();
	}

	@When("user clicks the Checkout Cta in Tier3 page")
	public void user_clicks_the_checkout_cta_in_tier3_page() {
		vbook.clickCheckoutCTATier3();
	}

//	@When("user should view format dropdown with option VBooks & Video")
//	public void user_should_view_format_dropdown_with_option_v_books_video() {
//
//	}
//
//	@When("user select the video format from the dropdown")
//	public void user_select_the_video_format_from_the_dropdown() {
//
//	}

	@When("user click the check out CTA for VBooks")
	public void user_click_the_check_out_cta_for_v_books() {
		search.clickCheckoutVBookLibPage();
	}

	@Then("System should show toast message upon user clicking on the checked out title action CTA")
	public void system_should_show_toast_message_upon_user_clicking_on_the_checked_out_title_action_cta() {
		Assert.assertTrue(search.getSuccess_msg().isDisplayed());
	}

	@Then("user should be able to view success toast message {string}")
	public void user_should_be_able_to_view_success_toast_message(String string) {
		System.out.println(search.getSuccess_msg().getText());
		Assert.assertEquals(search.getSuccess_msg().getText().contains(string), true);
	}

	@When("user clicks the title card with Play Cta")
	public void user_clicks_the_title_card_with_play_cta() {
		video.click_vBookTitleCardPlayCTA();
	}

//	@When("user should view format dropdown with option VBooks & Video")
//	public void user_should_view_format_dropdown_with_option_v_books_video() {
//		Assert.assertTrue(video.renewCTA.isDisplayed());
//		Assert.assertTrue(video.returnCTA.isDisplayed());
//	}

//	@When("user select the video format from the dropdown")
//	public void user_select_the_video_format_from_the_dropdown() {
//
//	}

	@Then("System should show toast message upon user clicking on the return title action CTA")
	public void system_should_show_toast_message_upon_user_clicking_on_the_return_title_action_cta() {
		Assert.assertTrue(search.getSuccess_msg().isDisplayed());
	}

	@When("user return the VBooks title after finished the checkout from secondary action")
	public void user_return_the_v_books_title_after_finished_the_checkout_from_secondary_action() {
		search.clickReturnCTA();
	}

	@When("user sould be select renew the title from secondary action")
	public void user_sould_be_select_renew_the_title_from_secondary_action() {
		search.clickRenewCTA();
	}

	@Then("System should show toast message upon user clicking on the renewe title action CTA")
	public void system_should_show_toast_message_upon_user_clicking_on_the_renewe_title_action_cta() {
		Assert.assertTrue(search.getSuccess_msg().isDisplayed());
	}

	@Then("user should be able to view success toast message {string} and {string}")
	public void user_should_be_able_to_view_success_toast_message_and(String string, String string2) {
		Assert.assertEquals(search.getSuccess_msg().getText().contains(string), true);
		Assert.assertEquals(search.getSuccess_msg().getText().contains(string2), true);
	}

//	@Given("user checkout video title in adult profile")
//	public void user_checkout_video_title_in_adult_profile() {
//
//	}
//
//	@Given("user can view see all option from library to navigate tier {int} page")
//	public void user_can_view_see_all_option_from_library_to_navigate_tier_page(Integer int1) {
//
//	}
//
//	@When("user clicks on Checkout CTA for the same Video Titles")
//	public void user_clicks_on_checkout_cta_for_the_same_video_titles() {
//
//	}

	@When("user search the video title in teen profile and checkout")
	public void user_search_the_video_title_in_teen_profile_and_checkout() {
		search.searchTitleInTeen();
		search.checkoutSearchResult();
	}

	@Then("user should be able to view the pop-up for informing user that Video Titles has already been checked out by other mapped profile")
	public void user_should_be_able_to_view_the_pop_up_for_informing_user_that_video_titles_has_already_been_checked_out_by_other_mapped_profile() {
		WaitForWebElement(search.getPopUpCheckout());
		Assert.assertTrue(search.getPopUpCheckout().isDisplayed());
	}

	@Then("user should be able to view popup {string} with message and OK CTA")
	public void user_should_be_able_to_view_popup_with_message_and_ok_cta(String string) {
		Assert.assertTrue(search.getPopUpCheckoutokBtn().isDisplayed());
		Assert.assertEquals(search.getPopUpCheckout().getText().contains(string), true);
	}

	@Then("user click on OK CTA to dismiss the pop-up and remain on the same page")
	public void user_click_on_ok_cta_to_dismiss_the_pop_up_and_remain_on_the_same_page() {
		search.clickPopUpOk();
	}

	@When("user tap see all CTA of 3rd party carousel in library page")
	public void user_tap_see_all_cta_of_3rd_party_carousel_in_library_page() {

	}

	@When("user click see all option from library to navigate tier {int} page")
	public void user_click_see_all_option_from_library_to_navigate_tier_page(Integer int1) {

	}

	@When("user click see all option from tier {int} page to navigate tier {int} page")
	public void user_click_see_all_option_from_tier_page_to_navigate_tier_page(Integer int1, Integer int2) {

	}

	@When("user navigate to title details page from list page categories")
	public void user_navigate_to_title_details_page_from_list_page_categories() {
		Assert.assertTrue(video.getTitleDetailPage().isDisplayed());
	}

	@Then("user should able to view checkout action CTA for available VBooks title")
	public void user_should_able_to_view_checkout_action_cta_for_available_v_books_title() {
		Assert.assertTrue(video.getPrimaryCTA().isDisplayed());
	}

	@Then("user should be able to click on {string} CTA to checkout the title")
	public void user_should_be_able_to_click_on_cta_to_checkout_the_title(String string) {
		Assert.assertTrue(video.getPrimaryCTA().isDisplayed());
	}

	@Then("user should not able to view secondary cta")
	public void user_should_not_able_to_view_secondary_cta() {
		Assert.assertFalse(isElementPresent(video.returnCTA));
		Assert.assertFalse(isElementPresent(video.renewCTA));
	}

	@Then("user should be able to view the secondary action CTA for that VBooks Title")
	public void user_should_be_able_to_view_the_secondary_action_cta_for_that_v_books_title() {
		Assert.assertTrue(video.returnCTA.isDisplayed());
		Assert.assertTrue(video.renewCTA.isDisplayed());
	}

	@Then("user should be able to view the font,colour text and alignment look and feel same as mocks")
	public void user_should_be_able_to_view_the_font_colour_text_and_alignment_look_and_feel_same_as_mocks() {
		Logger.log("UI Validation");
	}

	@When("user checkout the available title")
	public void user_checkout_the_available_title() {
		vbook.click_checkoutInTier2page();
	}

	@When("user not started watching the checkout VBooks title")
	public void user_not_started_watching_the_checkout_v_books_title() {
		video.checkoutTitleTier3();
	}

	@Then("user should able to view play action CTA for that VBooks title")
	public void user_should_able_to_view_play_action_cta_for_that_v_books_title() {
		WaitForWebElement(video.playButton);
		javascriptScroll(video.playButton);
		Assert.assertTrue(video.playButton.isDisplayed());
	}

	@Then("user should be able to click on {string} the video")
	public void user_should_be_able_to_click_on_the_video(String string) {
		video.click_PlayCTA();
	}

	@Then("user should able to view resume action CTA for that VBooks title")
	public void user_should_able_to_view_resume_action_cta_for_that_v_books_title() {
		Assert.assertTrue(video.getLib_videoCarousel_ResumeCTA().isDisplayed());
	}

	@Then("user should be able to click on {string} and resume the video")
	public void user_should_be_able_to_click_on_and_resume_the_video(String string) {
		video.click_ResumeCTA();
	}

	@When("user click see all CTA of VBook carousel in tier {int} page")
	public void user_click_see_all_cta_of_v_book_carousel_in_tier_page(Integer int1) {
		vbook.click_SeeAllTier1VBook();
	}

	@When("user navigate to title detail page by click on VBook title card")
	public void user_navigate_to_title_detail_page_by_click_on_v_book_title_card() {
		vbook.click_vbookSeeAllCTA();
		video.click_TitleCardTier1Video();
	}

	@When("user click on see all CTA in VBook carousel")
	public void user_click_on_see_all_cta_in_v_book_carousel() {
		video.clickVBookSeeAll();
	}

	@When("user navigate to title detail page by click on play CTA in vbook title card")
	public void user_navigate_to_title_detail_page_by_click_on_play_cta_in_vbook_title_card() {
		vbook.click_vbookTitleCard();
	}

	@When("user not started watching the checkout vbook title")
	public void user_not_started_watching_the_checkout_vbook_title() {
		Logger.log("user not started watching the checkout vbook title");
	}

	@Then("user should able to view play action CTA for that vbook title")
	public void user_should_able_to_view_play_action_cta_for_that_vbook_title() {
		search. verify_PlayCTA();
	}
	@When("user click on see all CTA in VBook carousel in Tier {int}")
	public void user_click_on_see_all_cta_in_v_book_carousel_in_tier(Integer int1) {
		vbook.click_SeeAllTier1VBook();
	}

	@Then("user should be able to navigate to VBook title list page")
	public void user_should_be_able_to_navigate_to_v_book_title_list_page() {
		Assert.assertTrue(vbook.getTier2PageVBook().isDisplayed());
	}

	@Then("user should be able to view the list of VBook titles based on the configuraion in drupal")
	public void user_should_be_able_to_view_the_list_of_v_book_titles_based_on_the_configuraion_in_drupal() {
		Logger.log("user able to view the list of VBook titles based on the configuraion in drupal");
	}

	@Given("user should be able to view video categories in the carousel format")
	public void user_should_be_able_to_view_video_categories_in_the_carousel_format() {
		Assert.assertTrue(video.view_videoCarouselFormat());
	}

	@When("user clicks the check out CTA for video")
	public void user_clicks_the_check_out_cta_for_video() {
		search.clickCheckoutVideoLibPage();
	}

	@Then("user should be able to view default VBook title image if the title image is not available")
	public void user_should_be_able_to_view_default_v_book_title_image_if_the_title_image_is_not_available() {
		Logger.log("User able to view default VBook title image if the title image is not available");
	}

	@When("user is able tap on checkout cta from mystuff screen and navigate to checkedout screen")
	public void user_is_able_tap_on_checkout_cta_from_mystuff_screen_and_navigate_to_checkedout_screen() {
		login.click_HamburgerMenu();
		myshelfpage.click_MyshelfCTA();
		myshelfpage.click_checkoutMyshelfpage();
	}

	@Then("user should be able to view the action cta for the video and vbooks titles")
	public void user_should_be_able_to_view_the_action_cta_for_the_video_and_vbooks_titles() {
		visibilityWait(myshelfpage.primaryCTAMyStuffPage);
		Assert.assertTrue(myshelfpage.primaryCTAMyStuffPage.isDisplayed());
	}

	@Then("system should display cta based on the title status")
	public void system_should_display_cta_based_on_the_title_status() {
		Assert.assertTrue(myshelfpage.primaryCTAMyStuff.isDisplayed());
	}

	@Then("user should be able to see the title checked out and not started watching the title")
	public void user_should_be_able_to_see_the_title_checked_out_and_not_started_watching_the_title() {
		Assert.assertTrue(myshelfpage.playas_primaryCTA.isDisplayed());
	}

	@Then("user should be able to see play as primary cta and return and renew are the secondary cta")
	public void user_should_be_able_to_see_play_as_primary_cta_and_return_and_renew_are_the_secondary_cta() {
		Assert.assertTrue(myshelfpage.playas_primaryCTA.isDisplayed());
	}

	@Then("user should be able to see the title checked out and started watching and exit without complete")
	public void user_should_be_able_to_see_the_title_checked_out_and_started_watching_and_exit_without_complete() {
		myshelfpage.click_playSecondaryCTADropdown();
		Assert.assertTrue(myshelfpage.playSecondaryCTA_Return.isDisplayed());
		Assert.assertTrue(myshelfpage.playSecondaryCTA_Renew.isDisplayed());
	}

	@Then("user should be able to see resume as primary cta and return and renew are the secondary cta")
	public void user_should_be_able_to_see_resume_as_primary_cta_and_return_and_renew_are_the_secondary_cta() {
		Assert.assertTrue(myshelfpage.resumeAs_primaryCTA.isDisplayed());
//		myshelfpage.click_playSecondaryCTADropdown();
//		Assert.assertTrue(myshelfpage.ResumeSecondaryCTA_Renew.isDisplayed());
//		Assert.assertTrue(myshelfpage.ResumeSecondaryCTA_Return.isDisplayed());
	}

	@Then("user navigate to tier {int} page")
	public void user_navigate_to_tier_page(Integer int1) {
		Assert.assertTrue(vbook.getTier2Page().isDisplayed());
	}

	@Then("user should able to view checkout action CTA for available Video title")
	public void user_should_able_to_view_checkout_action_cta_for_available_video_title() {
		visibilityWait(video.Lib_videoCarousel_videotitleCoverimg);
		jsClick(video.Lib_videoCarousel_videotitleCoverimg);
		visibilityWait(vbook.getLib_vbookCarousel_Nav_Tier3Detailspage());
//		javascriptScroll(video.lib_videoTitle);
//		jsClick(video.lib_videoTitle);
		if (isElementPresent(video.checkoutButton)) {
			Assert.assertTrue(video.checkoutButton.isDisplayed());
		}else {
			Logger.log("User should be shown another primary CTA");
		}

	}

	@When("user not started watching the checkout Video title")
	public void user_not_started_watching_the_checkout_video_title() {
		Logger.log("User not started watching the title");
	}

	@Then("user should able to view play action CTA for that Video title")
	public void user_should_able_to_view_play_action_cta_for_that_video_title() {
		visibilityWait(video.Tier2_title);
		jsClick(video.Tier2_title);
		waitFor(2000);
		if (isElementPresent(MyshelfvideosVbooks.playas_primaryCTA)) {
			Logger.log("Primary cta has Play");
		}else {
			Logger.log("Primary cta has checkout or resume");
		}
		
	}

	// 182553

	@Then("user should able to view checkout action CTA for available VBook title")
	public void user_should_able_to_view_checkout_action_cta_for_available_v_book_title() {
		visibilityWait(video.Tier2_title);
		jsClick(video.Tier2_title);
		if (video.checkoutButton.isDisplayed()) {
			Assert.assertTrue(video.checkoutButton.isDisplayed());
		}else {
			Logger.log("User should be shown another primary CTA");
		}
	}

	@When("user not started watching the checkout VBook title")
	public void user_not_started_watching_the_checkout_v_book_title() {
		Logger.log("User not started watching the title");
	}

	@Then("user should able to view play action CTA for that VBook title")
	public void user_should_able_to_view_play_action_cta_for_that_v_book_title() {
		visibilityWait(video.Tier2_title);
		jsClick(video.Tier2_title);
		if (MyshelfvideosVbooks.playas_primaryCTA.isDisplayed()) {
			Assert.assertTrue(MyshelfvideosVbooks.playas_primaryCTA.isDisplayed());
		}else {
			Logger.log("Primary cta has checkout or resume");
		}
	}

	@When("user started watching and exit from checkout VBook title")
	public void user_started_watching_and_exit_from_checkout_v_book_title() {
		Logger.log("user started watching and exit from checkout VBook title");
	}

	@When("user navigate to title detail page by click on VBook title card in Tier2 Page")
	public void user_navigate_to_title_detail_page_by_click_on_v_book_title_card_in_tier2_page() {
		vbook.click_vbookTitleCardTier2();
	}

	@Given("user navigate to title detail page by click on VBook title card for {string}")
	public void user_navigate_to_title_detail_page_by_click_on_v_book_title_card_for(String string) {
//		video.click_TitleCardTier2VBook();

	}

	@Then("user should be able to click on any Title card in Tier {int} Page")
	public void user_should_be_able_to_click_on_any_title_card_in_tier_page(Integer int1) {
		video.click_TitleCardTier2VBook();
	}
	
	
	/***********************************************************Rel1.3.2****************************************************************/
	
	
	//209570
	
	@When("user selects any refine option in the refine section")
	public void user_selects_any_refine_option_in_the_refine_section() {
	    migration.selectRefiners();
	}

	@When("user clicks on the search CTA")
	public void user_clicks_on_the_search_cta() {
		search.Click_Searchbtn();
	}

	@Then("user should be able to view refiner pills for the selected refiners")
	public void user_should_be_able_to_view_refiner_pills_for_the_selected_refiners() {
	    Assert.assertTrue(migration.refinerPills.isDisplayed());
	}

	@Then("user should be able to view clear all pill to remove all the filters")
	public void user_should_be_able_to_view_clear_all_pill_to_remove_all_the_filters() {
	    Assert.assertTrue(migration.clearAllPill.isDisplayed());
	}

	@Then("user should not view default pill")
	public void user_should_not_view_default_pill() {
	    Logger.log("no default pill is displayed");
	}
	
	@Given("user select newspaper option from advance search")
	public void user_select_newspaper_option_from_advance_search() {
	    search.click_NewspaperOptionInAdvanceSearch();
	    search.Click_Searchbtn();
	}

	@Then("user should navigate to the tier {int} page")
	public void user_should_navigate_to_the_tier_page(Integer int1) {
	    Assert.assertTrue(migration.tier2Publications.isDisplayed());
	}
	
	@Given("user select video book option from advance search")
	public void user_select_video_book_option_from_advance_search() {
	    ClickOnWebElement(search.AdvanceSearch_VBooks);
	}

	@When("user click on the {string} CTA in vBook carousel")
	public void user_click_on_the_cta_in_v_book_carousel(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Given("user select videos option from advance search")
	public void user_select_videos_option_from_advance_search() {
	    ClickOnWebElement(search.AdvanceSearch_VideoOption);
	}
	


	@Then("user able to view search count values matching with the titles displayed")
	public void user_able_to_view_search_count_values_matching_with_the_titles_displayed() {
		search.lazyLoadValidation();
	}
	

	@Then("user able to click on See All CTA in search landing page")
	public void user_able_to_click_on_see_all_cta_in_search_landing_page() {
		search.click_SeeAllCTA();
	}

	@Then("user able to click on See All CTA for Videos in search landing page")
	public void user_able_to_click_on_see_all_cta_for_videos_in_search_landing_page() {
		search.click_VideoSeeAllCTA();

	}
	
	@When("user is able to navigate search result landing page after click on search for all results")
	public void user_is_able_to_navigate_search_result_landing_page_after_click_on_search_for_all_results() {

		WaitForWebElement(search.search_ResultAll);
		Assert.assertTrue(search.search_ResultAll.isDisplayed());
	}
	

	
/********************************************************VisualUI*******************************************************************************/
	
	
	@Then("capture the screenshot of videos and vbooks third party option in advance search")
	public void capture_the_screenshot_of_videos_and_vbooks_third_party_option_in_advance_search() {
	    eyes.checkWindow("VideosAndVBooksInAdvanceSearch");
	}

	@Then("capture the screenshot of search result landing page")
	public void capture_the_screenshot_of_search_result_landing_page() {
	    eyes.checkWindow("SearchLandingPage");
	}
	
	@Then("capture the screenshot of title detail page with play cta")
	public void capture_the_screenshot_of_title_detail_page_with_play_cta() {
	    eyes.checkWindow("TitleDetailPageWithPlayCta");
	}

	@Then("capture the screenshot of players full sreen with options")
	public void capture_the_screenshot_of_players_full_sreen_with_options() {
	    eyes.checkWindow("PlayersWithFullScreenOptions");
	}

	@Then("capture the screenshot of title detail page")
	public void capture_the_screenshot_of_title_detail_page() {
	    eyes.checkWindow("TitleDetailPage");
		WaitForWebElement(search.search_withoutSelectionFormat);
		Assert.assertTrue(search.search_withoutSelectionFormat.isDisplayed());
	}
	
	@Then("user able to click on See All CTA for vBooks in search landing page")
	public void user_able_to_click_on_see_all_cta_for_v_books_in_search_landing_page() {
		search.click_VBookSeeAllCTA();
	}
	
	@Then("user clicks the Age range in refiners and verify the related results loaded")
	public void user_clicks_the_age_range_in_refiners_and_verify_the_related_results_loaded() {
		search.ageRangeValidation();
	}
	
	@When("user clicks on play CTA in Title")
	public void user_clicks_on_play_cta_in_title() {
		myshelfpage.clickPlayOrResume();
	}

	@When("user switch to player tab and inspects the video")
	public void user_switch_to_player_tab_and_inspects_the_video() {
		myshelfpage.switchPlayer();
	}

	@Then("user click on full screen icon and screen should get expanded")
	public void user_click_on_full_screen_icon_and_screen_should_get_expanded() {
		myshelfpage.fullScreen();
	}

	@Then("user click on exit full screen icon and screen should get minimised")
	public void user_click_on_exit_full_screen_icon_and_screen_should_get_minimised() {
		myshelfpage.exitFullScreen();
	}

	@Then("user click forward button and video should get forwarded")
	public void user_click_forward_button_and_video_should_get_forwarded() {
		myshelfpage.playerFwd();
	}

	@Then("user click backward button and video should get backwarded")
	public void user_click_backward_button_and_video_should_get_backwarded() {
		myshelfpage.playerRev();
	}

	@Then("user should able to mute and unmute the video")
	public void user_should_able_to_mute_and_unmute_the_video() {
		myshelfpage.muteAndUnmute();
	}

	@Then("user should able to view the seek bar and volume control bar")
	public void user_should_able_to_view_the_seek_bar_and_volume_control_bar() {
		Assert.assertTrue(myshelfpage.seekBar.isDisplayed());
		Assert.assertTrue(myshelfpage.volumeBar.isDisplayed());
	}
	
	@Then("user should able to close the video tab and navigate back to Title Details page")
	public void user_should_able_to_close_the_video_tab_and_navigate_back_to_title_details_page() {
		myshelfpage.exitPlayer();
		WaitForWebElement(myshelfpage.titleDetailPage);
		Assert.assertTrue(myshelfpage.titleDetailPage.isDisplayed());

	}
	
	@When("user navigates to myshelf page and get the title name")
	public void user_navigates_to_myshelf_page_and_get_the_title_name() {
		login.click_HamburgerMenu();
		myshelfpage.click_MyshelfCTA();
		myshelfpage.click_checkoutMyshelfpage();
		myshelfpage.clickTitleCoverImage();
		
	}
	
	@When("user searches the checkout title")
	public void user_searches_the_checkout_title(){
		myshelfpage.search_checkoutTitle();
	}
	
	@Given("user select the category {string} checkbox")
	public void user_select_the_category_checkbox(String type) {
		search.select_AdvanceSearchType(type);
	}

	
	
}