package parallel;

import java.util.List;

import java.util.Map;

import com.driverfactory.DriverManager;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pom.kidszone.Login;
import pom.kidszone.Loginpageview;
import pom.kidszone.Profilecreation;

public class Loginwithidandpin_Stepdef {

	static ExcelReader reader = new ExcelReader();
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());
	@Given("user launch the 'Magic Independent library' url")
	public void user_launch_the_magic_independent_library_url() throws Throwable {
		login.Login_PrefixWithPin();
		profile.readInAppClose();
	}

	@Given("User launch the kids NYC {string} url")
	public void user_launch_the_kids_NYC_url(String url) throws Throwable {
		
		login.Login_PrefixWithoutPin();
		profile.readInAppClose();
	}
	
	@Given("User launch the manual kids NYC {string} url")
	public void user_launch_the_manual_kids_nyc_url(String string) throws Exception {
		
		login.login_manualnyc();
		profile.readInAppClose();
	}

	@Given("user launch the kids Texas {string} url")
	public void user_launch_the_kids_Texas_url(String url) throws Throwable {
		login.Login_texas();
	}

	@Given("User launch the axis charlotte {string} url")
	public void user_launch_the_axis_charlotte_url(String url) throws Throwable {
		
		login.Login_AxisOnly();
	}

//
//    @When("user click on login button")
//    public void user_click_on_login_button() throws Throwable {
//    	loginpageUpdatedui.click_loginPage();
//       
//    }

	@Then("user should see updated login screen")
	public void user_should_see_updated_login_screen() throws Throwable {
		loginpageUpdatedui.loginwithpinview();
		// loginpageUpdatedui.updated_login();
	}

	@And("verify font color should be display as per mocks")
	public void verify_font_color_should_be_display_as_per_mocks() throws Throwable {
		Logger.log("UI Verified Manually");
	}

	@And("verify alignment should be display as per mocks")
	public void verify_alignment_should_be_display_as_per_mocks() throws Throwable {
		Logger.log("UI Verified Manually");
	}

	/////////////////////// 110487//////////////////////////
	@And("user click on forgot pin cta")
	public void user_click_on_forgot_pin_cta() throws Throwable {
		loginpageUpdatedui.loginwithpin_clickForgotPin();
	}

	@And("user should see updated pin recovery screen")
	public void user_should_see_updated_pin_recovery_screen() throws Throwable {
		loginpageUpdatedui.verifyFogotpin();
	}

	@Then("user should see updated pin recovery screen oldUI")
	public void user_should_see_updated_pin_recovery_screen_old_ui() {
		loginpageUpdatedui.verifyFogotpinOldUI();
	}

	//////////////////////// 110488//////////////////////////

	@And("user enter correct library id and click submit cta")
	public void user_enter_correct_library_id_and_click_submit_cta() throws Throwable {
		loginpageUpdatedui.submitFogotpin();
	}

	@And("user should see updated security question screen")
	public void user_should_see_updated_security_question_screen() throws Throwable {
		// loginpageUpdatedui.securityQuestion();
	}

	////////////////// 110490/////////////////////////////////
	@Given("user launch the 'KidsZone New York Library' url")
	public void user_launch_the_kidszone_new_york_library_url() throws Throwable {
		login.Login_PrefixWithoutPin();
	}

	@Then("user able to see updated login screen")
	public void user_able_to_see_updated_login_screen() throws Throwable {
		loginpageUpdatedui.onlywithLibraryid();
	}

	//////////////// 110491/////////////////////////////////////
	@Given("user launch the 'KidsZone Texas Library' url")
	public void user_launch_the_kidszone_texas_library_url() throws Throwable {
		login.Login_texas();
	}

	////////////////// 110492/////////////////////////////////
	@And("user click on forgot password cta")
	public void user_click_on_forgot_password_cta() throws Throwable {
		loginpageUpdatedui.loginwithpin_clickForgotPin();
	}

	@And("user should see updated password recovery screen")
	public void user_should_see_updated_password_recovery_screen() throws Throwable {
		loginpageUpdatedui.verifyFogotpassword();
	}

	@And("user enters the {string} and click submit cta")
	public void user_enters_the_something_and_click_submit_cta(String username) throws Throwable {
		loginpageUpdatedui.submitFogotpassword(username);
	}
//    /////////////////110493-110494/////////////////////////////
//    @Then("user enters the {string} and {string}")
//    public void user_enters_the_something_and_something(String libraryid, String pin) throws Throwable {
    	//loginpageUpdatedui.loginwithPinRegistration(libraryid,pin);
//    }

	@Then("user enters the {string}")
	public void user_enters_the_something(String libraryid) throws Throwable {
		loginpageUpdatedui.loginwithoutPinRegistration(libraryid);
		profile.preferenceScreen_popup();
		profile.readInAppClose();
	}

	@Then("user enters the new {string}")
	public void user_enters_the__new_something(String libraryid) throws Throwable {
		loginpageUpdatedui.loginwithoutPinRegistrationNew(libraryid);
	}

//    @And("user clicks on login cta and navigate to registration screen")
//    public void user_clicks_on_login_cta_and_navigate_to_registration_screen() throws Throwable {
//        
//    }

	@And("user should see updated registration screen with pin")
	public void user_should_see_updated_registration_screen_with_pin() throws Throwable {
		loginpageUpdatedui.verifyRegisterScreenwithPin();
	}

	@And("user should see updated registration screen")
	public void user_should_see_updated_registration_screen() throws Throwable {
		loginpageUpdatedui.verifyRegisterScreenwithoutPin();
	}

}
