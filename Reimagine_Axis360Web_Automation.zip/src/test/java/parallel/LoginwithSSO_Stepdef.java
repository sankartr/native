package parallel;

import java.io.IOException;

import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.Loginpageview;

public class LoginwithSSO_Stepdef extends CommonAction {

	static ExcelReader reader = new ExcelReader();
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());

	@Given("user launch the appliaction clever sso")
	public void user_launch_the_appliaction_clever_sso() throws Exception {
		login.Login_cleverSSO();
	}

	@Given("user launch the appliaction follett url")
	public void user_launch_the_appliaction_follett_url() {
		Logger.log("user launch the appliaction follett url");
	}

	@Given("user launch the appliaction authentication url")
	public void user_launch_the_appliaction_authentication_url() throws Exception {
		login.Login_ssoUrl();
	}

	@Then("system redirects to the openathens sso login page")
	public void system_redirects_to_the_openathens_sso_login_page() {
		WaitForWebElement(loginpageUpdatedui.getOpenauthenSSO_txt_login());
		Assert.assertTrue(loginpageUpdatedui.getOpenauthenSSO_txt_login().isDisplayed());
		Logger.log("user is inopenathens sso login page");
	}

	@Then("system redirects to the clever sso login page")
	public void system_redirects_to_the_clever_sso_login_page() {
		WaitForWebElement(loginpageUpdatedui.getCleversso_txt_loginInformation());
		Assert.assertTrue(loginpageUpdatedui.getCleversso_txt_loginInformation().isDisplayed());
		Logger.log("user is in clever sso login page");
	}

	@Then("system redirects to the follett sso login page")
	public void system_redirects_to_the_follett_sso_login_page() {
		Logger.log("System redirects to the follett sso login page");
	}

	@Then("clever sso user should enter {string} and {string}")
	public void clever_sso_user_should_enter_and(String username, String password) {
		loginpageUpdatedui.Enter_loginWithPin_cleverSSO(username, password);
	}

	@Then("openathens sso user should enter {string} and {string}")
	public void openathens_sso_user_should_enter_and(String username, String password) {
		loginpageUpdatedui.Enter_login_openAuthens(username, password);
	}

	@Then("follett sso user should enter {string} and {string}")
	public void follett_sso_user_should_enter_and(String string, String string2) {
		Logger.log("user entered login page");
	}

	@Then("system redirects to the homescreen of the application")
	public void system_redirects_to_the_homescreen_of_the_application() {
		Logger.log("user entered homescreen");
	}

}