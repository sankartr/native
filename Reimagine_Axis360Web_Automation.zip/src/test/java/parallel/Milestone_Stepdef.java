package parallel;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import api.APIClient;
import api.searchTitlev8.SearchTitleResponse;
import api.searchTitlev8.Title;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.Milestone;
import pom.kidszone.Milestone_edit;
import pom.kidszone.SearchResults_Vbooks;

public class Milestone_Stepdef extends CommonAction {
	static ExcelReader reader = new ExcelReader();
	Login login = new Login(DriverManager.getDriver());
	Milestone milestone = new Milestone(DriverManager.getDriver());
	Milestone_edit milestone_edit = new Milestone_edit(DriverManager.getDriver());
	SearchResults_Vbooks search = new SearchResults_Vbooks(DriverManager.getDriver());
	private List<SearchTitleResponse> apiResponses;

	/*******************************************************/

	@Given("user clicks on programs option from menu list")
	public void user_clicks_on_programs_option_from_menu_list() {
		login.click_HamburgerMenu();
		milestone.Click_programsInmenu();
	}

	@When("user clicks open programs tab")
	public void user_clicks_open_programs_tab() {
		milestone.click_openProgramTab();
	}

	@Then("user should be able to view a milestone program tile in ongoing program section based on the start date of program")
	public void user_should_be_able_to_view_a_milestone_program_tile_in_ongoing_program_section_based_on_the_start_date_of_program() {
		milestone.view_ongoingProgTitle();
		milestone.Click_OngoingProgTitle();
	}

	@Then("user should be able to view a milestone program tile in upcoming program section based on the start date of program")
	public void user_should_be_able_to_view_a_milestone_program_tile_in_upcoming_program_section_based_on_the_start_date_of_program() {
		milestone.view_upcomingProgTitle();
		milestone.click_upcomingProgTitle();
	}

	@Then("user should be able to join the program using {string} cta in program details screen")
	public void user_should_be_able_to_join_the_program_using_cta_in_program_details_screen(String string) {
		milestone.click_joinProgramCTA();

	}

	@Then("user should be able to view the milestone based programs in {string} section under {string} tab")
	public void user_should_be_able_to_view_the_milestone_based_programs_in_section_under_tab(String string,
			String string2) {
		milestone.click_programDetails_Breadcrumb();
		// milestone.click_MyprogramTab();
		Assert.assertEquals(milestone.ongoingprograms.isDisplayed(), true);
		// Assert.assertTrue(milestone.verify_myprogramUnder_Activeprogram());

	}

	@Then("user should be able to view the milestone based programs upcoming program in {string} section under {string} tab")
	public void user_should_be_able_to_view_the_milestone_based_programs_upcoming_program_in_section_under_tab(
			String string, String string2) {
		milestone.click_programDetails_Breadcrumb();
		Assert.assertEquals(milestone.upcomingprograms.isDisplayed(), true);
	}

	@Then("user should be able to view the milestone program details as a tile under active program section")
	public void user_should_be_able_to_view_the_milestone_program_details_as_a_tile_under_active_program_section() {
		visibilityWait(milestone.Activeprograms_Details);
		Assert.assertTrue(milestone.Activeprograms_Details.isDisplayed());
	}

	@Then("user should be able to view the program status say {string} or {string} or {string} based on the patron's program status")
	public void user_should_be_able_to_view_the_program_status_say_or_based_on_the_patron_s_program_status(
			String started, String completed, String Status) {
		milestone.verify_programStatus(Status);
	}

	@Then("user should be able to view a milestone program details such as {string} and {string} and {string}")
	public void user_should_be_able_to_view_a_milestone_program_details_such_as_and_and(String string, String string2,
			String string3) {
		milestone.activeProgram_Details();
	}

	@Then("user should be able to view a milestone program {string} in program card if the admin created the program with end date")
	public void user_should_be_able_to_view_a_milestone_program_in_program_card_if_the_admin_created_the_program_with_end_date(
			String string) {
		Assert.assertEquals(milestone.getActiveprograms_EndDate().isDisplayed(), true);
	}

	@Then("user should be able to view {string} if the user added outside the library's collection")
	public void user_should_be_able_to_view_if_the_user_added_outside_the_library_s_collection(String string) {
		Assert.assertEquals(milestone.Activeprogram_Titleimg.isDisplayed(), true);
	}

	@Then("user able to navigate to the program detail screen by clicking program tile")
	public void user_able_to_navigate_to_the_program_detail_screen_by_clicking_program_tile() {
		milestone.click_Activeprogram_NavTitleDatails();
	}

	@Then("user clicks on the leave programs")
	public void user_clicks_on_the_leave_programs() {
		milestone.click_Leaveprogram();
	}

	@Given("user navigates to the my programs tab")
	public void user_navigates_to_the_my_programs_tab() {
		milestone.click_MyprogramTab();
	}

	@When("user clicks on program that has {string} status under active program section")
	public void user_clicks_on_program_that_has_status_under_active_program_section(String status) {
		milestone.verify_programStatus(status);
		milestone.click_Activeprogram_NavTitleDatails();
	}

	@Then("user should be able to navigate to the program details screen")
	public void user_should_be_able_to_navigate_to_the_program_details_screen() {
		visibilityWait(milestone.Nav_TitleDetails);
		Assert.assertEquals(milestone.Nav_TitleDetails.isDisplayed(), true);
	}

	@When("user clicks on program that has {string} status under closed program section")
	public void user_clicks_on_program_that_has_status_under_closed_program_section(String status) {
		milestone.verify_closedProgramStatus(status);
		milestone.click_ClosedProgram();
	}

	@When("user clicks on milestone based program under open programs section")
	public void user_clicks_on_milestone_based_program_under_open_programs_section() {
		milestone.click_MilestoneongoingProgram();
	}

	@When("user clicks on milestone based upcoming program under open programs section")
	public void user_clicks_on_milestone_based_upcoming_program_under_open_programs_section() {
		milestone.click_MilestoneUpcoingProgram();
	}

	@Then("user able to join the milestone based program by clicking {string} cta")
	public void user_able_to_join_the_milestone_based_program_by_clicking_cta(String string) {
		milestone.click_joinProgramCTA();
	}

	@Then("user should be able to view a milestone program details such as {string} and {string} and {string} and {string} and {string} and {string}")
	public void user_should_be_able_to_view_a_milestone_program_details_such_as_and_and_and_and_and(String string,
			String string2, String string3, String string4, String string5, String string6) {
		milestone.programDetails_TitleDetails();
	}

	@Then("user should be able to view a {string} after joined that program")
	public void user_should_be_able_to_view_a_after_joined_that_program(String string) {
		javascriptScroll(milestone.progDetails_JoinDate);
		Assert.assertTrue(milestone.progDetails_JoinDate.isDisplayed());
	}

	@Then("user should be able to view book in the reading list if they click on ADD from the suggested list")
	public void user_should_be_able_to_view_book_in_the_reading_list_if_they_click_on_add_from_the_suggested_list() {
		visibilityWait(milestone.progDetails_SuggestedList);
		Assert.assertEquals(milestone.progDetails_SuggestedList.isDisplayed(), true);
	}

	@Then("user should be able to view the {string} CTA indicating the user has successfully joined the program")
	public void user_should_be_able_to_view_the_cta_indicating_the_user_has_successfully_joined_the_program(
			String leaveprogram) {
		javascriptScroll(milestone.progDetails_LeaveProgram);
		Assert.assertEquals(milestone.progDetails_LeaveProgram.getText(), leaveprogram);
	}

	@Then("user should be able to view the milestone program be a part of {string} section under my programs tab once they join the program")
	public void user_should_be_able_to_view_the_milestone_program_be_a_part_of_section_under_my_programs_tab_once_they_join_the_program(
			String joinedprogram) {
		milestone.click_programDetails_Breadcrumb();
		// milestone.click_MyprogramTab();
		milestone.verify_joinedprogram(joinedprogram);
		milestone.click_MilestoneongoingProgram();
		milestone.click_Leaveprogram();

	}

	@Then("user should be able to view the milestone upcoming program be a part of {string} section under my programs tab once they join the program")
	public void user_should_be_able_to_view_the_milestone_upcoming_program_be_a_part_of_section_under_my_programs_tab_once_they_join_the_program(
			String joinedprogram) {
		milestone.click_programDetails_Breadcrumb();
		milestone.verify_joinedupcomingprogram(joinedprogram);
		milestone.click_MilestoneUpcoingProgram();
		milestone.click_Leaveprogram();
	}

	@When("user clicks on milestone based program under open programs section without the end date")
	public void user_clicks_on_milestone_based_program_under_open_programs_section_without_the_end_date() {
		milestone.click_MilestoneongoingProgram_withoutEndDate();
		milestone.click_MilestoneongoingProgram();
		milestone.click_Leaveprogram();
	}

	@Then("user should be able to view a milestone program details such as {string} and {string} and {string} and {string} and {string}")
	public void user_should_be_able_to_view_a_milestone_program_details_such_as_and_and_and_and(String string,
			String string2, String string3, String string4, String string5) {
		milestone.programDetails_TitleDetails_WithoutEndDate();
	}

	@When("user joins a milestone upcoming program from open program section which has end date")
	public void user_joins_a_milestone_upcoming_program_from_open_program_section_which_has_end_date() {
		visibilityWait(milestone.ongoingprograms_1);
		Assert.assertTrue(milestone.ongoingprograms_1.isDisplayed());
		Logger.log("user is already joned the program");
		// milestone.click_openProgramTab();
		// milestone.upcomingprogram_WithoutEndData();
	}

	@When("user add more than one e-reading titles that are physically read to the program")
	public void user_add_more_than_one_e_reading_titles_that_are_physically_read_to_the_program() {
		Logger.log("user add more than one e-reading titles that are physically read to the program");
		// Assert.assertTrue(milestone.physical_EReadprog.isDisplayed());
	}

	@When("user also add more than one titles from the library")
	public void user_also_add_more_than_one_titles_from_the_library() {
		Logger.log("ser also add more than one titles from the library");
	}

	@When("user navigate to milestone program detail be a part of {string} tab")
	public void user_navigate_to_milestone_program_detail_be_a_part_of_tab(String string) {
		milestone.upcomingprogram_WithoutEndData();
	}

	@Then("user should able to view program title")
	public void user_should_able_to_view_program_title() {
		visibilityWait(milestone.progDetails_Title);
		javascriptScroll(milestone.progDetails_Title);
		Assert.assertTrue(milestone.progDetails_Title.isDisplayed());
	}

	@Then("user should able to view program description")
	public void user_should_able_to_view_program_description() {
		Assert.assertTrue(milestone.progDetails_Description.isDisplayed());
	}

	@Then("user should able to view milestone start date")
	public void user_should_able_to_view_milestone_start_date() {
		Assert.assertTrue(milestone.progDetails_StartDate.isDisplayed());
	}

	@Then("user should able to view milestone end date")
	public void user_should_able_to_view_milestone_end_date() {
		Assert.assertTrue(milestone.progDetails_EndDate.isDisplayed());
		// milestone.click_Leaveprogram();
	}

	@Then("user should be able to view {string} CTA")
	public void user_should_be_able_to_view_cta(String string) {
		visibilityWait(milestone.progDetail_SeeAll);
		Assert.assertTrue(milestone.progDetail_SeeAll.isDisplayed());
	}

	@Then("user should be able to view the {string} CTA on the program detail page")
	public void user_should_be_able_to_view_the_cta_on_the_program_detail_page(String string) {
		javascriptScroll(milestone.progDetail_EditReadingList_CTA);
		Assert.assertTrue(milestone.progDetail_EditReadingList_CTA.isDisplayed());
	}

	@Given("user clicks milestone program which is joined by the user")
	public void user_clicks_milestone_program_which_is_joined_by_the_user() {
		milestone.click_Activeprogram_NavTitleDatails();
	}

	@Given("user should be able to view a page with all the titles added in a grid view")
	public void user_should_be_able_to_view_a_page_with_all_the_titles_added_in_a_grid_view() {
		visibilityWait(milestone.Titles_gridview);
		Assert.assertEquals(milestone.Titles_gridview.isDisplayed(), true);
		Logger.log("user is able to view the grid view");
	}

	@When("user should be able click see all cta if the more than one title was added in the reading program")
	public void user_should_be_able_click_see_all_cta_if_the_more_than_one_title_was_added_in_the_reading_program() {
		milestone.click_SeeAllCTA();
	}

	@Then("user should be able to view {string} and {string} and {string} option")
	public void user_should_be_able_to_view_and_and_option(String string, String string2, String string3) {
		visibilityWait(milestone.Readingprog_Sort);
		Assert.assertTrue(milestone.Readingprog_Sort.isDisplayed());
		Assert.assertTrue(milestone.Readingprog_Filter.isDisplayed());
		Assert.assertTrue(milestone.Readingprog_Edit.isDisplayed());
	}

	@Then("user select the {string} option")
	public void user_select_the_option(String string) {
		milestone.click_sort();
	}

	@Then("user able to view {string} and {string} and {string} and {string} under sort option")
	public void user_able_to_view_and_and_and_under_sort_option(String LatestCheckout, String Duedate, String atoz,
			String Ratings) {
		// milestone.view_SortOptions(LatestCheckout, Duedate, atoz, Ratings);
	}

	@Then("user able to sort the title by {string} option")
	public void user_able_to_sort_the_title_by_option(String sortoptions) {
		milestone.soryby_Duedate(sortoptions);
	}

	@Then("user able to filter the titles using {string} option")
	public void user_able_to_filter_the_titles_using_option(String string) {
		milestone.click_Filter();
	}

	@Then("user able to view {string} and {string} and {string} and {string} under filter option")
	public void user_able_to_view_and_and_and_under_filter_option(String string, String string2, String string3,
			String string4) {
		Assert.assertTrue(milestone.Filter_ebook.isDisplayed());
		Assert.assertTrue(milestone.Filter_eAudio.isDisplayed());
		// Assert.assertTrue(milestone.Filter_video.isDisplayed());
		// Assert.assertTrue(milestone.Filter_vbooks.isDisplayed());
		Assert.assertTrue(milestone.Filter_Addedbyuser.isDisplayed());
	}

	@Then("user should be able to filter the title {string} only by selecting ebooks under filter dropdown")
	public void user_should_be_able_to_filter_the_title_only_by_selecting_ebooks_under_filter_dropdown(String ebooks) {
		milestone.select_FilterbyEbook(ebooks);
	}

	@Then("user should be able to filter the title {string} only by selecting eAudio under filter dropdown")
	public void user_should_be_able_to_filter_the_title_only_by_selecting_e_audio_under_filter_dropdown(String eAudio) {
		milestone.select_FilterbyEAudio(eAudio);
	}

	@Then("user should be able to filter the title {string} only by selecting Video under filter dropdown")
	public void user_should_be_able_to_filter_the_title_only_by_selecting_video_under_filter_dropdown(String video) {
		milestone.select_FilterbyVideo(video);
	}

	@Then("user should be able to filter the title {string} only by selecting Added by You under filtr dropdown")
	public void user_should_be_able_to_filter_the_title_only_by_selecting_added_by_you_under_filtr_dropdown(
			String Addedbyuser) {
		milestone.select_FilterbyAddedbyuser(Addedbyuser);
	}

	@Given("user click see all {string} cta")
	public void user_click_see_all_cta(String string) {
		milestone.click_SeeAllCTA();
	}

	@When("user clicks on edit option in program")
	public void user_clicks_on_edit_option_in_program() {
		milestone.click_edit();
	}

	@Then("user should see cancel icons on the title to delete individual titles")
	public void user_should_see_cancel_icons_on_the_title_to_delete_individual_titles() {
		visibilityWait(milestone.edit_Cancel);
		Assert.assertEquals(milestone.edit_cancelicon_deleteTitle.isDisplayed(), true);
	}

	@Then("user should be able to view save and cancel cta")
	public void user_should_be_able_to_view_save_and_cancel_cta() {
		Assert.assertTrue(milestone.edit_Remove.isDisplayed());
		Assert.assertTrue(milestone.edit_Cancel.isDisplayed());
	}

	@Given("user joins a milestone upcoming program from open program section")
	public void user_joins_a_milestone_upcoming_program_from_open_program_section() {
		milestone.click_openProgramTab();
		milestone.upcomingprogram_WithoutEndData();
		milestone.click_joinProgramCTA();
		waitFor(3000);

	}

	@Given("user navigate to milestone program detail be a part of the {string} tab")
	public void user_navigate_to_milestone_program_detail_be_a_part_of_the_tab(String string) {
		visibilityWait(milestone.Nav_TitleDetails);
		Assert.assertEquals(milestone.Nav_TitleDetails.isDisplayed(), true);
	}

	@Given("user add title1 then observes the reading list count")
	public void user_add_title1_then_observes_the_reading_list_count() {
		visibilityWait(milestone_edit.TitleDetails_ReadingList);
		Assert.assertTrue(milestone_edit.TitleDetails_ReadingList.isDisplayed());

	}

	@Given("user should be able to view {string} CTA on the program detail page")
	public void user_should_be_able_to_view_cta_on_the_program_detail_page(String LeaveCTA) {
		visibilityWait(milestone.progDetails_LeaveProgram);
		javascriptScroll(milestone.progDetails_LeaveProgram);
		Assert.assertTrue(milestone.progDetails_LeaveProgram.getText().contains(LeaveCTA));
	}

	@When("user select the {string} in program detail page")
	public void user_select_the_in_program_detail_page(String string) {
		milestone.click_LeaveCTA();
	}

	@Then("user should able to view confirmation message {string} and {string} and {string}")
	public void user_should_able_to_view_confirmation_message_and_and(String Leavecontent, String Ok, String cancel) {
		Assert.assertEquals(milestone.progDetails_LeaveProgram_content.getText().equalsIgnoreCase(Leavecontent), true);
		Assert.assertTrue(milestone.leaveprog_yes.getText().equalsIgnoreCase(Ok));
		Assert.assertTrue(milestone.leaveprog_cancel.getText().equalsIgnoreCase(cancel));
		waitFor(2000);
		jsClick(milestone.leaveprog_yes);
		waitFor(3000);

	}

	@Given("user can join the program by clicking join programs CTA")
	public void user_can_join_the_program_by_clicking_join_programs_cta() {
		milestone.completed_BadgeProgram();
	}

	@Given("user checkout and completed the titles in the program")
	public void user_checkout_and_completed_the_titles_in_the_program() {
		visibilityWait(milestone_edit.Reading_AllTitles);
		Assert.assertTrue(milestone_edit.Reading_AllTitles.isDisplayed());
		Logger.log("This Milestone program already completed");

	}

	@When("user navigates to my profile screen and enabling the insights and badges option")
	public void user_navigates_to_my_profile_screen_and_enabling_the_insights_and_badges_option() {
		Logger.log("user is already enabled the insights and badges");
	}

	@Then("user navigates to the my shelf page by clicking my shelf CTA in hamburger menu")
	public void user_navigates_to_the_my_shelf_page_by_clicking_my_shelf_cta_in_hamburger_menu() {
		login.click_HamburgerMenu();
		login.click_Myshelf();
	}

	@Then("user should view lets do this badge for the first program completion")
	public void user_should_view_lets_do_this_badge_for_the_first_program_completion() {
		Assert.assertTrue(isElementPresent(milestone_edit.Milestone_LetsDothis_badge));
	}

	@Then("user should be able to view insights and badges widget in my shelf page")
	public void user_should_be_able_to_view_insights_and_badges_widget_in_my_shelf_page() {
		Assert.assertTrue(milestone_edit.myshelf_Goalsandinsight_widget.isDisplayed());
	}

	@Then("user should be able to view bages for completing the program")
	public void user_should_be_able_to_view_bages_for_completing_the_program() {
		Assert.assertEquals(isElementPresent(milestone_edit.Milestone_programcompleted_badge), true);
	}

	@Then("user should be able to view the full program name")
	public void user_should_be_able_to_view_the_full_program_name() {
		javascriptScroll(milestone_edit.Milestone_programName_badge);
		Assert.assertEquals(milestone_edit.Milestone_programName_badge.getText().contains("BadgeProgram"), true);
	}

	@Then("user should be able to view the badge only when they {int}% complete the particular program")
	public void user_should_be_able_to_view_the_badge_only_when_they_complete_the_particular_program(Integer int1) {
		Logger.log("user should be able to view the badge only when they 100% complete the particular program");
	}

	@Then("user should be able to click the cancel icon to delete the title from the program")
	public void user_should_be_able_to_click_the_cancel_icon_to_delete_the_title_from_the_program() {
		milestone.click_closeIcon_delete();
	}

	@Then("user should be able to click save cta")
	public void user_should_be_able_to_click_save_cta() {

	}

	@Then("user able to view the confirmation popup with {string} and {string} cta")
	public void user_able_to_view_the_confirmation_popup_with_and_cta(String OK, String Cancel) {
		Assert.assertEquals(milestone.leaveprog_cancel.getText().equalsIgnoreCase(Cancel), true);
		Assert.assertEquals(milestone.leaveprog_yes.getText().equalsIgnoreCase(OK), true);

	}

	@Then("user able to view the confirmation popup with {string} and {string} and {string} cta")
	public void user_able_to_view_the_confirmation_popup_with_and_and_cta(String verbiage, String Cancel, String OK) {
		Assert.assertEquals(milestone.progDetails_LeaveProgram_content.getText().contains(verbiage), true);
		Assert.assertEquals(milestone.leaveprog_cancel.getText().equalsIgnoreCase(Cancel), true);
		Assert.assertEquals(milestone.leaveprog_yes.getText().equalsIgnoreCase(OK), true);
	}

	@Then("user clicks the {string} cta from confirmation popup")
	public void user_clicks_the_cta_from_confirmation_popup(String string) {
		jsClick(milestone.leaveprog_yes);
	}

	@Then("user should be able to navigate to the program details screen with updated reading list")
	public void user_should_be_able_to_navigate_to_the_program_details_screen_with_updated_reading_list() {
		visibilityWait(milestone.Nav_updatedTitleDetails);
		Assert.assertEquals(milestone.Nav_updatedTitleDetails.isDisplayed(), true);
	}

	@Then("user should be able to click {string} to unsave the changes")
	public void user_should_be_able_to_click_to_unsave_the_changes(String string) {
		jsClick(milestone.leaveprog_cancel);
		Logger.log("Deleted title will be retained");

	}

	@Then("user clicks {string} cta from confirmation popup")
	public void user_clicks_cta_from_confirmation_popup(String string) {
		jsClick(milestone.leaveprog_cancel);
	}

	@Then("user should be able to view the sort option in right side of the page")
	public void user_should_be_able_to_view_the_sort_option_in_right_side_of_the_page() {
		visibilityWait(milestone.browse_Sort);
		Assert.assertEquals(milestone.browse_Sort.isDisplayed(), true);
	}

	@Then("user should not be able to view the sort options under the refine section")
	public void user_should_not_be_able_to_view_the_sort_options_under_the_refine_section() {
		Logger.log("UI validation");
	}

	@Then("user should be able to click the sort option")
	public void user_should_be_able_to_click_the_sort_option() {
		milestone.click_BrowseSort();
	}

	@Then("user should be able to view the sort options as dropdown")
	public void user_should_be_able_to_view_the_sort_options_as_dropdown() {
		Assert.assertTrue(milestone.browse_publicationDate.isDisplayed());
	}

	@Then("user should be able to view the  {string} and {string} and {string} and {string} and {string} and {string} options in dropdown")
	public void user_should_be_able_to_view_the_and_and_and_and_and_options_in_dropdown(String ReturnDate,
			String Popularity, String PublicationDate, String AddedDate, String Title, String Author) {
		Assert.assertEquals(milestone.browse_ReturnDate.getText().contains(ReturnDate), true);
		Assert.assertEquals(milestone.browse_Popularity.getText().contains(Popularity), true);
		Assert.assertEquals(milestone.browse_publicationDate.getText().contains(PublicationDate), true);
		Assert.assertEquals(milestone.browse_AddedDate.getText().contains(AddedDate), true);
		Assert.assertEquals(milestone.browse_Title.getText().contains(Title), true);
		Assert.assertEquals(milestone.browse_Author.getText().contains(Author), true);
	}

	@Then("user selects {string} from the dropdown")
	public void user_selects_from_the_dropdown(String sort) {
		milestone.click_BrowseSortoption(sort);
	}

	@Then("user should be able to view the titles sorted based on the Return date")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_return_date() {
		Assert.assertTrue(milestone.browse_resultsScreen.isDisplayed());
		apiResponses = APIClient.getBrowseSearchTitleResponse("returnedDate");
		List<String> isbListfromUI = new ArrayList<String>();
		List<String> isbListfromAPI = new ArrayList<String>();
		isbListfromUI = login.get_TitlesISBN();
		for (SearchTitleResponse apiResponse : apiResponses) {
			List<Title> titles = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getTitlesList()
					.getTitles();
			for (Title title : titles) {
				isbListfromAPI.add(title.getiSBN());
			}
		}
		
		for(int i = 0; i < 24; i++) {
			System.out.println( i + ": isbn from API : " + isbListfromAPI.get(i) + " isbn from UI : " + isbListfromUI.get(i));
		}
		
		Assert.assertEquals(isbListfromUI, isbListfromAPI);
	}

	@Then("user should be able to view the titles sorted based on the Popularity")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_popularity() {
		Assert.assertTrue(milestone.browse_resultsScreen.isDisplayed());
		apiResponses = APIClient.getBrowseSearchTitleResponse("popularity");
		List<String> isbListfromUI = new ArrayList<String>();
		List<String> isbListfromAPI = new ArrayList<String>();
		isbListfromUI = login.get_TitlesISBN();
		for (SearchTitleResponse apiResponse : apiResponses) {
			List<Title> titles = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getTitlesList()
					.getTitles();
			for (Title title : titles) {
				isbListfromAPI.add(title.getiSBN());
			}
		}
		
		for(int i = 0; i < 24; i++) {
			System.out.println( i + ": isbn from API : " + isbListfromAPI.get(i) + " isbn from UI : " + isbListfromUI.get(i));
		}
		
		Assert.assertEquals(isbListfromUI, isbListfromAPI);
	}

	@Then("user should be able to view the titles sorted based on the Publication Date")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_publication_date() {
		Assert.assertTrue(milestone.browse_resultsScreen.isDisplayed());
		apiResponses = APIClient.getBrowseSearchTitleResponse("publicationDate");
		List<String> isbListfromUI = new ArrayList<String>();
		List<String> isbListfromAPI = new ArrayList<String>();
		isbListfromUI = login.get_TitlesISBN();
		for (SearchTitleResponse apiResponse : apiResponses) {
			List<Title> titles = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getTitlesList()
					.getTitles();
			for (Title title : titles) {
				isbListfromAPI.add(title.getiSBN());
			}
		}
		
		for(int i = 0; i < 24; i++) {
			System.out.println( i + ": isbn from API : " + isbListfromAPI.get(i) + " isbn from UI : " + isbListfromUI.get(i));
		}
		
		Assert.assertEquals(isbListfromUI, isbListfromAPI);
	}

	@Then("user should be able to view the titles sorted based on the Added Date")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_added_date() {
		Assert.assertTrue(milestone.browse_resultsScreen.isDisplayed());
		apiResponses = APIClient.getBrowseSearchTitleResponse("AddedDate");
		List<String> isbListfromUI = new ArrayList<String>();
		List<String> isbListfromAPI = new ArrayList<String>();
		isbListfromUI = login.get_TitlesISBN();
		for (SearchTitleResponse apiResponse : apiResponses) {
			List<Title> titles = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getTitlesList()
					.getTitles();
			for (Title title : titles) {
				isbListfromAPI.add(title.getiSBN());
			}
		}
		
		for(int i = 0; i < 24; i++) {
			System.out.println( i + ": isbn from API : " + isbListfromAPI.get(i) + " isbn from UI : " + isbListfromUI.get(i));
		}
		
		Assert.assertEquals(isbListfromUI, isbListfromAPI);
	}

	@Then("user should be able to view the titles sorted based on the Title")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_title() {
		Assert.assertTrue(milestone.browse_resultsScreen.isDisplayed());
		apiResponses = APIClient.getBrowseSearchTitleResponse("Title");
		List<String> isbListfromUI = new ArrayList<String>();
		List<String> isbListfromAPI = new ArrayList<String>();
		isbListfromUI = login.get_TitlesISBN();
		for (SearchTitleResponse apiResponse : apiResponses) {
			List<Title> titles = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getTitlesList()
					.getTitles();
			for (Title title : titles) {
				isbListfromAPI.add(title.getiSBN());
			}
		}
		
		for(int i = 0; i < 24; i++) {
			System.out.println( i + ": isbn from API : " + isbListfromAPI.get(i) + " isbn from UI : " + isbListfromUI.get(i));
		}
		
		Assert.assertEquals(isbListfromUI, isbListfromAPI);
	}

	@Then("user should be able to view the titles sorted based on the Author")
	public void user_should_be_able_to_view_the_titles_sorted_based_on_the_author() {
		Assert.assertTrue(milestone.browse_resultsScreen.isDisplayed());
		apiResponses = APIClient.getBrowseSearchTitleResponse("Author");
		List<String> isbListfromUI = new ArrayList<String>();
		List<String> isbListfromAPI = new ArrayList<String>();
		isbListfromUI = login.get_TitlesISBN();
		for (SearchTitleResponse apiResponse : apiResponses) {
			List<Title> titles = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getTitlesList()
					.getTitles();
			for (Title title : titles) {
				isbListfromAPI.add(title.getiSBN());
			}
		}
		
		for(int i = 0; i < 24; i++) {
			System.out.println( i + ": isbn from API : " + isbListfromAPI.get(i) + " isbn from UI : " + isbListfromUI.get(i));
		}
		
		Assert.assertEquals(isbListfromUI, isbListfromAPI);
	}

	@Then("user search a {string} and land on search result page")
	public void user_search_a_and_land_on_search_result_page(String keyword) {
		search.AdvanceSesarch_EnterInput(keyword);
		search.click_AdvanceSearchCTA();
	}

	@Then("user clicks on see All CTA in Search results page")
	public void user_clicks_on_see_all_cta_in_search_results_page() {
		search.click_SeeAllCTA();
	}

	@Then("user do not view the default pills")
	public void user_do_not_view_the_default_pills() {
		Logger.log("no default pill is displayed");
	}

	@Then("user select any filter in result page the same filter show in pills")
	public void user_select_any_filter_in_result_page_the_same_filter_show_in_pills() {
		search.click_Refineroptions();
	}

	@Then("user click clear all pills default pills not able to view in search result page")
	public void user_click_clear_all_pills_default_pills_not_able_to_view_in_search_result_page() {
		Assert.assertTrue(search.pills_clearAll.isDisplayed());
		jsClick(search.pills_clearAll);
		// Assert.assertEquals(isElementPresent(search.advanceSearch_thirdpartySearchResult_pills),
		// false);
	}
}
