package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class InterestSurvey_Eyes_StepDefinition {
	
	Eyes eyes = EyesManager.getEyes();

	@Then("capture the screenshot of the interest survey screen")
	public void capture_the_screenshot_of_the_interestSurveyScreen() {
		eyes.checkWindow("IneterestSurveyScreen");
	}
	

}
