package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelfscreen;

public class MyLibrary_Eyes_StepDef {

	Eyes eyes = EyesManager.getEyes();
	MyShelfscreen myShelf = new MyShelfscreen(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	CommonAction common = new CommonAction();

	@Then("capture the screenshot of Menu Screen")
	public void capture_the_screenshot_of_the_menuScreen() {
		common.WaitForWebElement(hamburgerMenu.getNavigationMenu_btn_browseBySubject());
		eyes.checkWindow("menuScreen");
	}

	@Then("capture the screenshot of MyLibraryScreen")
	public void capture_the_screenshot_of_the_MyLibraryScreen() {
//			common.WaitForWebElement(hamburgerMenu.getLink_MyShelf());
		eyes.checkWindow("MyLibraryScreen");
	}

	@Then("capture the screenshot of bottomNavigationBar")
	public void capture_the_screenshot_of_the_bottomNavigationBar() {
//			common.WaitForWebElement(hamburgerMenu.getLink_MyShelf());
		eyes.checkWindow("bottomNavigationBar");
	}

	@Then("capture the screenshot of NewspaperAndMagazinesCarousel")
	public void capture_the_screenshot_of_the_NewspaperAndMagazinesCarousel() {
//			common.WaitForWebElement(hamburgerMenu.getLink_MyShelf());
		eyes.checkWindow("NewspaperAndMagazinesCarousel");
	}

	@Then("capture the screenshot of notificationsBar")
	public void capture_the_screenshot_of_the_NewspaperAndMagazinesScreen() {
//			common.WaitForWebElement(hamburgerMenu.getLink_MyShelf());
		eyes.checkWindow("notificationsBar");
	}
	
	@Then("capture the screenshot of featuredProgramScreen")
	public void capture_the_screenshot_of_featuredProgramScreen() {
		eyes.checkWindow("FeaturedProgramScreen");
	}
	
	@Then("capture the screenshot of the menuWithNoProfileOptionScreen")
	public void capture_the_screenshot_of_menuWithNoProfileOptionScreen() {
		eyes.checkWindow("menuWithNoProfileOptionScreen");
	}
	
	@Then("capture the screenshot of the featured program banner screen")
	public void capture_the_screenshot_of_the_featured_program_banner_screen() {
		eyes.checkWindow("featuredProgramBannerScreen");
	}

}
