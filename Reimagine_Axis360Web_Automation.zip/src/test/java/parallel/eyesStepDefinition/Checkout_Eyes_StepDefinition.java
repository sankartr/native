package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class Checkout_Eyes_StepDefinition {
	
Eyes eyes = EyesManager.getEyes();
	
	@Then("capture the screenshot of the checkout screen")
	public void capture_the_screenshot_of_the_checkout_screen() {
	    eyes.checkWindow("CheckoutScreen");
	}
	
	@Then("capture the screenshot of the list/grid view screen")
	public void capture_the_screenshot_of_the_gridView_screen() {
	    eyes.checkWindow("gridView");
	}
	
	@Then("capture the screenshot of the checkout screen after clicking back cta")
	public void capture_the_screenshot_of_the_checkout_screen_after_clicking_back_cta() {
	    eyes.checkWindow("checkoutScreenAfterClickingBackCTA");
	}
	
	@Then("capture the screenshot after clicking more options cta")
	public void capture_the_screenshot_after_clicking_more_options_cta() {
	    eyes.checkWindow("ScreenAfterMoreOptionsCTA");
	}
	
	@Then("capture the screenshot of the list\\/grid view screen")
	public void capture_the_screenshot_of_the_list_grid_view_screen() {
		eyes.checkWindow("list-grid view");
	}

}
