package parallel.eyesStepDefinition;

import org.junit.Assert;

import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;
import pom.kidszone.Profilecreation;

public class ManageProfile_Eyes_StepDef {

	Eyes eyes = EyesManager.getEyes();
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	CommonAction common = new CommonAction();

	@Then("capture the screenshot of the editManageProfileScreen")
	public void capture_the_screenshot_of_the_editManageProfileScreen() {
		eyes.checkWindow("editManageProfileScreen");
	}

	@Then("capture the screenshot of the profileDetailScreen")
	public void capture_the_screenshot_of_the_profileDetailScreen() {
		Assert.assertTrue(profile.getAddprofile_txt_profile().isDisplayed());
		eyes.checkWindow("profileDetailScreen");
	}

	@Then("capture the screenshot of the incorrect pin error message")
	public void capture_the_screenshot_of_the_incorrect_pin_error_message() {
		eyes.checkWindow("incorrectPinErrorMessageScreen");
	}

	@Then("capture the screenshot of the profileScreen")
	public void capture_the_screenshot_of_the_profileScreen() {
		Assert.assertTrue(profile.getAddprofile_txt_profile().isDisplayed());
		eyes.checkWindow("profileScreen");
	}

}
