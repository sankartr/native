package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;
import com.resuableMethods.CommonAction;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class SearchAndBoundless_Eyes_StepDefinition {
	
	Eyes eyes = EyesManager.getEyes();
	CommonAction common = new CommonAction();

	@Then("capture the screenshot of the advanced search popup screen")
	public void capture_the_screenshot_of_the_advanced_search_popup_screen() {
	    eyes.checkWindow("advanced search popup screen");
	}

	@Then("capture the screenshot of the search screen")
	public void capture_the_screenshot_of_the_search_screen() {
		eyes.checkWindow("search screen");
	}

	@Then("capture the screenshot of the search result landing page")
	public void capture_the_screenshot_of_the_search_result_landing_page() {
		eyes.checkWindow("search result landing page");
	}

	@Then("capture the screenshot of the profile page")
	public void capture_the_screenshot_of_the_profile_page() {
		eyes.checkWindow("profile page");
	}

	@Then("capture the screenshot of the advanced search page")
	public void capture_the_screenshot_of_the_advanced_search_page() {
		eyes.checkWindow("advanced search page");
	}

	@Then("capture the screenshot of the purchase request page")
	public void capture_the_screenshot_of_the_purchase_request_page() {
		eyes.checkWindow("purchase request page");
	}

	@Then("capture the screenshot of the Newspapers and magazines radio button in collections")
	public void capture_the_screenshot_of_the_radio_button_in_collections(String string) {
		eyes.checkWindow("Newspapers and magazines radio button in collections");
	}

	@Then("capture the screenshot of the advanced search CTA")
	public void capture_the_screenshot_of_the_advanced_search_cta() {
		eyes.checkWindow("advanced search cta");
	}

	@Then("capture the screenshot of the study sites screen")
	public void capture_the_screenshot_of_the_study_sites_screen() {
		eyes.checkWindow("study sites screen");
	}

	@Then("capture the screenshot of the Always Available carousel")
	public void capture_the_screenshot_of_the_always_available_carousel() {
		eyes.checkWindow("always available carousel");
	}

	@Then("capture the screenshot of the advance search screen")
	public void capture_the_screenshot_of_the_advance_search_screen() {
		eyes.checkWindow("advanced search screen");
	}
	
	@Then("capture the screenshot of the boundless logo in the footer as per mock")
	public void capture_the_screenshot_of_the_boundless_logo_in_the_footer_as_per_mock() {
		eyes.checkWindow("boundless logo in the footer as per mock");
	}
	
}
