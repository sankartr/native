package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class LearningActivites_Eyes_StepDefinition {
	
	Eyes eyes = EyesManager.getEyes();

	@Then("capture the screenshot of learning activities screen")
	public void capture_the_screenshot_of_the_learningActivitiesScreen() {
		eyes.checkWindow("LearningActivitesScreen");
	}
	
	@Then("capture the screenshot of screen after changing category from refine option to view learning resources")
	public void capture_the_screenshot_of_screen_after_changing_category_from_refine_option_to_view_learning_resources() {
		eyes.checkWindow("ScreenAfterChangingRefineCategory");
	}

	@Then("capture the screenshot of screen after changing refine option")
	public void capture_the_screenshot_of_screen_after_changing_refine_option() {
		eyes.checkWindow("LearningActivitesScreen");
	}
	
	@Then("capture the screenshot of screen after expanding sort option")
	public void capture_the_screenshot_of_screen_after_expanding_sort_option() {
		eyes.checkWindow("ScreenAfterExpandingSortOption");
	}

	@Then("capture the screenshot of learning activities screen after refine options are expanded")
	public void capture_the_screenshot_of_learning_activities_screen_after_refine_options_are_expanded() {
		eyes.checkWindow("ScreenAfterRefineOption");
	}

}
