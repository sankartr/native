package parallel.eyesStepDefinition;

import org.junit.Assert;

import com.applitools.eyes.selenium.Eyes;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.MyLibrary;
import pom.kidszone.MyShelfscreen;

public class NavigationMenu_Eyes_StepDef {

	Eyes eyes = EyesManager.getEyes();
	MyShelfscreen myShelf = new MyShelfscreen(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	CommonAction common = new CommonAction();

	@Then("capture the screenshot of the menuScreen")
	public void capture_the_screenshot_of_the_menuScreen() {
		eyes.checkWindow("menuScreen");
	}

	@Then("capture the screenshot of the myShelfScreen")
	public void capture_the_screenshot_of_the_myShelfScreenn() {
		common.WaitForWebElement(hamburgerMenu.getText_MyShelf_Page());
		eyes.checkWindow("myShelfScreen");
	}

	@Then("capture the screenshot of the checkoutScreen")
	public void capture_the_screenshot_of_the_checkoutScreen() {
//		common.WaitForWebElement(hamburgerMenu.getMyStuffScreenText());
		common.waitForInvisibilityOf("//*[contains(@class,'spinner-loader')]");
		eyes.checkWindow("checkoutScreen");
	}

	@Then("capture the screenshot of the holdsScreen")
	public void capture_the_screenshot_of_the_holdsScreen() {
		common.waitForInvisibilityOf("//*[contains(@class,'spinner-loader')]");
		eyes.checkWindow("holdsScreen");
	}

	@Then("capture the screenshot of the programsScreen")
	public void capture_the_screenshot_of_the_programsScreen() {
//		common.WaitForWebElement(hamburgerMenu.getTxt_MyProgramCards());
		common.waitForInvisibilityOf("//*[@class='spinner-loader']");
		eyes.checkWindow("programsScreen");
	}

	@Then("capture the screenshot of the signOutAlertPopup")
	public void capture_the_screenshot_of_the_signOutAlertPopup() {
		common.WaitForWebElement(hamburgerMenu.getYesButton());
		eyes.checkWindow("signOutAlertPopup");
	}

	@Then("capture the screenshot of the helpPortalScreen")
	public void capture_the_screenshot_of_the_helpPortalScreen() {
//		common.WaitForWebElement(hamburgerMenu.getHelpPageTopicLink());
		try {
			common.waitForInvisibilityOf("//*[@class='loadingCon siteforceLoadingBalls']");
		} catch (Exception e) {
			System.out.println("loader not present");
		}
		eyes.checkWindow("helpPortalScreen");
	}

	@Then("capture the screenshot of the libraryHomeScreen")
	public void capture_the_screenshot_of_the_libraryHomeScreen() {
		Assert.assertTrue(mylibrary.getTxt_NavlibraryScreen().isDisplayed());
		eyes.checkWindow("libraryHomeScreen");
	}

	@Then("capture the screenshot of the myLibraryScreen")
	public void capture_the_screenshot_of_the_myLibraryScreen() {
		Assert.assertTrue(mylibrary.getTxt_NavlibraryScreen().isDisplayed());
		eyes.checkWindow("myLibraryScreen");
	}

}
