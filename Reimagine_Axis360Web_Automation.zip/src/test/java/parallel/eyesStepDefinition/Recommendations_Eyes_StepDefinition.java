package parallel.eyesStepDefinition;

import com.applitools.eyes.selenium.Eyes;
import com.resuableMethods.CommonAction;

import eyesmanager.EyesManager;
import io.cucumber.java.en.Then;

public class Recommendations_Eyes_StepDefinition {

	Eyes eyes = EyesManager.getEyes();
	CommonAction common = new CommonAction();

	@Then("capture the screenshot of my shelf screen for kids")
	public void capture_the_screenshot_of_my_shelf_screen_for_kids() {
		eyes.checkWindow("myShelfScreenForKids");
	}

	@Then("capture the screenshot of interest based recommendations titles screen for kids")
	public void capture_the_screenshot_of_interest_based_recommendations_titles_screen_for_kids() {
		eyes.checkWindow("recommendationsTitlesScreenForKids");
	}
	
	@Then("capture the screenshot of interest based recommendations titles screen for adult")
	public void capture_the_screenshot_of_interest_based_recommendations_titles_screen_for_adult() {
		eyes.checkWindow("recommendationsTitlesScreenForAdult");
	}

	@Then("capture the screenshot of my shelf screen for teen")
	public void capture_the_screenshot_of_my_shelf_screen_for_teen() {
		eyes.checkWindow("myShelfScreenForTeen");
	}
	
	@Then("capture the screenshot of my shelf screen for adult")
	public void capture_the_screenshot_of_my_shelf_screen_for_adult() {
		eyes.checkWindow("myShelfScreenForAdult");
	}

	@Then("capture the screenshot of interest based recommendations titles screen for teen")
	public void capture_the_screenshot_of_interest_based_recommendations_titles_screen_for_teen() {
		eyes.checkWindow("recommendationsTitlesScreenForTeen");
	}

	@Then("capture the screenshot of the my Shelf screen")
	public void capture_the_screenshot_of_my_shelf_screen() {
		eyes.checkWindow("myShelfScreen");
	}

}
