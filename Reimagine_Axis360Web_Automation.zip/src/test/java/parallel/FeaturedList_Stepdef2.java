package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.FeaturedList;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.MyLibrary;

public class FeaturedList_Stepdef2 extends CommonAction{

	FeaturedList featurelist = new FeaturedList(DriverManager.getDriver());
	MyLibrary mylibrary = new MyLibrary(DriverManager.getDriver());
	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());
	
	
	
	//131687
		@When("featured list is set and enabled in admin portal")
		public void featured_list_is_set_and_enabled_in_admin_portal() {
			Logger.log("featured list is set and enabled in admin portal");
		}

		@Then("user should be able to view set featured list section based on adult profile with adult profile specific theme")
		public void user_should_be_able_to_view_set_featured_list_section_based_on_adult_profile_with_adult_profile_specific_theme() {
			Logger.log("user able to view adult featured list title");
			//featurelist.click_adultprofileFeaturedlist();
		}
		@Then("user should be able to view adult featured list title and description")
		public void user_should_be_able_to_view_adult_featured_list_title_and_description() {
			 Logger.log("user be able to view adult featured list title");
			//Assert.assertTrue(featurelist.getMyshelf_txt_featuredlistTeenprofileTheme().isDisplayed());
		}

		@Then("user should be able to view featured list title and description")
		public void user_should_be_able_to_view_featured_list_title_and_description() {
			featurelist.adult_featuredListTitle();
			
		}

		@Then("user should be able to view featured list titles and description as carousel")
		public void user_should_be_able_to_view_featured_list_titles_and_description_as_carousel() {
		//featurelist.viewTeenprofile_featuredListcarousel();
			mylibrary.featuredCarousel();
       //Assert.assertTrue(isElementPresent(mylibrary.getFeaturedList_carousel()));
		}
		
		@Then("user should be able to view featured list titles and description as carousel for kid user")
		public void user_should_be_able_to_view_featured_list_titles_and_description_as_carousel_for_kid_user() {
			Logger.log("Kid user carousel is different and needs to set in backend");
		}

		@Then("user should be able to click in view all cta and navigate to titles list screen for the featured list")
		public void user_should_be_able_to_click_in_view_all_cta_and_navigate_to_titles_list_screen_for_the_featured_list() {
			featurelist.click_viewAllctaNavFeaturelist();
		}
		
		@Then("user should be able to click in view all cta and navigate to titles list screen for the featured list kid user")
		public void user_should_be_able_to_click_in_view_all_cta_and_navigate_to_titles_list_screen_for_the_featured_list_kid_user() {
			Logger.log("Kid user see all  is different and needs to set in backend");
		}

		@Then("user should be able to view set featured list section based on teen profile with teen profile specific theme")
		public void user_should_be_able_to_view_set_featured_list_section_based_on_teen_profile_with_teen_profile_specific_theme() {
			 Logger.log("user should be able to view teen featured list title");
			//featurelist.teenprofileFeaturedList();
		}

		@Then("user should be able to view set featured list section based on kid profile with kid profile specific theme")
		public void user_should_be_able_to_view_set_featured_list_section_based_on_kid_profile_with_kid_profile_specific_theme() {
			featurelist.kidprofileFeaturedList();
		} 
		
	//125286
		
		@Given("user clicks on Hamburger menu")
		public void user_clicks_on_hamburger_menu() {
			ham.click_HamburgerMenu();
		}
		
		@When("user clicks on featured list")
		public void user_clicks_on_featured_list() {
		   featurelist.click_adultprofileFeaturedlist();
		}

		@Then("user should be able to view library curated lists in the sidebar based on adult profile type")
		public void user_should_be_able_to_view_library_curated_lists_in_the_sidebar_based_on_adult_profile_type() {
		   Assert.assertEquals(featurelist.Adult_viewSidebarLibraryCuratedList(), true);
		}

		@Then("user should be able to navigate to specific featured list screen by clicking specific featured list")
		public void user_should_be_able_to_navigate_to_specific_featured_list_screen_by_clicking_specific_featured_list() {
			 Logger.log("Clicking particular features from features list of hamburger menu is not implemented yet ");
		}

		@Then("user should be able to click on back cta and navigate back to the last screen")
		public void user_should_be_able_to_click_on_back_cta_and_navigate_back_to_the_last_screen() {
		    Assert.assertTrue(featurelist.getMenu_MenuList().isDisplayed());
		    Logger.log("system should navigate to menu list screen");
		}

		@Then("user should be able to click on close {string} cta and navigate back to last screen")
		public void user_should_be_able_to_click_on_close_cta_and_navigate_back_to_last_screen(String string) {
		    featurelist.click_closeCTA();
		}
		
		//125619
		
		@When("user click on patron support")
		public void user_click_on_patron_support() {
		    mylibrary.click_patronSupport();
		}

		@Then("user should be able to navigate to axis360 patron support portal")
		public void user_should_be_able_to_navigate_to_axis360_patron_support_portal() {
		  // Assert.assertTrue(mylibrary.getTxt_NavpatronSupportScreen().isDisplayed());
			Logger.log("The page gets opened in new window");
		   
		}

//125342
		
		@Then("user should be able to view availability and format filters for listed titles with profile based theme")
		public void user_should_be_able_to_view_availability_and_format_filters_for_listed_titles_with_profile_based_theme() {
		    featurelist.getTxt_availabilityt().isDisplayed();
		}

		@Then("user should be able to view all and available now options in availability filter dropdown menu")
		public void user_should_be_able_to_view_all_and_available_now_options_in_availability_filter_dropdown_menu() {
		    featurelist. view_availabilityAlldropdown();
		}

		@Then("user should be abel to select available Now options in dropdown")
		public void user_should_be_abel_to_select_available_now_options_in_dropdown() {
//			Assert.assertTrue(featurelist.getDrop_availabilityt_availablenow().isDisplayed());
		    featurelist.click_AvailableNow();
		}

		@Then("user should be able to view only available titles on selecting availability filter available now")
		public void user_should_be_able_to_view_only_available_titles_on_selecting_availability_filter_available_now() {
		    Assert.assertTrue(isElementPresent(featurelist.getTxt_availabilityt()));
		}

		@Then("system should display the default availability and format filter to all")
		public void system_should_display_the_default_availability_and_format_filter_to_all() {
		    featurelist.click_defaultAvailabilityandFormatAll();
		}
		
		@Then("user should be able to view all and ebook and audio options in format filter dropdown menu")
		public void user_should_be_able_to_view_all_and_ebook_and_audio_options_in_format_filter_dropdown_menu() {
		   featurelist.view_formatViewAll();
		}

		@Then("user should be able to view ebook only on selecting format filter ebook books")
		public void user_should_be_able_to_view_ebook_only_on_selecting_format_filter_ebook_books() {
		   featurelist.click_ebook();
		}

		@Then("user should be able to view audio books only on selecting format filter audio books")
		public void user_should_be_able_to_view_audio_books_only_on_selecting_format_filter_audio_books() {
		   featurelist.click_Audio();
		}

		//125852
		
		@Then("user should be able to view quick navigation ctas new and trending and surprise me")
		public void user_should_be_able_to_view_quick_navigation_ctas_new_and_trending_and_surprise_me() {
		   Assert.assertEquals(featurelist.view_newTrendingAndSurprise(), true);
		}

		@Then("user should be able to navigate to new titles list screen by clicking new cta")
		public void user_should_be_able_to_navigate_to_new_titles_list_screen_by_clicking_new_cta() {
		    featurelist.click_new();
		}

		@Then("user should be able to navigate to trending titles list screen by clicking trending cta")
		public void user_should_be_able_to_navigate_to_trending_titles_list_screen_by_clicking_trending_cta() {
		    featurelist.click_trending();
		}

		@Then("user should be able to navigate to surprise me title list screen by clicking surprise me cta")
		public void user_should_be_able_to_navigate_to_surprise_me_title_list_screen_by_clicking_surprise_me_cta() {
		  featurelist.click_surpriseMe();
		}
		
		//125339
		
		@When("user navigates to screen that has title listed")
	    public void user_navigates_to_screen_that_has_title_listed() throws Throwable {
	       Logger.log("User navigates to screen that has title listed");
	    }

	    @Then("user should be able to view updated title widget")
	    public void user_should_be_able_to_view_updated_title_widget() throws Throwable {
	       Logger.log("user able to view updated title widget");
	    }

	    @And("user should be able to view audio book title total hours for listening in the title widget")
	    public void user_should_be_able_to_view_audio_book_title_total_hours_for_listening_in_the_title_widget() throws Throwable {
	       Logger.log("User able to view audio book title total hours for listening in the title widget");
	    }
	    
	    
	    @Given("user should be able to view always available carousel,description,See All CTa")
	    public void user_should_be_able_to_view_always_available_carousel_description_see_all_c_ta() {
	    	featurelist.Verify_AlwaysAvailableCarousel();
	    }

	    @Given("user navigates to list page if user clicks on See All cTA")
	    public void user_navigates_to_list_page_if_user_clicks_on_see_all_c_ta() {
	    	featurelist.Click_AlwaysAvailableSeeAllCTA();
	    	Assert.assertTrue(featurelist.AlwaysAvailable_ResultCount.isDisplayed());
	    	Logger.log("Always Available Title Count: " +featurelist.AlwaysAvailable_ResultCount);
	    }

	    @Given("user navigates to tier3 page if user clicks on always available title")
	    public void user_navigates_to_tier3_page_if_user_clicks_on_always_available_title() {
	    	featurelist.NavTier3_alwaysAvailableTitle();
	    }

	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
/*
	//131688
	
	@When("user disables the featured list in admin portal")
	public void user_disables_the_featured_list_in_admin_portal() {
		Logger.log("user disable the featured list in admin portal");
	}

	@Then("user should not view the featured list if disabled in the admin portal")
	public void user_should_not_view_the_featured_list_if_disabled_in_the_admin_portal() {
	   featurelist.shouldnotshow_featuredList();
	}

	@When("no feature list is created for the adult profile type")
	public void no_feature_list_is_created_for_the_adult_profile_type() {
		Logger.log("no feature list is created for the adult profile");
	}

	@Then("user should not view the featured list if no feature list is created for the particular profile type")
	public void user_should_not_view_the_featured_list_if_no_feature_list_is_created_for_the_particular_profile_type() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("no title in the list to be displayed")
	public void no_title_in_the_list_to_be_displayed() {
	  featurelist.shouldnotshow_title();
	}

	@Then("user should not view the featured list")
	public void user_should_not_view_the_featured_list() {
		featurelist.shouldnotshow_featuredList();
	}
	@When("no feature list is created for the kid profile type")
	public void no_feature_list_is_created_for_the_kid_profile_type() {
		Logger.log("no feature list is created for the kid profile");
	}
	
	@When("no feature list is created for the teen profile type")
	public void no_feature_list_is_created_for_the_teen_profile_type() {
		Logger.log("no feature list is created for the teen profile");
	}
	*/
}
