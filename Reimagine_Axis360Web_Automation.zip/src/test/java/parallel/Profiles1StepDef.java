package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.Profile;

public class Profiles1StepDef extends CommonAction {

	Profile profile = new Profile(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());

	@Given("user selects the profile icon in the static header")
	public void user_selects_the_profile_icon_in_the_static_header() {
		profile.clickProfile();
	}

	@When("user is on profile detail screen")
	public void user_is_on_profile_detail_screen() {
		visibilityWait(profile.profileEditSection);
		Assert.assertTrue(profile.profileEditSection.isDisplayed());
	}

	@Then("user should be able to disable an already set pin {string} by clicking on the disable pin cta in the profile details screen")
	public void user_should_be_able_to_disable_an_already_set_pin_by_clicking_on_the_disable_pin_cta_in_the_profile_details_screen(
			String pin) {
		profile.Already_DisabledPin(pin);
		// profile.setProfilePin(pin);
	}

	@Then("user should be able to navigated to view pin screen")
	public void user_should_be_able_to_navigated_to_view_pin_screen() {
		profile.clickDisablePin();
		// Assert.assertTrue(profile.disableProfilePin_toggle.isDisplayed());
////		Assert.assertTrue(profile.profileEditSection.isDisplayed());
	}

	@Then("user provides the {string} in pin field")
	public void user_provides_the_in_pin_field(String Pin) {
		profile.Enter_setPin(Pin);
		profile.click_submit();
//		profile.disableProcess(pin);
//		profile.enterPin(pin);
//		ClickOnWebElement(profile.setPinDoneButton);
	}

	@Then("user is able to view confirmation popup {string}")
	public void user_is_able_to_view_confirmation_popup(String string) {
		Assert.assertEquals(profile.Disablepin_content.getText().contains(string), true);
	}

	@Then("user clicks on Cancel button in the popup")
	public void user_clicks_on_cancel_button_in_the_popup() {
		profile.clickCancelBtn();
		profile.clickSaveProfile();
	}

	@Then("user should dismiss from the disabling action")
	public void user_should_dismiss_from_the_disabling_action() {
		Assert.assertFalse(isElementPresent(profile.disablePinPopUp));
	}

	@Then("user clicks on yes button in the popup")
	public void user_clicks_on_yes_button_in_the_popup() {
		profile.disablePinOK();
		profile.clickSaveProfile();
	}

	@Then("user is able to verify success message {string} regarding pin disable statement")
	public void user_is_able_to_verify_success_message_regarding_pin_disable_statement(String msg) {
		Assert.assertTrue(profile.getSucessMsg().isDisplayed());
		Assert.assertEquals(profile.getSucessMsg().getText().contains(msg), true);
	}

	@Then("user should displayed with error message and restricted from moving forward")
	public void user_should_displayed_with_error_message_and_restricted_from_moving_forward() {
		Assert.assertTrue(false);
	}

//	@Given("user clicks on Teen Profille from the list")
//	public void user_clicks_on_teen_profille_from_the_list() {
//
//	}
//
//	@Given("user clicks on Kid Profille from the list")
//	public void user_clicks_on_kid_profille_from_the_list() {
//
//	}

	@Then("user on clicking the teen profile icon")
	public void user_on_clicking_the_teen_profile_icon() {
		login.select_Teenprofilewithpenicon();
		// login.select_Teenprofile();
	}

	@Then("user needs to be navigated to profile details screen")
	public void user_needs_to_be_navigated_to_profile_details_screen() {
		WaitForWebElement(profile.profileEditSection);
		Assert.assertTrue(profile.profileEditSection.isDisplayed());
	}

	@Then("user update the details in the {string} field in profile screen")
	public void user_update_the_details_in_the_field_in_profile_screen(String name) {
		profile.enterDisplayName(name);
	}

	@Then("user save the updated details successfully")
	public void user_save_the_updated_details_successfully() {
		Logger.log("User successfully changed the display name");
	}

	@Then("user on clicking the adult profile icon")
	public void user_on_clicking_the_adult_profile_icon() {
		login.select_Adultprofile();
	}

	@Then("user should be able to switch between the profiles by clicking on the particular profile")
	public void user_should_be_able_to_switch_between_the_profiles_by_clicking_on_the_particular_profile() {
		Logger.log("User sucessfully switched to profiles");
	}

	@Then("user should be able to view the back icon to navigate back from profile edit page")
	public void user_should_be_able_to_view_the_back_icon_to_navigate_back_from_profile_edit_page() {
		Assert.assertTrue(profile.backIcon.isDisplayed());
		profile.clickBackIcon();
	}

	@Then("user should be able to view the back icon to navigate back from profile edit page for adult user with kidszone subscription")
	public void user_should_be_able_to_view_the_back_icon_to_navigate_back_from_profile_edit_page_for_adult_user_with_kidszone_subscription() {
		Assert.assertTrue(profile.backIcon.isDisplayed());
		WaitForWebElement(profile.libraryPage);
		Assert.assertTrue(profile.libraryPage.isDisplayed());
		Logger.log("User navigate to previous screen by clicking the back button");
	}

	@When("user made any changes")
	public void user_made_any_changes() {
		profile.changeDispName();
	}

	@When("user tap on save option")
	public void user_tap_on_save_option() {
		profile.clickSaveProfile();
	}

	@Then("user should stay on the edit profile page when user click on save option")
	public void user_should_stay_on_the_edit_profile_page_when_user_click_on_save_option() {
		Assert.assertTrue(profile.profileEditSection.isDisplayed());
		Logger.log("User stayed on the same page after clicking on the save option");
	}

	@When("user tap on add icon in manage profile screen")
	public void user_tap_on_add_icon_in_manage_profile_screen() {
		profile.clickPlusIcon();
	}

		@Then("user should be able to view the back icon to navigate back from Add a profile screen")
	public void user_should_be_able_to_view_the_back_icon_to_navigate_back_from_add_a_profile_screen() {
		Assert.assertTrue(profile.backIcon.isDisplayed());
		profile.clickBackIcon();
		WaitForWebElement(profile.Manageprofile_plusIcon);
		Assert.assertTrue(profile.Manageprofile_plusIcon.isDisplayed());
		Logger.log("User navigate to previous screen by clicking the back button");
	}

	@When("user tap on add a teen option")
	public void user_tap_on_add_a_teen_option() {
		profile.clickPlusIcon();
		profile.clickAddATeen();
	}

	@When("user tap on select an avatar option")
	public void user_tap_on_select_an_avatar_option() {
		profile.clickAvatar();
	}

	@Then("user should view the back icon to navigate back from select avatar screen")
	public void user_should_view_the_back_icon_to_navigate_back_from_select_avatar_screen() {
		visibilityWait(profile.backIcon);
		Assert.assertTrue(profile.backIcon.isDisplayed());
		profile.clickBackIcon();
//		visibilityWait(profile.addTeenPage);
//		Assert.assertTrue(profile.addTeenPage.isDisplayed());
		Logger.log("User navigate to previous screen by clicking the back button");
	}

	@When("user tap on add a kid option")
	public void user_tap_on_add_a_kid_option() {
		profile.clickPlusIcon();
		profile.clickAddAKid();
	}

	@When("user tap on adult option")
	public void user_tap_on_adult_option() {
		login.click_Adultprofile();
	}

	@When("user tap on edit icon in profile")
	public void user_tap_on_edit_icon_in_profile() {
		WaitForWebElement(profile.profileEditSection);
		profile.clickEditProfileAvatar();
	}

	@Then("user should view the back icon to navigate back from select avatar and upload photo screen")
	public void user_should_view_the_back_icon_to_navigate_back_from_select_avatar_and_upload_photo_screen() {
//		Assert.assertTrue(profile.backIcon.isDisplayed());
//		profile.clickBackIcon();
		visibilityWait(profile.uploadphoton_AddaTeen);
		Assert.assertTrue(profile.uploadphoton_AddaTeen.isDisplayed());
		Logger.log("User navigate to previous screen by clicking the back button");
		profile.clickBackIcon();
		
	}

	@Then("user should view the back icon to navigate back to  profile details page from select avatar screen")
	public void user_should_view_the_back_icon_to_navigate_back_to_profile_details_page_from_select_avatar_screen() {
		Assert.assertTrue(profile.avatarPage.isDisplayed());
		Assert.assertTrue(profile.backIcon.isDisplayed());
		profile.clickBackIcon();
		WaitForWebElement(profile.profileEditSection);
		Assert.assertTrue(profile.profileEditSection.isDisplayed());
		Logger.log("User navigate to previous screen by clicking the back button");
	}

	@Given("user already have the five profiles under the patron")
	public void user_already_have_the_five_profiles_under_the_patron() {
		Assert.assertEquals(profile.profileDetails.size(), 5);
	}

	@Given("user should not able to view + icon in profile screen")
	public void user_should_not_able_to_view_icon_in_profile_screen() {
		Assert.assertEquals(isElementPresent(profile.Manageprofile_plusIcon), false);
	}

	@Given("User able to view {string} and {string} in profile screen")
	public void user_able_to_view_and_in_profile_screen(String string, String string2) {
		Assert.assertEquals(profile.profileVerbiage.getText().contains(string), true);
		Assert.assertEquals(profile.profileVerbiage.getText().contains(string2), true);
	}

	@Given("user should be able to view profile icons wrap based on the breakpoint")
	public void user_should_be_able_to_view_profile_icons_wrap_based_on_the_breakpoint() {
		Logger.log("UI Validation done manually");
	}

	@Given("user should be able to view only one profile selected at a time")
	public void user_should_be_able_to_view_only_one_profile_selected_at_a_time() {
		Logger.log("Selection Process done Manually");
	}

	@When("user enters invalid mail id into the check box {string}")
	public void user_enters_invalid_mail_id_into_the_check_box(String test) {
		profile.enterEmailID(test);
	}

	@Then("user should be able to view the in line error message {string}")
	public void user_should_be_able_to_view_the_in_line_error_message(String string) {
//		visibilityWait(profile.profileEditSection);
		ClickOnWebElement(profile.emailDescription);
		visibilityWait(profile.invalidEmailIDVerb);
		Assert.assertEquals(profile.invalidEmailIDVerb.isDisplayed(), true);
		Assert.assertEquals(profile.invalidEmailIDVerb.getText().contains(string), true);
//		DriverManager.getDriver().navigate().back();
		waitFor(2000);
//		ClickOnWebElement(profile.saveAlertPopUpLeave);
//		visibilityWait(profile.libraryPage);
	}
	
	@Then("Axis user should be able to view the in line error message {string}")
	public void axis_user_should_be_able_to_view_the_in_line_error_message(String string) {
		jsClick(profile.Createprofile_input_displayName);
		visibilityWait(profile.axiskids_invalidEmailIDVerb);
		Assert.assertEquals(profile.axiskids_invalidEmailIDVerb.isDisplayed(), true);
		Assert.assertEquals(profile.axiskids_invalidEmailIDVerb.getText().contains(string), true);
		waitFor(2000);
	}

	@Given("user placed hold any title which is not available to checkout")
	public void user_placed_hold_any_title_which_is_not_available_to_checkout() {
		Logger.log("User have the title in Hold");
	}

	@Given("user should be able to click the flag to enable the notification")
	public void user_should_be_able_to_click_the_flag_to_enable_the_notification() {
		profile.clickEmailNotify();
	}

	@When("user should be able to click the save cta")
	public void user_should_be_able_to_click_the_save_cta() {
		profile.clickSaveProfile();
	}

	@Then("user should be able to recive title available from hold email notification by enabling the {string} flag from my profile screen if the title is available to checkout")
	public void user_should_be_able_to_recive_title_available_from_hold_email_notification_by_enabling_the_flag_from_my_profile_screen_if_the_title_is_available_to_checkout(
			String string) {
//		Assert.assertTrue(profile.enableEmailNotifyCheckBox.isSelected());
		Logger.log("Email Notification will be verified Manually");
	}

	@Given("user should be able to click the flag to enable the notification for Auto Checkout")
	public void user_should_be_able_to_click_the_flag_to_enable_the_notification_for_auto_checkout() {
		profile.autoCheckOut();
	}

	@Given("user request to purchase for the library")
	public void user_request_to_purchase_for_the_library() {
		Logger.log("User requested some of the titles for Purchase Request");
	}

//	@Given("user should be able to click the flag to enable the notification for Purchase Request")
//	public void user_should_be_able_to_click_the_flag_to_enable_the_notification_for_purchase_request() {
//		profile.purReqNotify();
//	}

	@Then("user should be able to recive the title added to the library from puchase request notification by enabling the {string} flag from my profile screen if the title was added into the library")
	public void user_should_be_able_to_recive_the_title_added_to_the_library_from_puchase_request_notification_by_enabling_the_flag_from_my_profile_screen_if_the_title_was_added_into_the_library(
			String string) {
		Logger.log("Email Notification will be verified Manually");
	}

	@Then("user should be able to recive the auto checkout notification by enabling the {string} flag from my profile screen if the title checked out automaticaly from hold when it was available to checkout")
	public void user_should_be_able_to_recive_the_auto_checkout_notification_by_enabling_the_flag_from_my_profile_screen_if_the_title_checked_out_automaticaly_from_hold_when_it_was_available_to_checkout(
			String string) {
		Logger.log("Email Notification will be verified Manually");
	}

	@Then("user should be able to view the error popup with {string} with {string} cta")
	public void user_should_be_able_to_view_the_error_popup_with_with_cta(String string, String string2) {
		Assert.assertEquals(profile.errorAlertEmailPopUp.isDisplayed(), true);
		Assert.assertEquals(profile.errorAlertEmailPopUp.getText().contains(string), true);
		Assert.assertEquals(profile.errorAlertEmailPopUp.getText().contains(string2), true);
		Assert.assertTrue(profile.errorAlertEmailPopUpCloseCTA.isDisplayed());
		jsClick(profile.errorAlertEmailPopUpCloseCTA);
	}

	@Then("user navigate back to library page to by clicking leave page in pop up")
	public void user_navigate_back_to_library_page_to_by_clicking_leave_page_in_pop_up() {
		waitFor(2000);
		profile.clickBackIcon();
		jsClick(profile.saveAlertPopUpLeave);
		visibilityWait(profile.Nav_profileManagementPage);
		//WaitForWebElement(profile.libraryPage);
	}

	@Then("user should not be able to view the error popup with {string} with {string} cta")
	public void user_should_not_be_able_to_view_the_error_popup_with_with_cta(String string, String string2) {
		WaitForWebElement(profile.errorAlertEmailPopUp);
		Assert.assertEquals(isElementPresent(profile.errorAlertEmailPopUp), true);
	}

	@Then("user should be able to view profile detail page with Automatically checkout checkbox")
	public void user_should_be_able_to_view_profile_detail_page_with_automatically_checkout_checkbox() {
		Assert.assertEquals(profile.AutomaticallyCheckout_checkbox.isDisplayed(), true);

	}

	@Then("user should be able to view updated verbiage from {string} to {string}")
	public void user_should_be_able_to_view_updated_verbiage_from_to(String string, String string2) {
		Assert.assertEquals(profile.AutomaticallyCheckout_checkbox.getText().contains(string2), true);
	}
	
	@Then("user click on tool tip for Auto checkout available hold and view the updated verbiage for {string}")
	public void user_click_on_tool_tip_for_auto_checkout_available_hold_and_view_the_updated_verbiage_for(String verbiage) {
		profile.click_AutocheckoutTooltip(verbiage);
	}

	@Then("user should be able to view profile detail page with Automatically checkout checkbox for disable state")
	public void user_should_be_able_to_view_profile_detail_page_with_automatically_checkout_checkbox_for_disable_state() {
	  Assert.assertTrue(profile.verify_DisableStateAutocheckout());
	}
	
	@Then("user should be able to view profile detail page with My Shelf as home page")
	public void user_should_be_able_to_view_profile_detail_page_with_my_shelf_as_home_page() {
		Assert.assertEquals(profile.myShelfAsHome.isDisplayed(), true);
	}

	@Then("user should be able to view updated verbiage from Set My Shelf page as my default landing page to {string}")
	public void user_should_be_able_to_view_updated_verbiage_from_set_my_shelf_page_as_my_default_landing_page_to(
			String string) {
		Assert.assertEquals(profile.myShelfAsHome.getText().contains(string), true);
	}

	@Then("user should be able to enable an already set PIN by toggling {string} CTA")
	public void user_should_be_able_to_enable_an_already_set_pin_by_toggling_cta(String Pin) {
		profile.clickDisablePin();
		profile.Enter_setPin(Pin);
		profile.click_submit();
		profile.disablePinOK();

	}

	@Then("user should be able to enable an already set PIN by toggling {string} CTA {string}")
	public void user_should_be_able_to_enable_an_already_set_pin_by_toggling_cta(String string, String pin) {
		profile.click_EnableprofilePin();
		// profile.click_EnableprofilePin(pin);
	}

//	@Then("user should be able to enable an already set PIN by toggling {string} CTA")
//	public void user_should_be_able_to_enable_an_already_set_pin_by_toggling_cta(String string) {
//		profile.click_EnableprofilePin();
//	}

	@Then("user should be able to disable an already set PIN by toggling {string} CTA with pin {string}")
	public void user_should_be_able_to_disable_an_already_set_pin_by_toggling_cta_with_pin(String string, String pin) {
		profile.clickDisablePin();
		profile.disablePinOK();
		profile.Enter_setPin(pin);
		profile.click_submit();
//		profile.clickDisablePin();
//		profile.disableProcess(pin);
//		profile.disablePinOK();
//		Assert.assertEquals(profile.enableProfilePin.getText().contains(string), true);
	}

	@Then("user should be able to view {string} CTA only")
	public void user_should_be_able_to_view_cta_only(String string) {
		if (isElementPresent(profile.AlreadyEnablePin)) {
			visibilityWait(profile.Enablepin_txt);
			Assert.assertEquals(profile.Enablepin_txt.getText().contains(string), true);
		}
	}

	@When("user enter the teen profile with the pin {string}")
	public void user_enter_the_teen_profile_with_the_pin(String pin) {
		profile.enterTeenProfile(pin);
	}

	@Then("user save the updated profile details")
	public void user_save_the_updated_profile_details() {
		profile.clickSaveProfile();
	}

	@Then("system should not show Disable PIN CTA after enable parental pin")
	public void system_should_not_show_disable_pin_cta_after_enable_parental_pin() {
		Logger.log("System not shows the Disable Pin for disbaling the Pin");
	}

	@When("user enter profile pin {string} to access the profile")
	public void user_enter_profile_pin_to_access_the_profile(String pin) {
		profile.enterPin(pin);
	}

	@Then("user able to view the adult mail id by default in edit profile screen with non editable state")
	public void user_able_to_view_the_adult_mail_id_by_default_in_edit_profile_screen_with_non_editable_state() {
		Logger.log("User able to view the Adult Email ID in Non-Editable in profile state");
	}

	@Then("user should be able to recive title available from hold email notification to adult mail id by enabling the {string} flag from my profile screen if the title is available to checkout")
	public void user_should_be_able_to_recive_title_available_from_hold_email_notification_to_adult_mail_id_by_enabling_the_flag_from_my_profile_screen_if_the_title_is_available_to_checkout(
			String string) {
		Assert.assertTrue(profile.AutomaticallyCheckout_checkbox.isEnabled());
		Logger.log("Email Alerts will be verified Manually");
	}

	@Then("user should be able to recive the title added to the library from puchase request notification to adult mail id by enabling the {string} flag from my profile screen if the title was added into the library")
	public void user_should_be_able_to_recive_the_title_added_to_the_library_from_puchase_request_notification_to_adult_mail_id_by_enabling_the_flag_from_my_profile_screen_if_the_title_was_added_into_the_library(
			String string) {
		Logger.log("Email Alerts will be verified Manually");
	}

	@Given("user enabled the auto checkout in preference")
	public void user_enabled_the_auto_checkout_in_preference() {
		profile.autoCheckOut();
	}

	@Then("user should be able to recive the auto checkout notification to adult mail id by enabling the {string} flag from my profile screen if the title checked out automaticaly from hold when it was available to checkout")
	public void user_should_be_able_to_recive_the_auto_checkout_notification_to_adult_mail_id_by_enabling_the_flag_from_my_profile_screen_if_the_title_checked_out_automaticaly_from_hold_when_it_was_available_to_checkout(
			String string) {
		Assert.assertTrue(profile.enableEmailNotifyCheckBox.isSelected());
		Logger.log("Email Alerts will be verified Manually");
	}

	@Given("user should be able to disable the flag that enable the email notification")
	public void user_should_be_able_to_disable_the_flag_that_enable_the_email_notification() {
		profile.disableEmailNotify();
	}

	@Then("user should not be able to view the notifications by the email")
	public void user_should_not_be_able_to_view_the_notifications_by_the_email() {
		Assert.assertFalse(profile.enableEmailNotifyCheckBox.isSelected());
		Logger.log("Email Alerts will be verified Manually");
	}

	@Then("{string} Option should not be Editable for the teen profile")
	public void option_should_not_be_editable_for_the_teen_profile(String text) {
		Assert.assertEquals(profile.AutomaticallyCheckout_checkbox.isDisplayed(), true);
		Logger.log("Automatically Checkout checkbox is not editable for a Teen profile");
	}

	@Then("{string} Option should not be Editable for the kid profile")
	public void option_should_not_be_editable_for_the_kid_profile(String string) {
		Assert.assertEquals(profile.autoCheckoutCheckBox.isSelected(), false);
		Logger.log("Automatically Checkout checkbox is not editable for a Kid profile");
	}

	@Then("Automatically should have the tool tip with info with verbiage {string}.")
	public void automatically_should_have_the_tool_tip_with_info_with_verbiage(String verbiage) {
		profile.clickAutoCheckoutToolTip(verbiage);
	}

	@Given("user already set the profile pin for the adult profile")
	public void user_already_set_the_profile_pin_for_the_adult_profile() {
		visibilityWait(profile.profilePin_popup);
		Logger.log("Pin Enable already in Adult profile");
	}

	@Given("user provides {string} to pin field two times")
	public void user_provides_to_pin_field_two_times(String pin) {
		profile.inValidPinTwoTimes(pin);
	}

	@When("user tap on teen option in profile")
	public void user_tap_on_teen_option_in_profile() {
		login.click_Teenprofile();
	}

	@When("user provides {string} in third attempt")
	public void user_provides_in_third_attempt(String pin) {
		profile.correctPinNav(pin);
		login.preferenceScreen_popup();
		Logger.log("User succesfully navigated to profile settings page after entering correct pin in third attempt");
	}

	@Then("user should be able to manage the profile successfully")
	public void user_should_be_able_to_manage_the_profile_successfully() {
		Assert.assertEquals(profile.profileEditSection.isDisplayed(), true);
	}

	@Given("user provides {string} to pin field three times")
	public void user_provides_to_pin_field_three_times(String pin) {
		profile.inValidPinThreeTimes(pin);
	}

	@Given("user will see a notification {string}")
	public void user_will_see_a_notification(String string) {
		Assert.assertEquals(profile.resetPinScreen.getText().contains(string), true);
	}

	@Then("user should be able to view reset pin via OTP")
	public void user_should_be_able_to_view_reset_pin_via_otp() {
		profile.clickResetPinCta();
	}

	@Then("user provide {string} in the otp field")
	public void user_provide_in_the_otp_field(String otp) {
		profile.inValidOtp(otp);
	}

	@Then("user should be restricted from reset option and verbiage message is displayed {string}")
	public void user_should_be_restricted_from_reset_option_and_verbiage_message_is_displayed(String string) {
		Assert.assertEquals(profile.errorMsgInvalidOtp.getText().contains(string), true);
	}

	@Then("user should be able to view notification that lets them know they will receive an email for reset PIN if they input the wrong otp")
	public void user_should_be_able_to_view_notification_that_lets_them_know_they_will_receive_an_email_for_reset_pin_if_they_input_the_wrong_otp() {
		Logger.log("Email Verification will be done manually");
	}

	@When("user change the some settings in the profile edit screen")
	public void user_change_the_some_settings_in_the_profile_edit_screen() {
		profile.changeDispName();
	}

	@When("user tap on the back cta in the header")
	public void user_tap_on_the_back_cta_in_the_header() {
		profile.clickBackIcon();
	}

	@Then("user should be able to view the save alert message {string} with CTA - Cancel\\/Leave Page")
	public void user_should_be_able_to_view_the_save_alert_message_with_cta_cancel_leave_page(String text) {
		WaitForWebElement(profile.saveAlertPopUp);
		Assert.assertEquals(profile.saveAlertPopUpTxt.getText().contains(text), true);
		Assert.assertTrue(profile.saveAlertPopUpCancel.isDisplayed());
	}

	@Then("user tap on the ok cta without saving any changes")
	public void user_tap_on_the_ok_cta_without_saving_any_changes() {
//		profile.clickBackIcon();
		WaitForWebElement(profile.saveAlertPopUp);
		jsClick(profile.saveAlertPopUpLeave);
		waitFor(5000);
		Logger.log("User able to navigate back without saving any changes");
	}

	@Then("user tap on the cancel cta popup getting dismissed")
	public void user_tap_on_the_cancel_cta_popup_getting_dismissed() {
		jsClick(profile.saveAlertPopUpCancel);
		waitFor(2000);
	}

	@When("user selects forgot pin cta on pin screen")
	public void user_selects_forgot_pin_cta_on_pin_screen() {
		profile.clickForgotPinCta();
	}

	@Then("user should be able to view send OTP cta")
	public void user_should_be_able_to_view_send_otp_cta() {
		Assert.assertEquals(profile.resetScreenSendPinCTA.isDisplayed(), true);
	}

	@Then("user should be able to view popup with Header: Reset PIN  Body: {string}")
	public void user_should_be_able_to_view_popup_with_header_reset_pin_body(String string) {
		Assert.assertEquals(profile.resetPinScreen.getText().contains(string), true);
	}

	@Then("user will receive an email for reset PIN if they input the PIN that the Adult set up")
	public void user_will_receive_an_email_for_reset_pin_if_they_input_the_pin_that_the_adult_set_up() {
		Logger.log("Email Verfication will be done Manually");
	}

	@Then("user should be able to receive an email from library giving them the one time PIN which they can use to reset new PIN")
	public void user_should_be_able_to_receive_an_email_from_library_giving_them_the_one_time_pin_which_they_can_use_to_reset_new_pin() {
		Logger.log("Email Verfication will be done Manually");
	}

	@Then("user will receive an email for reset PIN if they input the incorrect PIN {string} that the Adult set up")
	public void user_will_receive_an_email_for_reset_pin_if_they_input_the_incorrect_pin_that_the_adult_set_up(
			String pin) {
		profile.inValidOtp(pin);
	}

	@Then("user should be able to view the error message for the invalid")
	public void user_should_be_able_to_view_the_error_message_for_the_invalid() {
		Assert.assertEquals(profile.errorMsgInvalidOtp.isDisplayed(), true);
	}

	@When("user close the reset pin popup")
	public void user_close_the_reset_pin_popup() {
		WaitForWebElement(profile.resetPinScreen);
		profile.closeResetPinScreen();
	}

	@Then("user should be able to enter pin for n number of times")
	public void user_should_be_able_to_enter_pin_for_n_number_of_times() {
		Assert.assertTrue(profile.profilePin_popup.isDisplayed());
		Assert.assertTrue(profile.profilePin_popup.getText().contains("Profile Management PIN"));
		profile.enterPin("1234");
		jsClick(profile.setPinDoneButton);
		waitFor(5000);
		WaitForWebElement(profile.libraryPage);
		Logger.log("User again prompted to enter the PIN");
	}

	@When("user able to set the pin {string} and enable for a adult")
	public void user_able_to_set_the_pin_and_enable_for_a_adult(String pin) {
		profile.enableProfilePin(pin);
	}

	@When("user able to set the pin {string} and enable for a teen")
	public void user_able_to_set_the_pin_and_enable_for_a_teen(String pin) {
		profile.enableProfilePin(pin);
	}

	@Then("user should be able to view and click on send pin CTA reset pin screen via OTP")
	public void user_should_be_able_to_view_and_click_on_send_pin_cta_reset_pin_screen_via_otp() {
		profile.clickSendPinCta();
	}

	@Then("user enter the pin {string} to enable the pin again")
	public void user_enter_the_pin_to_enable_the_pin_again(String pin) {
		profile.enterPin(pin);
		Assert.assertTrue(profile.setPinDoneButton.isDisplayed());
		jsClick(profile.setPinDoneButton);
		profile.enterPin(pin);
		jsClick(profile.setPinDoneButton);
		inVisibilityWait(profile.setPinDoneButton);
	}
	
	@Given("user tap on kid option in profile")
	public void user_tap_on_kid_option_in_profile() {
	    login.click_Kid();
	}
	
	//197382
	
	@Then("user enter the kid profile with the pin {string}")
	public void user_enter_the_kid_profile_with_the_pin(String pin) {
	    profile.enterKidProfile(pin);
	}
	
	

}