package parallel;

import java.util.List;
import java.util.Map;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Login;
import pom.kidszone.Loginpageview;

public class Loginwithregistration_Stepdef {

	static ExcelReader reader = new ExcelReader();
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());


	@Given("user launches the application which has id and pin login type")
	public void user_launches_the_application_which_has_id_and_pin_login_type() throws Exception {
		login.Login_PrefixWithPin();
		loginpageUpdatedui.click_loginPage();
	}

	@When("user navigates to login screen")
	public void user_navigates_to_login_screen() throws Throwable {
		Assert.assertTrue(loginpageUpdatedui.viewlogin_Page());
	}

	@Then("user should be able to view updated login screen with {string} and {string}")
	public void user_should_be_able_to_view_updated_login_screen_with_something_and_something(String libraryid,
			String password) throws Throwable {
		// loginpageUpdatedui.updated_login();
		Logger.log("user is in login Pop up page");
		loginpageUpdatedui.enterIDandPassword(libraryid, password);
	}

	@When("user navigates to clicks on forgot password")
	public void user_navigates_to_clicks_on_forgot_password() throws Throwable {
		Thread.sleep(2000);
		loginpageUpdatedui.clickForgotpassword();
	}

	@Then("user should be able to view updated password recovery screen")
	public void user_should_be_able_to_view_updated_password_recovery_screen() {
		Assert.assertTrue(loginpageUpdatedui.view_passwordRecovery());
	}

	@When("user navigates to login screen on selecting library")
	public void user_navigates_to_login_screen_on_selecting_library() {
		Logger.log("User navigates to login screen on selecting library");
	}

	@Then("user should be able to view updated login screen only with libraryid and without pin")
	public void user_should_be_able_to_view_updated_login_screen_only_with_libraryid_and_without_pin() {
		// Assert.assertTrue(loginpageUpdatedui.view_libraryidonly());
		Logger.log("User able to view updated login screen only with libraryid and without pin");
	}

	@When("user enters the {string} and {string} and Clicks on sign in button and navigate to registration screen")
	public void user_enters_the_and_and_clicks_on_sign_in_button_and_navigate_to_registration_screen(String loginid,
			String pin) {
		loginpageUpdatedui.enter_loginwithPin(loginid, pin);
	}

	@Then("user should be able to view updated user registration screen")
	public void user_should_be_able_to_view_updated_user_registration_screen() {
		Assert.assertTrue(loginpageUpdatedui.getRegister_txt_Register().isDisplayed());
		Logger.log("User is able to see registration screen");
	}

	@When("user enters the {string} Clicks on sign in button and navigate to registration screen")
	public void user_enters_the_clicks_on_sign_in_button_and_navigate_to_registration_screen(String loginid) {
		loginpageUpdatedui.enter_loginIdonly(loginid);
	}

	@Then("user should be able to view updated only Login ID required registration screen")
	public void user_should_be_able_to_view_updated_only_login_id_required_registration_screen() {
		Assert.assertTrue(loginpageUpdatedui.getRegister_txt_Register().isDisplayed());
		Logger.log("User is able to see only Login ID required registration screen");
	}

}
