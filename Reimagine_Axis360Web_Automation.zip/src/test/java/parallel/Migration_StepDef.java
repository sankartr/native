package parallel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.regex.Pattern;

import api.searchTitlev8.SearchTitleResponse;
import api.searchTitlev8.SearchTitleResult;
import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import api.APIClient;
import api.searchTitlev8.SearchTitleResult;
import api.searchTitlev8.Title;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import parallel.api.stepDefinition.BrowseSearchSteps;
import pom.kidszone.BrowseBySearch;
import pom.kidszone.Login;
import pom.kidszone.Migration;
import pom.kidszone.Profile;
import pom.kidszone.SearchResults_Vbooks;
import pom.kidszone.TitleDetail;

public class Migration_StepDef extends CommonAction {
	static ExcelReader reader = new ExcelReader();
	Login login = new Login(DriverManager.getDriver());
	Migration migration = new Migration(DriverManager.getDriver());
	Profile profile = new Profile(DriverManager.getDriver());
	SearchResults_Vbooks search = new SearchResults_Vbooks(DriverManager.getDriver());
	TitleDetail title = new TitleDetail(DriverManager.getDriver());
	BrowseBySearch browsesearch = new BrowseBySearch(DriverManager.getDriver());

	BrowseSearchSteps browse =new BrowseSearchSteps();
	
	private List<String> extractedIsbnValues = new ArrayList<>();
	private static final Pattern p = Pattern.compile("/[\\d]+");
	public static int get_eBookcount;
	public static int get_eAudiocount;
	public static int get_CategoryCount;

	private List<SearchTitleResponse> apiResponses;
	HashMap<String, String> isbnAudienceCodeMap = new HashMap<String, String>();
	String ebookResultCount;
	String audioResultCount;

	@Then("verify the {string} field availability on profile detail page")
	public void verify_the_field_availability_on_profile_detail_page(String string) {
		javascriptScroll(migration.diplayCheckHisCheckBox);
		Assert.assertTrue(migration.diplayCheckHisCheckBox.isDisplayed());
	}

	@Then("user select the {string} checkbox")
	public void user_select_the_checkbox(String string) {
		migration.clickDisplayCheckoutHistory();
	}

	@Then("user unselect the {string} checkbox and verify the alert popup")
	public void user_unselect_the_checkbox_and_verify_the_alert_popup(String string) {
		migration.clickDisplayCheckoutHistory();
		WaitForWebElement(migration.displayCheckoutPopUp);
	}

	@Then("user able to the see the title {string}, description {string} and {string} and {string} CTAs")
	public void user_able_to_the_see_the_title_description_and_and_ct_as(String title, String desc, String disable,
			String cancel) {
		Assert.assertTrue(migration.displayCheckoutPopUp.isDisplayed());
		Assert.assertTrue(migration.displayCheckoutPopUpDesc.isDisplayed());
		Assert.assertTrue(migration.displayCheckoutPopUpHeading.getText().contains(title));
		System.out.println("ZZZZ" + migration.displayCheckoutPopUpDesc.getText());
		System.out.println(migration.displayCheckoutPopUpDesc);
//		Assert.assertTrue(migration.displayCheckoutPopUpDesc.getText().contains(desc));
		Assert.assertTrue(migration.displayCheckoutPopUpDesc.isDisplayed());
		Assert.assertTrue(migration.displayCheckoutPopUpCancel.isDisplayed());
	}

	@Then("user click {string} from the Alert poup")
	public void user_click_from_the_alert_poup(String cancel) {
		Assert.assertTrue(migration.displayCheckoutPopUpCancel.getText().contains(cancel));
		migration.clickDisplayCheckoutCancel();
	}

	@Then("again unselect the {string} checkbox and verify the alert popup")
	public void again_unselect_the_checkbox_and_verify_the_alert_popup(String string) {
		migration.clickDisplayCheckoutHistory();
		WaitForWebElement(migration.displayCheckoutPopUp);
	}

	@Then("again unselect the {string} Insights and Badges checkbox and verify the alert popup")
	public void again_unselect_the_insights_and_badges_checkbox_and_verify_the_alert_popup(String string) {
		migration.clickDisplayInsightBadges();
		WaitForWebElement(migration.displayCheckoutPopUp);
	}

	@Then("user click {string} from the alert popup")
	public void user_click_from_the_alert_popup(String disable) {
		Assert.assertTrue(migration.displayCheckoutPopUpDisable.getText().contains(disable));
		migration.clickDisplayCheckoutDisable();
	}

	@Then("{string} checkbox unselected")
	public void checkbox_unselected(String string) {
		Logger.log("User Disables the Display Checkout History");
	}

	@When("user click on publication title navigate to detail screen")
	public void user_click_on_publication_title_navigate_to_detail_screen() {
		migration.clickNewsPaperTitleCard();
	}

	@When("user click on publication title navigate to detail screen from Library page")
	public void user_click_on_publication_title_navigate_to_detail_screen_from_library_page() {
		visibilityWait(migration.SearchResult_publicationtxt);
		migration.clickNewsPaperTitleCardLib();
	}

	@Then("user should view with publication name, country details, language , Read now CTA, Select issue CTA")
	public void user_should_view_with_publication_name_country_details_language_read_now_cta_select_issue_cta() {
		migration.verifyNewsPaperDetails();
	}

	@Then("user should view the multiple country on publication detail screen if available")
	public void user_should_view_the_multiple_country_on_publication_detail_screen_if_available() {
		migration.multipleCountry();
	}

	@Then("user clicking on the down arrow icon the countries list expand and get displayed")
	public void user_clicking_on_the_down_arrow_icon_the_countries_list_expand_and_get_displayed() {
		migration.multipleCountryDropDown();
	}

	@Then("user clicking on up arrow sign it will contract to show less")
	public void user_clicking_on_up_arrow_sign_it_will_contract_to_show_less() {
		migration.multipleCountryUpArrow();
	}

	@When("user click on see all cta in {string} carousel and navigate to tier1 screen")
	public void user_click_on_see_all_cta_in_carousel_and_navigate_to_tier1_screen(String string) {
		migration.clickSeeAllReaderLib();
	}

	@When("user click on see all cta any carousel and naviagate to tier2 screen")
	public void user_click_on_see_all_cta_any_carousel_and_naviagate_to_tier2_screen() {
		migration.clickSeeAllReaderTier1();
	}

	@When("user select the {string} from category section")
	public void user_select_the_from_category_section(String category) {
		migration.clickNewsPaperCategory();
		search.Click_Searchbtn();
	}

	@When("user should view the multiple country availability on listed for publication cards with three dot")
	public void user_should_view_the_multiple_country_availability_on_listed_for_publication_cards_with_three_dot() {
		Assert.assertEquals(migration.multipleCountry_Ribbon.isDisplayed(), true);
		// Assert.assertEquals(migration.mutipleCountryRefPub.isDisplayed(), true);
	}

	@When("user clicks publication carousel See All CTA")
	public void user_clicks_publication_carousel_see_all_cta() {
		migration.clickSeeAllPubSearchResult();
	}

	@Then("user view ellipses {string} when the countries names are longer or more than one country name present for the publication")
	public void user_view_ellipses_when_the_countries_names_are_longer_or_more_than_one_country_name_present_for_the_publication(
			String string) {
		Logger.log("Three Dots will be validated in UI");
	}

	@Then("country names should be separated by {string} when more than one country is present for the publication on the Search Result page")
	public void country_names_should_be_separated_by_when_more_than_one_country_is_present_for_the_publication_on_the_search_result_page(
			String string) {
		Assert.assertEquals(migration.mutipleCountryRefPub.isDisplayed(), true);
		Assert.assertEquals(migration.countryText.getText().contains("|"), true);
		Logger.log("User able to view Separator Line for the title which is larger");
	}

	@When("user should view the multiple country availability on listed for article cards with three dot")
	public void user_should_view_the_multiple_country_availability_on_listed_for_article_cards_with_three_dot() {
		Assert.assertEquals(migration.mutipleCountryRefPub.isDisplayed(), true);
	}

	@When("user clicks article carousel See All CTA")
	public void user_clicks_article_carousel_see_all_cta() {
		migration.clickSeeAllArtSearchResult();
	}

	@Then("user view ellipses {string} when the countries names are longer or more than one country name present for the article")
	public void user_view_ellipses_when_the_countries_names_are_longer_or_more_than_one_country_name_present_for_the_article(
			String string) {
		Logger.log("Three Dots will be validated in UI");
	}

	@Then("country names should be separated by {string} when more than one country is present for the article on the Search Result page")
	public void country_names_should_be_separated_by_when_more_than_one_country_is_present_for_the_article_on_the_search_result_page(
			String string) {
		Assert.assertEquals(migration.mutipleCountryRefPub.getText().contains("|"), true);
		Logger.log("User able to view Separator Line for the title which is larger");
	}

	@Then("verify the {string} Display Insight and Badges field availability on profile detail page")
	public void verify_the_display_insight_and_badges_field_availability_on_profile_detail_page(String string) {
		javascriptScroll(migration.diplayInsBadCheckBox);
		Assert.assertTrue(migration.diplayInsBadCheckBox.isDisplayed());
	}

	@Then("user select the {string} Display Insight and Badges checkbox")
	public void user_select_the_display_insight_and_badges_checkbox(String string) {
		migration.clickDisplayInsightBadges();
	}

	@Then("user unselect the {string} Display Insight and Badges checkbox and verify the alert popup")
	public void user_unselect_the_display_insight_and_badges_checkbox_and_verify_the_alert_popup(String title) {
		migration.clickDisplayInsightBadges();
		WaitForWebElement(migration.displayCheckoutPopUp);
	}

	@Then("{string} Display Insight and Badges checkbox unselected")
	public void display_insight_and_badges_checkbox_unselected(String string) {
		Logger.log("User Disables the Display Insights & Badges");
	}

	@Then("user click outside from the Alert poup")
	public void user_click_outside_from_the_alert_poup() {
		migration.clickOutsidePopUpArea();
	}

	@Then("user must be on same screen \\(My profile detail screen) without disable the insights & badges")
	public void user_must_be_on_same_screen_my_profile_detail_screen_without_disable_the_insights_badges() {
		inVisibilityWait(migration.displayCheckoutPopUp);
		Assert.assertTrue(profile.profileEditSection.isDisplayed());
		Logger.log("User Still on the same page");
	}

	@Then("user should view newspapers & magazines carousel in the featured banner")
	public void user_should_view_newspapers_magazines_carousel_in_the_featured_banner() {
		Assert.assertTrue(migration.featuredBannerPubTier1.isDisplayed());
	}

	@Then("user should view First Magazine \\(Highest Rank) then Newspaper \\(Highest rank)")
	public void user_should_view_first_magazine_highest_rank_then_newspaper_highest_rank() {
		migration.displayedOrder();
	}

	@Then("user should view these {int} newspapers & magazines placed in alternate fashion")
	public void user_should_view_these_newspapers_magazines_placed_in_alternate_fashion(Integer int1) {
		Logger.log("User able to view the Casrousel in Alternate Fashion");
	}

	@Then("user should not view featured banner in tier1 screen if block not available in drupal")
	public void user_should_not_view_featured_banner_in_tier1_screen_if_block_not_available_in_drupal() {
		Assert.assertFalse(isElementPresent(migration.featuredBannerPubTier1));
	}

	@When("if user already saved some interest survey")
	public void if_user_already_saved_some_interest_survey() {
		Logger.log("User already saved the Interest Survey in his Profile");
	}

	@When("user click on menu and select {string}")
	public void user_click_on_menu_and_select(String string) {
		login.click_NewMenu();
		login.click_Myshelf();
	}

	@When("user click on {string} Cta in Based on interest carousal")
	public void user_click_on_cta_in_based_on_interest_carousal(String string) {
		migration.clickBasedOnSeeAll();
	}

	@Then("verify naviagate to title list screen")
	public void verify_naviagate_to_title_list_screen() {
		Assert.assertTrue(migration.basedOnTier2.isDisplayed());
	}

	@Then("user click on {string} cta navigate to interest survey screen and without making changes and clicking back")
	public void user_click_on_cta_navigate_to_interest_survey_screen_and_without_making_changes_and_clicking_back(
			String string) {
		int titleCountPrev = migration.titleCardTier2.size();
		migration.clickEditIconBasedOn();
		Assert.assertTrue(migration.intrestSurveyPage.isDisplayed());
		migration.clickBack();
		Assert.assertEquals(titleCountPrev, migration.titleCardTier2.size());
	}

	@Then("user click on {string} cta navigate to interest survey screen")
	public void user_click_on_cta_navigate_to_interest_survey_screen(String string) {
		migration.clickEditIconBasedOn();
	}

	@Then("user update the interest topic and click save cta")
	public void user_update_the_interest_topic_and_click_save_cta() {
		migration.updateInterestSurvey();
		migration.clickSaveCTA();
	}

	@Then("user navigate to title list screen if interest topics have recommendation title")
	public void user_navigate_to_title_list_screen_if_interest_topics_have_recommendation_title() {
		Assert.assertTrue(migration.basedOnTier2.isDisplayed());
	}

	@Then("user without update the interest topic and click back")
	public void user_without_update_the_interest_topic_and_click_back() {
		// Logger.log("User will click on Browser Back Button");
		migration.clickBack();
	}

	@Then("user navigate to title list screen without change any title")
	public void user_navigate_to_title_list_screen_without_change_any_title() {
		Assert.assertTrue(migration.basedOnTier2.isDisplayed());
	}

	@Then("user navigate to my shelf screen if interest topics have no recommendation title")
	public void user_navigate_to_my_shelf_screen_if_interest_topics_have_no_recommendation_title() {
//		migration.verifyIntersetSurveyWOSave();
		Assert.assertTrue(migration.noRecommendationDisplayed.isDisplayed());
	}

	@Then("user should sse the Pop up getting closed")
	public void user_should_sse_the_pop_up_getting_closed() {
		Assert.assertEquals(isElementPresent(migration.displayCheckoutPopUp), false);
	}

	@Then("user able to the see the title {string}, description \"\"Are you sure you want to Disable checkout history? This will delete your history and cannot be restored.{string} and {string} and {string} CTAs")
	public void user_able_to_the_see_the_title_description_are_you_sure_you_want_to_disable_checkout_history_this_will_delete_your_history_and_cannot_be_restored_and_and_ct_as(
			String title, String desc, String disable, String cancel) {
		Assert.assertTrue(migration.displayCheckoutPopUp.isDisplayed());
		Assert.assertTrue(migration.displayCheckoutPopUpDesc.isDisplayed());
		Assert.assertTrue(migration.displayCheckoutPopUpHeading.getText().contains(title));
		Assert.assertTrue(migration.displayCheckoutPopUpDesc.getText().contains(desc));
		Assert.assertTrue(migration.displayCheckoutPopUpDesc.isDisplayed());
		Assert.assertTrue(migration.displayCheckoutPopUpCancel.isDisplayed());
	}

	@Then("user must be on same screen \\(My profile detail screen)")
	public void user_must_be_on_same_screen_my_profile_detail_screen() {
		Assert.assertTrue(isElementPresent(profile.profileEditSection));
	}

	@Given("user should view filter select the default country as per the contact details.")
	public void user_should_view_filter_select_the_default_country_as_per_the_contact_details() {
		visibilityWait(migration.filterCountry);
		Assert.assertTrue(migration.filterCountry.isDisplayed());
		migration.clickFilterCountry();
		// Assert.assertTrue(migration.defaultCountrySorted.isDisplayed());
	}

	@Given("user search any keyword {string} and naviagate to search result screen")
	public void user_search_any_keyword_and_naviagate_to_search_result_screen(String keyword) {
		search.click_AdvanceSearch();
		search.AdvanceSesarch_EnterInput(keyword);
		// search.searchTitle(keyword);
	}

	@Given("user should view sorted with the relevance by default in search result page")
	public void user_should_view_sorted_with_the_relevance_by_default_in_search_result_page() {
		Logger.log("User able to view the results sorted by Relavance by default");
	}

//	@Given("user should view filter select the default country as per the updated contact details.")
//	public void user_should_view_filter_select_the_default_country_as_per_the_updated_contact_details() {
//
//	}

	@Given("user should view sorted with the popularity by default in tier2 list screen")
	public void user_should_view_sorted_with_the_popularity_by_default_in_tier2_list_screen() {
		migration.newspaperMagazine_tier2_RefinerDetails();
		Logger.log("User able to view the title list sorted by popularity by default");
	}

//	@Given("user should view sorted with the relevance by default in search result page")
//	public void user_should_view_sorted_with_the_relevance_by_default_in_search_result_page() {
//
//	}

	@Given("user should be able to view reading programs featured banner")
	public void user_should_be_able_to_view_reading_programs_featured_banner() {

	}

	@Given("user should not be able to view see all programs option on the featured banner")
	public void user_should_not_be_able_to_view_see_all_programs_option_on_the_featured_banner() {

	}

	@Then("user click on {string} cta navigate to interest survey screen and made changes and clicking back cta")
	public void user_click_on_cta_navigate_to_interest_survey_screen_and_made_changes_and_clicking_back_cta(
			String string) {
		migration.clickEditIconBasedOn();
		Assert.assertTrue(migration.intrestSurveyPage.isDisplayed());
		migration.updateInterestSurvey();
		migration.clickBack();
	}

	/*********************************************************************************/

	@When("User should view the {string} title text")
	public void user_should_view_the_title_text(String txt) {
		Assert.assertEquals(search.AdvancedSearch_txt.getText().equalsIgnoreCase(txt), true);
	}

	@When("User click {string} cta from heade bar")
	public void user_click_cta_from_heade_bar(String verbiage) {
		// visibilityWait(search.AdvanceSearch_txt);
		// Assert.assertEquals(search.AdvanceSearch_txt.getText().contains(verbiage),
		// true);
		search.click_AdvanceSearch();
	}

	@When("User should view the advanced search overlay with search for content field")
	public void user_should_view_the_advanced_search_overlay_with_search_for_content_field() {
		Assert.assertEquals(search.AdvancedSearch_input.isDisplayed(), true);
	}

	@When("verify the cross icon in search bar if user enters the keyword {string}")
	public void verify_the_cross_icon_in_search_bar_if_user_enters_the_keyword(String keyword) {
		search.verify_crossIconInSearchbar(keyword);
	}

	@When("User should be avle to view the {string} {string} {string} {string} checkboxes")
	public void user_should_be_avle_to_view_the_checkboxes(String keyword, String title, String author, String isbn) {
		search.verify_AdvancedSearchOptions(keyword);
		search.verify_AdvancedSearchOptions(title);
		search.verify_AdvancedSearchOptions(author);
		search.verify_AdvancedSearchOptions(isbn);
	}

	@When("User should be able to view the overlay close icon")
	public void user_should_be_able_to_view_the_overlay_close_icon() {
		Assert.assertTrue(search.AdvancedSearch_closeIcon.isDisplayed());
	}

	@When("User should be able to view the {string} subtitle")
	public void user_should_be_able_to_view_the_subtitle(String string) {
		Assert.assertTrue(search.AdvancedSearch_formattxt.isDisplayed());
	}

	@When("User should be able to view the {string} checkbox")
	public void user_should_be_able_to_view_the_checkbox(String options) {
		search.verify_AdvancedSearchOptions(options);
	}

	@When("user clicks the menu option in header")
	public void user_clicks_the_menu_option_in_header() {
		login.click_HamburgerMenu();
	}

	@When("user clicks {string} from menu list")
	public void user_clicks_from_menu_list(String string) {
		login.click_browse();
	}

	@Then("user should not be able to view the intermediate screen for browse in menu")
	public void user_should_not_be_able_to_view_the_intermediate_screen_for_browse_in_menu() {
		Assert.assertEquals(isElementPresent(login.browse_level1), false);
	}

	@Then("user should be able to view browse result page")
	public void user_should_be_able_to_view_browse_result_page() {
		visibilityWait(login.browse_searchResultPage);
		Assert.assertTrue(login.browse_searchResultPage.isDisplayed());
	}

	@Then("user should be able to view refiners section on left side page with options")
	public void user_should_be_able_to_view_refiners_section_on_left_side_page_with_options() {
		Assert.assertTrue(login.browse_refiner.isDisplayed());
	}

	@Then("user should be able to view refiner section with no selection")
	public void user_should_be_able_to_view_refiner_section_with_no_selection() {
		login.verify_RefinerNoselection();
	}

	@Then("user should be able to view the result screen with no pills")
	public void user_should_be_able_to_view_the_result_screen_with_no_pills() {
		Assert.assertEquals(isElementPresent(login.browse_pills), false);
		Logger.log("user should be able to view the result screen with no pills");
	}

	@Then("user should be able to view the breadcrumb in browse result screen")
	public void user_should_be_able_to_view_the_breadcrumb_in_browse_result_screen() {
		visibilityWait(login.browse_breadcrumb);
		Assert.assertTrue(login.browse_breadcrumb.isDisplayed());
	}

	@Then("user should be able toview the breadcrumb in browse result screen")
	public void user_should_be_able_toview_the_breadcrumb_in_browse_result_screen() {

	}

	@When("User should enter the keyword and select the {string} checkbox under format section")
	public void user_should_enter_the_keyword_and_select_the_checkbox_under_format_section(String format) {
		search.click_NewspaperInAdvanceSearch(format);
	}

	@When("system should show the respective selection items in Grid view")
	public void system_should_show_the_respective_selection_items_in_grid_view() {
		Logger.log("UI validation for Grid view ");
	}

	@When("User click the search button and get the search result")
	public void user_click_the_search_button_and_get_the_search_result() {
		search.Click_Searchbtn();
	}

	@When("User compare the search result with respect to title search API response")
	public void user_compare_the_search_result_with_respect_to_title_search_api_response() {
		Logger.log("API validation of Search results screen ");
	}

	@When("System should display the search result screen with available Newspaper cards")
	public void system_should_display_the_search_result_screen_with_available_newspaper_cards() {
		Assert.assertEquals(search.advanceSearch_thirdpartySearchResult_title.getText().contains("Newspapers"), true);
		Assert.assertEquals(search.advanceSearch_thirdpartySearchResult.isDisplayed(), true);
	}

	@When("System should display the search result screen with available Magazine cards")
	public void system_should_display_the_search_result_screen_with_available_magazine_cards() {
		Assert.assertEquals(search.advanceSearch_thirdpartySearchResult_title.getText().contains("Magazines"), true);
		visibilityWait(search.advanceSearch_thirdpartySearchResult);
		Assert.assertEquals(search.advanceSearch_thirdpartySearchResult.isDisplayed(), true);
	}

	@When("System should display the search result screen with available Article cards")
	public void system_should_display_the_search_result_screen_with_available_article_cards() {
		Assert.assertEquals(search.advanceSearch_thirdpartySearchResult_title.getText().contains("Articles"), true);
		Assert.assertEquals(search.advanceSearch_thirdpartySearchResult.isDisplayed(), true);
	}

	@When("User click the search button and get the zero search result if no title available")
	public void user_click_the_search_button_and_get_the_zero_search_result_if_no_title_available() {
		search.Click_Searchbtn();
		WaitForWebElement(search.advanceSearch_thirdpartySearchResult_Notitle);
		Assert.assertEquals(search.advanceSearch_thirdpartySearchResult_Notitle.getText().contains("(0)"), true);
	}

	@When("User should verify the zeroresults message {string}")
	public void user_should_verify_the_zeroresults_message(String msg) {
		Assert.assertEquals(search.advanceSearch_thirdpartySearchResult_msg.getText().contains(msg), true);
	}

	@When("User should enter the keyword {string} and select {string} format and select {string} and click search")
	public void user_should_enter_the_keyword_and_select_format_and_select_and_click_search(String keyword,
			String string2, String string3) {
		search.AdvanceSesarch_EnterInput(keyword);
		search.Click_Searchbtn();
	}

	@When("User should view the search result page with repsect to the search entry")
	public void user_should_view_the_search_result_page_with_repsect_to_the_search_entry() {
		WaitForWebElement(search.searchResult);
		Assert.assertTrue(search.searchResult.isDisplayed());
	}

	@When("User should view the Results title with total available product count")
	public void user_should_view_the_results_title_with_total_available_product_count() {
		Assert.assertTrue(search.advanceSearch_thirdpartySearchResult_count.isDisplayed());
	}

	@When("User should view the result category pills in updated theme format")
	public void user_should_view_the_result_category_pills_in_updated_theme_format() {
		Assert.assertTrue(search.advanceSearch_thirdpartySearchResult_pills.isDisplayed());
	}

	@When("System should display the all format carousel data based on all format selection")
	public void system_should_display_the_all_format_carousel_data_based_on_all_format_selection() {
		search.verify_Allformats();
	}

	@When("System should display the seperate carousel for newspaper, magazine and articles")
	public void system_should_display_the_seperate_carousel_for_newspaper_magazine_and_articles() {

	}

	@When("User should be able to choose the different format and get the respective filter Results")
	public void user_should_be_able_to_choose_the_different_format_and_get_the_respective_filter_results() {

	}

	@When("User should enter the keyword and select any of the newspaper or magazine or Article checkbox under format section")
	public void user_should_enter_the_keyword_and_select_any_of_the_newspaper_or_magazine_or_article_checkbox_under_format_section() {
		search.click_Articles();
	}

	@When("User click the {string} from newspaper and magazine carousel")
	public void user_click_the_from_newspaper_and_magazine_carousel(String string) {
		migration.click_NewsMagSeeAll();
	}

	@When("System should redirect to the newspaper and magazines tier1 page")
	public void system_should_redirect_to_the_newspaper_and_magazines_tier1_page() {
		Assert.assertTrue(migration.tier1_newsMag.isDisplayed());
	}

	@When("User should verify the {string} CTA from any of the feture card carousel in tier1 page")
	public void user_should_verify_the_cta_from_any_of_the_feture_card_carousel_in_tier1_page(String string) {

	}

	@When("User click any of the {string} CTA from newspaper and magazines tier1 page")
	public void user_click_any_of_the_cta_from_newspaper_and_magazines_tier1_page(String string) {

	}

	@When("System should redirect to the respective tier2 pages")
	public void system_should_redirect_to_the_respective_tier2_pages() {

	}

	@When("User click the {string} from checkers library tv's widget")
	public void user_click_the_from_checkers_library_tv_s_widget(String string) {

	}

	@When("System should redirect to the checkers library tv's tier1 page")
	public void system_should_redirect_to_the_checkers_library_tv_s_tier1_page() {

	}

	@When("User should verify the {string} CTA from any of the checkers library tv's feture card carousel in tier1 page")
	public void user_should_verify_the_cta_from_any_of_the_checkers_library_tv_s_feture_card_carousel_in_tier1_page(
			String string) {

	}

	@When("User click any of the {string} CTA from checkers library tv's tier1 page")
	public void user_click_any_of_the_cta_from_checkers_library_tv_s_tier1_page(String string) {

	}

	@When("User click the {string} from videobook's featured widget")
	public void user_click_the_from_videobook_s_featured_widget(String string) {

	}

	@When("System should redirect to the videobook's featured tier1 page")
	public void system_should_redirect_to_the_videobook_s_featured_tier1_page() {

	}

	@When("User should verify the {string} CTA from any of the videobook's feture card carousel in tier1 page")
	public void user_should_verify_the_cta_from_any_of_the_videobook_s_feture_card_carousel_in_tier1_page(
			String string) {

	}

	@When("User click any of the {string} CTA from videobook's Feature tier1 page")
	public void user_click_any_of_the_cta_from_videobook_s_feature_tier1_page(String string) {

	}

	@Then("System should disable the Author and ISBN checkbox under the type")
	public void system_should_disable_the_author_and_isbn_checkbox_under_the_type() {
		if (search.FormatAndType_disabled.get(0).isDisplayed()) {
			Assert.assertTrue(search.FormatAndType_disabled.get(1).isDisplayed());
			Logger.log(" Author and ISBN checkbox are disabled state" + search.FormatAndType_disabled.get(0));
			Logger.log(" Author and ISBN checkbox are disabled state" + search.FormatAndType_disabled.get(1));
		} else {
			Logger.log(" Author and ISBN checkbox are Enabled state");
		}
	}

	@Given("user select any of the checkbox under format of {string}")
	public void user_select_any_of_the_checkbox_under_format_of(String FormatOptions) {
		search.select_FortmatOptions(FormatOptions);
	}

	@Given("User select any of the Author and ISBN checkbox")
	public void user_select_any_of_the_author_and_isbn_checkbox() {
		search.click_ISBN();
	}

	@Then("system should disabled the format Web resource, Newspaper, Magazine, Resource Hub")
	public void system_should_disabled_the_format_web_resource_newspaper_magazine_resource_hub() {
		if (search.FormatAndType_disabled.get(2).isDisplayed()) {
			Assert.assertTrue(search.FormatAndType_disabled.get(3).isDisplayed());
			Logger.log("newspaper and web resource, Resource Hub checkbox are disabled state");
		} else {
			Logger.log("newspaper and web resource, Resource Hub checkbox are Enabled state");
		}
	}

	// 203440

	@When("user should be able to view refiners section with title as Browse")
	public void user_should_be_able_to_view_refiners_section_with_title_as_browse() {
		Assert.assertTrue(login.RefinerAsBrowse.isDisplayed());
	}

	@When("user should be able to view refiners selction as pills with the updated theme colors")
	public void user_should_be_able_to_view_refiners_selction_as_pills_with_the_updated_theme_colors() {
		Logger.log("Theme can be done in visual UI");
	}

	@When("user should be able to view the refiner section background to be in White color and font in black")
	public void user_should_be_able_to_view_the_refiner_section_background_to_be_in_white_color_and_font_in_black() {
		Logger.log("Theme can be done in visual UI");
	}

	@When("user should be able to view the selected option change to light blue and text to bold")
	public void user_should_be_able_to_view_the_selected_option_change_to_light_blue_and_text_to_bold() {
		Logger.log("Theme can be done in visual UI");
	}

	@When("user should be able to view the titles listed in the new updated theme format")
	public void user_should_be_able_to_view_the_titles_listed_in_the_new_updated_theme_format() {
		Logger.log("Theme can be done in visual UI");
	}

	@When("user should be able to view the titles gap between every row to be {int} pixel")
	public void user_should_be_able_to_view_the_titles_gap_between_every_row_to_be_pixel(Integer int1) {
		Logger.log("cannot automate");
	}

	@Given("user should be able to view the {string} option in right side of the page")
	public void user_should_be_able_to_view_the_option_in_right_side_of_the_page(String string) {
		Logger.log("UI validation for refiner right side of the page ");
	}

	@Given("user clicks the refine option")
	public void user_clicks_the_refine_option() {
		login.click_browseRefiner();
	}

	@When("User should be ale to view level {int} subject under the {string} option")
	public void user_should_be_ale_to_view_level_subject_under_the_option(Integer int1, String options) {
		login.verify_MultiSelectOptions(options);
	}

	@Then("user user should be able to do multiselect under Browse section")
	public void user_user_should_be_able_to_do_multiselect_under_browse_section() {
		Assert.assertTrue(login.Refiner_categories.isDisplayed());
	}

	@Then("user should be able to view the results updated dynamicaly when user selects the refine option")
	public void user_should_be_able_to_view_the_results_updated_dynamicaly_when_user_selects_the_refine_option() {
		visibilityWait(login.Refiner_Results);
		Assert.assertTrue(login.Refiner_Results.isDisplayed());
		Logger.log("Refiner results get updated");
	}

	@Then("user should be able to view pills with respective of the refine selected by the user")
	public void user_should_be_able_to_view_pills_with_respective_of_the_refine_selected_by_the_user() {
		visibilityWait(login.browse_pills);
		Assert.assertTrue(isElementPresent(login.browse_pills));
	}

	@Then("user should not able to view the sort option under refine screen")
	public void user_should_not_able_to_view_the_sort_option_under_refine_screen() {
		Assert.assertTrue(login.Refiner_SortBy.isDisplayed());
	}

	@Given("user clicks categories from menu list")
	public void user_clicks_categories_from_menu_list() {
		login.select_Categories();
	}

	@Then("user user should be able to do multiselect under categories section")
	public void user_user_should_be_able_to_do_multiselect_under_categories_section() {
		login.multiSelect_Categories();
	}

	@Given("user clicks Format from menu list")
	public void user_clicks_format_from_menu_list() {
		login.select_Format();
	}

	@Then("user user should be able to do multiselect under Format section")
	public void user_user_should_be_able_to_do_multiselect_under_format_section() {
		login.multiSelect_Format();
	}

	@Given("user clicks Availability from menu list")
	public void user_clicks_availability_from_menu_list() {
		login.select_Availability();
	}

	@Then("user user should be able to do multiselect under Availability section")
	public void user_user_should_be_able_to_do_multiselect_under_availability_section() {
		login.multiSelect_Availability();
	}

	@Given("user clicks language from menu list")
	public void user_clicks_language_from_menu_list() {
		login.select_Language();
	}

	@Then("user user should be able to do multiselect under language section")
	public void user_user_should_be_able_to_do_multiselect_under_language_section() {
		login.multiSelect_Language();
	}

	@Given("user clicks age level from menu list")
	public void user_clicks_age_level_from_menu_list() {
		login.select_AgeLevel();
	}

	@Then("user user should be able to do multiselect under age level section")
	public void user_user_should_be_able_to_do_multiselect_under_age_level_section() {
		login.multiSelect_AgeLevel();
	}

	@Given("user clicks release date from menu list")
	public void user_clicks_release_date_from_menu_list() {
		login.select_ReleaseDate();
	}

	@Then("user user should be able to do multiselect under release date section")
	public void user_user_should_be_able_to_do_multiselect_under_release_date_section() {
		login.multiSelect_ReleaseDate();
	}

	@Given("user clicks recently added from menu list")
	public void user_clicks_recently_added_from_menu_list() {
		login.select_RecentlyAdded();
	}

	@Then("user user should be able to do multiselect under recently added section")
	public void user_user_should_be_able_to_do_multiselect_under_recently_added_section() {
		login.multiSelect_RecentlyAdded();
	}

	@When("user selects the subjects")
	public void user_selects_the_subjects() {
		login.click_browseRefiner();
	}

	@When("user should be able to select the category")
	public void user_should_be_able_to_select_the_category() {
		login.select_Category();
	}

	@When("user should be able to view results based on category selection")
	public void user_should_be_able_to_view_results_based_on_category_selection() {
	   get_CategoryCount = login.get_CategoryCounts();
	   Assert.assertTrue("Category Title Count: " +get_CategoryCount, login.Results_count.isDisplayed());
	   Logger.log("Category results Total count: "  + get_CategoryCount);
		apiResponses = APIClient.getBrowseSearchTitleResponse("pubDate");
		String apiResultCount = "";
		HashMap<String, String> isbnAudienceMap = new HashMap<String, String>();
		for (SearchTitleResponse apiResponse : apiResponses) {
			 apiResultCount = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getResultCount();
			 ebookResultCount = apiResponse.getSearchTitleResponseData().getSearchTitleResult().geteBookCount();
			 audioResultCount = apiResponse.getSearchTitleResponseData().getSearchTitleResult()
					.geteAudioBookCount();
			 
			 List<Title> titles = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getTitlesList().getTitles();
			 List<String> isbnListFromAPI = new ArrayList<String>();
			 
		        for (Title title : titles) {
		            String audience = title.getAudience();
		            String isbn = title.getiSBN();
		            isbnAudienceMap.put(isbn, audience);
		            isbnListFromAPI.add(isbn);
		            System.out.println("extracted audience code for title : " + isbn + " is : " + audience);
		        }
		        
		    List<String> isbListfromUI = new ArrayList<String>();
		    
		    isbListfromUI = login.get_TitlesISBN();
		    
		    for(String isbn : isbListfromUI) {
		    	System.out.println("isbn from UI: " + isbn);
		    	if (isbnAudienceMap.containsKey(isbn)) {
		    		System.out.println("isbnAudienceMap.get(isbn): " + isbnAudienceMap.get(isbn));
		    		Assert.assertTrue("Audience should be Teen or Children", isbnAudienceMap.get(isbn).contains("Teen") ||isbnAudienceMap.get(isbn).contains("Children"));
		            System.out.println("HashMap contains the key: " + isbn + "Audience is: " + isbnAudienceMap.get(isbn));
		        } else {
		            System.out.println("HashMap does not contain the key: " + isbn);
		            System.out.println("isbnAudienceMap.get(isbn): " + isbnAudienceMap.get(isbn));
		        }
		    }
			get_CategoryCount = login.get_CategoryCounts();
			try {
			Assert.assertEquals("Category Title Count: " + get_CategoryCount, apiResultCount);
			} catch(Exception e) {
				System.out.println("Category results count are not matching:" + get_CategoryCount + " " + apiResultCount);
			}
			Logger.log("Category results count:" + get_CategoryCount);
			System.out.println(get_CategoryCount);
			
			Assert.assertTrue("isbn in UI and API is not matching", isbListfromUI.equals(isbnListFromAPI));
		}
		
		Assert.assertEquals("Category Title Count: " + get_CategoryCount, apiResultCount);

	}

	@When("user should be able to view results if selects the ebook format")
	public void user_should_be_able_to_view_results_if_selects_the_ebook_format() {
		get_eBookcount = login.get_CategoryEbookCount();
		Assert.assertTrue("Ebook Title Count: " + get_eBookcount, login.Results_count.isDisplayed());
		Assert.assertEquals("Category Title Count: " + get_CategoryCount, ebookResultCount);
		Logger.log("Ebook title count:" + get_eBookcount);
		System.out.println(get_eBookcount);
	}

	@When("user should be able to view results if selects the EAudio format")
	public void user_should_be_able_to_view_results_if_selects_the_e_audio_format() {
	   login.click_FormatDropdwn_eAudio();

	    get_eAudiocount = login.get_CategoryEbookCount();
		Assert.assertTrue("EAudio Title Count: " +get_eAudiocount, login.Results_count.isDisplayed());
		Logger.log("EAudio title count:"  +get_eAudiocount);
		login.click_FormatDropdwn_eAudio();
		get_eAudiocount = login.get_CategoryEbookCount();
		Assert.assertTrue("EAudio Title Count: " + get_eAudiocount, login.Results_count.isDisplayed());
		Assert.assertEquals("Category Title Count: " + get_CategoryCount, audioResultCount);
		Logger.log("EAudio title count:" + get_eAudiocount);
		System.out.println(get_eAudiocount);
		System.out.println(get_eAudiocount);
	}
	
//	@When("user clicks on the sortby option and select {string} as option, select subject as {string} and category as {string}, Availability as {string}, format type as {string} and age level as {string},language as {string} and get the search results count  for {string}")
	@When("user clicks on the sortby option and select {string} as option, select subject as {string} and category as {string}, Availability as {string}, format type as {string} and age level as {string},language as {string} and get the search results count for {string}")
	public void user_clicks_on_the_sortby_option_and_select_as_option_select_subject_as_and_category_as_availability_as_format_type_as_and_age_level_as_language_as_and_get_the_search_results_count(String popularity, String subject, String category, String Availability, String FormatType, String agelevel, String language, String profileType) {
		browsesearch.clickResetButton();
		browsesearch.selectSubject(subject);
		browsesearch.selectCategories(category);
		browsesearch.selectAvailability(Availability);
		browsesearch.selectFormatType(FormatType);
		browsesearch.selectAgeLevel(agelevel);
		browsesearch.selectLanguage(language);
		browsesearch.searchResultCount();
		browse.GetApiResultsCount(popularity,subject,category,Availability,FormatType,agelevel,language,profileType);
	}


}
