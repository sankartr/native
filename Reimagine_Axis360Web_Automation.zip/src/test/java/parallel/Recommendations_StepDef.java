package parallel;

import org.junit.Assert;

import com.driverfactory.DriverManager;
import com.resuableMethods.Highlighter;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.Adminconfiguration;
import pom.kidszone.HamburgerMenu;
import pom.kidszone.Holds;
import pom.kidszone.Recommendations;
import pom.kidszone.TitleAcrossProfile;
import pom.kidszone.Wishlist;

public class Recommendations_StepDef {

	static ExcelReader reader = new ExcelReader();
	Adminconfiguration admin = new Adminconfiguration(DriverManager.getDriver());
	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());
	Holds hold = new Holds(DriverManager.getDriver());
	Wishlist wish = new Wishlist(DriverManager.getDriver());
	Recommendations recommend = new Recommendations(DriverManager.getDriver());
	TitleAcrossProfile title = new TitleAcrossProfile(DriverManager.getDriver());

	@Given("user click on login button after user enter Axisandkidszone subscription only {string} and {string} Adult User")
	public void user_click_on_login_button_after_user_enter_axisandkidszone_subscription_only_and_adult_user(String id,
			String pass) {
		hold.logInClick();
		hold.adult_login(id, pass);
	}

	@Given("user clicks on recommendation")
	public void user_clicks_on_recommendation() {
		ham.click_HamburgerMenu();
		recommend.clickPurchaseReq();
	}

	@When("user lands on recommendations screen")
	public void user_lands_on_recommendations_screen() {
		Assert.assertTrue(recommend.getPurchaseReqPage().isDisplayed());
	}

	@Then("user should be able to view recommendations screen with theme rendered based on library subscription and adult profile type")
	public void user_should_be_able_to_view_recommendations_screen_with_theme_rendered_based_on_library_subscription_and_adult_profile_type() {
		Logger.log(
				"User able to view recommendations screen with theme rendered based on library subscription and profile type");
	}

	@Then("user should be able to view no title recommendations screen")
	public void user_should_be_able_to_view_no_title_recommendations_screen() {
		Assert.assertTrue(recommend.getPurchaseReqNoStuff().isDisplayed());
	}

	@Then("user should be able to view quick navigation ctas as a carousel on top with recommendations highlighted and number of titles recommended")
	public void user_should_be_able_to_view_quick_navigation_ctas_as_a_carousel_on_top_with_recommendations_highlighted_and_number_of_titles_recommended() {
		recommend.quickCtaPR();
	}

	@Then("user should be able to view titles recommended by that user only")
	public void user_should_be_able_to_view_titles_recommended_by_that_user_only() {
		Logger.log("user able to view titles recommended by that user only");
	}

	@Then("user should be able to view titles sorted by latest title recommended first by default")
	public void user_should_be_able_to_view_titles_sorted_by_latest_title_recommended_first_by_default() {
		Logger.log("user able to view titles sorted by latest title recommended first by default");
	}

	@When("user clicks on recommendations")
	public void user_clicks_on_recommendations() {
		ham.click_HamburgerMenu();
		recommend.clickPurReqHam();
	}

	@Then("user should be able to view Quick navigation ctas as a carousel on top with recommendations highlighted and number of titles recommended")
	public void user_should_be_able_to_view_Quick_navigation_ctas_as_a_carousel_on_top_with_recommendations_highlighted_and_number_of_titles_recommended() {
		recommend.quickCtaPRDemo();
	}

	@Then("user should be able to view recommendations screen with theme rendered based on library subscription and kid profile type")
	public void user_should_be_able_to_view_recommendations_screen_with_theme_rendered_based_on_library_subscription_and_kid_profile_type() {
		Logger.log(
				"User able to view recommendations screen with theme rendered based on library subscription and profile type");
	}

	@Then("user should be able to updated my stuff screen for user with teen profile type and kidszone subscription")
	public void user_should_be_able_to_updated_my_stuff_screen_for_user_with_teen_profile_type_and_kidszone_subscription() {
		Logger.log(
				"user able to view updated my stuff screen for user with teen profile type and kidszone subscription");
	}

	@Then("user should be able to updated my stuff screen for user with teen profile type and kidszone and axis360 subscription")
	public void user_should_be_able_to_updated_my_stuff_screen_for_user_with_teen_profile_type_and_kidszone_and_axis360_subscription() {
		Logger.log(
				"user able to view updated my stuff screen for user with teen profile type and kidszone and axis360 subscription");
	}

	@Then("user should be able to view recommendations screen with theme rendered based on library subscription and teen profile type")
	public void user_should_be_able_to_view_recommendations_screen_with_theme_rendered_based_on_library_subscription_and_teen_profile_type() {
		Logger.log(
				"User able to view recommendations screen with theme rendered based on library subscription and profile type");
	}

	@Then("user should be able to click on back Cta to navigate back to last screen")
	public void user_should_be_able_to_click_on_back_cta_to_navigate_back_to_last_screen() {
		recommend.navigateBackCta();
	}

	@Then("user should be able to view Bread crumb navigation for the screen")
	public void user_should_be_able_to_view_bread_crumb_navigation_for_the_screen() {
		Assert.assertTrue(recommend.getBreadCrumb().isDisplayed());
	}

	@Then("user should be able to click on Back Cta to navigate back to last screen")
	public void user_should_be_able_to_click_on_Back_Cta_to_navigate_back_to_last_screen() {
		recommend.navigateBackCtaDemo();
	}

	@When("user has recommended titles")
	public void user_has_recommended_titles() {
		Assert.assertTrue(recommend.getRecommendedTitle().isDisplayed());
	}

	@Then("user should be able to view primary action for the title as button")
	public void user_should_be_able_to_view_primary_action_for_the_title_as_button() {
		hold.primaryAction();
	}

	@Then("user should be able to view more options Cta to view secondary actions available for the title")
	public void user_should_be_able_to_view_more_options_cta_to_view_secondary_actions_available_for_the_title() {
		recommend.secCtaOptions();
	}

	@Then("user should be able to click in more options Cta and view secondary actions for the title")
	public void user_should_be_able_to_click_in_more_options_cta_and_view_secondary_actions_for_the_title() {
		Assert.assertTrue(recommend.getSecCta().isDisplayed());
	}

	@Then("user should be able to view sort options as latest recommended and rating and A-Z")
	public void user_should_be_able_to_view_sort_options_as_latest_recommended_and_rating_and_a_z() {
		recommend.sortOptions();
	}

	@Then("user should view the titles sorted with latest title recommended first by default")
	public void user_should_view_the_titles_sorted_with_latest_title_recommended_first_by_default() {
		Logger.log("User able to view the latest title recommended by default");
	}

	@When("user switch to grid view for Recommendations screen")
	public void user_switch_to_grid_view_for_recommendations_screen() {
		hold.clickGrid();
		hold.gridViewDisplayed();
		hold.listViewDisplayed();
	}

	@Then("user should be able view title cover image and title name with title format icon")
	public void user_should_be_able_view_title_cover_image_and_title_name_with_title_format_icon() {
		hold.titleListDetails();
	}

	@Given("user switches the profile to kid in KidsZone")
	public void user_switches_the_profile_to_kid_in_kids_zone() {
		title.switchKidProfile();
	}

	@Given("user switches the profile to kid in OldUI")
	public void user_switches_the_profile_to_kid_in_old_ui() {
		hold.switchKidOldUI();
	}

	@Given("user switches the profile to teen in KidsZone")
	public void user_switches_the_profile_to_teen_in_kids_zone() {
		title.switchTeenProfile();
	}

	@Given("user switches the profile to teen in OldUI")
	public void user_switches_the_profile_to_teen_in_old_ui() {
		hold.switchTeenOldUI();
	}

}
