package pom.kidszone;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Librarysubscription extends CommonAction {
	Login login = new Login(DriverManager.getDriver());
	public List<String> LibHeading = new ArrayList<>();
	List items;

	public Librarysubscription(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	static ExcelReader reader = new ExcelReader();

	@FindBy(id = "LibrarySearch")
	private WebElement drop_searchBy;

	@FindBy(id = "searchText")
	private WebElement txtfld_librarySearch;

	@FindBy(xpath = "//*[@id=\"search\"]/div[1]")
	private WebElement btn_search;

	@FindBy(xpath = "//a[@data-tooltip='Edit Library Settings']")
	private WebElement btn_libraryEdit;

	@FindBy(xpath = "//*[@class=\"icon_button_edit\"]")
	private WebElement btn_libraryediting;

	@FindBy(id = "CustomerID")
	private WebElement txt_customerid;

	@FindBy(id = "axis360")
	private WebElement chk_axis360;

	@FindBy(id = "kidszone")
	private WebElement chk_kidszone;

	@FindBy(xpath = "//*[@class=\"icon_button_save\"]")
	private WebElement btn_saveLibrary;

	@FindBy(xpath = "//*[@class=\"ui-icon ui-icon-closethick\"]")
	private WebElement btn_closepop;

	@FindBy(xpath = "//*[@title=\"Log Off\"]")
	private WebElement btn_logoff;

	@FindBy(id = "adultprofile")
	private WebElement chk_adultprof;

	@FindBy(id = "teenprofile")
	private WebElement chk_teenprof;

	@FindBy(id = "kidsprofile")
	private WebElement chk_kidsprof;

	@FindBy(xpath = "//*[@class='icon_action_back bread-crumb-back']")
	private WebElement btn_libraryback;

	@FindBy(id = "lsettings")
	private WebElement salesdemo_label_librarysettingmenu;

	@FindBy(id = "UserName")
	private WebElement salesdemo_txtfield_username;

	@FindBy(id = "Password")
	private WebElement salesdemo_txtfield_password;

	@FindBy(xpath = "//input[@type='submit']")
	private WebElement salesdemo_btn_login;

	@FindBy(id = "settings")
	private WebElement salesdemo_lable_setting;

	@FindBy(xpath = "//div[text()='Library Settings']")
	private WebElement salesdemo_lable_librarysetting;

	@FindBy(xpath = "//legend[text()='Profile Settings']")
	private WebElement salesdemo_txt_profilesetting;

	@FindBy(xpath = "//*[@class='title']")
	private List<WebElement> Carousel_Heading;

	//////////////////////////////////////
	@FindBy(id = "adult")
	private WebElement btn_adult;

	@FindBy(id = "teen")
	private WebElement btn_teen;

	@FindBy(id = "kid")
	private WebElement btn_kid;

	@FindBy(xpath = "(//div[@class='kz-title-carousel ng-star-inserted']/following::carousel/div)[3]/div[@class='carousel-cells']/div//img[contains(@src,'97')]")
	private List<WebElement> ListofCarousel_Titles;

	@FindBy(xpath = "(//div[@class='kz-title-carousel ng-star-inserted']/following::carousel/div)[1]/div[@class='carousel-cells']/div//img[contains(@src,'')]")
	private List<WebElement> ListofFeaturedTeenCarousel_Titles;

	@FindBy(xpath = "(//div[@class='kz-title-carousel ng-star-inserted']/div/h2/following::carousel/div)[1]/div[@class='carousel-cells']/div//img[contains(@src,'97')]")
	private List<WebElement> ListofFeaturedKidCarousel_Titles;

	@FindBy(xpath = "//*[contains(text(),'Non-fiction')]/following::a[@aria-label='See all Non-Fiction']")
	private WebElement NonFictionCarousel_SeeAllCTA;

	@FindBy(xpath = "//a[@aria-label='See all Featured']")
	private WebElement FeaturedCarousel_SeeAllCTA;

	@FindBy(xpath = "//a[@aria-label='See all Kids']")
	private WebElement KidsCarousel_SeeAllCTA;

	@FindBy(xpath = "//*[@class='title-with-arrow ng-star-inserted']/h2/following::a[contains(text(),'See all')]")
	private List<WebElement> Carousel_SeeAllCTA;

	/*****************************
	 * Action methods
	 ************************************************/

	// 112826//

	public void verify_enable_kidszone() {
		javascriptScroll(chk_kidszone);
		waitFor(3000);
		if (chk_kidszone.isSelected()) {
			System.out.println("Kidszone already enabled");
		} else {
			ClickOnWebElement(chk_kidszone);
		}
	}

	public void verify_enable_axis360() {
		javascriptScroll(chk_axis360);
		waitFor(3000);
		if (chk_axis360.isSelected()) {
			System.out.println("Axis360 already enabled");
		} else {
			ClickOnWebElement(chk_axis360);
		}
	}

	public void verify_disable_axis360() {
		javascriptScroll(chk_axis360);
		waitFor(3000);
		if (chk_axis360.isSelected()) {
			ClickOnWebElement(chk_axis360);
		} else {
			System.out.println("Axis360 already disabled");

		}
	}

	public void saleslibrary_search() {
		waitFor(3000);
		ClickOnWebElement(drop_searchBy);
		waitFor(3000);
		Select select = new Select(drop_searchBy);
		select.selectByVisibleText("Customer ID");
		SendKeysOnWebElement(txtfld_librarySearch, "530743");
		ClickOnWebElement(btn_search);
		waitFor(3000);
		jsClick(btn_libraryEdit);
	}

	public void kidsnyclibrary_search() {
		waitFor(3000);
		ClickOnWebElement(drop_searchBy);
		waitFor(3000);
		Select select = new Select(drop_searchBy);
		select.selectByVisibleText("Customer ID");
		SendKeysOnWebElement(txtfld_librarySearch, "9102239");
		ClickOnWebElement(btn_search);
		waitFor(3000);
		jsClick(btn_libraryEdit);
	}

	public void magiclibrary_search() {
		waitFor(3000);
		ClickOnWebElement(drop_searchBy);
		waitFor(3000);
		Select select = new Select(drop_searchBy);
		select.selectByVisibleText("Customer ID");
		SendKeysOnWebElement(txtfld_librarySearch, "70222");
		ClickOnWebElement(btn_search);
		waitFor(3000);
		jsClick(btn_libraryEdit);
	}

	public void savelibrary_logoff() {
		waitFor(5000);
		ClickOnWebElement(btn_saveLibrary);
		Actions action = new Actions(DriverManager.getDriver());
		action.sendKeys(Keys.ENTER).perform();
		ClickOnWebElement(btn_logoff);
		waitFor(3000);
	}

	public void profileavailability() {
		isElementPresent(btn_adult);
		isElementPresent(btn_teen);
		isElementPresent(btn_kid);

	}

	public void profilenonavailability() {

		if (btn_adult.isDisplayed()) {
			System.out.println("Error: Kidszone also enabled, Adult profile available");
		} else {
			System.out.println("Success : Profiles are disabled as expected");
		}
	}

	public List<String> verify_LibraryCarousel() throws Exception {
		List<String> carouselList = new ArrayList<String>();
//		TreeSet<String> carouselList = new TreeSet<String>();
		pagescrollDown();
		waitForDocumentToLoad();
		for (WebElement Heading : Carousel_Heading) {
			String Libheading = Heading.getText();
			System.out.println("The list of component names from UI " + Libheading);
			carouselList.add(Libheading);
//					new  ArrayList<String>(Arrays.asList(Libheading.split(",")));
		}
		return carouselList;

	}

	public List<String> get_LibCarouselTitlesISBN(String categoryName, String profileType) {
		List<String> isbnList = new ArrayList<String>();
		int maxRetries = 3;
		int retries = 0;

		WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 30);
		wait.until(ExpectedConditions.jsReturnsValue("return document.readyState === 'complete';"));
		String isbn = "";
		while (retries < maxRetries) {
			if (categoryName.equalsIgnoreCase("Non-Fiction")) {
				System.out.println("Came inside of category name " + categoryName);
				try {

					for (int i = 0; i < ListofCarousel_Titles.size(); i++) {
						String srcImageText = ListofCarousel_Titles.get(i).getAttribute("src");
						// Regular expression pattern to match the ISBN
						Pattern pattern = Pattern.compile("/(\\d{13})/");
						Matcher matcher = pattern.matcher(srcImageText);

						if (matcher.find()) {
							isbn = matcher.group(1);
						} else {
							System.out.println("ISBN not found in the src attribute.");
						}
						isbnList.add(isbn);
					}
					break;

				} catch (StaleElementReferenceException e) {
					System.out.println("Retry count : " + retries);
					retries++;
					isbnList = new ArrayList<String>();
				}
			} else if (categoryName.equalsIgnoreCase("Featured") && profileType.equalsIgnoreCase("2")) {
				System.out.println("Came inside of Teen category name " + categoryName);

				for (int i = 0; i < ListofFeaturedTeenCarousel_Titles.size(); i++) {
					String srcImageText = ListofFeaturedTeenCarousel_Titles.get(i).getAttribute("src");
					// Regular expression pattern to match the ISBN
					Pattern pattern = Pattern.compile("/(\\d{13})/");
					Matcher matcher = pattern.matcher(srcImageText);
//					String isbn = "";
					if (matcher.find()) {
						isbn = matcher.group(1);
					} else {
						System.out.println("ISBN not found in the src attribute.");
					}
					isbnList.add(isbn);
				}
				break;

			} else if (categoryName.equalsIgnoreCase("Featured") && profileType.equalsIgnoreCase("3")) {
				System.out.println("Came inside of Kid category name " + categoryName);

				for (int i = 0; i < ListofFeaturedKidCarousel_Titles.size(); i++) {
					String srcImageText = ListofFeaturedKidCarousel_Titles.get(i).getAttribute("src");
					// Regular expression pattern to match the ISBN
					Pattern pattern = Pattern.compile("/(\\d{13})/");
					Matcher matcher = pattern.matcher(srcImageText);
					if (matcher.find()) {
						isbn = matcher.group(1);
					} else {
						System.out.println("ISBN not found in the src attribute.");
					}
					isbnList.add(isbn);
				}
				break;

			}
		}
		return isbnList;
	}

	public void clickLibCarousel_NavTitleListPage() {
		javascriptScroll(NonFictionCarousel_SeeAllCTA);
		jsClick(NonFictionCarousel_SeeAllCTA);
		visibilityWait(login.Results_count);

	}

	public void clickfeaturedCarousel_TitleListPage() {
		javascriptScroll(FeaturedCarousel_SeeAllCTA);
		jsClick(FeaturedCarousel_SeeAllCTA);
		visibilityWait(login.Results_count);

	}

	public void clickKidsCarousel_TitleListPage() {
		javascriptScroll(KidsCarousel_SeeAllCTA);
		jsClick(KidsCarousel_SeeAllCTA);
		visibilityWait(login.Results_count);

	}

	public void clickLibraryComponent(String componentName) {

		waitForDocumentToLoad();
		Logger.info("Selecting the category: " + componentName);
		for (WebElement element : Carousel_SeeAllCTA) {
			WaitForWebElement(element);
			String value = element.getAttribute("aria-label").substring(8);
			System.out.println("checking value " + value);
			try {
				if (element.getAttribute("aria-label").substring(8).equalsIgnoreCase(componentName)) {
					javascriptScroll(element);
					jsClick(element);
					break;
				}
			} catch (Exception e) {
				javascriptScroll(element);
				jsClick(element);
			}
		}
		
		visibilityWait(login.Results_count);

	}

}
