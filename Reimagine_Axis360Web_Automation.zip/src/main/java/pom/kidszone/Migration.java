package pom.kidszone;

import java.util.List;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

public class Migration extends CommonAction {

	public Migration(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//a[contains(text(),'See All ')]")
	private WebElement newsMag_SeeAll;
	
	@FindBy(xpath = "(//a[contains(text(),'See All ')])[1]")
	private WebElement newsMag_Tier1SeeAll;
	
	@FindBy(xpath = "//axis360-third-party-refiner-ac[@class='ng-star-inserted']")
	public WebElement newsMag_Tier2_Refiner;
	
	@FindBy(xpath = "//label[contains(text(),'Newspapers & Magazines')]")
	public WebElement newsMag_categories;
	
	@FindBy(id = "dummy")
	private WebElement newsMag_articleSeeAll;
	
	@FindBy(xpath = "//*[contains(text(),'Display Checkout History')]")
	public static WebElement diplayCheckHisCheckBox;

	@FindBy(xpath = "//*[contains(text(),' Display Insights & Badges')]")
	public static WebElement diplayInsBadCheckBox;

	@FindBy(id = "alert-dialog-title")
	public static WebElement displayCheckoutPopUp;

	@FindBy(xpath = "//*[@svgicon='kz-profile-user']")
	public static WebElement avatarIcon;

	@FindBy(xpath = "//*[@class='cdk-overlay-container']")
	public static WebElement outsideArea;

	@FindBy(id = "alert-heading")
	public static WebElement displayCheckoutPopUpHeading;

	@FindBy(id = "loc_textalertcontent")
	public static WebElement displayCheckoutPopUpDesc;

	@FindBy(id = "loc_cancelbtn")
	public static WebElement displayCheckoutPopUpCancel;

	@FindBy(id = "loc_confirmbtnOK")
	public static WebElement displayCheckoutPopUpDisable;
	
	@FindBy(xpath = "//div[@class='featured-magazine ng-star-inserted']")
	public static WebElement tier1_newsMag;
	
	@FindBy(xpath = "(//div[@role='button'])[2]")
	public static WebElement Tier2_country_dropdwn;
	
	@FindBy(xpath = "//label[@class='ac-textBlock']")
	public static List<WebElement> Tier2_country;
	
	@FindBy(xpath = "//label[contains(text(),'Publication Date')]")
	public static WebElement Tier2_publicationDate;
	
	@FindBy(xpath = "//label[contains(text(),'Relevance')]")
	public static WebElement Tier2_Relevence;
	
	@FindBy(xpath = "(//div[@id='newspaper_magazine_book-img'])[1]")
	public static WebElement publicationTitle_NavTier3;
	
	@FindBy(xpath = "//div[@class='third-party-card-details']")
	public static WebElement newsmag_tier3;
	
	@FindBy(xpath = "(//div[@class='ac-textBlock'])[1]")
	public static WebElement Tier3_publicationName;
	
	@FindBy(xpath = "//div[contains(text(),'COUNTRY')]/following::div[2]")
	public static WebElement Tier3_CountrynName;
	
	@FindBy(xpath = "//div[contains(text(),'COUNTRY')]")
	public static WebElement Tier3_Country;
	
	@FindBy(xpath = "//div[contains(text(),'Read Now')]")
	public static WebElement Tier3_ReadnowCTA;
	
	@FindBy(xpath = "//div[contains(text(),'Select Issue')]")
	public static WebElement Tier3_selectIssueCTA;
	
	@FindBy(xpath = "//div[contains(text(),'LANGUAGE')]")
	public static WebElement Tier3_Language;
	
	@FindBy(xpath = "//div[contains(text(),'LANGUAGE')]/following::div[2]")
	public static WebElement Tier3_LanguageName;
	
	@FindBy(xpath = "//div[contains(text(),'COUNTRY')]/following::div[2]")
	public static WebElement Tier3_MultipleCountry;
	
	@FindBy(id = "countrydownarrow")
	public static WebElement Tier3_MultipleCountry_downarrow;
	
	@FindBy(id = "countryuparrow")
	public static WebElement Tier3_MultipleCountry_uparrow;
	
	@FindBy(id = "loc_TxtFeaturedReadingProgram")
	public static WebElement FeaturedReadingprog;
	
	@FindBy(xpath = "(//a[contains(text(),'See All Open Programs ')])[1]")
	public static WebElement seeAll_FeaturedReadingprogram;

	@FindBy(xpath = "(//*[@id='newspaper_magazine_book-img'])[2]")
	public static WebElement newsPaperCard;

	@FindBy(xpath = "//*[@class='third-party-card-details']")
	public static WebElement newsPaperDetailsScreen;

	@FindBy(xpath = "//*[@class='ac-textBlock'][contains(text(),'LANGUAGE')]")
	public static WebElement language;

	@FindBy(xpath = "(//*[@class='ac-textBlock'][contains(text(),'COUNTRY')])[1]")
	public static WebElement countryDetail1;

	@FindBy(xpath = "(//*[@class='ac-textBlock'][contains(text(),'COUNTRY')])[2]")
	public static WebElement countryDetail2;

	@FindBy(xpath = "//button[@title='Read']")
	public static WebElement readNowCta;

	@FindBy(xpath = "//button[@title='Select Issue']")
	public static WebElement selectIssueCta;

	@FindBy(id = "newspaper_magazine_title")
	public static WebElement publicationName;

	@FindBy(xpath = "//*[@id='countrydownarrow']//img")
	public static WebElement multipleCountryDropDwn;

	@FindBy(id = "countryuparrow")
	public static WebElement multipleCountryupArrow;

	@FindBy(xpath = "//a[contains(text(),'See All ')]")
	public static WebElement seeAllLibReader;

	@FindBy(xpath = "//*[@aria-label='See All Magazines']")
	public static WebElement seeAllTier1Reader;

	@FindBy(xpath = "")
	public static WebElement seeAllTier2Reader;

	@FindBy(id = "refine_modal_header_text_country")
	public static WebElement filterCountry;

	@FindBy(xpath = "//*[@class='ac-container'][@id='cardContent2']")
	public static WebElement listedCountry;

	@FindBy(xpath = "//label[@class='ac-textBlock'][contains(text(),'United States')]")
	public static WebElement listedCountryUS;

	@FindBy(xpath = "//*[@class='kz-press-reader']")
	public static WebElement tier1Page;

	@FindBy(xpath = "//label[contains(text(),'Newspapers & Magazines')]")
	public static WebElement newsPaperCategory;

	@FindBy(xpath = "//*[@class='search-result-info']//*[contains(text(),'Publications')]")
	public static WebElement newsPaperResult;

	@FindBy(xpath = "(//*[@class='ac-textBlock'][contains(text(),'COUNTRY')])[1]")
	public static WebElement mutipleCountryRefPub;

	@FindBy(xpath = "//*[@id='defaultcountrytext']")
	public static WebElement countryText;
	
	@FindBy(xpath = "(//div[@id='newspaper_magazine_ribbon_text'])[1]")
	public static WebElement multipleCountry_Ribbon;

	@FindBy(xpath = "")
	public static WebElement mutipleCountryRefArt;

	@FindBy(xpath = "//*[contains(text(),'Publications')]//following::*[@svgicon='kz-right-arrow']")
	public static WebElement seeAllLinkPubResult;

	@FindBy(xpath = "//*[contains(text(),'Articles')]//following::*[@svgicon='kz-right-arrow']")
	public static WebElement seeAllLinkArtResult;

	@FindBy(xpath = "//*[@class='third-party-tier-two-container']")
	public static WebElement tier2Publications;

	@FindBy(xpath = "//*[@class='third-party-tier-two-container']")
	public static WebElement tier2Articles;

	@FindBy(xpath = "//*[@class='featured-card-carousel']")
	public static WebElement featuredBannerPubTier1;

	@FindBy(xpath = "//*[@aria-label='See all Based on your Interests']")
	public static WebElement basedOnSeeAll;

	@FindBy(xpath = "//*[@class='title-list-container']//*[contains(text(),'based on your interest')]")
	public static WebElement basedOnTier2;

	@FindBy(xpath = "//*[@class='mat-card-image card-image']")
	public static List<WebElement> titleCardTier2;

	@FindBy(xpath = "//*[@svgicon='kz-edit-icon']")
	public static WebElement editIconBasedOnTier2;

	@FindBy(xpath = "")
	public static WebElement saveCTABasedOnTier2;

	@FindBy(xpath = "//*[@class='interest-heading']")
	public static WebElement intrestSurveyPage;

	@FindBy(xpath = "(//*[@alt='catagories'])")
	public static List<WebElement> intrestSurveyTopics;

	@FindBy(id = "loc_btnSaveinterest")
	public static WebElement intrestSurveySave;

	@FindBy(xpath = "")
	public static WebElement noRecommendationDisplayed;

	@FindBy(xpath = "(//*[@id='newspaper_magazine_ribbon_text'][contains(text(),'United...')])[1]")
	public static WebElement defaultCountrySorted;
	
	@FindBy(xpath = "//*[@class='kz-toast-msg']/*[contains(text(),'Success')]")
	private WebElement sucessMsg;

	@FindBy(xpath = "//*[@class='ac-textBlock'][contains(text(),'ISSUE DATE')]")
	public static WebElement issueDate;

	@FindBy(xpath = "//*[@class='featured-card-carousel']//*[@class='ac-textBlock adp-card-title-text-bottom']")
	public static List<WebElement> readerTypeDisplayed;
	
	@FindBy(xpath = "//h2[contains(text(),'Publications ')]")
	public static WebElement SearchResult_publicationtxt;
	
	@FindBy(id = "refine_modal_header_text_sort_by")
	public static WebElement Refiner_sort;
	
	@FindBy(xpath = "//label[contains(text(),'Popularity')]")
	public static WebElement Refiner_popularity;
	
	@FindBy(xpath = "//label[contains(text(),'Relevance')]")
	public static WebElement Refiner_Relevence;
	
	@FindBy(xpath = "//label[contains(text(),'Publication Date')]")
	public static WebElement Refiner_publicationDate;

	@FindBy(xpath = "//label[@class='ac-textBlock'][contains(text(),'International')]")
	public static WebElement listedcountryInternational;
	
	@FindBy(id = "refine_modal_header_text_languages")
	public static WebElement filterLanguage;
	
	@FindBy(xpath = "//*[@class='ac-textBlock'][contains(text(),'Afrikaans')]")
	public static WebElement listedlanguage;
	
	@FindBy(xpath = "//div[@class='mat-tab-link-container']")
	public static WebElement refinerPills;
	
	@FindBy(xpath = "//a[contains(text(),'Clear All')]")
	public static WebElement clearAllPill;
	
	public boolean newspaperMagazine_tier2_RefinerDetails() {
	boolean b=true;
	Assert.assertTrue(Refiner_sort.isDisplayed());
	Assert.assertTrue(Refiner_popularity.isDisplayed());
	Assert.assertTrue(Refiner_Relevence.isDisplayed());
	Assert.assertTrue(Refiner_publicationDate.isDisplayed());
	return b;

	}
	public void click_NewsMagSeeAll() {
		waitForDocumentToLoad();
		javascriptScroll(newsMag_SeeAll);
		jsClick(newsMag_SeeAll);
		visibilityWait(tier1_newsMag);
	}
	public void clickNewsPaperTitleCardLib() {
		waitForDocumentToLoad();
		jsClick(newsPaperCard);
		WaitForWebElement(newsPaperDetailsScreen);
	}
	
	public void click_Tier1SeeAll() {
		javascriptScroll(newsMag_Tier1SeeAll);
		jsClick(newsMag_Tier1SeeAll);
		waitForDocumentToLoad();
	}

	public void verifyNewsPaperDetails() {
		waitForDocumentToLoad();
		Assert.assertTrue(publicationName.isDisplayed());
		Assert.assertTrue(language.isDisplayed());
		Assert.assertTrue(issueDate.isDisplayed());
		Assert.assertTrue(countryDetail1.isDisplayed());
		Assert.assertTrue(selectIssueCta.isDisplayed());
		Assert.assertTrue(readNowCta.isDisplayed());
	}
	
	public void click_newsmagCategories() {
		waitForDocumentToLoad();
		visibilityWait(newsMag_categories);
		javascriptScroll(newsMag_categories);
		jsClick(newsMag_categories);
		waitForDocumentToLoad();
	}

	public void clickBack() {
		waitForDocumentToLoad();
		DriverManager.getDriver().navigate().back();
//			jsClick(intrestSurveySave);
		WaitForWebElement(basedOnTier2);
	}

	public void displayedOrder() {
		for (int i = 0; i < readerTypeDisplayed.size(); i++) {
			if (i == 0) {
				Assert.assertEquals(readerTypeDisplayed.get(i).getText().contains("Magazine"), true);
				Logger.log("Magazine Displayed First in the Order");
			} else if (i == 1) {
				Assert.assertEquals(readerTypeDisplayed.get(i).getText().contains("Newspaper"), true);
				Logger.log("Newspaper Displayed Second in the Order");
			} else if (i == 2) {
				Assert.assertEquals(readerTypeDisplayed.get(i).getText().contains("Magazine"), true);
				Logger.log("Magazine Displayed Third in the Order");
			} else if (i == 3) {
				Assert.assertEquals(readerTypeDisplayed.get(i).getText().contains("Newspaper"), true);
				Logger.log("Newspaper Displayed Fourth in the Order");
			}
		}
	}

	public void clickDisplayCheckoutHistory() {
		jsClick(diplayCheckHisCheckBox);
		waitForDocumentToLoad();
	}

	public void clickDisplayInsightBadges() {
		jsClick(diplayInsBadCheckBox);
		waitForDocumentToLoad();
	}

	public void clickDisplayCheckoutCancel() {
		waitForDocumentToLoad();
		jsClick(displayCheckoutPopUpCancel);
		inVisibilityWait(displayCheckoutPopUp);
	}

	public void clickDisplayCheckoutDisable() {
		waitForDocumentToLoad();
		jsClick(displayCheckoutPopUpDisable);
		inVisibilityWait(displayCheckoutPopUp);
	}
	
	
	public void verify_DefaultCountrySelected() {
	javascriptScroll(Tier2_country_dropdwn);
	jsClick(Tier2_country_dropdwn);
	waitForDocumentToLoad();
	for (int i = 0; i < Tier2_country.size(); i++) {
		if (Tier2_country.get(i).isSelected()) {
			System.out.println("Default selected country is: "+Tier2_country.get(i));
			break;		
		}else {
			
		}
	}
	

	}
	
	
	public void click_PublicationCarouselSeeAll() {
		waitForDocumentToLoad();
		javascriptScroll(newsMag_SeeAll);
		jsClick(newsMag_SeeAll);
		waitForDocumentToLoad();

	}
	
	public void click_PublicationTitle_navTier3() {
		javascriptScroll(publicationTitle_NavTier3);
		jsClick(publicationTitle_NavTier3);
		visibilityWait(newsmag_tier3);		

	}
	
	public boolean verify_Tier3Details() {
		boolean b=true;
		Assert.assertTrue(Tier3_publicationName.isDisplayed());
		Assert.assertTrue(Tier3_ReadnowCTA.isDisplayed());
		Assert.assertTrue(Tier3_selectIssueCTA.isDisplayed());
		javascriptScroll(Tier3_Country);
		if (Tier3_Country.isDisplayed()) {
			Assert.assertTrue(Tier3_CountrynName.isDisplayed());
		}
		else if (Tier3_Language.isDisplayed()) {
			Assert.assertTrue(Tier3_LanguageName.isDisplayed());
		}
		
		return b;
	}
	
	public void click_multiplicCountryDownarrow() {
		visibilityWait(Tier3_MultipleCountry_downarrow);
		jsClick(Tier3_MultipleCountry_downarrow);
		

	}

	public void clickNewsPaperTitleCard() {
		waitForDocumentToLoad();
		jsClick(newsPaperCard);
		WaitForWebElement(newsPaperDetailsScreen);
	}

	public void multipleCountry() {
		if (isElementPresent(countryDetail1)) {
			waitForDocumentToLoad();
			Logger.log("First Country detail is Available");
		} else if (isElementPresent(countryDetail2)) {
			waitForDocumentToLoad();
			Logger.log("Multiple Country detail is Available");
		}
	}

	public void multipleCountryDropDown() {
		javascriptScroll(multipleCountryDropDwn);
		jsClick(multipleCountryDropDwn);
		WaitForWebElement(multipleCountryupArrow);
		waitForDocumentToLoad();
		multipleCountry();
	}

	public void multipleCountryUpArrow() {
		javascriptScroll(multipleCountryupArrow);
		jsClick(multipleCountryupArrow);
		inVisibilityWait(multipleCountryupArrow);
	}

	public void clickSeeAllReaderLib() {
		javascriptScroll(seeAllLibReader);
		jsClick(seeAllLibReader);
		WaitForWebElement(tier1Page);
	}

	public void clickSeeAllReaderTier1() {
		javascriptScroll(seeAllTier1Reader);
		jsClick(seeAllTier1Reader);
		WaitForWebElement(tier2Publications);
	}

	public void clickNewsPaperCategory() {
		javascriptScroll(newsPaperCategory);
		jsClick(newsPaperCategory);
		//WaitForWebElement(newsPaperResult);
	}

	public void clickSeeAllPubSearchResult() {
		javascriptScroll(seeAllLinkPubResult);
		jsClick(seeAllLinkPubResult);
		WaitForWebElement(tier2Publications);
	}

	public void clickSeeAllArtSearchResult() {
		javascriptScroll(seeAllLinkArtResult);
		jsClick(seeAllLinkArtResult);
		WaitForWebElement(tier2Articles);
	}

	public void clickOutsidePopUpArea() {
		javascriptScroll(Profile.profileEditSection);
		jsClick(Profile.profileEditSection);
	}

	public void clickBasedOnSeeAll() {
		jsClick(basedOnSeeAll);
		WaitForWebElement(basedOnTier2);
	}

	public void clickEditIconBasedOn() {
		jsClick(editIconBasedOnTier2);
		WaitForWebElement(intrestSurveyPage);
	}
	
	public void updateInterestSurvey() {
		javascriptScroll(intrestSurveyTopics.get(4));
		jsClick(intrestSurveyTopics.get(4));
		javascriptScroll(intrestSurveyTopics.get(8));
		jsClick(intrestSurveyTopics.get(8));
	}

	public void clickSaveCTA() {
		waitForDocumentToLoad();
		jsClick(intrestSurveySave);
		WaitForWebElement(sucessMsg);
		WaitForWebElement(basedOnTier2);
	}

	public void clickFilterCountry() {
		jsClick(filterCountry);
		WaitForWebElement(listedCountry);
		if (listedCountryUS.isSelected()) {
			Logger.log("User able to see the selected by Default");
		}
	}
	
	public void selectRefiners() {
		ClickOnWebElement(Refiner_publicationDate);
		WaitForWebElement(filterCountry);
		ClickOnWebElement(filterCountry);
		WaitForWebElement(listedcountryInternational);
		ClickOnWebElement(listedcountryInternational);
		WaitForWebElement(filterLanguage);
		ClickOnWebElement(filterLanguage);
		WaitForWebElement(listedlanguage);
		ClickOnWebElement(listedlanguage);

	}
	
}
