package pom.kidszone;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class MyLibrary_Vbooks extends CommonAction {

	static ExcelReader reader = new ExcelReader();
//	MyLibrary_Videobooks video = new MyLibrary_Videobooks(DriverManager.getDriver());

	public MyLibrary_Vbooks(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='list_id_VBOOKS']")
	private WebElement Lib_vbookCarouselFormat;

	@FindBy(id = "dummy")
	private WebElement Lib_vbookCarousel_itemCarouselType;

	@FindBy(xpath = "//h2[text()='vBooks']")
	private WebElement Lib_vbookCarousel_CardCarouselType;

	@FindBy(xpath = "(//div[@id='loc_third_party_VBOOKS_item_carousel']//following-sibling::div)[2]")
	public WebElement Lib_vbookCarousel_vbooktitleCoverimg;
	
	@FindBy(xpath = "(//*[@class='ac-container ac-selectable'])[1]")
	private WebElement Lib_vbookCarousel_vbooktitleTier2;

	@FindBy(xpath = "(//button[@class='ac-pushButton style-default ac-selectable'])[1]")
	private WebElement Lib_vbookCarousel_PrimaryCTAasCheckout;

	@FindBy(xpath = "//*[@class='third-party-card-details third-party-videos-detail']")
	private WebElement Lib_vbookCarousel_Nav_Tier3Detailspage;

	@FindBy(xpath = "(//button[@class='ac-pushButton style-default primary style-positive ac-selectable'])[1]")
	private WebElement Lib_vbookCarousel_PrimaryCTATitleDetails;

	@FindBy(xpath = "//*[contains(text(),'Renew')]")
	public static WebElement renewCTA;

	@FindBy(xpath = "(//div[contains(text(),'Play')])[1]")
	private WebElement Lib_vbookCarousel_PrimaryCTAasPlay;

	@FindBy(xpath = "(//div[contains(text(),'Resume')])[1]")
	private WebElement Lib_vbookCarousel_Resume;

	@FindBy(id = "dummy")
	private WebElement Lib_vbookCarousel_ResumeCTA;

	@FindBy(xpath = "//*[@aria-label='See All Popular Videobooks']")
	private WebElement Lib_vbookCarousel_seeAllCTA;

	public WebElement getLib_vbookCarousel_seeAllCTA() {
		return Lib_vbookCarousel_seeAllCTA;
	}

	@FindBy(id = "dummy")
	private WebElement Lib_vbookCarousel_tier1_Featuredcarousel;

	@FindBy(id = "dummy")
	private WebElement Lib_vbookCarousel_tier1_othercarousel;

	@FindBy(id = "dummy")
	private WebElement Lib_vbookCarousel_tier1_titleCarousel;

	@FindBy(id = "dummy")
	private WebElement Lib_vbookCarousel_tier1_categoryCarousel;

	@FindBy(xpath = "(//a[contains(text(),'See All')])[1]")
	private WebElement tier1SeeAllVbook;

	@FindBy(xpath = "//div[@class='thirdparty-tiertworightwrap']")
	private WebElement tier2PageVBook;

	@FindBy(xpath = "//li[@class='breadcrumb-item current ng-star-inserted']")
	private WebElement tier2Page;

	@FindBy(xpath = "(//*[@class='kz-filter-select'])[2]")
	public static WebElement formatFilter;

	@FindBy(xpath = "(//*[@svgicon='kz-filter-down-arrow'])[2]")
	private WebElement formatDropdown;

	@FindBy(xpath = "//span[contains(text(),'eBook')]")
	private WebElement eBook;

	@FindBy(xpath = "//span[contains(text(),'Audio')]")
	private WebElement audioBook;

	@FindBy(xpath = "//*[contains(text(),'Video ')]")
	private WebElement format_Videos;

	@FindBy(xpath = "//span[contains(text(),' Videobooks ')]")
	private WebElement format_Vbooks;

	@FindBy(xpath = "//span[contains(text(),'Available Now')]")
	private WebElement Availability_AvailableNow_dropdwn;

	@FindBy(xpath = "dummy")
	private WebElement mylib_vbooks_titles;

	@FindBy(xpath = "//div[contains(text(),'Checkout')]")
	private WebElement chekoutCTATier3;

	@FindBy(xpath = "//*[contains(text(),'Vbook Carousel ')]//following::*[contains(text(),'Checkout')]")
	private List<WebElement> checkoutCTA_vbookcarousel;

	@FindBy(xpath = "//*[contains(text(),'Vbook Carousel ')]//following::*[@class='ac-container ac-adaptiveCard']/div[3]")
	private List<WebElement> checkoutCTA_vbookcarousel_titleName;

	@FindBy(xpath = "(//div[contains(text(),'The Reading Road Trip')])[1]")
	private WebElement mRBillie;

	@FindBy(id = "alert-dialog-title")
	private WebElement Alert_dialogpopup;

	@FindBy(xpath = "(//img[@class='ac-image ac-selectable'])[21]")
	private WebElement checkersTV;

	@FindBy(xpath = "//*[@class='kz-press-reader']")
	private WebElement vBookTier1Page;

	@FindBy(xpath = "//h3[contains(text(),'Vbook Carousel ')]/following::div[text()='Checkout']")
	private List<WebElement> vbook_CheckoutCTA;

	@FindBy(xpath = "//mat-icon[@svgicon='close']")
	public WebElement Checkout_popup;

	@FindBy(xpath = "//div[contains(text(),'Checkout')]")
	private List<WebElement> checkoutInTier2;
	
	@FindBy(xpath = "(//img[@class='ac-image ac-selectable'])[3]")
	private WebElement vBookCategory_scienceAndNature;
	
	@FindBy(xpath = "(//*[contains(text(),'Popular Videobooks ')]//following::*[@class='carousel-arrow carousel-arrow-next'])[1]")
	private WebElement VBookCarousel_nextButton;
	
	@FindBy(xpath = "(//*[contains(text(),'Popular Videobooks ')]//following::*[@class='carousel-arrow carousel-arrow-prev'])[1]")
	private WebElement VBookCarousel_prevButton;
	
	@FindBy(xpath = "dummy")
	private WebElement VBookseeAllCtaOnWidget;
	
	@FindBy(id = "breadcrumb-link-1")
	private WebElement Tier1_Breadcrumb;
	
	@FindBy(xpath = "(//*[contains(text(),'Play')])[1]")
	public static WebElement playas_primaryCTA;
	
	@FindBy(xpath = "(//div[@id='adp-category-text'])[1]")
	public static WebElement Widget_SnoozersAdventure;
	
	@FindBy(id = "video")
	private WebElement video_content;
	
	@FindBy(id = "loc_confirmbtnOK")
	public static WebElement tier3_ReturnOk;
	
	@FindBy(xpath = "//button[@title='Checkout']")
	private WebElement checkOutSearchResult;
	
	@FindBy(xpath = "//*[contains(text(),'Return')]")
	public static WebElement returnCTA;
	
	public WebElement getVBookCarousel_nextButton() {
		return VBookCarousel_nextButton;
	}

	public WebElement getVBookCarousel_prevButton() {
		return VBookCarousel_prevButton;
	}
	
	public WebElement getTier2Page() {
		return tier2Page;
	}
	
	public WebElement getCheckersTV() {
		return checkersTV;
	}

	public WebElement getAvailability_AvailableNow_dropdwn() {
		return Availability_AvailableNow_dropdwn;
	}

	public WebElement getmRBillie() {
		return mRBillie;
	}

	public WebElement getTier2PageVBook() {
		return tier2PageVBook;
	}

	public WebElement getLib_vbookCarousel_tier1_categoryCarousel() {
		return Lib_vbookCarousel_tier1_categoryCarousel;
	}

	public WebElement getLib_vbookCarousel_tier1_titleCarousel() {
		return Lib_vbookCarousel_tier1_titleCarousel;
	}

	public WebElement getLib_vbookCarousel_tier1_Featuredcarousel() {
		return Lib_vbookCarousel_tier1_Featuredcarousel;
	}

	public WebElement getLib_videoCarousel_tier1_othercarousel() {
		return Lib_vbookCarousel_tier1_othercarousel;
	}

	public WebElement getLib_vbookCarousel_ResumeCTA() {
		return Lib_vbookCarousel_ResumeCTA;
	}

	public WebElement getLib_vbookCarousel_PrimaryCTAasPlay() {
		return Lib_vbookCarousel_PrimaryCTAasPlay;
	}

	public WebElement getLib_vbookCarousel_PrimaryCTAasCheckout() {
		return Lib_vbookCarousel_PrimaryCTAasCheckout;
	}

	public WebElement getLib_vbookCarousel_Nav_Tier3Detailspage() {
		return Lib_vbookCarousel_Nav_Tier3Detailspage;
	}

	public WebElement getLib_vbookCarousel_vbooktitleCoverimg() {
		return Lib_vbookCarousel_vbooktitleCoverimg;
	}

	public WebElement getLib_vbookCarousel_itemCarouselType() {
		return Lib_vbookCarousel_itemCarouselType;
	}

	public WebElement getLib_vbookCarousel_CardCarouselType() {
		return Lib_vbookCarousel_CardCarouselType;
	}

	public WebElement getLib_vbookCarousel_PrimaryCTATitleDetails() {
		return Lib_vbookCarousel_PrimaryCTATitleDetails;
	}

	/***********************************************************************************************************/

	public boolean view_vbookCarouselFormat() {
		javascriptScroll(Lib_vbookCarouselFormat);
		boolean b = true;
		if (Lib_vbookCarouselFormat.isDisplayed()) {
			b = true;
		} else {
			b = false;
		}
		return b;
	}

	public boolean view_coverimgAndprimaryCTA() {
		boolean b = true;
		Assert.assertTrue(Lib_vbookCarousel_vbooktitleCoverimg.isDisplayed());
		//Assert.assertTrue(Lib_vbookCarousel_PrimaryCTAasCheckout.isDisplayed());
		return b;
	}

	public void click_vbookTitleCard() {
		WaitForWebElement(Lib_vbookCarousel_vbooktitleCoverimg);
		ClickOnWebElement(Lib_vbookCarousel_vbooktitleCoverimg);
		WaitForWebElement(Lib_vbookCarousel_Nav_Tier3Detailspage);
	}
	
	public void click_vbookTitleCardTier2() {
		WaitForWebElement(Lib_vbookCarousel_vbooktitleTier2);
		ClickOnWebElement(Lib_vbookCarousel_vbooktitleTier2);
		WaitForWebElement(Lib_vbookCarousel_Nav_Tier3Detailspage);
	}


	public void click_CheckoutAsprimaryCTA() {
		if (Lib_vbookCarousel_PrimaryCTATitleDetails.getText().equalsIgnoreCase("Checkout")) {
			waitFor(2000);
			jsClick(Lib_vbookCarousel_PrimaryCTATitleDetails);
//			WaitForWebElement(getLib_vbookCarousel_PrimaryCTAasPlay());
		} else {
			waitFor(2000);
		}
	}

	public void click_PlayCTA() {
		if (Lib_vbookCarousel_PrimaryCTAasPlay.isDisplayed()) {
			jsClick(Lib_vbookCarousel_PrimaryCTAasPlay);
			waitFor(2000);
			ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
			DriverManager.getDriver().switchTo().window(tabs.get(1));
			waitFor(2000);
			jsClick(video_content);
			waitFor(3000);
			DriverManager.getDriver().close();
			DriverManager.getDriver().switchTo().window(tabs.get(0));
			DriverManager.getDriver().navigate().refresh();
			waitFor(2000);
			visibilityWait(Lib_vbookCarousel_Resume);
			Assert.assertTrue(isElementPresent(Lib_vbookCarousel_Resume));
		}else {
			jsClick(returnCTA);
			waitFor(2000);
			javascriptScroll(tier3_ReturnOk);
			jsClick(tier3_ReturnOk);
			WaitForWebElement(checkOutSearchResult);
			jsClick(checkOutSearchResult);
			visibilityWait(Lib_vbookCarousel_PrimaryCTAasPlay);
			jsClick(Lib_vbookCarousel_PrimaryCTAasPlay);
			waitFor(2000);
			ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
			DriverManager.getDriver().switchTo().window(tabs.get(1));
			waitFor(2000);
			jsClick(video_content);
			waitFor(3000);
			DriverManager.getDriver().close();
			DriverManager.getDriver().switchTo().window(tabs.get(0));
			DriverManager.getDriver().navigate().refresh();
			waitFor(2000);
			visibilityWait(Lib_vbookCarousel_Resume);
			Assert.assertTrue(isElementPresent(Lib_vbookCarousel_Resume));
		}			
	}

	public void Click_level1page() {
		javascriptScroll(Lib_vbookCarouselFormat);
		jsClick(Lib_vbookCarousel_seeAllCTA);
		waitFor(2000);
	}

	public void click_SeeAllTier1VBook() {
		visibilityWait(tier1SeeAllVbook);
		javascriptScroll(tier1SeeAllVbook);
		jsClick(tier1SeeAllVbook);
		visibilityWait(tier2PageVBook);
		// WaitForWebElement(tier2PageVBook);
	}

	public void click_vbookSeeAllCTA() {
		javascriptScroll(Lib_vbookCarousel_seeAllCTA);
		jsClick(Lib_vbookCarousel_seeAllCTA);
		waitFor(2000);
		//WaitForWebElement(vBookTier1Page);
	}

	public void View_FormatOptions() {
		WaitForWebElement(formatFilter);
		jsClick(formatDropdown);
		WaitForWebElement(eBook);
		eBook.isDisplayed();
		audioBook.isDisplayed();
		format_Videos.isDisplayed();
		format_Vbooks.isDisplayed();

	}

	public void select_Vbooks() {
		jsClick(format_Vbooks);
		waitFor(2000);
	}

	public void select_videos() {
		visibilityWait(format_Videos);
		jsClick(format_Videos);
		waitFor(3000);
	}

	public void click_vbookcheckoutCTALibpage() {
		// visibilityWait(checkoutCTA_vbookcarousel.get(1));
		javascriptScroll(checkoutCTA_vbookcarousel.get(1));
		for (int i = 0; i < vbook_CheckoutCTA.size(); i++) {
			jsClick(vbook_CheckoutCTA.get(i));
			break;
		}

//		javascriptScroll(checkoutCTA_vbookcarousel.get(1));
//		for (int i = 0; i < checkoutCTA_vbookcarousel.size(); i++) {
//			if (vbook_CheckoutCTA.get(i).getText().equalsIgnoreCase("Checkout")) {
//				//String checkout_titleName = checkoutCTA_vbookcarousel_titleName.get(i).getText();
//				jsClick(vbook_CheckoutCTA.get(i));
//				waitFor(2000);
//				try {
//					if (Checkout_popup.isDisplayed()) {
//						visibilityWait(Checkout_popup);
//						jsClick(Checkout_popup);
//						waitFor(2000);
//						javascriptScroll(checkoutCTA_vbookcarousel.get(2));
//						jsClick(vbook_CheckoutCTA.get(2));
//						break;
//					}else {
//						System.out.println("checkout popup not displayed");
//					}
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//				
//			}						
//		}
	}

	public void click_checkoutCTALibpage() {
		visibilityWait(checkoutCTA_vbookcarousel.get(1));
		javascriptScroll(checkoutCTA_vbookcarousel.get(1));
		for (int i = 0; i < checkoutCTA_vbookcarousel.size(); i++) {
			if (checkoutCTA_vbookcarousel.get(i).getText().equalsIgnoreCase("Checkout")) {
				// String checkout_titleName =
				// checkoutCTA_videocarousel_titleName.get(i).getText();
				jsClick(checkoutCTA_vbookcarousel.get(i));
				break;
			}
		}
	}

	public void clickMrBillie() {
		javascriptScroll(mRBillie);
		jsClick(mRBillie);
		WaitForWebElement(tier2Page);
	}

	public void clickCheckoutCTATier3() {
		javascriptScroll(chekoutCTATier3);
		jsClick(chekoutCTATier3);
		WaitForWebElement(renewCTA);
		waitFor(2000);
		// WaitForWebElement(video.renewCTA);
	}
	
	public boolean view_vbookWidgetCarousel() {
		javascriptScroll(Lib_vbookCarousel_CardCarouselType);
		boolean b = true;
		if (Lib_vbookCarousel_CardCarouselType.isDisplayed()) {
			b = true;
		} else {
			b = false;
		}
		return b;
	}
	
	public void click_checkoutInTier2page() {
		visibilityWait(checkoutInTier2.get(1));
		for (int i = 0; i < checkoutInTier2.size(); i++) {
			if (checkoutInTier2.get(i).getText().equalsIgnoreCase("Checkout")) {
				jsClick(checkoutInTier2.get(i));
				break;
			}
		}
		WaitForWebElement(playas_primaryCTA);
	}
	
	public void click_VBookCategory() {
		WaitForWebElement(vBookCategory_scienceAndNature);
		ClickOnWebElement(vBookCategory_scienceAndNature);
		WaitForWebElement(tier2Page);

	}
	
	public void click_VBookCarouselLeftRightButton() {
		WaitForWebElement(VBookCarousel_nextButton);
		jsClick(VBookCarousel_nextButton);
		WaitForWebElement(VBookCarousel_prevButton);
		jsClick(VBookCarousel_prevButton);
	}
	
	public void click_VBookSeeAllOnWidget() {
		WaitForWebElement(VBookseeAllCtaOnWidget);
		ClickOnWebElement(VBookseeAllCtaOnWidget);
		WaitForWebElement(Tier1_Breadcrumb);

	}
}
