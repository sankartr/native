package pom.kidszone;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class FeaturedList extends CommonAction {
	static ExcelReader reader = new ExcelReader();

	public FeaturedList(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "loc_linkFeaturedLists")
	private WebElement myshelf_btn_featuredlistadultprofileTheme;

	@FindBy(xpath = "//h2[text()=' featured list ']")
	private WebElement myshelf_txt_featuredlistadultprofileTheme;

	@FindBy(xpath = "//span[@class='text-truncate menu-item-text']")
	private List<WebElement> menu_txt_featuredlistTitle;

	@FindBy(xpath = "//h1[text()=' featured list ']")
	private WebElement myshelf_txt_featuredlistadultprofileTitle;

	@FindBy(id = "menu-list")
	private WebElement menu_MenuList;

	@FindBy(xpath = "(//a[@aria-label='Close'])[1]")
	private WebElement menu_btn_closeCTA;

	@FindBy(id = "Icon-arrow-back")
	private WebElement menu_btn_BackCTA;

	@FindBy(id = "loc_linkEdit")
	private WebElement txt_NavprofilePage;

	@FindBy(id = "dummy")
	private WebElement myshelf_txt_featuredlistkidprofileTheme;

	@FindBy(xpath = "//h2[normalize-space()='Featured']")
	private WebElement myshelf_txt_featuredlistTeenprofileTheme;

	@FindBy(xpath = "//h1[@class='kz-card-title single-ellipsis']")
	private List<WebElement> myshelf_title_featuredlistTeenprofileCarousel;

	@FindBy(id = "dummy")
	private WebElement myshelf_txt_featuredlistdescription;

	@FindBy(xpath = "//a[@class='link']")
	private WebElement myshelf_btn_viewAllcta;

	@FindBy(xpath = "//h2[@class='list-Header']")
	private List<WebElement> txt_featurelistScreen;

	@FindBy(id = "loc_txtAvailability")
	private WebElement txt_availabilityt;

	@FindBy(xpath = "(//mat-icon[@svgicon='kz-filter-down-arrow'])[1]")
	private WebElement btn_availabilityt_arrow;

	@FindBy(xpath = "(//mat-icon[@svgicon='kz-filter-down-arrow'])[2]")
	private WebElement btn_format_arrow;

	@FindBy(xpath = "//span[@class='mat-option-text'][normalize-space()='All']")
	private WebElement drop_availabilityt_All;

	@FindBy(xpath = "//span[normalize-space()='Available Now']")
	private WebElement drop_availabilityt_availablenow;

	@FindBy(xpath = "//span[@class='mat-option-text'][normalize-space()='All']")
	private WebElement drop_format_All;

	@FindBy(xpath = "//span[normalize-space()='eBook']")
	private WebElement drop_format_ebook;

	@FindBy(xpath = "//span[normalize-space()='eAudio']")
	private WebElement drop_format_audio;

	@FindBy(id = "loc_labelNew")
	private WebElement libraryscreen_label_new;

	@FindBy(id = "loc_labelTrending")
	private WebElement libraryscreen_label_trending;

	@FindBy(id = "loc_labelSurprise Me!")
	private WebElement libraryscreen_label_surpriseMe;

	@FindBy(xpath = "//*[@class='kz-featured']//*[@class='link see-all-text']")
	private WebElement viewAllcta_featuredlist;

	@FindBy(id = "list_id_always_available")
	private WebElement AlwaysAvailable_carousel;

	@FindBy(xpath = "//*[@id='list_id_always_available']/div/axis360-titles-carousel/div/p")
	private WebElement AlwaysAvailable_Description;

	@FindBy(xpath = "//*[@id='list_id_always_available']/div/axis360-titles-carousel/div")
	private WebElement AlwaysAvailable_Carousel;

	@FindBy(xpath = "(//*[@aria-label='See all Always Available'])[1]")
	private WebElement AlwaysAvailable_SeeAllCTA;

	@FindBy(xpath = "//div[@class='title-details-info']")
	private WebElement AlwaysAvailable_ResultsScreen;

	@FindBy(xpath = "//*[@class='result-count ng-star-inserted']")
	public WebElement AlwaysAvailable_ResultCount;

	@FindBy(xpath = "(//*[@class='mat-card-image card-image'])[1]")
	public WebElement AlwaysAvailable_title;

	@FindBy(xpath = "//div[@class='titledetails-bookwrapper']")
	public WebElement AlwaysAvailable_tier3;

	@FindBy(xpath = "(//*[contains(text(),' Unlimited Copies Available ')])[2]")
	public WebElement AlwaysAvailable_unlimitedCopies;
	
	@FindBy(xpath = "//*[@class='kz-drawer-inner-container drawer-subnav-container ng-star-inserted']")
	private WebElement featuredList_Level1;

	@FindBy(id = "loc_txtonly_vocational")
	private WebElement FeaturedList_vocational;

	@FindBy(id = "loc_txtteens")
	private WebElement FeaturedList_Teens;

	@FindBy(xpath = "//*[@class='title-details-info']")
	private WebElement FeaturedList_ResultScreen;

	public WebElement getDrop_availabilityt_availablenow() {
		return drop_availabilityt_availablenow;
	}

	public WebElement getTxt_availabilityt() {
		return txt_availabilityt;
	}

	public WebElement getMenu_MenuList() {
		return menu_MenuList;
	}

	public WebElement getMyshelf_txt_featuredlistadultprofileTitle() {
		return myshelf_txt_featuredlistadultprofileTitle;
	}

	public WebElement getMyshelf_txt_featuredlistadultprofileTheme() {
		return myshelf_txt_featuredlistadultprofileTheme;
	}

	public WebElement getMyshelf_txt_featuredlistkidprofileTheme() {
		return myshelf_txt_featuredlistkidprofileTheme;
	}

	public WebElement getMyshelf_txt_featuredlistTeenprofileTheme() {
		return myshelf_txt_featuredlistTeenprofileTheme;
	}

//	public void click_adultprofileFeaturedlist() {
//		ClickOnWebElement(myshelf_btn_featuredlistadultprofileTheme);
//		waitFor(2000);
//	}

	public void click_backCTAfeaturedList() {
		ClickOnWebElement(menu_btn_BackCTA);
		waitFor(3000);
	}

	public void adult_featuredListTitle() {

		try {
			waitFor(2000);
			javascriptScroll(myshelf_txt_featuredlistadultprofileTheme);
			if (isElementPresent(myshelf_txt_featuredlistadultprofileTheme)) {

				Logger.log("featured list is displayed");
			} else {
				Logger.log("No featured list is displayed");

			}
		} catch (Exception e) {

			Logger.log("No featured list is displayed");
		}

	}

	public void click_closeCTA() {
		ClickOnWebElement(menu_btn_closeCTA);
		waitFor(2000);
//		if (txt_NavprofilePage.isDisplayed()) {
//			Logger.log("user is able to view profile page");
//		}

	}

	public void teenprofileFeaturedList() {
		javascriptScroll(myshelf_txt_featuredlistTeenprofileTheme);
		if (myshelf_txt_featuredlistTeenprofileTheme.isDisplayed()) {
			Logger.log("user is able to view teen profile with teen profile specific theme");
		}

	}

	public void kidprofileFeaturedList() {
		try {
			javascriptScroll(myshelf_txt_featuredlistTeenprofileTheme);
			if (myshelf_txt_featuredlistTeenprofileTheme.isDisplayed()) {
				Logger.log("user is able to view kid profile with teen profile specific theme");
			}
		} catch (Exception e) {
			Logger.log("user not able to see featured list for Teen profile");
		}
	}

	public void viewTeenprofile_featuredListcarousel() {
		waitFor(2000);
		for (int i = 0; i < myshelf_title_featuredlistTeenprofileCarousel.size(); i++) {
			if (myshelf_title_featuredlistTeenprofileCarousel.get(i).isDisplayed()) {
				Logger.log("user is able to view featured list titles and description as carousel");
			}
		}

	}

	public boolean Adult_viewSidebarLibraryCuratedList() {
		boolean b = true;
		for (int i = 0; i < menu_txt_featuredlistTitle.size(); i++) {
			if (isElementPresent(menu_txt_featuredlistTitle.get(i))) {
				Logger.log("user is able to view library curated lists in the sidebar based on adult profile type");
			}
		}
		return b;
	}

	public boolean view_featuredListdescriptionAndtitle() {
		boolean b = true;
		// isElementPresent(myshelf_txt_featuredlistTitle);
		isElementPresent(myshelf_txt_featuredlistdescription);
		return b;
	}

	public void click_viewAllctaNavFeaturelist() {
		try {
			ClickOnWebElement(viewAllcta_featuredlist);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean shouldnotshow_featuredList() {
		boolean b = true;
		if (txt_featurelistScreen.size() == 0) {
			Logger.log("system should not view featurelist screen");
		}
		return b;
	}

//	public boolean shouldnotshow_title() {
//		boolean b =true;
//		if (txt_noTitle.size()==0) {
//			Logger.log("system should not view featurelist screen");
//		}
//		return b;
//
//	}

	public void view_availabilityAlldropdown() {
		ClickOnWebElement(btn_availabilityt_arrow);
		waitFor(2000);
		isElementPresent(drop_availabilityt_All);
		isElementPresent(drop_availabilityt_availablenow);
		waitFor(2000);

	}

	public void click_AvailableNow() {
		ClickOnWebElement(drop_availabilityt_availablenow);
		// ClickOnWebElement(drop_availabilityt_availablenow);
		waitFor(3000);
	}

	public void click_defaultAvailabilityandFormatAll() {
		ClickOnWebElement(btn_availabilityt_arrow);
		waitFor(2000);
		ClickOnWebElement(drop_availabilityt_All);
//		isElementPresent(drop_availabilityt_All);
		ClickOnWebElement(btn_format_arrow);
		waitFor(2000);
		ClickOnWebElement(drop_format_All);
//		isElementPresent(drop_format_All);
	}

	public void view_formatViewAll() {
		ClickOnWebElement(btn_format_arrow);
		waitFor(3000);
		isElementPresent(drop_availabilityt_All);
		isElementPresent(drop_format_ebook);
		isElementPresent(drop_format_audio);

	}

	public void click_ebook() {
		ClickOnWebElement(drop_format_ebook);

	}

	public void click_Audio() {
		ClickOnWebElement(drop_format_audio);

	}

	public boolean view_newTrendingAndSurprise() {
		boolean b = true;
		isElementPresent(libraryscreen_label_new);
		isElementPresent(libraryscreen_label_trending);
		isElementPresent(libraryscreen_label_surpriseMe);
		return b;

	}

	public void click_new() {
		ClickOnWebElement(libraryscreen_label_new);
		waitFor(2000);
	}

	public void click_trending() {
		ClickOnWebElement(libraryscreen_label_trending);
		waitFor(2000);
	}

	public void click_surpriseMe() {
		ClickOnWebElement(libraryscreen_label_surpriseMe);
		waitFor(2000);
	}

	public boolean Verify_AlwaysAvailableCarousel() {
		boolean b = true;
		visibilityWait(AlwaysAvailable_carousel);
		javascriptScroll(AlwaysAvailable_carousel);
		Assert.assertEquals(AlwaysAvailable_Description.isDisplayed(), true);
		Assert.assertEquals(AlwaysAvailable_Carousel.isDisplayed(), true);
		visibilityWait(AlwaysAvailable_SeeAllCTA);
		Assert.assertEquals(AlwaysAvailable_SeeAllCTA.isDisplayed(), true);
		return b;

	}

	public void Click_AlwaysAvailableSeeAllCTA() {
		javascriptScroll(AlwaysAvailable_SeeAllCTA);
		jsClick(AlwaysAvailable_SeeAllCTA);
		visibilityWait(AlwaysAvailable_ResultsScreen);

	}

	public void NavTier3_alwaysAvailableTitle() {
		visibilityWait(AlwaysAvailable_title);
		jsClick(AlwaysAvailable_title);
		visibilityWait(AlwaysAvailable_tier3);
		Assert.assertTrue("Unlimited copies Available in Always available",
				AlwaysAvailable_unlimitedCopies.isDisplayed());

	}
	
	public void click_OnlyVocational() {
		javascriptScroll(FeaturedList_vocational);
		jsClick(FeaturedList_vocational);
		visibilityWait(FeaturedList_ResultScreen);

 

	}

	public void click_Teens() {
		javascriptScroll(FeaturedList_Teens);
		jsClick(FeaturedList_Teens);
		visibilityWait(FeaturedList_ResultScreen);

	}
	
	public void click_adultprofileFeaturedlist() {
		visibilityWait(myshelf_btn_featuredlistadultprofileTheme);
		ClickOnWebElement(myshelf_btn_featuredlistadultprofileTheme);
		visibilityWait(featuredList_Level1);

	}	
}
