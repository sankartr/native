package pom.kidszone;

import java.io.IOException;

import java.util.List;
import java.util.Map;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.resuableMethods.Highlighter;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Profileviewudpate extends CommonAction {

	static ExcelReader reader = new ExcelReader();

	public Profileviewudpate(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//p[contains(text(), 'Adult')]")
	private WebElement adult_label;

	@FindBy(xpath = "//a[text()='Add an adult ']")
	private WebElement addanAdult_btn;

	@FindBy(xpath = "//a[text()='Add a teen ']")
	private WebElement addaTeen_btn;

	@FindBy(xpath = "//a[contains(text(),'Add a kid')]")
	private WebElement addaKid_btn;

	@FindBy(xpath = "//a[text()='PROFILES']")
	private WebElement adult_profileMenu;

	@FindBy(id = "loc_dpProfileType")
	private WebElement profileSelect_drop;

	@FindBy(xpath = "//button[contains(text(), 'Yes')]")
	private WebElement btn_Yes;

	@FindBy(xpath = "//button[contains(text(), 'No')]")
	private WebElement deleteNo_btn;

	@FindBy(xpath = "//input[@formcontrolname='displayName']")
	private WebElement displayName_txtfield;

	@FindBy(id = "loc_btnSave")
	private WebElement profileSave_btn;

	@FindBy(xpath = "//*[@id='mat-checkbox-1']/label/div")
	private WebElement displayCheckoutHistory_chkbox;

	@FindBy(id = "add-profile-button")
	private WebElement profileCreate_btn;

	@FindBy(id = "loc_linkEdit")
	private WebElement profileEdit_btn;

	@FindBy(xpath = "//div[@role='button']")
	private List<WebElement> manageProf_pencilIcon_editProfile;

	@FindBy(id = "loc_txtDisplayName")
	private WebElement edit_displayName_txtfield;

	@FindBy(id = "mat-input-2")
	private WebElement edit_displayName_txtfieldKid;

	@FindBy(xpath = "//div[@class=\"action-icon kz-edit-profile-icon ng-star-inserted\"]")
	private WebElement profileAvatar_btn;

	@FindBy(xpath = "//div[@class=\"mat-form-field-flex ng-tns-c78-18\"]")
	private WebElement parentalEmail_txtfield;

	@FindBy(xpath = "//button[contains(text(), 'Delete Profile')]")
	private WebElement profileDelete_btn;

	@FindBy(xpath = "//input[@formcontrolname='displayName']")
	private WebElement displayNameCreate_txtfield;

	@FindBy(xpath = "//button[contains(text(),'Upload Photo')]")
	private WebElement avatarUpload_btn;

	@FindBy(xpath = "//button[contains(text(),'Select Avatar')]")
	private WebElement avatarSelect_btn;

	@FindBy(id = "upload-photo-button")
	private WebElement uploadPhoto_btn;

	@FindBy(xpath = "//button[@class='doneBtn']")
	private WebElement avatarUploadDone_btn;

	@FindBy(xpath = "/html/body/div[6]")
	private WebElement emptyPage_btn;

	@FindBy(xpath = "//span[@class='mat-option-text']")
	private List<WebElement> editprofile_dropdown_profileType;

	@FindBy(xpath = "//span[text()='Kid 0-12']")
	private WebElement drpdown_selectkidProfile;

	@FindBy(xpath = "//span[text()='Teen 13-17']")
	private WebElement drpdown_selectTeenProfile;

	@FindBy(xpath = "//div[@class='profile-image teen profile-default-border']")
	private WebElement manageProf_lbl_notselectprofileimg;

	@FindBy(id = "edit-icon-focus")
	private WebElement editprofile_icon_profileimg;

	@FindBy(xpath = "//a[@class='ng-star-inserted']")
	private List<WebElement> editprofile_img_listofavatar;

	@FindBy(xpath = "//div[@class='profile-listing-sec']")
	private static List<WebElement> profile_list;

	@FindBy(id = "LogOnModel_UserName")
	private static WebElement txt_userName_Textfield;

	@FindBy(xpath = "//button[text()='login']")
	private WebElement login_btn;

	@FindBy(xpath = "//input[@type='password']")
	private WebElement txt_pin_Textfield;

	@FindBy(id = "loc_btnSubmit")
	private WebElement pinsubmit_btn;

	@FindBy(id = "alert-dialog-title")
	private WebElement profile_content;

	@FindBy(xpath = "//*[contains(text(),'Set My Shelf page as my default landing page')]//preceding-sibling::*[@class='mat-checkbox-inner-container']")
	private WebElement manageprof_checkbox_myshelfdefaultLandingPage;

	public WebElement getEditprofile_icon_profileimg() {
		return editprofile_icon_profileimg;
	}

	public List<WebElement> getEditprofile_img_listofavatar() {
		return editprofile_img_listofavatar;
	}

	/*****************************
	 * Action methods
	 ************************************************/

	// Pagesource Changes 05May2022 //

	public void loginwithPin() throws InvalidFormatException, IOException {

		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Pin");
		SendKeysOnWebElement(txt_userName_Textfield, testData.get(0).get("usern"));
		// SendKeysOnWebElement(txt_password_Textfield, testData.get(0).get("userpin"));
		ClickOnWebElement(login_btn);
	}

	public void parentalPin() throws InvalidFormatException, IOException {
		waitFor(4000);
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Pin");
		SendKeysOnWebElement(txt_pin_Textfield, testData.get(0).get("userpin"));
		ClickOnWebElement(pinsubmit_btn);
		WaitForWebElement(profileCreate_btn);

	}

	public void createNewprofile() {
		ClickOnWebElement(profileCreate_btn);
		waitFor(6000);

	}

	public void Clickavatar() {
		ClickOnWebElement(avatarSelect_btn);
		waitFor(6000);

	}

	public void displaynamepass() throws InvalidFormatException, IOException {
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Pin");
		SendKeysOnWebElement(displayName_txtfield, testData.get(0).get("displayname"));

	}

	public void profileEdit() {
		ClickOnWebElement(profileEdit_btn);
		waitFor(6000);

	}

	public void deleteProfile() {
		waitFor(6000);
		ClickOnWebElement(profileDelete_btn);
		ClickOnWebElement(emptyPage_btn);
		isElementPresent(btn_Yes);
		Logger.log("Delete confirmation Yes Button is available");
	}

	public void profileSelect() throws InvalidFormatException, IOException {
		ClickOnWebElement(profileCreate_btn);
		waitFor(5000);
	}

	public void change_profileType() {
		ClickOnWebElement(profileSelect_drop);
		waitFor(3000);

	}

	public void select_profileType_Teen() {
		jsClick(profileSelect_drop);
		waitFor(2000);
		jsClick(editprofile_dropdown_profileType.get(0));
		// editprofile_dropdown_profileType.get(0).click();
	}

	public void select_profileType_Kid() {
		if (drpdown_selectkidProfile.getText().contains("Kid 0-12")) {
			jsClick(profileSelect_drop);
			editprofile_dropdown_profileType.get(1).click();
		} else if (drpdown_selectTeenProfile.getText().contains("Teen 13-17")) {
			jsClick(profileSelect_drop);
			editprofile_dropdown_profileType.get(0).click();
		}
	}

	public void manageProfile_saveCTA() {
		javascriptScroll(profileSave_btn);
		ClickOnWebElement(profileSave_btn);
		waitFor(3000);
	}

	public void select_kidProfile() {
		jsClick(profileSelect_drop);
		waitFor(2000);
		editprofile_dropdown_profileType.get(1).click();

	}

	public void enable_myshelfDefaultLandingPage() {
		javascriptScroll(manageprof_checkbox_myshelfdefaultLandingPage);
		waitFor(2000);
		if (manageprof_checkbox_myshelfdefaultLandingPage.isSelected()) {
			jsClick(manageprof_checkbox_myshelfdefaultLandingPage);
			System.out.println("Already enable");
		} else {
			jsClick(manageprof_checkbox_myshelfdefaultLandingPage);
			// ClickOnWebElement(manageprof_checkbox_myshelfdefaultLandingPage);
			waitFor(2000);
		}

	}

	public void disable_myshelfDefaultLandingPage() {
		javascriptScroll(manageprof_checkbox_myshelfdefaultLandingPage);
		javaScriptScrollToEnd();
		waitFor(2000);
		if (manageprof_checkbox_myshelfdefaultLandingPage.isSelected()) {
			jsClick(manageprof_checkbox_myshelfdefaultLandingPage);
			// ClickOnWebElement(manageprof_checkbox_myshelfdefaultLandingPage);
			System.out.println("disable");
		} else {
			System.out.println("user is disable myshelf default landing page");
			waitFor(2000);
		}
	}

	public void chooseaddaTeen() {
		// Assert.assertEquals(addaTeen_btn.isDisplayed(), true);
		ClickOnWebElement(addaTeen_btn);

	}

	public void chooseaddaKid() {
		// Assert.assertEquals(addaKid_btn.isDisplayed(), true);
		ClickOnWebElement(addaKid_btn);

	}

	public void editDisplayname() throws InvalidFormatException, IOException {

		ClickOnWebElement(edit_displayName_txtfield);
		edit_displayName_txtfield.clear();
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Pin");
		SendKeysOnWebElement(edit_displayName_txtfield, testData.get(0).get("displayname"));
		ClickOnWebElement(profileSave_btn);
		waitFor(6000);
	}

	public void displayNameChange(String dispname) {
		SendKeysOnWebElement(edit_displayName_txtfield, dispname);
		javascriptScroll(profileSave_btn);
		javascriptScroll(profileSave_btn);
		WaitForWebElement(profileSave_btn);
		ClickOnWebElement(profileSave_btn);
		waitFor(3000);
	}

	public boolean displayNameGet() {
		boolean b = true;
		isElementPresent(edit_displayName_txtfieldKid);
		return b;
	}

	public void click_Avatarimg() {
		WaitForListWebElement(editprofile_img_listofavatar);
		for (int i = 0; i < editprofile_img_listofavatar.size(); i++) {
			ClickOnWebElement(editprofile_img_listofavatar.get(2));
		}
	}

	public void afterselectAvatar_save() {
		javaScriptScrollToEnd();
		// javascriptScroll(profileSave_btn);
		waitFor(2000);
		ClickOnWebElement(profileSave_btn);
	}

	public void interestSurvey_popupDisplay() {
		if (profile_content.isDisplayed()) {
			System.out.println(
					"user is able to view confirmation message on changing profile type that interest survey preferences will be reset");
		} else {
			System.out.println("user is not able to view confirmation message");
		}

	}

	public void menu_adultProfile() {
		visibilityWait(adult_profileMenu);
		jsClick(adult_profileMenu);
		waitFor(2000);

	}

}
