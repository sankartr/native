package pom.kidszone;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;

public class Announcement_Admin extends CommonAction {

	public static final Logger logger = LoggerFactory.getLogger(Announcement_Admin.class);
	static ExcelReader reader = new ExcelReader();
	Loginpageview loginpageUpdatedui = new Loginpageview(DriverManager.getDriver());
	AdminPrograms adminPrograms = new AdminPrograms(DriverManager.getDriver());
	WebDriver driver;

	public Announcement_Admin(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@id='LibraryManagement']")
	private WebElement libraryMgmt;

	@FindBy(xpath = "//*[@class='bread-crumb-widget']//*[contains(text(),'Home')]")
	private WebElement homePage;

	@FindBy(xpath = "//*[@class='bread-crumb-widget']//*[contains(text(),'Library Management')]")
	private WebElement libraryMgmtPage;

	@FindBy(id = "searchText")
	private WebElement searchBar;

	@FindBy(xpath = "//button[@id='search']")
	private WebElement searchButton;

	@FindBy(xpath = "(//*[@data-tooltip='Edit Library Settings'])[1]")
	private WebElement editIcon;

	@FindBy(id = "mainContent")
	private WebElement libraryPage;

	@FindBy(xpath = "")
	private WebElement publishCTA;

	@FindBy(xpath = "//*[@class='kz-annouce-edit custom-row']")
	private WebElement announceSection;

	@FindBy(xpath = "(//*[@id='mat-input-0'])")
	private WebElement announceHeadline;

	@FindBy(xpath = "(//*[@id='mat-input-2'])")
	private WebElement announceTitle;

	@FindBy(xpath = "(//*[@id='description'])")
	private WebElement announceDescription;

	@FindBy(xpath = "//button[contains(text(),'Publish')]")
	private WebElement publishButton;

	@FindBy(xpath = "(//button[contains(text(),'Preview')])")
	private WebElement previewButton;

	@FindBy(xpath = "//button[contains(text(),'Unpublish')]")
	private WebElement unPublishButton;

	@FindBy(xpath = "//*[contains(text(),'CURRENT ANNOUNCEMENT')]//..//div[@class='preview']")
	private WebElement publishedSection;

	@FindBy(id = "announcements")
	private WebElement libraryAnnouncement;

	@FindBy(xpath = "(//*[@class='ng-star-inserted'])[2]")
	private WebElement announceMentPage;

	@FindBy(xpath = "//*[@title='Log Off']")
	private WebElement logOff;

	@FindBy(xpath = "//*[@title='Log in']")
	private WebElement logIn;

	@FindBy(xpath = "(//*[@class='announcement ng-star-inserted'])")
	private WebElement previewSection;

	@FindBy(xpath = "//button[@class='submit-btn']")
	private WebElement submitPublish;

	@FindBy(xpath = "//button[@class='submit-btn']")
	private WebElement submitUnPublish;

	@FindBy(id = "opturl")
	private WebElement urlRadioBtn;

	@FindBy(id = "library-administration")
	private WebElement libraryAdministration;

	@FindBy(xpath = "//div[@class='tab-lib-screen-mgmt']")
	private WebElement libraryScreenMgmt;

	@FindBy(xpath = "//*[@placeholder='Enter URL here']")
	private WebElement enterUrl;

	@FindBy(xpath = "//button[contains(text(),'Add')]")
	private WebElement addUrlBtn;

	@FindBy(xpath = "//*[@class='icon_submenu_libraryactions']")
	private WebElement librarySubMenu;

	@FindBy(id = "announcements")
	private WebElement announcementNaviLibrary;

	@FindBy(xpath = "//span[@class='mat-content ng-tns-c98-5']//mat-icon[@svgicon='edit-icon']")
	private WebElement announcementSecEditIcon;

	public WebElement getLibraryAdministration() {
		return libraryAdministration;
	}

	public WebElement getLibraryPage() {
		return libraryPage;
	}

	public WebElement getAnnouncementNaviLibrary() {
		return announcementNaviLibrary;
	}

	public WebElement getLibraryAnnouncement() {
		return libraryAnnouncement;
	}

	public WebElement getAnnounceMentPage() {
		return announceMentPage;
	}

	public WebElement getPublishedSection() {
		return publishedSection;
	}

	public WebElement getUnPublishButton() {
		return unPublishButton;
	}

	public void administrationCTA() {
		WaitForWebElement(libraryAdministration);
		ClickOnWebElement(libraryAdministration);
		WaitForWebElement(libraryScreenMgmt);
	}

	public void clickSubMenu() {
		WaitForWebElement(librarySubMenu);
		ClickOnWebElement(librarySubMenu);
		WaitForWebElement(libraryAdministration);
	}

	public void libraryMgmtClick() {
		WaitForWebElement(homePage);
		javascriptScroll(libraryMgmt);
		ClickOnWebElement(libraryMgmt);
		WaitForWebElement(libraryMgmtPage);
	}

	public void searchLibrary(String libraryName) {
		WaitForWebElement(libraryMgmtPage);
		javascriptScroll(searchBar);
		SendKeysOnWebElement(searchBar, libraryName);
		waitFor(2000);
		jsClick(searchButton);
		waitFor(2000);
	}

	public void clickEditIcon() {
		waitFor(2000);
		javascriptScroll(editIcon);
		ClickOnWebElement(editIcon);
		WaitForWebElement(libraryPage);
	}

	public void clickPublishCTA() {
		javascriptScroll(publishCTA);
		ClickOnWebElement(publishCTA);
		WaitForWebElement(announceSection);
	}

	public void unPublishCase(String url) {
		if (isElementPresent(publishedSection)) {
			logger.info("User already have published content");
		} else {
			publishAction(url);
			clickPublish();
		}
	}

	public void publishCase(String url) {
		if (isElementPresent(publishedSection)) {
			clickUnPublish();
			publishAction(url);
			clickPublish();
		}
		else {
			publishAction(url);
			clickPublish();
		}
	}

	public void publishAction(String url) {
		javascriptScroll(announceHeadline);
		SendKeysOnWebElement(announceHeadline, "Publishing_Announcement");
		waitFor(2000);
		SendKeysOnWebElement(announceTitle, "QA_Test");
		waitFor(2000);
		SendKeysOnWebElement(announceDescription, "Publishing Announcement in QA Environment");
		waitFor(2000);
		if (urlRadioBtn.isSelected()) {
			System.out.println("radio btn is enabled");
		} else {
			ClickOnWebElement(urlRadioBtn);
		}
		WaitForWebElement(enterUrl);
		SendKeysOnWebElement(enterUrl, url);
		WaitForWebElement(addUrlBtn);
		ClickOnWebElement(addUrlBtn);
		WaitForWebElement(previewButton);
		ClickOnWebElement(previewButton);
		WaitForWebElement(previewSection);
	}

	public void clickPublish() {
		javascriptScroll(publishButton);
		ClickOnWebElement(publishButton);
		WaitForWebElement(submitPublish);
		javascriptScroll(submitPublish);
		ClickOnWebElement(submitPublish);
		WaitForWebElement(publishedSection);
	}

	public void clickUnPublish() {
		javascriptScroll(unPublishButton);
		ClickOnWebElement(unPublishButton);
		WaitForWebElement(submitUnPublish);
		javascriptScroll(submitUnPublish);
		ClickOnWebElement(submitUnPublish);
		waitFor(5000);
		WaitForWebElement(announceMentPage);
	}

	public void clickAnnouncementCTA() {
		javascriptScroll(libraryAnnouncement);
		ClickOnWebElement(libraryAnnouncement);
		WaitForWebElement(announceMentPage);
	}

	public void clickLogOff() {
		WaitForWebElement(logOff);
		javascriptScroll(logOff);
		ClickOnWebElement(logOff);
		WaitForWebElement(logIn);
	}

	public void clickAnnounceLibraryCTA() {
		WaitForWebElement(announcementNaviLibrary);
		javascriptScroll(announcementNaviLibrary);
		ClickOnWebElement(announcementNaviLibrary);
		WaitForWebElement(announceMentPage);
	}
}
