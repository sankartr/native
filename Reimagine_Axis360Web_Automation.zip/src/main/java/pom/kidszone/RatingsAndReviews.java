package pom.kidszone;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class RatingsAndReviews extends CommonAction {

	static ExcelReader reader = new ExcelReader();

	public RatingsAndReviews(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//h1[@class='primary-heading-1 ng-star-inserted']")
	private WebElement Nav_TitledetailsScreen;

	@FindBy(xpath = "(//p[@class='ratings ng-star-inserted'])[2]")
	private WebElement view_avg_reviews;

	@FindBy(xpath = "(//div[@class='start-rating-icons ng-star-inserted'])[2]")
	private WebElement view_ratings;

	@FindBy(xpath = "//h2[text()='Children']")
	private WebElement children_carousel;

	@FindBy(xpath = "//div[@class='kz-card-image ng-star-inserted']")
	private List<WebElement> title_in_fiction_carousel;

	@FindBy(xpath = "//h3[contains(text(),'Darkly Dreaming Dexter')]")
	private WebElement rated_title;

	@FindBy(xpath = "//h3[contains(text(),'Splat the Cat: Splat the Cat Sings Flat')]")
	private WebElement rated_title_kid;

	@FindBy(xpath = "(//span[@class='full-stars'])[2]")
	private WebElement rating_stars;

	@FindBy(xpath = "(//span[@class='empty-stars'])[2]")
	private WebElement Btn_start_rating;

	@FindBy(xpath = "//span[@class='rating-title']")
	private WebElement validate_ratings_drawer;

	@FindBy(xpath = "(//div[@class='mat-ripple mat-menu-ripple'])[3]")
	private WebElement Btn_click_star;

	@FindBy(xpath = "//div[@class='kz-toast-msg']")
	private WebElement success_toast_msg;

	@FindBy(xpath = "//span[contains(text(),' You have succesfully rated')]")
	private WebElement success_msg;

	@FindBy(xpath = "//h3[contains(text(),'Turbo Racers')]")
	private WebElement title_to_rate;

	@FindBy(xpath = "(//div[@class='mat-ripple mat-menu-ripple'])[4]")
	private WebElement Btn_click_star_to_update;

	@FindBy(xpath = "//div[text()='Details']")
	private WebElement Btn_detail_cta;

	@FindBy(xpath = "//span[@class='reviewer-name review-desc']")
	private WebElement validate_review_submitted;

	@FindBy(xpath = "//button[contains(text(),' Write A Review ')]")
	private WebElement Btn_write_review_cta;

	@FindBy(id = "alert-dialog-content")
	private WebElement validate_review_input_screen;

	@FindBy(xpath = "//p[contains(text(),'You already submitted a review for this title, which is approved.')]")
	private WebElement validate_approved_msg;

	@FindBy(xpath = "//h3[contains(text(),'Angel Time')]")
	private WebElement rejected_title;

	@FindBy(xpath = "//span[@class='secondary-para']")
	private WebElement character_limit;

	@FindBy(xpath = "//button[text()='Submit']")
	private WebElement Btn_submit_cta;

	@FindBy(xpath = "//h3[contains(text(),'Biscuit and the Lost Teddy Bear')]")
	private WebElement rejected_title_kid;

	@FindBy(xpath = "//h3[contains(text(),'That Old Cape Magic')]")
	private WebElement title_to_review;

	@FindBy(xpath = "//h3[contains(text(),'Starstruck')]")
	private WebElement kid_title_to_review;

	@FindBy(xpath = "//span[contains(text(),' Your review has been submitted to your library for approval. ')]")
	private WebElement success_msg_for_review_submit;

	@FindBy(xpath = "//h3[contains(text(),'Rise of Nine')]")
	private WebElement rated_title_01;

	@FindBy(xpath = "//h3[contains(text(),'Splat the Cat and the Duck With No Quack')]")
	private WebElement title_to_rate_01;

	@FindBy(xpath = "//h3[contains(text(),'Splat the Cat and the Duck With No Quack')]")
	private WebElement rejected_title_kid_01;

	public WebElement getSuccess_msg_for_review_submit() {
		return success_msg_for_review_submit;
	}

	public WebElement getKid_title_to_review() {
		return kid_title_to_review;
	}

	public WebElement getTitle_to_review() {
		return title_to_review;
	}

	public WebElement getRejected_title_kid() {
		return rejected_title_kid;
	}

	public WebElement getBtn_submit_cta() {
		return Btn_submit_cta;
	}

	public WebElement getCharacter_limit() {
		return character_limit;
	}

	public WebElement getRejected_title() {
		return rejected_title;
	}

	public WebElement getBtn_write_review_cta() {
		return Btn_write_review_cta;
	}

	public WebElement getValidate_review_input_screen() {
		return validate_review_input_screen;
	}

	public WebElement getValidate_approved_msg() {
		return validate_approved_msg;
	}

	public WebElement getBtn_detail_cta() {
		return Btn_detail_cta;
	}

	public WebElement getValidate_review_submitted() {
		return validate_review_submitted;
	}

	public WebElement getBtn_click_star_to_update() {
		return Btn_click_star_to_update;
	}

	public WebElement getTitle_to_rate() {
		return title_to_rate;
	}

	public WebElement getSuccess_toast_msg() {
		return success_toast_msg;
	}

	public WebElement getSuccess_msg() {
		return success_msg;
	}

	public WebElement getBtn_start_rating() {
		return Btn_start_rating;
	}

	public WebElement getValidate_ratings_drawer() {
		return validate_ratings_drawer;
	}

	public WebElement getBtn_click_star() {
		return Btn_click_star;
	}

	public WebElement getRating_stars() {
		return rating_stars;
	}

	public WebElement getRated_title() {
		return rated_title;
	}

	public WebElement getRated_title_kid() {
		return rated_title_kid;
	}

	public WebElement getchildren_carousel() {
		return children_carousel;
	}

	public List<WebElement> getTitle_in_fiction_carousel() {
		return title_in_fiction_carousel;
	}

	public WebElement getView_ratings() {
		return view_ratings;
	}

	public WebElement getView_reviews() {
		return view_avg_reviews;
	}

	public WebElement getNav_TitledetailsScreen() {
		return Nav_TitledetailsScreen;
	}

	public void click_title_in_Children() {
		javascriptScroll(children_carousel);
		ClickOnWebElement(title_in_fiction_carousel.get(1));
		Assert.assertTrue(isElementPresent(Nav_TitledetailsScreen));
	}

	public void click_rated_title() {
		waitFor(3000);
		visibilityListWait(title_in_fiction_carousel);
		waitFor(3000);
		jsClick(title_in_fiction_carousel.get(2));
		Assert.assertTrue(isElementPresent(Nav_TitledetailsScreen));
	}

	public void click_title_to_rate() {
		visibilityListWait(title_in_fiction_carousel);
		jsClick(title_in_fiction_carousel.get(5));
		Assert.assertTrue(isElementPresent(Nav_TitledetailsScreen));
	}

	public void click_start_ratings() {
		jsClick(Btn_start_rating);
	}

	public void click_stars() {
		jsClick(Btn_click_star);
	}

	public void click_Stars_to_update() {
		jsClick(Btn_click_star_to_update);
	}

	public void click_details_Tab() {
		jsClick(Btn_detail_cta);
		javaScriptScrollToEnd();
	}

	public void click_write_review_cta() {
		ClickOnWebElement(Btn_write_review_cta);
	}

	public void click_rejectedReview_title() {
		waitFor(3000);
		visibilityListWait(title_in_fiction_carousel);
		jsClick(title_in_fiction_carousel.get(4));
		Assert.assertTrue(isElementPresent(Nav_TitledetailsScreen));
	}

	public void write_review() {
		click_write_review_cta();
		SendKeysOnWebElement(validate_review_input_screen, "testing the title");

	}

	public void click_submit_cta() {
		ClickOnWebElement(Btn_submit_cta);

	}

	public void click_title_to_review() {
		waitFor(3000);
		visibilityListWait(title_in_fiction_carousel);
		jsClick(title_in_fiction_carousel.get(7));
		Assert.assertTrue(isElementPresent(Nav_TitledetailsScreen));
	}

	public void validate_success_msg() {
		if (isElementPresent(success_msg)) {
			Assert.assertTrue(isElementPresent(success_msg));
		} else {
			Logger.log("success msg is disappeared");
		}
	}

	public void validate_approved_msg() {
		if (isElementPresent(validate_approved_msg)) {
			Assert.assertTrue(isElementPresent(validate_approved_msg));
		} else {
			Logger.log("review is not approved");
		}
	}

	public void validate_success_msg_for_review_submit() {
		if (isElementPresent(success_msg_for_review_submit)) {
			Assert.assertTrue(isElementPresent(success_msg_for_review_submit));
		} else {
			Logger.log("review is not approved");
		}

	}
}
