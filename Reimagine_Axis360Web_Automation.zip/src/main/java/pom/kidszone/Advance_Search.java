package pom.kidszone;

import java.util.Iterator;
import java.util.List;

import javax.xml.xpath.XPath;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Advance_Search extends CommonAction{
  
	static ExcelReader reader = new ExcelReader();
	public Advance_Search(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//input[@placeholder='Search for content']")
	private WebElement Btn_searchbar;
	
	@FindBy(xpath = "//button[@class='kz-searchButton']")
	private WebElement searchIcon_in_AdvanceSearch;
	
	@FindBy(xpath = "//*[@class='breadcrumb-item current ng-star-inserted']")
	private WebElement results_for_search;
	
	@FindBy(xpath = "//div[@class='kz-carousel']")
	private List<WebElement> results_in_carousel_format;
	
	@FindBy(xpath = "//a[contains(text(),'eBook, eAudio')]")
	private WebElement validate_eBooks_eAudio_Video;
	
	@FindBy(xpath = "//a[contains(text(),'Activity Resources')]")
	private WebElement validate_Activity_resources;
	
	@FindBy(xpath = "//a[contains(text(),'Web Resources')]")
	private WebElement validate_Web_resources;
	
	@FindBy(xpath = "//h2[@class='carousel-title heading-2']")
	private List<WebElement> results_for_each_paranthesis;
	
	@FindBy(xpath = "//ul[@class='breadcrumb kz-breadcrumb kz-search']")
	private WebElement page_Breadcrumb;
	
	@FindBy(xpath = "//h2[text()=' Category ']")
	private WebElement category_in_left_panel;
	
	@FindBy(xpath = "//h2[text()='Refine']")
	private WebElement refiners_in_left_panel;
	
	@FindBy(xpath = "//a[text()='All ']")
	private WebElement All_option_in_left_panel;
	
	@FindBy(xpath = "//h2[contains(text(),'Please select a category to refine.')]")
	private WebElement choose_category_in_left_panel;
	
	@FindBy(xpath = "//a[text()='See All']")
	private List<WebElement> seeAll_cta;
	
	@FindBy(xpath = "//div[@class='kz-card-image ng-star-inserted']")
	private List<WebElement> title_image;
	
	@FindBy(xpath = "//div[@class='book-poster ng-star-inserted']")
	private List<WebElement> format_icon;
	
	@FindBy(xpath = "//mat-card-content[@class='mat-card-content']")
	private List<WebElement> Authorname_and_title;
	
	@FindBy(xpath = "//button[@class='primary-action ng-star-inserted']")
	private List<WebElement> primary_cta;
	
	@FindBy(xpath = "//button[contains(text(),'Clear')]")
	private WebElement clearAll_cta;
	
	@FindBy(xpath = "//span[contains(text(),'Advanced Search')]")
	private WebElement Btn_advance_search;
	
	@FindBy(xpath = "//input[@aria-required='false']")
	private WebElement searchBar_in_advancesearch;
	
	@FindBy(xpath = "//h3[contains(text(),'Type' )]")
	private WebElement typeOption_in_advanceSearch;
	
	@FindBy(xpath = "//h3[contains(text(),'Category')]")
	private WebElement collections_in_advanceSearch;
	
	@FindBy(xpath = "//h3[contains(text(),'Availability' )]")
	private WebElement availability_in_advanceSearch;
	
	@FindBy(xpath = "//h3[contains(text(),'Format' )]")
	private WebElement format_in_advance_Search;
	
	@FindBy(xpath = "//h3[contains(text(),'Attributes' )]")
	private WebElement attributes_in_advance_search;
	
	@FindBy(xpath = "//div[@class='ui-radiobutton ui-widget']")
	private List<WebElement> radioButtons_in_advanceSearch;
	
	@FindBy(id = "mat-checkbox-1-input")
	private WebElement Available_checkbox;
	
	@FindBy(id = "mat-checkbox-2-input")
	private WebElement AllChecbox_in_format;
	
	@FindBy(id = "mat-checkbox-3-input")
	private WebElement AudioBooks_checkbox_in_format;
	
	@FindBy(id = "mat-checkbox-4-input")
	private WebElement eBooks_checkbox_in_format;
	
	@FindBy(id = "mat-checkbox-5-input")
	private WebElement eReadAlong_checkbox_in_Attributes;
	
	@FindBy(xpath = "//button[@class='close-icon']")
	private WebElement Btn_closeIcon_in_advanceSearch;
	
	@FindBy(xpath = "//h2[contains(text(),'eBook')]")
	private WebElement eBooks_pill;
	
	@FindBy(xpath = "//h2[contains(text(),'Sort By')]")
	private WebElement sortOption_in_refiner;
	
	@FindBy(xpath = "//*[@class='ui-radiobutton-box ui-widget ui-state-default']")
	private List<WebElement> radio_buttons_in_refiners;
	
	@FindBy(xpath = "//h2[contains(text(),'Collections')]")
	private WebElement collections_in_refiner;
	
	@FindBy(xpath = "//a[contains(text(),'Web Resources')]")
	private WebElement txt_activityResources;
	
	@FindBy(xpath = "//h2[contains(text(),'Web Resources')]")
	private WebElement txt_activityResourcesResult;
	
	@FindBy(xpath = "(//ul[@role='menu'])[2]")
	private WebElement category_section;
	
	@FindBy(xpath = "//h2[contains(text(),'Resource Hub')]")
	private WebElement txt_LearningActitvity;
	
	@FindBy(xpath = "//h2[contains(text(),'Web Resources')]")
	private WebElement txt_WebResources;

	@FindBy(xpath = "(//*[@class='web-resources-container'])[1]")
	private WebElement activityResource_cardTitle;
	
	@FindBy(xpath = "//h2[contains(text(),' Sort By ')]")
	private WebElement sortby_dropdown;
	
	@FindBy(xpath = "//h2[contains(text(),' activityTypes ')]")
	private WebElement activityTypes_dropdown;
	
	@FindBy(xpath = "//h2[contains(text(),' audiences ')]")
	private WebElement audiences_dropdown;
	
	@FindBy(xpath = "//a[text()='All ']")
	private WebElement txt_all;
	
	@FindBy(xpath = "//h2[contains(text(),'Refine')]")
	private WebElement txt_Refine;
	
	@FindBy(xpath = "//h2[@class='refiners-sub-title ng-star-inserted']")
	private WebElement txt_subtitles;
	
	@FindBy(xpath = "//h2[contains(text(),'Release Date ')]")
	private WebElement txt_releaseDate;
	
	@FindBy(xpath = "//h2[contains(text(),' Recently Added ')]")
	private WebElement txt_recentlyAdded;
	
	@FindBy(xpath = "//input[@value='General']")
	private WebElement enable_general;
	
	@FindBy(id = "loc_txtAvailability")
	private WebElement landing_homepage;
	
	@FindBy(xpath = "//span[contains(text(),' Display high contrast')]")
	public static WebElement checkbox_highContrast;
	
	@FindBy(xpath = "(//button[@class='primary-action ng-star-inserted'])[1]")
	private WebElement checkoutCTA_advanceSearch;
	
	@FindBy(xpath = "//h2[contains(text(),'Collections' )]")
	private WebElement drop_collections_advanceSearch;
	
	@FindBy(xpath = "//h3[contains(text(),'Availability' )]")
	private WebElement drop_availability_advanceSearch;
	
	public WebElement getTxt_WebResources() {
		return txt_WebResources;
	}
	
	public WebElement getCheckoutCTA_advanceSearch() {
		return checkoutCTA_advanceSearch;
	}

	public WebElement getLanding_homepage() {
		return landing_homepage;
	}

	public WebElement getTxt_subtitles() {
		return txt_subtitles;
	}

	public WebElement getTxt_Refine() {
		return txt_Refine;
	}

	public WebElement getTxt_all() {
		return txt_all;
	}

	public WebElement getTxt_LearningActitvity() {
		return txt_LearningActitvity;
	}

	public WebElement getActivityResource_cardTitle() {
		return activityResource_cardTitle;
	}

	public WebElement getCategory_section() {
		return category_section;
	}

	public WebElement getBtn_searchbar() {
		return Btn_searchbar;
	}

	public WebElement getSearchIcon_in_AdvanceSearch() {
		return searchIcon_in_AdvanceSearch;
	}

	public WebElement getResults_for_search() {
		return results_for_search;
	}

	public List<WebElement> getResults_in_carousel_format() {
		return results_in_carousel_format;
	}

	public WebElement getValidate_eBooks_eAudio_Video() {
		return validate_eBooks_eAudio_Video;
	}

	public WebElement getValidate_Activity_resources() {
		return validate_Activity_resources;
	}

	public WebElement getValidate_Web_resources() {
		return validate_Web_resources;
	}

	public List<WebElement> getResults_for_each_paranthesis() {
		return results_for_each_paranthesis;
	}

	public WebElement getPage_Breadcrumb() {
		return page_Breadcrumb;
	}
	
	public WebElement getCategory_in_left_panel() {
		return category_in_left_panel;
	}

	public WebElement getRefiners_in_left_panel() {
		return refiners_in_left_panel;
	}

	public WebElement getAll_option_in_left_panel() {
		return All_option_in_left_panel;
	}

	public WebElement getChoose_category_in_left_panel() {
		return choose_category_in_left_panel;
	}
	
	public List<WebElement> getSeeAll_cta() {
		return seeAll_cta;
	}

	public List<WebElement> getTitle_image() {
		return title_image;
	}

	public List<WebElement> getFormat_icon() {
		return format_icon;
	}

	public List<WebElement> getAuthorname_and_title() {
		return Authorname_and_title;
	}

	public List<WebElement> getPrimary_cta() {
		return primary_cta;
	}
	
	public WebElement getClearAll_cta() {
		return clearAll_cta;
	}

	public WebElement getBtn_advance_search() {
		return Btn_advance_search;
	}

	public WebElement getSearchBar_in_advancesearch() {
		return searchBar_in_advancesearch;
	}

	public WebElement getTypeOption_in_advanceSearch() {
		return typeOption_in_advanceSearch;
	}

	public WebElement getCollections_in_advanceSearch() {
		return collections_in_advanceSearch;
	}

	public WebElement getAvailability_in_advanceSearch() {
		return availability_in_advanceSearch;
	}

	public WebElement getFormat_in_advance_Search() {
		return format_in_advance_Search;
	}

	public WebElement getAttributes_in_advance_search() {
		return attributes_in_advance_search;
	}
	
	public List<WebElement> getRadioButtons_in_advanceSearch() {
		return radioButtons_in_advanceSearch;
	}

	public WebElement getAvailable_checkbox() {
		return Available_checkbox;
	}

	public WebElement getAllChecbox_in_format() {
		return AllChecbox_in_format;
	}

	public WebElement getAudioBooks_checkbox_in_format() {
		return AudioBooks_checkbox_in_format;
	}

	public WebElement geteBooks_checkbox_in_format() {
		return eBooks_checkbox_in_format;
	}

	public WebElement geteReadAlong_checkbox_in_Attributes() {
		return eReadAlong_checkbox_in_Attributes;
	}
	
	public WebElement getBtn_closeIcon_in_advanceSearch() {
		return Btn_closeIcon_in_advanceSearch;
	}
	
	public WebElement geteBooks_pill() {
		return eBooks_pill;
	}
	
	public WebElement getSortOption_in_refiner() {
		return sortOption_in_refiner;
	}
	
	public List<WebElement> getRadio_buttons_in_refiners() {
		return radio_buttons_in_refiners;
	}
	
	public WebElement getCollections_in_refiner() {
		return collections_in_refiner;
	}
	
	//Methods
	
	public void enter_text_in_Advance_Search_() {
		jsClick(Btn_searchbar);
		SendKeysOnWebElement(Btn_searchbar, "the");

	}
	public void enterkeyword_Advance_Search_() {
		jsClick(Btn_searchbar);
		SendKeysOnWebElement(Btn_searchbar,  RandomStringGenerate());
		waitFor(2000);
	}
	
	
	public void click_searchIcon() {
		jsClick(searchIcon_in_AdvanceSearch);

	}
	
	public void validate_results_in_carousel_format() {
		for (int i = 0; i < results_in_carousel_format.size(); i++) {
			isElementPresent(results_in_carousel_format.get(i));
		}
		Logger.log("carousel format is displayed");
	}
	
	public void validate_results_for_each_parathesis() {
		for (int i = 0; i < results_for_each_paranthesis.size(); i++) {
			isElementPresent(results_for_each_paranthesis.get(i));
		}
		Logger.log("results are viewed as category in paranthesis");
	}
	
	public void validate_seeAllCta() {
		for (int i = 0; i < seeAll_cta.size() ; i++) {
			isElementPresent(seeAll_cta.get(i));
		}
		Logger.log("see all cta is displayed");
	}
	
	public void validate_TitleImage() {
			isElementPresent(title_image.get(0));
			Logger.log("Title image is visible");
	}
	
	public void validate_FormatIcon() {
			isElementPresent(format_icon.get(0));
			Logger.log("Format image is visible");
	}
	
	public void validate_AuthorName_And_title() {
			isElementPresent(Authorname_and_title.get(0));
			Logger.log("Author name is visible");
	}
	
	public void validate_primaryCta() {
			isElementPresent(primary_cta.get(0));
			Logger.log("primary cta is visible");
	}
	
	public void click_clearAll() {
		jsClick(clearAll_cta);
	}
	
	public void click_advanceSearch() {
		jsClick(Btn_advance_search);
		WaitForWebElement(searchBar_in_advancesearch);
		jsClick(searchBar_in_advancesearch);
		SendKeysOnWebElement(searchBar_in_advancesearch, "the");
	}
	
	public void select_options_in_type() {
		jsClick(radioButtons_in_advanceSearch.get(1));
	}
	
	public void select_options_in_collections() {
		jsClick(radioButtons_in_advanceSearch.get(5));
	}
	
	public void select_options_in_Availability() {
		WaitForWebElement(Available_checkbox);
		jsClick(Available_checkbox);

	}
	
	public void select_options_in_Format() {
		WaitForWebElement(eBooks_checkbox_in_format);
		jsClick(eBooks_checkbox_in_format);

	}
	
	public void select_options_in_Attributes() {
		WaitForWebElement(eReadAlong_checkbox_in_Attributes);
		jsClick(eReadAlong_checkbox_in_Attributes);

	}
	public void click_close_Icon_in_advanceSearch() {
		ClickOnWebElement(Btn_closeIcon_in_advanceSearch);

	}
	
	public void click_eBook_from_refiners() {
		ClickOnWebElement(validate_eBooks_eAudio_Video);

	}
	
	public void click_sort_option_in_refiner() {
		javascriptScroll(radio_buttons_in_refiners.get(0));
		jsClick(sortOption_in_refiner);
		waitFor(2000);
		jsClick(radio_buttons_in_refiners.get(1));
	}
	
	public void click_alwaysAvailable_in_collections() {
		javascriptScroll(collections_in_refiner);
		jsClick(collections_in_refiner);
		//ClickOnWebElement(collections_in_refiner);
		WaitForWebElement(radio_buttons_in_refiners.get(6));
		ClickOnWebElement(radio_buttons_in_refiners.get(6));
		waitFor(2000);
	}
	
	public void click_seeAll_cta() {
		WaitForListWebElement(seeAll_cta);
		jsClick(seeAll_cta.get(0));

	}
	
	public void not_view_seeAll_cta() {
         for (int i = 0; i < seeAll_cta.size(); i++) {
			Assert.assertFalse(seeAll_cta.get(i).isDisplayed());
		}
	}
	
	public void click_web_resources() {
		ClickOnWebElement(validate_Web_resources);
		waitFor(2000);
	}
	
	public void click_activity_resources() {
		ClickOnWebElement(validate_Activity_resources);
		waitFor(2000);
	}
	
	public void click_SeeAllCTA() {
		WaitForWebElement(seeAll_cta.get(0));
		ClickOnWebElement(seeAll_cta.get(0));
		waitFor(3000);

	}
	
	public void click_ActivityResource() {
		javascriptScroll(txt_activityResources);
		waitFor(2000);
		jsClick(txt_activityResources);
		WaitForWebElement(txt_activityResourcesResult);
	}
	
	public boolean view_sort() {
		ClickOnWebElement(txt_activityResources);
		javascriptScroll(activityResource_cardTitle);
		boolean b= true;
		isElementPresent(activityResource_cardTitle);
		return b;
	}
	
	public void select_EbooksEAudio() {
	visibilityWait(validate_eBooks_eAudio_Video);
	//javascriptScroll(validate_eBooks_eAudio_Video);
	ClickOnWebElement(validate_eBooks_eAudio_Video);
	waitFor(3000);
	}
	
	public void view_subRefinerBeforeSelectEbooks() {
		waitFor(2000);
		javascriptScroll(sortby_dropdown);
		isElementPresent(sortby_dropdown);
		isElementPresent(drop_collections_advanceSearch);
		isElementPresent(drop_availability_advanceSearch);
		isElementPresent(txt_releaseDate);
		isElementPresent(txt_recentlyAdded);
				
	}
	
	public void onlyone_selectioninRefiner() {
	javascriptScroll(drop_collections_advanceSearch);
	jsClick(drop_collections_advanceSearch);
	if (enable_general.isSelected()) {
		Logger.log("user is able to select only one selection within one refiner drawer ");
	}
	}
	
	public void enable_highContrast() {
		javascriptScroll(checkbox_highContrast);
		if (checkbox_highContrast.isSelected()) {
			Logger.log("Already high contrast checkbox enabled");
		} else {
			jsClick(checkbox_highContrast);
			//ClickOnWebElement(checkbox_highContrast);
			waitFor(2000);
		}

	}
	
	public void disable_highContrast() {
		javascriptScroll(checkbox_highContrast);
		if (checkbox_highContrast.isSelected()) {
			ClickOnWebElement(checkbox_highContrast);
			waitFor(2000);
		} else {
			Logger.log("high contrast checkbox disabled");
		}

	}
	public boolean view_highContrast() {
		javascriptScroll(checkbox_highContrast);
		boolean b=true;
		isElementPresent(checkbox_highContrast);
		return b;
	}
	
}
