package pom.kidszone;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

public class BrowseBySearch extends CommonAction {

	public BrowseBySearch(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//button[@class='anchor-link btn-nobg-bluecolor']")
	public static WebElement browseRefiner_reset;

	@FindBy(xpath = "//a[@id='breadcrumb-link-0']")
	public static WebElement advancedSearch;

	@FindBy(xpath = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), ' subject ')]/following::label/span")
	public static List<WebElement> browseRefiner_subjects;

	@FindBy(xpath = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), ' categories')]/following::label/span")
	public static List<WebElement> browseRefiner_category;

	@FindBy(xpath = "//*[@id='loc_dropdwnAvailability']/ancestor::mat-expansion-panel-header")
	public static WebElement browse_availability;

	@FindBy(xpath = "(//*[@id='loc_dropdwnAvailability']/ancestor::mat-expansion-panel-header/following::label)[1]")
	public static WebElement browse_availability_Alltitles;

	@FindBy(xpath = "(//*[@id='loc_dropdwnAvailability']/ancestor::mat-expansion-panel-header/following::label)[2]")
	public static WebElement browse_availability_Availablenow;

	@FindBy(xpath = "//*[@id='loc_dropdwnFormat']/ancestor::mat-expansion-panel-header")
	public static WebElement browse_Format;

	@FindBy(xpath = "(//*[@id='loc_dropdwnFormat']/ancestor::mat-expansion-panel-header/following::label)[1]")
	public static WebElement browse_format_ebook;

	@FindBy(xpath = "(//*[@id='loc_dropdwnFormat']/ancestor::mat-expansion-panel-header/following::label)[1]")
	public static WebElement browse_format_EAudio;

	@FindBy(xpath = "//*[@id='loc_dropdwnAge Level']/ancestor::mat-expansion-panel-header")
	public static WebElement browse_Agelevel;

	@FindBy(xpath = "//*[@id='loc_dropdwnAge Level']/ancestor::mat-expansion-panel-header/following::span[contains(text(),' General Adult ')]")
	public static WebElement browse_generalAdult;

	@FindBy(xpath = "//*[@id='loc_dropdwnAge Level']/ancestor::mat-expansion-panel-header/following::span[contains(text(),' Vocational > Technical ')]")
	public static WebElement browse_vocationalTechnical;

	@FindBy(xpath = "//*[@id='loc_dropdwnAge Level']/ancestor::mat-expansion-panel-header/following::span[contains(text(),' Teen - Grade 10-12, Age 15-18 ')]")
	public static WebElement browse_TeenGrade10;

	@FindBy(xpath = "//*[@id='loc_dropdwnAge Level']/ancestor::mat-expansion-panel-header/following::span[contains(text(),' Children's - Babies, Age 0-2 ')]")
	public static WebElement childrensBabiesAge02;

	@FindBy(xpath = "//*[@id='loc_dropdwnLanguage']/ancestor::mat-expansion-panel-header")
	public static WebElement browse_language;

	@FindBy(xpath = "//*[@id='loc_dropdwnLanguage']/ancestor::mat-expansion-panel-header/following::span[contains(text(),'English')]")
	public static WebElement browse_Englishlanguage;

	@FindBy(xpath = "//*[@class='result-count ng-star-inserted']")
	public static WebElement browse_SearchCount;
	
	@FindBy(xpath = "//button[text()='Reset']")
	public static WebElement resetBtn;

	public void selectSubject(String subject) {
		if (!subject.trim().isEmpty())

		{
			try {
				if (browseRefiner_reset.getAttribute("disabled") != null) {
					jsClick(browseRefiner_reset);
				}
			} catch (Exception e1) {

			}
			for (int i = 0; i < browseRefiner_subjects.size(); i++) {
				try {
					if (browseRefiner_subjects.get(i).getText().equalsIgnoreCase(subject)) {
						javascriptScroll(browseRefiner_subjects.get(i));
						jsClick(browseRefiner_subjects.get(i));
						break;
					}
				} catch (Exception e) {
					javascriptScroll(browseRefiner_subjects.get(i));
					jsClick(browseRefiner_subjects.get(i));
				}

			}
		}
	}

	public void selectAvailability(String availability) {
		if (!availability.trim().isEmpty()) {
			waitForDocumentToLoad();
			visibilityWait(browse_availability);
			if (browse_availability.getAttribute("aria-expanded").equalsIgnoreCase("false")) {
				jsClick(browse_availability);
				visibilityWait(browse_availability_Alltitles);

				switch (availability) {

				case "All Titles":
					jsClick(browse_availability_Alltitles);
					break;

				case "Available Now":
					jsClick(browse_availability_Availablenow);
					break;
				}
			}
		}
	}


	public void selectCategories(String categories) {
		if (categories.trim().isEmpty()) {
			Logger.error("No format provided to click");
			return;
		}
		
		String[] categoryArray = categories.contains("#") ? categories.split("[#]+") : new String[] { categories };
		List<String> categoriesList = new ArrayList<String>(Arrays.asList(categoryArray));
		for (String category : categoriesList) {
			waitForDocumentToLoad();
			Logger.info("Selecting the category: " + category);
			waitForInvisibilityOf("(//axis360-spinner-loader[@class='ng-star-inserted'])[1]");
			for (WebElement element : browseRefiner_category) {
				WaitForWebElement(element);
				try {
					if (element.getText().equalsIgnoreCase(category.trim())) {
						javascriptScroll(element);
						jsClick(element);
						break;
					}
				} catch (Exception e) {
					javascriptScroll(element);
					jsClick(element);
				}
			}
		}
	}

	public void selectLanguage(String language) {
		String dynamicText = "//*[contains(@id,'loc_dropdwnLanguage')]/ancestor::mat-expansion-panel-header/following::span[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '"
				+ language.toLowerCase() + "')]";

		if (!language.trim().isEmpty()) {
			Logger.info("Language provided is : " + language);
			waitForDocumentToLoad();
			WebElement element = DriverManager.getDriver().findElement(By.xpath(dynamicText));
			visibilityWait(browse_language);
			waitForInvisibilityOf("//axis360-spinner-loader[@class='ng-star-inserted']");
            javascriptScroll(browse_language);
            jsClick(browse_language);
			javascriptScroll(element);
			if (browse_language.getAttribute("aria-expanded").equalsIgnoreCase("false")) {
				clickByXPath(dynamicText);
			}
		}
	}

	public void selectFormatType(String format) {
		if (!format.trim().isEmpty()) {
			Logger.info("Format provided is : " + format);
			waitForDocumentToLoad();
			if (browse_Format.getAttribute("aria-expanded").equalsIgnoreCase("false")) {
				visibilityWait(browse_Format);
				javascriptScroll(browse_Format);
				jsClick(browse_Format);
				visibilityWait(browse_format_ebook);

				switch (format) {
				case "eBook":

					jsClick(browse_format_ebook);
					break;

				case "eAudio":

					jsClick(browse_format_EAudio);
					break;
				}
			}
		} else {
			Logger.error("No format available to click");
		}
	}

	public void selectAgeLevel(String ageLevel) {

		String dynamicText = ageLevel;

        if(!ageLevel.trim().isEmpty()) {
        Logger.info("AgeLevel provided is: " + ageLevel);
		waitForDocumentToLoad();
		String xpath = "//*[@id='loc_dropdwnAge Level']/ancestor::mat-expansion-panel-header/following::span[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '"
				+ dynamicText.toLowerCase() + "')]";
		Logger.log("xpath: " + xpath);
		WebElement element = DriverManager.getDriver().findElement(By.xpath(xpath));
		if (browse_Agelevel.getAttribute("aria-expanded").equalsIgnoreCase("false")) {
			jsClick(browse_Agelevel);
		}
		javascriptScroll(element);
		clickByXPath(xpath);
        } else {
        	Logger.error("Age level is not provided, age level received is : " + ageLevel);
        }
	}

	public int searchResultCount() {
		int searchCount = 0;
		visibilityWait(browse_SearchCount);
		javascriptScroll(advancedSearch);
		waitFor(4000);
		waitForDocumentToLoad();
		String replaceAll = browse_SearchCount.getText().replaceAll("[^0-9]", "");
		waitFor(4000);
		System.out.println("Search results count from UI " + replaceAll);
		searchCount = Integer.parseInt(replaceAll);
		return searchCount;
	}
	
	public void clickResetButton() {
		if (resetBtn.isEnabled()) {
			resetBtn.click();
			Logger.info("BrowseBySubject reset refiner is clicked");
		}
	}

}
