package pom.kidszone;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

public class TitleAcrossProfile extends CommonAction {

	Holds holds = new Holds(DriverManager.getDriver());

	HamburgerMenu ham = new HamburgerMenu(DriverManager.getDriver());
	MyLibrary_Guest library = new MyLibrary_Guest(DriverManager.getDriver());
	Profilecreation profile = new Profilecreation(DriverManager.getDriver());
	HamburgerMenu hamburgerMenu = new HamburgerMenu(DriverManager.getDriver());
	TitleDetails title = new TitleDetails(DriverManager.getDriver());
	Wishlist wish = new Wishlist(DriverManager.getDriver());
	ProfileS4 profileNew = new ProfileS4(DriverManager.getDriver());

	public TitleAcrossProfile(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "(//h3[@class='card-title single-ellipsis'])[1]")
	private WebElement checkout_title;

	@FindBy(xpath = "//input[@type='text']")
	private WebElement input_advanceSearch;

	@FindBy(xpath = "//button[@class='kz-searchButton']")
	private WebElement searchicon_advanceSearch;

	@FindBy(xpath = "(//span[text()='Checkout'])[1]")
	private WebElement txt_checkoutCTA;

	@FindBy(xpath = "//div[@id='loc_textalertcontent']")
	private WebElement informating_popup;

	@FindBy(xpath = "//button[contains(text(),'wishlist')]")
	private WebElement wishlistCTA_popup;

	@FindBy(xpath = "//button[contains(text(),'Wishlist')]")
	private WebElement closeicon_popup;

	@FindBy(xpath = "//mat-icon[text()='close']")
	WebElement wish_closeicon_popup;

	@FindBy(xpath = "//div[@class='mat-tab-link-container']")
	private WebElement landing_myshelfscreen;

	@FindBy(xpath = "//a[@id='loc_labelWishlist']")
	private WebElement navigation_wishlist;

	@FindBy(id = "alert-dialog-title")
	private WebElement wishListPopUp;

	@FindBy(id = "alert-heading")
	private WebElement alertHeading;

	@FindBy(id = "loc_textalertcontent")
	private WebElement alertContent;

	@FindBy(xpath = "//button[@class='holdBtn']")
	private WebElement alertButton;

	@FindBy(xpath = "//mat-icon[@role='button']")
	private WebElement closeIcon;

	@FindBy(xpath = "//*[@placeholder='Search for content']")
	private WebElement searchBar;

	@FindBy(xpath = "//*[@class='kz-searchButton']")
	private WebElement searchButton;

	@FindBy(id = "loc_linkHolds")
	private WebElement holdsHam;

	@FindBy(xpath = "//*[@class='mat-card-image card-image']")
	private List<WebElement> titlecardCoverImage;

	@FindBy(id = "loc_profiles")
	private WebElement profileHam;

	@FindBy(id = "loc_txtProfiles")
	private WebElement profilePage;

	@FindBy(xpath = "//*[@class='search-view ng-star-inserted']")
	private WebElement searchResult;

	@FindBy(xpath = "(//*[@class='btn-primary btn-primary-blue ng-star-inserted'])[2]")
	private WebElement primaryCta;

	@FindBy(xpath = "(//*[@class='primary-action ng-star-inserted'])[1]/*[contains(text(),'Read Now')]")
	private WebElement readNow;

	@FindBy(xpath = "(//*[contains(text(),'Checkout')])[3]")
	private WebElement checkOut;

	@FindBy(xpath = "//axis360-overlay-spinner//*[@class='overlay-loading overlay-mc-loading ng-star-inserted']")
	private WebElement loader;

	@FindBy(xpath = "//*[@class='kz-toast-msg']/*[contains(text(),'Failure!')]")
	private WebElement failureToastMsg;

	@FindBy(xpath = "//h2[text()='Log Into Your Library']")
	private WebElement loginpage_popup;

	@FindBy(id = "searchText")
	private WebElement input_search;

	@FindBy(xpath = "//span[contains(text(),'Advanced Search')]")
	private WebElement advanceSearch;

	@FindBy(xpath = "//label[contains(text(),'Requests For Library Purchase')]")
	private WebElement radio_btn_purchaseRequest;

	@FindBy(xpath = "//button[text()='Search']")
	private WebElement btn_search;

	@FindBy(xpath = "//*[@class='kz-card-image ng-star-inserted']")
	private WebElement Search_resultScreen;

	@FindBy(xpath = "//button[@class='primary-action ng-star-inserted']")
	private WebElement CTA_purchaseRequest;

	@FindBy(id = "loc_labelPurchase Requests")
	public static WebElement cta_purchaseRequest;

	@FindBy(id = "txtSearch")
	private WebElement adult_input_search;

	@FindBy(id = "btnSearch")
	private WebElement adult_icon_search;

	@FindBy(xpath = "//mat-icon[@svgicon='kz-down-arrow']")
	private WebElement wishlist_arrow;

	@FindBy(xpath = "//mat-icon[@svgicon='kz-up-arrow']")
	private WebElement wishlist_uparrow;

	@FindBy(xpath = "//button[text()='Add to Wishlist']")
	private WebElement btn_addtowishlist;

	@FindBy(xpath = "(//h2[text()='Children']//following-sibling::div//button[@class='primary-action ng-star-inserted'])[1]")
	private WebElement btn_checkout;

	@FindBy(xpath = "//span[text()='eAudio ']")
	private WebElement ebook_radiobtn;

	@FindBy(xpath = "//button[contains(text(),'Return')]")
	private WebElement returnButton;

	@FindBy(id = "loc_confirmbtnOK")
	private WebElement returnOK;

	@FindBy(xpath = "(//*[@class='kz-card-image ng-star-inserted'])[1]")
	public static WebElement firstTitle_searchscreen;

	@FindBy(xpath = "(//img[@class='mat-card-image card-image'])[1]")
	public WebElement search_titlecard;

	@FindBy(xpath = "//div[@class='titledetails-bookwrapper']")
	public WebElement titleDetails;

	@FindBy(xpath = "//*[@class='result-count']")
	public WebElement Search_TotalResultCount;

	@FindBy(xpath = "(//*[contains(text(),' eBooks ')]/span)[1]")
	public WebElement Search_EbookResultCount;

	@FindBy(xpath = "(//*[contains(text(),' eAudios ')]/span)[1]")
	public WebElement Search_EAudioResultCount;

	@FindBy(xpath = "(//*[contains(text(),'Videobooks ')]/span)[1]")
	public WebElement Search_VbookResultCount;

	@FindBy(xpath = "(//*[contains(text(),'Checkers Library TV ')]/span)[1]")
	public WebElement Search_VideoResultCount;

	@FindBy(xpath = "(//*[contains(text(),' Resource Hub ')]/span)[1]")
	public WebElement Search_ResourceHubResultCount;

	@FindBy(xpath = "(//*[contains(text(),' Web Resources ')]/span)[1]")
	public WebElement Search_WebResourcesResultCount;

	@FindBy(xpath = "//*[@class='carousel-title heading-2']")
	public WebElement categoryCount;
	
	@FindBy(xpath = "//*[@class='thirdparty-title']/span[contains(@class, 'results-text')]")
	public WebElement searchResultHeaderThirdParty;

//	@FindBy(xpath = "")
//	private WebElement ;

	public WebElement getBtn_addtowishlist() {
		return btn_addtowishlist;
	}

	public WebElement getPrimaryCta() {
		return primaryCta;
	}

	public WebElement getSearch_resultScreen() {
		return Search_resultScreen;
	}

	public WebElement getLoginpage_popup() {
		return loginpage_popup;
	}

	public WebElement getLanding_myshelfscreen() {
		return landing_myshelfscreen;
	}

	public WebElement getWishlistCTA_popup() {
		return wishlistCTA_popup;
	}

	public WebElement getInformating_popup() {
		return informating_popup;
	}

	public void click_checkoutTitles() {
		String text = checkout_title.getText();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_AdultProfile();
		waitFor(3000);
		ClickOnWebElement(input_advanceSearch);
		SendKeysOnWebElement(input_advanceSearch, text);
		jsClick(searchicon_advanceSearch);
		waitFor(2500);
		if (txt_checkoutCTA.isDisplayed()) {
			jsClick(txt_checkoutCTA);
		} else if (txt_checkoutCTA.isDisplayed()) {
			jsClick(txt_checkoutCTA);
		}
		waitFor(3000);
	}

	public void click_adultWishlistcheckoutTitles() {
		String text = checkout_title.getText();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_AdultProfile();
		waitFor(3000);
		ClickOnWebElement(input_advanceSearch);
		SendKeysOnWebElement(input_advanceSearch, text);
		jsClick(searchicon_advanceSearch);
		waitFor(2000);
		findByClick(wishlist_arrow);
		waitFor(2000);
		if (isElementPresent(btn_addtowishlist)) {
			findByClick(btn_addtowishlist);
			waitFor(2000);
			hamburgerMenu.click_HamburgerMenu();
			hamburgerMenu.click_MyShelf();
			DriverManager.getDriver().navigate().refresh();
			waitFor(2000);
			click_wishlist();
			findByClick(txt_checkoutCTA);
		} else {
			jsClick(wishlist_uparrow);
			// findByClick(wishlist_uparrow);
			System.out.println("already added the wishlist");
			waitFor(2000);
			hamburgerMenu.click_HamburgerMenu();
			hamburgerMenu.click_MyShelf();
			DriverManager.getDriver().navigate().refresh();
			waitFor(2000);
			click_wishlist();
			findByClick(txt_checkoutCTA);
		}

	}

	public void click_kidWishlistcheckoutTitles() {
		String text = checkout_title.getText();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		waitFor(3000);
		ClickOnWebElement(input_advanceSearch);
		SendKeysOnWebElement(input_advanceSearch, text);
		jsClick(searchicon_advanceSearch);
		waitFor(2000);
		findByClick(wishlist_arrow);
		waitFor(2000);
		if (isElementPresent(btn_addtowishlist)) {
			findByClick(btn_addtowishlist);
			waitFor(2000);
			hamburgerMenu.click_HamburgerMenu();
			hamburgerMenu.click_MyShelf();
			click_wishlist();
			findByClick(txt_checkoutCTA);
		} else {
			jsClick(wishlist_uparrow);
			// findByClick(wishlist_uparrow);
			System.out.println("already added the wishlist");
			waitFor(2000);
			hamburgerMenu.click_HamburgerMenu();
			hamburgerMenu.click_MyShelf();
			click_wishlist();
			findByClick(txt_checkoutCTA);
		}

	}

	public void click_teenWishlistcheckoutTitles() {
		String text = checkout_title.getText();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Teenprofile();
		waitFor(3000);
		ClickOnWebElement(input_advanceSearch);
		SendKeysOnWebElement(input_advanceSearch, text);
		jsClick(searchicon_advanceSearch);
		waitFor(2000);
		findByClick(wishlist_arrow);
		waitFor(2000);
		if (isElementPresent(btn_addtowishlist)) {
			findByClick(btn_addtowishlist);
			waitFor(2000);
			hamburgerMenu.click_HamburgerMenu();
			hamburgerMenu.click_MyShelf();
			click_wishlist();
			findByClick(txt_checkoutCTA);
		} else {
			jsClick(wishlist_uparrow);
			// findByClick(wishlist_uparrow);
			System.out.println("already added the wishlist");
			waitFor(2000);
			hamburgerMenu.click_HamburgerMenu();
			hamburgerMenu.click_MyShelf();
			click_wishlist();
			findByClick(txt_checkoutCTA);
		}

	}

	public void click_kidcheckoutTitles() {
		String text = checkout_title.getText();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		waitFor(3000);
		ClickOnWebElement(input_advanceSearch);
		SendKeysOnWebElement(input_advanceSearch, text);
		jsClick(searchicon_advanceSearch);
		waitFor(2500);
		if (txt_checkoutCTA.isDisplayed()) {
			jsClick(txt_checkoutCTA);
		} else if (txt_checkoutCTA.isDisplayed()) {
			jsClick(txt_checkoutCTA);
		}
		waitFor(3000);
	}

	public void click_teencheckoutTitles() {
		String text = checkout_title.getText();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Teenprofile();
		waitFor(3000);
		ClickOnWebElement(input_advanceSearch);
		SendKeysOnWebElement(input_advanceSearch, text);
		jsClick(searchicon_advanceSearch);
		waitFor(2500);
		if (txt_checkoutCTA.isDisplayed()) {
			jsClick(txt_checkoutCTA);
		} else if (txt_checkoutCTA.isDisplayed()) {
			jsClick(txt_checkoutCTA);
		}
		waitFor(3000);
	}

	public void click_Adulthistory() {
		String text = checkout_title.getText();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_AdultProfile();
		waitFor(3000);
	}

	public void click_checkoutsonAnyscreen() {
		javascriptScroll(txt_checkoutCTA);
		findByClick(txt_checkoutCTA);
		waitFor(2000);
	}

	public void click_kidhistory() {
		String text = checkout_title.getText();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Kidprofile();
		waitFor(3000);
		ClickOnWebElement(input_advanceSearch);
		SendKeysOnWebElement(input_advanceSearch, text);
		jsClick(searchicon_advanceSearch);
		if (txt_checkoutCTA.isDisplayed()) {
			jsClick(txt_checkoutCTA);
		} else if (txt_checkoutCTA.isDisplayed()) {
			jsClick(txt_checkoutCTA);
		}
		waitFor(3000);
	}

	public void click_Teencheckout() {
		String text = checkout_title.getText();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_Teenprofile();
		waitFor(3000);
		ClickOnWebElement(input_advanceSearch);
		SendKeysOnWebElement(input_advanceSearch, text);
		jsClick(searchicon_advanceSearch);
		if (txt_checkoutCTA.isDisplayed()) {
			jsClick(txt_checkoutCTA);
		} else if (txt_checkoutCTA.isDisplayed()) {
			jsClick(txt_checkoutCTA);
		}
		waitFor(3000);
	}

	public void click_addtoWishlist() {
		jsClick(btn_addtowishlist);
		waitFor(2000);

	}

	public void click_closeIcon() {
		findByClick(closeicon_popup);
		// ClickOnWebElement(closeicon_popup);
		// jsClick(closeicon_popup);
		waitFor(2000);

	}

	public void wish_closeicon_popup() {
		findByClick(wish_closeicon_popup);
		waitFor(2000);

	}

	public void click_wishlist() {
		ClickOnWebElement(navigation_wishlist);
		waitFor(2000);

	}

	public WebElement getSearchResult() {
		return searchResult;
	}

	public WebElement getCloseIcon() {
		return closeIcon;
	}

	public WebElement getAlertButton() {
		return alertButton;
	}

	public void clickProfiles() {
		WaitForWebElement(profileHam);
		javascriptScroll(profileHam);
		ClickOnWebElement(profileHam);
		WaitForWebElement(profilePage);
	}

	public void searchTitle(String QAtitle, String UATtitle) {
		waitFor(2000);
		if (System.getProperty("ENVIRONMENT").equalsIgnoreCase("QA2")) {
			WaitForWebElement(searchBar);
			javascriptScroll(searchBar);
			SendKeysOnWebElement(searchBar, QAtitle);
			ClickOnWebElement(searchButton);
			WaitForWebElement(searchResult);
		} else if (System.getProperty("ENVIRONMENT").equalsIgnoreCase("UAT")) {
			WaitForWebElement(searchBar);
			javascriptScroll(searchBar);
			SendKeysOnWebElement(searchBar, UATtitle);
			ClickOnWebElement(searchButton);
			WaitForWebElement(searchResult);
		}
	}

	public void searchTitleHold(String title) {
		waitFor(2000);
		WaitForWebElement(searchBar);
		javascriptScroll(searchBar);
		SendKeysOnWebElement(searchBar, title);
		jsClick(searchButton);
		waitFor(2000);
		// ClickOnWebElement(searchButton);
		visibilityWait(searchResult);
		// WaitForWebElement(searchResult);
	}

	public void returnTitle() {
		javascriptScroll(wishlist_arrow);
		jsClick(wishlist_arrow);
		WaitForWebElement(returnButton);
		jsClick(returnButton);
		javascriptScroll(returnOK);
		jsClick(returnOK);
		WaitForWebElement(title.getSuccToastMsg());
		waitFor(3000);
	}

	public void checkoutTitle() {
		waitFor(2000);
		javascriptScroll(checkOut);
		jsClick(checkOut);
	}

	public void checkoutTitleinProfile() {
		if (isElementPresent(readNow)) {
			waitFor(3000);
		} else if (isElementPresent(checkOut)) {
			checkoutTitle();
			WaitForWebElement(title.getSuccToastMsg());
			waitFor(2000);
		}
		Logger.log("User succesfully checked out the title");
	}

	public void switchAdultProfile() {
//		library.clickHamNew();
//		clickProfiles();
		profileNew.clickProfileAvatar();
		profileNew.clickPrimaryDropDown();
//		holds.clickAdultProfile();
		profile.preferenceScreen_popup();
		WaitForWebElement(holds.getLibraryPage());
	}

	public void switchTeenProfile() {
//		library.clickHamNew();
//		clickProfiles();
		profileNew.clickProfileAvatar();
		profileNew.clickTeenDropDown();
//		holds.clickTeenProfile();
		profile.preferenceScreen_popup();
		profile.readInAppClose();
		WaitForWebElement(holds.getLibraryPage());
	}

	public void switchKidProfile() {
//		library.clickHamNew();
//		clickProfiles();
		profileNew.clickProfileAvatar();
		profileNew.clickKidDropDown();
//		holds.clickKidProfile();
		profile.preferenceScreen_popup();
		profile.readInAppClose();
		WaitForWebElement(holds.getLibraryPage());
	}

	public void titleNameSearchToAdult() {
		WaitForWebElement(holds.getHoldPage());
		waitFor(2000);
		jsClick(holds.mystuff_titlecard_navTier3);
		visibilityWait(holds.getTitleName());
		String titleName = holds.getTitleName().getText();
		System.out.println("title Name " + titleName);
		waitFor(2000);
		switchAdultProfile();
		searchTitleHold(titleName);
	}

	public void titleNameSearchToTeen() {
		WaitForWebElement(holds.getHoldPage());
		jsClick(holds.mystuff_titlecard_navTier3);
		waitFor(2000);
		visibilityWait(holds.getTitleName());
		String titleName = holds.getTitleName().getText();
		System.out.println("title Name " + titleName);
		waitFor(2000);
		switchTeenProfile();
		searchTitleHold(titleName);
	}

	public void titleNameSearchToKid() {
		WaitForWebElement(holds.getHoldPage());
		waitFor(2000);
		jsClick(holds.mystuff_titlecard_navTier3);
		visibilityWait(holds.getTitleName());
		String titleName = holds.getTitleName().getText();
		System.out.println("title Name " + titleName);
		waitFor(2000);
		switchKidProfile();
		searchTitleHold(titleName);
	}

	public void notificationPopUp() {
		WaitForWebElement(wishListPopUp);
		Assert.assertTrue(wishListPopUp.isDisplayed());
		Assert.assertTrue(alertHeading.isDisplayed());
		Assert.assertTrue(alertContent.isDisplayed());
	}

	public void removeWishList() {
		jsClick(wish.getSecCtaOptions());
		WaitForWebElement(wish.getSecCtaOptions());
		jsClick(wish.getSecCtaOptions());
		WaitForWebElement(wish.getRemoveWish());
		javascriptScroll(wish.getRemoveWish());
		jsClick(wish.getRemoveWish());
//		inVisibilityWait(loader);
		WaitForWebElement(title.getSuccToastMsg());
	}

	public void clickAlertButon() {
		javascriptScroll(alertButton);
		ClickOnWebElement(alertButton);
//		inVisibilityWait(loader);
		WaitForWebElement(title.getSuccToastMsg());
		Logger.log("Title successfully added into wishlist");
	}

	public void clickWishListCta() {
		WaitForWebElement(wish.getSecCtaOptions());
		jsClick(wish.getSecCtaOptions());
		if (isElementPresent(wish.getAddToWish())) {
			jsClick(wish.getSecCtaOptions());
			clickAlertButon();
		} else {
			clickCloseIcon();
			removeWishList();
			clickPrimaryCta();
			clickAlertButon();
//			javascriptScroll(alertButton);
//			ClickOnWebElement(alertButton);
//			inVisibilityWait(loader);
//			WaitForWebElement(title.getSuccToastMsg());
//			Logger.log("Title successfully added into wishlist");
		}
//		if (isElementPresent(title.getSuccToastMsg())) {
//			Logger.log("Title successfully added into wishlist");
//		} else if (failureToastMsg.isDisplayed()) {
//			removeWishList();
//			javascriptScroll(alertButton);
//			ClickOnWebElement(alertButton);
//			inVisibilityWait(loader);
//			WaitForWebElement(title.getSuccToastMsg());
//		}
//		WaitForWebElement(wish.getWishlistPage());
//		Assert.assertTrue(wish.getWishlistPage().isDisplayed());
//		Assert.assertTrue(wish.getWishlistTitle().isDisplayed());
	}

	public void clickPrimaryCta() {
		javascriptScroll(primaryCta);
		jsClick(primaryCta);
		waitFor(3000);
	}

	public void clickPrimaryCtaMyShef() {
		javascriptScroll(holds.getPrimaryCta());
		jsClick(holds.getPrimaryCta());
	}

	public void clickCloseIcon() {
		javascriptScroll(closeIcon);
		jsClick(closeIcon);
		inVisibilityWait(wishListPopUp);
	}

	public void clickTitleCard() {
		javascriptScroll(titlecardCoverImage.get(0));
		ClickOnWebElement(titlecardCoverImage.get(0));
		WaitForWebElement(title.getTitleDetailScreen());
	}

	public void click_advanceSearch() {
		visibilityWait(advanceSearch);
		jsClick(advanceSearch);
		waitFor(000);
	}

	public void Search_RecommendedTitles() {
		SendKeysOnWebElement(input_search, "The");
		javascriptScroll(radio_btn_purchaseRequest);
		findByClick(radio_btn_purchaseRequest);
		javascriptScroll(ebook_radiobtn);
		jsClick(ebook_radiobtn);
		javascriptScroll(btn_search);
		jsClick(btn_search);
		WaitForWebElement(Search_resultScreen);
	}

	public void click_purchaseRequest() {
		// javascriptScroll(CTA_purchaseRequest);
		// jsClick(CTA_purchaseRequest);
		waitFor(2000);
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_MyShelf();
		waitFor(2000);
		ClickOnWebElement(cta_purchaseRequest);
		waitFor(2000);
	}

	public void clickon_purchaseRequest() {
		javascriptScroll(CTA_purchaseRequest);
		jsClick(CTA_purchaseRequest);
		waitFor(2000);
	}

	public void nav_Recommendation() {
		String text = checkout_title.getText();
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_Profiles();
		profile.select_AdultProfile();
		waitFor(3000);
		click_advanceSearch();
		waitFor(3000);
		javascriptScroll(input_search);
		SendKeysOnWebElement(input_search, text);
		waitFor(3000);
		javascriptScroll(radio_btn_purchaseRequest);
		jsClick(radio_btn_purchaseRequest);
//			javascriptScroll(ebook_radiobtn);
//			jsClick(ebook_radiobtn);
		javascriptScroll(btn_search);
		jsClick(btn_search);
		WaitForWebElement(Search_resultScreen);
//			jsClick(searchicon_advanceSearch);
		waitFor(2000);
		if (CTA_purchaseRequest.isDisplayed()) {
			jsClick(CTA_purchaseRequest);
		}
		waitFor(3000);
	}

	public void lib_clickCheckout() {
		title.select_availablenowdrop();
		waitFor(2000);
		javascriptScroll(btn_checkout);
		jsClick(btn_checkout);
		waitFor(3000);
	}

	public void click_purchase() {
		hamburgerMenu.click_HamburgerMenu();
		hamburgerMenu.click_MyShelf();
		waitFor(2000);
		ClickOnWebElement(cta_purchaseRequest);
		waitFor(2000);
	}

	public int search_ResultCount() {
		String SearchCount = Search_TotalResultCount.getText();
		String ExtractNumber = SearchCount.replaceAll("[^0-9]", "");
		int Totalcount = Integer.parseInt(ExtractNumber);
		return Totalcount;
	}

	public int get_EbookSearchCount() {
		int Ebook_Totalcount = 0;
		try {
		visibilityWait(Search_EbookResultCount);
		String ebook_count = Search_EbookResultCount.getText();
		String Ebook_extractcount = ebook_count.replaceAll("[^0-9]", "");
		Ebook_Totalcount = Integer.parseInt(Ebook_extractcount);
		} catch (Exception e) {
			Logger.log("eBook not displayed in the search result");
		}
		return Ebook_Totalcount;
	}

	public int get_EAudioSearchCount() {
		int EAudio_Totalcount = 0;
		try {
		visibilityWait(Search_EAudioResultCount);
		String EAudio_count = Search_EAudioResultCount.getText();
		String EAudio_extractcount = EAudio_count.replaceAll("[^0-9]", "");
		EAudio_Totalcount = Integer.parseInt(EAudio_extractcount);
		} catch (Exception e) {
			Logger.log("eAudio not displayed in the search result");
		}
		return EAudio_Totalcount;
	}

	public int get_VbookSearchCount() {
		int vbook_Totalcount = 0;
		try {
		javascriptScroll(Search_VbookResultCount);
		String vbook_count = Search_VbookResultCount.getText();
		String vbook_extractcount = vbook_count.replaceAll("[^0-9]", "");
		vbook_Totalcount = Integer.parseInt(vbook_extractcount);
		} catch (Exception e) {
			Logger.log("vbook not displayed in the search result");
		}
		return vbook_Totalcount;
	}

	public int get_VideoSearchCount() {
		int video_Totalcount = 0;
		try {
			javascriptScroll(Search_VideoResultCount);
			String video_count = Search_VideoResultCount.getText();
			String video_extractcount = video_count.replaceAll("[^0-9]", "");
			video_Totalcount = Integer.parseInt(video_extractcount);
		} catch (Exception e) {
			Logger.log("video not displayed in the search result");
		}
		return video_Totalcount;
	}

	public int get_ResourceHubSearchCount() {
		int ResouceHub_Totalcount = 0;
		try {
			javascriptScroll(Search_ResourceHubResultCount);
			String ResourceHub_count = Search_ResourceHubResultCount.getText();
			String Resourcehub_extractcount = ResourceHub_count.replaceAll("[^0-9]", "");
			ResouceHub_Totalcount = Integer.parseInt(Resourcehub_extractcount);
		} catch (Exception e) {
			Logger.log("resource hub not displayed in the search result");
		}
		return ResouceHub_Totalcount;
	}

	public int get_WebResourceSearchCount() {
		int WebResouce_Totalcount = 0;
		try {
		javascriptScroll(Search_WebResourcesResultCount);
		String WebResource_count = Search_WebResourcesResultCount.getText();
		String WebResource_extractcount = WebResource_count.replaceAll("[^0-9]", "");
		WebResouce_Totalcount = Integer.parseInt(WebResource_extractcount);
		} catch (Exception e) {
			Logger.log("Web resources option not displayed in the search result");
		}
		return WebResouce_Totalcount;
	}

}
