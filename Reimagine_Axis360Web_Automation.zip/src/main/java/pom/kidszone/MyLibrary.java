package pom.kidszone;

import java.util.Set;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class MyLibrary extends CommonAction {

	static ExcelReader reader = new ExcelReader();
	WebDriver driver;

	public MyLibrary(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//span[text()='Advanced Search']")
	private WebElement txt_libraryScreen;

	@FindBy(id = "advanceSearchLink")
	private WebElement old_libraryScreen;

	@FindBy(id = "loc_txtAvailability")
	private WebElement txt_NavlibraryScreen;

	@FindBy(id = "advanceSearchLink")
	private WebElement btn_oldNavLibraryScreen;

	@FindBy(xpath = "//header[@id='header']")
	private WebElement btn_Navigationbar;

	@FindBy(xpath = "//input[@placeholder='Search for content']")
	private WebElement btn_SearcBar;

	@FindBy(id = "loc_btnHamburgerMenu")
	private WebElement btn_HambergerNavigationbar;

	@FindBy(xpath = "//a[@title='Auto Kids Independent']")
	private WebElement img_logo;

	@FindBy(xpath = "//a[@class='brand-logo']")
	private WebElement img_brandlogo;

	@FindBy(xpath = "(//button[@aria-label='Notifications'])[1]")
	private WebElement label_notification;

	@FindBy(id = "loc_profileImg")
	private WebElement avatar_profile;

	@FindBy(xpath = "//span[text()='Advanced Search']")
	private WebElement txt_advancedSearch;

	@FindBy(id = "advanceSearchLink")
	private WebElement txt_oldadvancedSearch;

	@FindBy(id = "btnSearch")
	private WebElement btn_oldbtnSearch;

	@FindBy(xpath = "//button[@type='submit']")
	private WebElement btn_searchicon;

	@FindBy(xpath = "//*[text()='active Programs']")
	private WebElement txt_featuredProgramTitle;

	@FindBy(xpath = "//h2[@class='hero-heading']")
	private WebElement txt_adultfeaturedProgramTitle;

	@FindBy(xpath = "//*[@class='container-fluid kz-footer']")
	private WebElement txt_FooterNavigationbar;

	@FindBy(xpath = "//a[text()='Privacy Policy']")
	private WebElement txt_privacyPolicylink;

	@FindBy(xpath = "//a[text()='Terms & Conditions']")
	private WebElement txt_termsAndConditions;

	@FindBy(id = "content")
	private WebElement txt_navRespectivescreen;

	@FindBy(id = "divFootNote1]")
	private WebElement txt_footerDescription;

	@FindBy(xpath = "//h1[text()='NEWSPAPERS & MAGAZINES']")
	private WebElement txt_newspaperAndmagazines;

	@FindBy(xpath = "(//div[@class='kz-carousel kz-third-party-carousel ng-star-inserted'])[1]")
	private WebElement txt_oldnewspaperAndmagazines;

	@FindBy(xpath = "//*[@class='footer-brand-logo']")
	private WebElement txt_logotitle;

	@FindBy(xpath = "//h3[contains(text(),'Newspapers & Magazines')]//following::div[@class='carousel-arrow carousel-arrow-next']")
	private WebElement carousel_newspaper_right;

	@FindBy(xpath = "//h3[contains(text(),'Newspapers & Magazines')]//following::div[@class='carousel-arrow carousel-arrow-prev']")
	private WebElement carousel_newspaper_left;

	@FindBy(xpath = "//*[contains(text(),'Always Available ')]/following::span[1][@class='description-text']")
	private WebElement txt_description;

	@FindBy(xpath = "//a[text()='See All']")
	private WebElement btn_linkseeAll;

	@FindBy(xpath = "(//a[@class='link see-all-text ng-star-inserted'])[1]")
	private WebElement btn_oldlinkseeAll;

	@FindBy(xpath = "//div[@class='featured-card-carousel']")
	private WebElement txt_NavoldnewspaperAndmagazines;

	@FindBy(xpath = "//h2[normalize-space()='Always Available']")
	private WebElement txt_AlwaysavailableTitle;

	@FindBy(xpath = "(//span[@class='description-text'])[1]")
	private WebElement txt_AlwaysavailableDescription;

	@FindBy(xpath = "(//h2[normalize-space()='Always Available']//following-sibling::button)[1]")
	private WebElement txt_AlwaysavailableSeeAllcta;

	@FindBy(xpath = "//h1[normalize-space()='always available']")
	private WebElement txt_NavAlwaysavailableScreen;

	@FindBy(xpath = "//span[text()='Patron Support']")
	private WebElement btn_patronSupport;

	@FindBy(xpath = "//strong[contains(text(),'Jefferson County Public')]")
	private WebElement txt_NavpatronSupportScreen;

	@FindBy(xpath = "//a[text()='MY LIBRARY']")
	private WebElement menu_btn_oldMylibrary;

	@FindBy(id = "loc_linkPrograms")
	private WebElement menu_programs;

	@FindBy(xpath = "//*[@class='featured-carousel']")
	public static WebElement featuredList_carousel;

	@FindBy(xpath = "//*[@class='kz-featured']")
	public static WebElement featuredList_carousel1;

	@FindBy(xpath = "//*[@class='kz-drawer-inner-container ng-star-inserted']")
	private WebElement hamMenuDrawer;

	@FindBy(xpath = "//*[@class='footer-copy']")
	private WebElement copyRights;

	public WebElement getOld_libraryScreen() {
		return old_libraryScreen;
	}

	public WebElement getCopyRights() {
		return copyRights;
	}

	public WebElement getFeaturedList_carousel() {
		return featuredList_carousel;
	}

	public WebElement getHamMenuDrawer() {
		return hamMenuDrawer;
	}

	public WebElement getBtn_Navigationbar() {
		return btn_Navigationbar;
	}

	public WebElement getTxt_privacyPolicylink() {
		return txt_privacyPolicylink;
	}

	public WebElement getTxt_NavpatronSupportScreen() {
		return txt_NavpatronSupportScreen;
	}

	public WebElement getTxt_AlwaysavailableTitle() {
		return txt_AlwaysavailableTitle;
	}

	public WebElement getTxt_AlwaysavailableDescription() {
		return txt_AlwaysavailableDescription;
	}

	public WebElement getTxt_description() {
		return txt_description;
	}

	public WebElement getBtn_SearcBar() {
		return btn_SearcBar;
	}

	public WebElement getTxt_logotitle() {
		return txt_logotitle;
	}

	public WebElement getTxt_FooterNavigationbar() {
		return txt_FooterNavigationbar;
	}

	public WebElement getBtn_searchicon() {
		return btn_searchicon;
	}

	public WebElement getBtn_HambergerNavigationbar() {
		return btn_HambergerNavigationbar;
	}

	public WebElement getImg_logo() {
		return img_logo;
	}

	public WebElement getAvatar_profile() {
		return avatar_profile;
	}

	public WebElement getTxt_advancedSearch() {
		return txt_advancedSearch;
	}

	public WebElement getLabel_notification() {
		return label_notification;
	}

	public WebElement getTxt_NavlibraryScreen() {
		return txt_NavlibraryScreen;
	}

	public WebElement getTxt_libraryScreen() {
		return txt_libraryScreen;
	}

	public WebElement getTxt_newspaperAndmagazines() {
		return txt_newspaperAndmagazines;
	}

	public WebElement getTxt_oldnewspaperAndmagazines() {
		return txt_oldnewspaperAndmagazines;
	}

	public void featuredCarousel() {
		if (isElementPresent(featuredList_carousel)) {
			Logger.log("User able to see featured list Carousel");
		} else if (isElementPresent(featuredList_carousel1)) {
			Logger.log("User able to see featured list Carousel");
		}
	}

	/*
	 *******************************************************
	 *************** Action methods***********************
	 */

	public void click_oldmylibrary() {
		ClickOnWebElement(menu_btn_oldMylibrary);
		waitFor(2000);
	}

	public void view_LibraryScreen() {
		if (old_libraryScreen.isDisplayed()) {
			Logger.log("user lands on library screen adult profile type");
		} else if (txt_NavlibraryScreen.isDisplayed()) {
			Logger.log("user lands on library screen");
		}

	}

	public void view_updatedNavigationBar() {
		if (isElementPresent(btn_Navigationbar)) {
			Logger.log("user is able to view navigation bar");
		} else {

			Logger.log("For Axis 360 library subscription top navigation bar is not displayed");
		}
	}

	public void updated_NavigationBar() {
		if (btn_HambergerNavigationbar.isDisplayed()) {
			Logger.log("user is able to view updated top navigation bar");
		}

	}

	public void view_logoAlongwithLibraryName() {
		if (img_logo.isEnabled()) {
			Logger.log("user is able to view library name");
		} else {
			Logger.log("user is not able to view brand logo with library name");
		}
	}

	public boolean view_avatarAndnotificationAdvancedSearch() {
		boolean b = true;
		isElementPresent(label_notification);
		isElementPresent(avatar_profile);
		isElementPresent(txt_advancedSearch);
		return b;
	}

	public boolean view_oldAdvanceSearch() {
		boolean b = true;
		isElementPresent(txt_oldadvancedSearch);
		isElementPresent(btn_oldbtnSearch);
		return b;
	}

	public void click_featuredProgram() {
		jsClick(menu_programs);
		// ClickOnWebElement(menu_programs);
		waitFor(2000);
	}

	public void view_featuredProgram_state() {
		if (isElementPresent(txt_featuredProgramTitle)) {
			System.out.println("featured program banner is active state");
		} else {
			System.out.println("featured program banner is not active state");
		}
	}

	public void view_adultFeaturedProgram_state() {
		if (isElementPresent(txt_adultfeaturedProgramTitle)) {
			System.out.println("featured program banner is active state");
		} else {
			System.out.println("featured program banner is not active state");
		}
	}

	public void view_footerNavigationBar() {
		javaScriptScrollToEnd();
		javascriptScroll(txt_FooterNavigationbar);
		if (txt_FooterNavigationbar.isDisplayed()) {
			System.out.println("user is able to view footer navigation bar");
		}
	}

	public void click_privacypolicy() {
		// jsClick(txt_privacyPolicylink);
		isElementPresent(txt_privacyPolicylink);
		waitFor(2000);
		/*
		 * if (txt_navRespectivescreen.isDisplayed()) {
		 * System.out.println("system should navigate to privacy policy screen"); }
		 * waitFor(2000); driver.navigate().back();
		 */
		// waitFor(2000);

	}

	public void click_termsAndconditions() {
		// jsClick(txt_termsAndConditions);
		isElementPresent(txt_termsAndConditions);
		waitFor(2000);
		/*
		 * if (txt_navRespectivescreen.isDisplayed()) {
		 * System.out.println("system should navigate to terms and conditions screen");
		 * } driver.navigate().back(); waitFor(2000);
		 */
	}

	public void view_newspaperAndmagazine() {
		// javascriptScroll(txt_newspaperAndmagazines);
		if (isElementPresent(txt_oldnewspaperAndmagazines)) {
			System.out.println("user is able to view news paper and magazines");
		} else {

			System.out.println("user is able to view old news paper and magazies");
		}

	}

	public void view_newsPapermagazineCarousel() {
		if (isElementPresent(carousel_newspaper_right)) {
			ClickOnWebElement(carousel_newspaper_right);
			System.out.println("user is able to view featured publications");
		} else {
			isElementPresent(carousel_newspaper_left);
			ClickOnWebElement(carousel_newspaper_left);
			System.out.println("user is able to view featured publications");
		}

	}

	public void click_newsPaperAndMagazineSeeAllcta() {
		if (isElementPresent(btn_linkseeAll)) {
			jsClick(btn_linkseeAll);
		}

	}

	public void click_seeAllcta() {
			javascriptScroll(txt_oldnewspaperAndmagazines);
			ClickOnWebElement(btn_oldlinkseeAll);
			waitFor(2000);
			if (txt_NavoldnewspaperAndmagazines.isDisplayed()) {
				System.out.println("system should navigate to news paper & magazine screen");
			}
		
	}

	public boolean view_alwaysAvailableTitle() {
		visibilityWait(txt_AlwaysavailableTitle);
		javascriptScroll(txt_AlwaysavailableTitle);
		boolean b = true;
		isElementPresent(txt_AlwaysavailableTitle);
		return b;
	}

	public void alwaysAvailable_seeAllcta() {
		javascriptScroll(txt_AlwaysavailableSeeAllcta);
		jsClick(txt_AlwaysavailableSeeAllcta);
		waitFor(2000);
		isElementPresent(txt_NavAlwaysavailableScreen);
		System.out.println("system should navigate to always availablel screen");

	}

	public void click_patronSupport() {
		javascriptScroll(btn_patronSupport);
		// String windowHandle = driver.getWindowHandle();
		jsClick(btn_patronSupport);
		// ClickOnWebElement(btn_patronSupport);
		waitFor(5000);

	}

	public void view_patron() {
		String windowHandle = driver.getWindowHandle();
		Set<String> windowHandles = driver.getWindowHandles();
		for (String newWindow : windowHandles) {
			driver.switchTo().window(newWindow);
		}
		isElementPresent(txt_NavpatronSupportScreen);
		System.out.println("system should navigate to patron support screen");
	}

}
