package pom.kidszone;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

import org.junit.Assert;

public class Myprog extends CommonAction {
	
	static ExcelReader reader = new ExcelReader();

	public Myprog(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "loc_textalertcontent")
	private WebElement leaveprog_confirmationMsg;

	@FindBy(id = "loc_cancelbtn")
	private WebElement leaveprog_cancelCTA;
	
	@FindBy(id = "loc_confirmbtnOK")
	private WebElement leaveprog_OkCTA;
	
	@FindBy(xpath = "//p[text()='Success!']")
	private WebElement success_toastmsg;
	
	@FindBy(xpath = "//mat-card-title[text()='xyprogram2upcoming ']")
	private WebElement upcoming_xyprog;
	
	@FindBy(xpath = "//img[@class='mat-card-image card-image']")
	private WebElement upcoming_xyprogtitle;
	
	@FindBy(id = "breadcrumb-link-1")
	public static WebElement prog_titleListScreen;
	
	@FindBy(xpath = "(//span[text()='Checkout'])[1]")
    private WebElement primary_action_cta;
	
	@FindBy(xpath = "//a[text()='PROGRAMS']")
    private WebElement magicLib_programs;
	
	@FindBy(xpath = "//div[text()='ALL PROGRAMS']")
    public static WebElement magicLib_nav_programScreen;
	
	@FindBy(xpath = "(//mat-card[@class='mat-card mat-focus-indicator program-card'])[1]")
    private WebElement magicLib_nav_progName;
	
	@FindBy(xpath = "//img[@class='mat-card-image card-image']")
    private List<WebElement> img_xyprog;
	
	@FindBy(xpath = "(//button[@class='btn-primary btn-primary-blue ng-star-inserted'])")
    public static WebElement primary_CTA;
	
	@FindBy(xpath = "//mat-icon[@class='mat-icon notranslate book-poster-icon mat-icon-no-color']")
	private List<WebElement> format_icon;
	
	@FindBy(xpath = "//h3[text()='AutoProgram123']")
    public static WebElement magicLib_progName;
	
	@FindBy(xpath = "//h2[contains(text(),'Reading List')]")
    public static WebElement magicLib_noOFparticipants;
	
	@FindBy(xpath = "//button[text()='Join Program']")
    public static WebElement magicLib_joinPrg;
	
	@FindBy(xpath = "//h1[@class='primary-heading-1 ng-star-inserted']")
	private WebElement title_details_screen;
	
	@FindBy(id = "loc_txtReadingList")
	public static WebElement progDetailScreen_readinglist;
	
	public WebElement getSuccess_toastmsg() {
		return success_toastmsg;
	}

	public WebElement getLeaveprog_confirmationMsg() {
		return leaveprog_confirmationMsg;
	}
	
	public WebElement getLeaveprog_cancelCTA() {
		return leaveprog_cancelCTA;
	}

	public WebElement getLeaveprog_OkCTA() {
		return leaveprog_OkCTA;
		
	}


/**********************************************************************************************/
	public void click_cancelCTA() {
		ClickOnWebElement(leaveprog_cancelCTA);
		waitFor(2000);
	}
	
	public void click_yesCTA() {
		ClickOnWebElement(leaveprog_OkCTA);
		waitFor(2000);
	}
	
	public void click_upcomingXYprog() {
		javaScriptScrollToEnd();
		visibilityWait(upcoming_xyprog);
		javascriptScroll(upcoming_xyprog);
		ClickOnWebElement(upcoming_xyprog);
		WaitForWebElement(progDetailScreen_readinglist);
		waitFor(2000);

	}
	
	public void click_xytitle() {
		ClickOnWebElement(upcoming_xyprogtitle);
		waitFor(2000);
	}
	
	public void ctaEnabledOrDisabled() {
        try {
        	javascriptScroll(primary_action_cta);
            Assert.assertEquals(primary_action_cta.isEnabled(), true);
        } catch (Exception e) {
        	Logger.log("CTA is disabled ");
            e.printStackTrace();
        }
    }
	
	public void click_programsAdult() {
		javascriptScroll(magicLib_programs);
		ClickOnWebElement(magicLib_programs);
		waitFor(2000);
	}
	
	public void select_programAdult() {
		ClickOnWebElement(magicLib_nav_progName);
		waitFor(2000);
	}
	
	public void view_coverimgAndformatIcon() {
		for (int i = 0; i <img_xyprog.size(); i++) {
			isElementPresent(img_xyprog.get(i));
			isElementPresent(format_icon.get(i));
		}

	}
	
	public void click_coverimg() {
		ClickOnWebElement(img_xyprog.get(0));
		waitFor(2000);
	}
	
	public void validate_title_details_screen() {
		WaitForWebElement(title_details_screen);
        Assert.assertTrue(isElementPresent(title_details_screen));

	
	}	
}
