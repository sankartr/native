package pom.kidszone;

import java.io.IOException;

import java.util.List;
import java.util.Map;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Adminconfiguration extends CommonAction {

	public static String cardNumber;

	public Adminconfiguration(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	static ExcelReader reader = new ExcelReader();

	@FindBy(id = "UserName")
	private WebElement txtfld_username;

	@FindBy(id = "Password")
	private WebElement txtfld_password;

	@FindBy(xpath = "//*[@type=\"submit\"]")
	private WebElement btn_loginSubmit;

	@FindBy(id = "LibraryManagement")
	private WebElement btn_librarymanagementMenu;

	@FindBy(id = "LibrarySearch")
	private WebElement drop_searchBy;

	@FindBy(id = "searchText")
	private WebElement txtfld_librarySearch;

	@FindBy(xpath = "//*[@id=\"search\"]/div[1]")
	private WebElement btn_search;

	@FindBy(xpath = "//*[@data-tooltip='Edit Library Settings']")
	private WebElement btn_libraryEdit;

	@FindBy(xpath = "//*[@class=\"icon_button_edit\"]")
	private WebElement btn_libraryediting;

	@FindBy(id = "CustomerID")
	private WebElement txt_customerid;

	@FindBy(id = "axis360")
	private WebElement chk_axis360;

	@FindBy(id = "kidszone")
	private WebElement chk_kidszone;

	@FindBy(xpath = "//*[@class=\"icon_button_save\"]")
	private WebElement btn_saveLibrary;

	@FindBy(xpath = "//*[@class=\"ui-icon ui-icon-closethick\"]")
	private WebElement btn_closepop;

	@FindBy(xpath = "//*[@title=\"Log Off\"]")
	private WebElement btn_logoff;

	@FindBy(id = "adultprofile")
	private WebElement chk_adultprof;

	@FindBy(id = "teenprofile")
	private WebElement chk_teenprof;

	@FindBy(id = "kidsprofile")
	private WebElement chk_kidsprof;

	@FindBy(id = "adultPRGMS")
	private WebElement chk_adultprograms;

	@FindBy(id = "adultRCMS")
	private WebElement chk_adultrecomm;

	@FindBy(id = "adultINSBG")
	private WebElement chk_adultinsight;

	@FindBy(id = "adultWBEXP")
	private WebElement chk_adultwebpathex;

	@FindBy(id = "adultPRSRD")
	private WebElement chk_adultpressreader;

	@FindBy(id = "kidPRGMS")
	private WebElement chk_kidprograms;

	@FindBy(id = "kidRCMS")
	private WebElement chk_kidrecomm;

	@FindBy(id = "kidINSBG")
	private WebElement chk_kidinsight;

	@FindBy(id = "kidWBEXP")
	private WebElement chk_kidwebpathex;

	@FindBy(id = "kidPRSRD")
	private WebElement chk_kidpressreader;

	@FindBy(id = "teenPRGMS")
	private WebElement chk_teenprograms;

	@FindBy(id = "teenRCMS")
	private WebElement chk_teenrecomm;

	@FindBy(id = "teenINSBG")
	private WebElement chk_teeninsight;

	@FindBy(id = "teenWBEXP")
	private WebElement chk_teenwebpathex;

	@FindBy(id = "teenPRSRD")
	private WebElement chk_teenpressreader;

	@FindBy(xpath = "//*[@class='icon_action_back bread-crumb-back']")
	private WebElement btn_libraryback;

	@FindBy(id = "lsettings")
	private WebElement salesdemo_label_librarysettingmenu;

	@FindBy(id = "UserName")
	private WebElement salesdemo_txtfield_username;

	@FindBy(id = "Password")
	private WebElement salesdemo_txtfield_password;

	@FindBy(xpath = "//input[@type='submit']")
	private WebElement salesdemo_btn_login;

	@FindBy(id = "settings")
	private WebElement salesdemo_lable_setting;

	@FindBy(xpath = "//div[text()='Library Settings']")
	private WebElement salesdemo_lable_librarysetting;

	@FindBy(xpath = "//legend[text()='Profile Settings']")
	private WebElement salesdemo_txt_profilesetting;
	
	@FindBy(id = "save")
	private WebElement save_cta;
	
	@FindBy(id = "library-administration")
	private WebElement Btn_library_administration;
	
	@FindBy(xpath = "(//mat-icon[@svgicon='edit-icon'])[2]")
	private WebElement edit_cta_announcement;
	
	@FindBy(xpath = "//h2[text()='CURRENT ANNOUNCEMENT']")
	private WebElement view_published_announcement;
	
	@FindBy(xpath  = "//button[text()='Unpublish']")
	private WebElement btn_unpublish;

	@FindBy(id = "mat-dialog-0")
	private WebElement unpublish_dialogbox;
	
	@FindBy(xpath = "//button[@class='submit-btn']")
	private WebElement unpublish_ok_cta;
	
	@FindBy(xpath = "//div[@class='announcements-col ng-star-inserted']")
	private WebElement view_library_announcement;
	
	@FindBy(xpath = "//span[text()='Advanced Search']")
	private WebElement advanced_search;
	
	@FindBy(xpath = "//a[text()=' Library Announcements ']")
	private WebElement announcement_screen;

	@FindBy(xpath = "//button[text()='Publish']")
	private WebElement btn_publish;
	
	@FindBy(id = "mat-dialog-2")
	private WebElement replace_confirmation_dialogbox;

	@FindBy(xpath = "(//*[@id='mat-input-0'])")
	private WebElement announceHeadline;
	
	@FindBy(xpath = "(//*[@id='mat-input-2'])")
	private WebElement announceTitle;
	
	@FindBy(xpath = "(//*[@id='description'])")
	private WebElement announceDescription;
	
	@FindBy(id = "opturl")
	private WebElement urlRadioBtn;
	
	@FindBy(xpath = "//*[@placeholder='Enter URL here']")
	private WebElement enterUrl;
	
	@FindBy(xpath = "//*[@class='kz-addurl-btn primary-outline-btn']")
	private WebElement addUrlBtn;
	
	public WebElement getReplace_confirmation_dialogbox() {
		return replace_confirmation_dialogbox;
	}

	public WebElement getBtn_publish() {
		return btn_publish;
	}

	public WebElement getBtn_preview() {
		return btn_preview;
	}

	public WebElement getAnnouncement_screen() {
		return announcement_screen;
	}

	public WebElement getAdvanced_search() {
		return advanced_search;
	}

	public WebElement getView_library_announcement() {
		return view_library_announcement;
	}

	public WebElement getBtn_unpublish() {
		return btn_unpublish;
	}

	public WebElement getUnpublish_dialogbox() {
		return unpublish_dialogbox;
	}

	public WebElement getUnpublish_ok_cta() {
		return unpublish_ok_cta;
	}
	
	public WebElement getView_published_announcement() {
		return view_published_announcement;
	}

	public WebElement getEdit_cta_announcement() {
		return edit_cta_announcement;
	}

	public WebElement getBtn_library_administration() {
		return Btn_library_administration;
	}

	@FindBy(xpath = "//li[@class='bread-crumb-text']")
	private WebElement home_page;
	
	@FindBy(id = "announcements")
	private WebElement label_announcements;
	
	@FindBy(xpath = "//div[@class='icon_menu_library_admin']")
	private WebElement label_libraryAdministration;
	
	@FindBy(xpath = "(//mat-icon[@role='img'])[6]")
	private WebElement announcement_Editicon;
	
	@FindBy(xpath = "//a[text()=' Library Announcements ']")
	private WebElement Nav_announcement;
	
	@FindBy(id = "opturl")
	private WebElement url_radiobutton;
	
	@FindBy(id = "url")
	private WebElement url_txtbox;
	
	@FindBy(xpath = "//button[text()='Add']")
	private WebElement label_add;
	
	@FindBy(xpath = "//button[text()='Preview']")
	private WebElement btn_preview;
	
	@FindBy(id = "dummy")
	public static WebElement url_txtinAnnouncement;
	
	public WebElement getNav_announcement() {
		return Nav_announcement;
	}

	public WebElement getHome_page() {
		return home_page;
	}

	public WebElement getBtn_librarymanagementMenu() {
		return btn_librarymanagementMenu;
	}

/****************************** Action methods*****************************************/

//	public void app_launch(String loginType) throws Exception {
//		if (loginType.equalsIgnoreCase("idAndPassword")) {
//			DriverManager.getDriver().get(getData("idAndPassword"));
//		} else if (loginType.equalsIgnoreCase("prefixWithPin")) {
//			DriverManager.getDriver().get(getData("prefixWithPin"));
//		} else if (loginType.equalsIgnoreCase("prefixWithOutPin")) {
//			DriverManager.getDriver().get(getData("prefixWithoutPin"));
//		} else if (loginType.equalsIgnoreCase("SSO")) {
//			DriverManager.getDriver().get(getData("SSO"));
//		} else if (loginType.equalsIgnoreCase("cleverSSO")) {
//			DriverManager.getDriver().get(getData("cleverSSO"));
//		} else if (loginType.equalsIgnoreCase("BTadmin")) {
//			DriverManager.getDriver().get(getData("BTadmin"));
//		} else if (loginType.equalsIgnoreCase("Salesdemo")) {
//			DriverManager.getDriver().get(getData("Salesdemo"));
//		}
//		waitFor(5000);
//	}

	public void admin_login(String username, String password) {
		ClickOnWebElement(txtfld_username);
		SendKeysOnWebElement(txtfld_username, username);
		SendKeysOnWebElement(txtfld_password, password);
		ClickOnWebElement(btn_loginSubmit);
	}

	public void admin_relogin() throws InvalidFormatException, IOException {
		ClickOnWebElement(txtfld_username);
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Admin");
		SendKeysOnWebElement(txtfld_username, testData.get(0).get("username"));
		SendKeysOnWebElement(txtfld_password, testData.get(0).get("password"));
		ClickOnWebElement(btn_loginSubmit);
	}

	public void library_settings() {
		waitFor(3000);
		ClickOnWebElement(btn_librarymanagementMenu);
	}

	public void library_search() throws InvalidFormatException, IOException {
		waitFor(3000);
		ClickOnWebElement(drop_searchBy);
		waitFor(3000);
		Select select = new Select(drop_searchBy);
		select.selectByVisibleText("Customer ID");
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Admin");
		SendKeysOnWebElement(txtfld_librarySearch,  testData.get(0).get("libraryid"));
		ClickOnWebElement(btn_search);
		waitFor(3000);
		jsClick(btn_libraryEdit);
	}
	
	public void library_SearchAdmin(String library) {
		waitFor(3000);
		ClickOnWebElement(drop_searchBy);
		waitFor(3000);
		SendKeysOnWebElement(txtfld_librarySearch, library);
		visibilityWait(btn_search);
		ClickOnWebElement(btn_search);
		waitFor(5000);
		jsClick(btn_libraryEdit);

	}
	

	public void libraryback_navigation() {
		waitFor(3000);
		ClickOnWebElement(btn_libraryback);
		waitFor(3000);
		ClickOnWebElement(btn_libraryback);
	}

	public void enablekidsprof() throws IOException, Exception {
		waitFor(5000);
		javascriptScroll(chk_kidsprof);
		if (chk_kidsprof.isSelected()) {
			System.out.println("kids profile already selected");
		} else {
			ClickOnWebElement(chk_kidsprof);
		}
	}

	public void disablekidsprof() throws IOException, Exception {
		waitFor(5000);
		javascriptScroll(chk_kidsprof);
		if (chk_kidsprof.isSelected()) {
			ClickOnWebElement(chk_kidsprof);
		} else {
			System.out.println("kids profile already unchecked");
		}
	}

	public void savelibrary() {
		waitFor(5000);
		ClickOnWebElement(btn_saveLibrary);
		Actions action = new Actions(DriverManager.getDriver());
		action.sendKeys(Keys.ENTER).perform();
		waitFor(3000);
	}

	// 109404//

	public void enableteenprof() throws IOException, Exception {
		waitFor(5000);
		javascriptScroll(chk_teenprof);
		if (chk_teenprof.isSelected()) {
			System.out.println("teen profile already selected");
		} else {
			ClickOnWebElement(chk_teenprof);
		}
	}

	public void disableteenprof() throws IOException, Exception {
		waitFor(5000);
		javascriptScroll(chk_teenprof);
		if (chk_teenprof.isSelected()) {
			ClickOnWebElement(chk_teenprof);
		} else {
			System.out.println("teen profile already unchecked");
		}
	}

	// 109405//

	public void enableadultprof() throws IOException, Exception {
		waitFor(5000);
		javascriptScroll(chk_adultprof);
		if (chk_adultprof.isSelected()) {
			System.out.println("adult profile already selected");
		} else {
			ClickOnWebElement(chk_adultprof);
		}
	}

	public void disableadultprof() throws IOException, Exception {
		waitFor(5000);
		javascriptScroll(chk_adultprof);
		if (chk_adultprof.isSelected()) {
			ClickOnWebElement(chk_adultprof);
		} else {
			System.out.println("adult profile already unchecked");
		}
	}

	public void enable_kidszone() {
		waitFor(3000);
		javascriptScroll(chk_kidszone);
		if (chk_kidszone.isSelected()) {
			System.out.println("Kidszone already eabled");
		} else {
			ClickOnWebElement(chk_kidszone);
		}

	}
	
	public void enable_axistoKidzone() {
		waitFor(3000);
		javascriptScroll(chk_kidszone);	
		if (chk_axis360.isSelected()) {
			ClickOnWebElement(chk_axis360);
		} else {
			System.out.println("Axis360 already enabled");
			//ClickOnWebElement(chk_axis360);
		}
		if (chk_kidszone.isSelected()) {
			System.out.println("Kidszone already eabled");
		} else {
			ClickOnWebElement(chk_kidszone);
		}		

	}
	
	public void saveCTA_libpage() {
		waitFor(2000);
		jsClick(save_cta);
		waitFor(3000);

	}

	public void enable_adultprogram() {
		waitFor(3000);
		javascriptScroll(chk_adultprograms);

		if (chk_adultprograms.isSelected()) {
			System.out.println("Adult program enabled already");
		} else {
			ClickOnWebElement(chk_adultprograms);
		}

	}

	public void disable_adultprogram() {
		waitFor(3000);
		javascriptScroll(chk_adultprograms);

		if (chk_adultprograms.isSelected()) {
			ClickOnWebElement(chk_adultprograms);
		} else {
			System.out.println("Adult program disabled already");
		}

	}

	public void enable_teenprogram() {
		waitFor(3000);
		javascriptScroll(chk_teenprograms);

		if (chk_teenprograms.isSelected()) {
			System.out.println("teen program enabled already");
		} else {
			ClickOnWebElement(chk_teenprograms);
		}

	}

	public void disable_teenprogram() {
		waitFor(3000);
		javascriptScroll(chk_teenprograms);

		if (chk_teenprograms.isSelected()) {
			ClickOnWebElement(chk_teenprograms);
		} else {
			System.out.println("teen program disabled already");
		}

	}

	public void enable_kidsprogram() {
		waitFor(3000);
		javascriptScroll(chk_kidprograms);

		if (chk_kidprograms.isSelected()) {
			System.out.println("kid program enabled already");
		} else {
			ClickOnWebElement(chk_kidprograms);
		}

	}

	public void disable_kidsprogram() {
		waitFor(3000);
		javascriptScroll(chk_kidprograms);

		if (chk_kidprograms.isSelected()) {
			ClickOnWebElement(chk_kidprograms);
		} else {
			System.out.println("kid program disabled already");
		}

	}
	// 109407//

	public void enable_adultinsight() {
		waitFor(3000);
		javascriptScroll(chk_adultinsight);

		if (chk_adultinsight.isSelected()) {
			System.out.println("Adult insights enabled already");
		} else {
			ClickOnWebElement(chk_adultinsight);
		}

	}

	public void disable_adultinsight() {
		waitFor(3000);
		javascriptScroll(chk_adultinsight);

		if (chk_adultinsight.isSelected()) {
			ClickOnWebElement(chk_adultinsight);
		} else {
			System.out.println("Adult insights disabled already");
		}

	}

	public void enable_teeninsight() {
		waitFor(3000);
		javascriptScroll(chk_teeninsight);

		if (chk_teeninsight.isSelected()) {
			System.out.println("teen insights enabled already");
		} else {
			ClickOnWebElement(chk_teeninsight);
		}

	}

	public void disable_teeninsight() {
		waitFor(3000);
		javascriptScroll(chk_teeninsight);

		if (chk_teeninsight.isSelected()) {
			ClickOnWebElement(chk_teeninsight);
		} else {
			System.out.println("teen insights disabled already");
		}

	}

	public void enable_kidsinsight() {
		waitFor(3000);
		javascriptScroll(chk_kidinsight);

		if (chk_kidinsight.isSelected()) {
			System.out.println("kid insights enabled already");
		} else {
			ClickOnWebElement(chk_kidinsight);
		}

	}

	public void disable_kidsinsight() {
		waitFor(3000);
		javascriptScroll(chk_kidinsight);

		if (chk_kidinsight.isSelected()) {
			ClickOnWebElement(chk_kidinsight);
		} else {
			System.out.println("kid insights disabled already");
		}

	}

	// 109408//

	public void enable_adultrecomm() {
		waitFor(3000);
		javascriptScroll(chk_adultrecomm);

		if (chk_adultrecomm.isSelected()) {
			System.out.println("Adult recommendation enabled already");
		} else {
			ClickOnWebElement(chk_adultrecomm);
		}

	}

	public void disable_adultrecomm() {
		waitFor(3000);
		javascriptScroll(chk_adultrecomm);

		if (chk_adultrecomm.isSelected()) {
			ClickOnWebElement(chk_adultrecomm);
		} else {
			System.out.println("Adult recommendation disabled already");
		}

	}

	public void enable_teenrecomm() {
		waitFor(3000);
		javascriptScroll(chk_teenrecomm);

		if (chk_teenrecomm.isSelected()) {
			System.out.println("teen recommendation enabled already");
		} else {
			ClickOnWebElement(chk_teenrecomm);
		}

	}

	public void disable_teenrecomm() {
		waitFor(3000);
		javascriptScroll(chk_teenrecomm);

		if (chk_teenrecomm.isSelected()) {
			ClickOnWebElement(chk_teenrecomm);
		} else {
			System.out.println("teen recommendation disabled already");
		}

	}

	public void enable_kidrecomm() {
		waitFor(3000);
		javascriptScroll(chk_kidrecomm);

		if (chk_kidrecomm.isSelected()) {
			System.out.println("kid recommendation enabled already");
		} else {
			ClickOnWebElement(chk_kidrecomm);
		}

	}

	public void disable_kidrecomm() {
		waitFor(3000);
		javascriptScroll(chk_kidrecomm);

		if (chk_kidrecomm.isSelected()) {
			ClickOnWebElement(chk_kidrecomm);
		} else {
			System.out.println("kid recommendation disabled already");
		}

	}

	// 109409//

	public void enable_adultwebpathex() {
		waitFor(3000);
		javascriptScroll(chk_adultwebpathex);

		if (chk_adultwebpathex.isSelected()) {
			System.out.println("Adult Web Path express enabled already");
		} else {
			ClickOnWebElement(chk_adultwebpathex);
		}

	}

	public void disable_adultwebpathex() {
		waitFor(3000);
		javascriptScroll(chk_adultwebpathex);

		if (chk_adultwebpathex.isSelected()) {
			ClickOnWebElement(chk_adultwebpathex);
		} else {
			System.out.println("Adult Web Path express disabled already");
		}

	}

	public void enable_teenwebpathex() {
		waitFor(3000);
		javascriptScroll(chk_teenwebpathex);

		if (chk_teenwebpathex.isSelected()) {
			System.out.println("teen Web Path express enabled already");
		} else {
			ClickOnWebElement(chk_teenwebpathex);
		}

	}

	public void disable_teenwebpathex() {
		waitFor(3000);
		javascriptScroll(chk_teenwebpathex);

		if (chk_teenwebpathex.isSelected()) {
			ClickOnWebElement(chk_teenwebpathex);
		} else {
			System.out.println("teen Web Path express disabled already");
		}

	}

	public void enable_kidwebpathex() {
		waitFor(3000);
		javascriptScroll(chk_kidwebpathex);

		if (chk_kidwebpathex.isSelected()) {
			System.out.println("kid Web Path express enabled already");
		} else {
			ClickOnWebElement(chk_kidwebpathex);
		}

	}

	public void disable_kidwebpathex() {
		waitFor(3000);
		javascriptScroll(chk_kidwebpathex);

		if (chk_kidwebpathex.isSelected()) {
			ClickOnWebElement(chk_kidwebpathex);
		} else {
			System.out.println("kid Web Path express disabled already");
		}

	}

	// 109410//

	public void enable_adultpressreader() {
		waitFor(3000);
		javascriptScroll(chk_adultpressreader);

		if (chk_adultpressreader.isSelected()) {
			System.out.println("Adult Press reader enabled already");
		} else {
			ClickOnWebElement(chk_adultpressreader);
		}

	}

	public void disable_adultpressreader() {
		waitFor(3000);
		javascriptScroll(chk_adultpressreader);

		if (chk_adultpressreader.isSelected()) {
			ClickOnWebElement(chk_adultpressreader);
		} else {
			System.out.println("Adult Press reader disabled already");
		}

	}

	public void enable_teenpressreader() {
		waitFor(3000);
		javascriptScroll(chk_teenpressreader);

		if (chk_teenpressreader.isSelected()) {
			System.out.println("teen Press reader enabled already");
		} else {
			ClickOnWebElement(chk_teenpressreader);
		}

	}

	public void disable_teenpressreader() {
		waitFor(3000);
		javascriptScroll(chk_teenpressreader);

		if (chk_teenpressreader.isSelected()) {
			ClickOnWebElement(chk_teenpressreader);
		} else {
			System.out.println("teen Press reader disabled already");
		}

	}

	public void enable_kidpressreader() {
		waitFor(3000);
		javascriptScroll(chk_kidpressreader);

		if (chk_kidpressreader.isSelected()) {
			System.out.println("kid Press reader enabled already");
		} else {
			ClickOnWebElement(chk_kidpressreader);
		}

	}

	public void disable_kidpressreader() {
		waitFor(3000);
		javascriptScroll(chk_kidpressreader);

		if (chk_kidpressreader.isSelected()) {
			ClickOnWebElement(chk_kidpressreader);
		} else {
			System.out.println("kid Press reader disabled already");
		}

	}

	// Geetha Changes//

	public void verify_enable_kidprofile() {
		if (chk_kidsprof.isSelected()) {
			System.out.println("kids profile already selected");
		} else {
			System.out.println("kids profile not selected");
			ClickOnWebElement(chk_kidsprof);
		}

	}

	public void verify_enable_teenprofile() {
		if (chk_teenprof.isSelected()) {
			System.out.println("teen profile already selected");
		} else {
			System.out.println("teen profile not selected");
			ClickOnWebElement(chk_teenprof);
		}
	}

	public void verify_enable_adultprofile() {
		if (chk_adultprof.isSelected()) {
			System.out.println("adult profile already selected");
		} else {
			System.out.println("adult profile not selected");
			ClickOnWebElement(chk_adultprof);
		}

	}

	public void verify_disable_kidprfile() {
		if (chk_kidsprof.isSelected()) {
			ClickOnWebElement(chk_kidsprof);
			System.out.println("kids profile should disable");
		} else {
			System.out.println("kids profile should be enable");

		}

	}

	public void verify_disable_teenprfile() {
		if (chk_teenprof.isSelected()) {
			ClickOnWebElement(chk_teenprof);
			System.out.println("teen profile should disable");
		} else {
			System.out.println("teen profile should be enable");

		}

	}

	public void verify_disable_adultprfile() {
		if (chk_adultprof.isSelected()) {
			ClickOnWebElement(chk_adultprof);
			System.out.println("adult profile should disable");
		} else {
			System.out.println("adult profile should be enable");

		}

	}

	public void login_salesdemo(String username, String password) {
		waitFor(2000);
		SendKeysOnWebElement(salesdemo_txtfield_username, username);
		SendKeysOnWebElement(salesdemo_txtfield_password, password);
		ClickOnWebElement(salesdemo_btn_login);
		waitFor(2000);
	}

	public void click_settingmenu() {
		ClickOnWebElement(salesdemo_lable_setting);
		waitFor(2000);
	}

	public void click_settingcard() {
		ClickOnWebElement(salesdemo_lable_librarysetting);
		waitFor(2000);
	}

	public void verify_profileManagementscreen() {
		javascriptScroll(salesdemo_txt_profilesetting);
		if (isElementPresent(salesdemo_txt_profilesetting)) {
			Logger.log("user is on library settings screen");
		}
	}

	public void disable_allPrfiles() {
		javascriptScroll(chk_adultprof);
		if (chk_adultprof.isDisplayed()) {
			verify_disable_kidprfile();
			verify_disable_teenprfile();
			verify_disable_adultprfile();
		} else {
			Logger.log("all profile not disable");
		}

	}

	public void verify_disable_kidszone() {
		javascriptScroll(chk_kidszone);
		if (chk_kidszone.isSelected()) {
			ClickOnWebElement(chk_kidszone);
		} else {
			System.out.println("Kidszone already disabled");
		}

	}
	
	//112826//
	
	public void verify_enable_kidszone() {
		javascriptScroll(chk_kidszone);
		waitFor(3000);
		if (chk_kidszone.isSelected()) {			
			System.out.println("Kidszone already enabled");
		} else {
			ClickOnWebElement(chk_kidszone);
		}
	}
	
	public void verify_enable_axis360() {
		javascriptScroll(chk_axis360);
		waitFor(3000);
		if (chk_axis360.isSelected()) {			
			System.out.println("Axis360 already enabled");
		} else {
			ClickOnWebElement(chk_axis360);
		}
	}
	
	public void verify_disable_axis360() {
		javascriptScroll(chk_axis360);
		waitFor(3000);
		if (chk_axis360.isSelected()) {	
			ClickOnWebElement(chk_axis360);
		} else {
			System.out.println("Axis360 already disabled");
			
		}
	}
	
	public void saleslibrary_search() {
		waitFor(3000);
		ClickOnWebElement(drop_searchBy);
		waitFor(3000);
		Select select = new Select(drop_searchBy);
		select.selectByVisibleText("Customer ID");
		SendKeysOnWebElement(txtfld_librarySearch, "530743");
		ClickOnWebElement(btn_search);
		waitFor(3000);
		jsClick(btn_libraryEdit);
	}
	
	public void kidsnyclibrary_search() {
		waitFor(3000);
		ClickOnWebElement(drop_searchBy);
		waitFor(3000);
		Select select = new Select(drop_searchBy);
		select.selectByVisibleText("Customer ID");
		SendKeysOnWebElement(txtfld_librarySearch, "9102239");
		ClickOnWebElement(btn_search);
		waitFor(3000);
		jsClick(btn_libraryEdit);
	}
	
	public void magiclibrary_search() {
		waitFor(3000);
		ClickOnWebElement(drop_searchBy);
		waitFor(3000);
		Select select = new Select(drop_searchBy);
		select.selectByVisibleText("Customer ID");
		SendKeysOnWebElement(txtfld_librarySearch, "70222");
		ClickOnWebElement(btn_search);
		waitFor(3000);
		jsClick(btn_libraryEdit);
	}
	
	public void savelibrary_logoff() {
		waitFor(5000);
		ClickOnWebElement(btn_saveLibrary);
		Actions action = new Actions(DriverManager.getDriver());
		action.sendKeys(Keys.ENTER).perform();
		ClickOnWebElement(btn_logoff);
		waitFor(3000);
	}
	
	public void click_library_administration() {
           waitFor(2000);
           ClickOnWebElement(Btn_library_administration);
	}
	
	public void click_edit_cta_announcement() {
		waitFor(4000);
             ClickOnWebElement(edit_cta_announcement);
	}
	
	public void click_unpublish_cta() {
		javascriptScroll(btn_unpublish);
          waitFor(2000);
          ClickOnWebElement(btn_unpublish);
		
	}
	
	public void click_okCta() {
              waitFor(2000);
              ClickOnWebElement(unpublish_ok_cta);
              DriverManager.getDriver().navigate().refresh();
	}
	
	public void click_preview_cta() {
       waitFor(2000);
       ClickOnWebElement(btn_preview);
       waitFor(3000);
	}
	
	public void click_publish_cta() {
          waitFor(2000);
          ClickOnWebElement(btn_publish);
	   }

	public void select_announcements() {
		javascriptScroll(label_announcements);
		ClickOnWebElement(label_announcements);
		waitFor(2000);
	}
	
	public void click_libAdministration() {
		visibilityWait(label_libraryAdministration);
		ClickOnWebElement(label_libraryAdministration);
		waitFor(2000);
	}
	
	public void click_announcementEditicon() {
	visibilityWait(edit_cta_announcement);
	ClickOnWebElement(edit_cta_announcement);
	}
	
	public void enter_urlDetails(String url) throws InvalidFormatException, IOException {
		javascriptScroll(announceHeadline);
		SendKeysOnWebElement(announceHeadline, "Publishing_Announcement");
		waitFor(2000);
		SendKeysOnWebElement(announceTitle, "QA_Test");
		waitFor(2000);
		SendKeysOnWebElement(announceDescription, "Publishing Announcement in QA Environment");
		waitFor(2000);
		if (urlRadioBtn.isSelected()) {
			System.out.println("radio btn is enabled");
		} else {
			ClickOnWebElement(urlRadioBtn);
		}
		WaitForWebElement(enterUrl);
		SendKeysOnWebElement(enterUrl, url);
		WaitForWebElement(addUrlBtn);
		ClickOnWebElement(addUrlBtn);
		
	}
	public void select_preview() {
		javascriptScroll(btn_preview);
		ClickOnWebElement(btn_preview);
		waitFor(2000);
	}
	
	
	
}
