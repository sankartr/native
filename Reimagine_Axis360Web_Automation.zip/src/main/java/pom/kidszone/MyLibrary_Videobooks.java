package pom.kidszone;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class MyLibrary_Videobooks extends CommonAction {
	MyshelfvideosVbooks myshelfpage = new MyshelfvideosVbooks(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());
	static ExcelReader reader = new ExcelReader();
	MyLibrary_Vbooks vbook = new MyLibrary_Vbooks(DriverManager.getDriver());

	public MyLibrary_Videobooks(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "loc_txtAvailability")
	private WebElement LibraryPage;

	@FindBy(id = "list_id_VIDEOS")
	private WebElement Lib_videoCarouselFormat;

	@FindBy(xpath = "(//div[@class='kz-carousel kz-third-party-carousel kz-video-carousel item-carousel-default ng-star-inserted'])[2]")
	private WebElement Lib_videoCarousel_itemCarouselType;

	@FindBy(id = "loc_third_party_VBOOKS_item_carousel")
	private WebElement Lib_videoCarousel_CardCarouselType;

	@FindBy(xpath = "(//div[@class='kz-carousel kz-third-party-carousel kz-video-carousel item-carousel-default ng-star-inserted'])[1]")
	private WebElement Lib_vBookCarousel_CardCarouselType;

	@FindBy(xpath = "//*[@class='featured-card-carousel']//following::*[contains(text(),'Videobooks')]")
	private WebElement Lib_vBookCarousel_CardCarousel;

	@FindBy(xpath = "//*[@aria-label='See All Popular Videobooks']")
	private WebElement vBookSeeAll;

	@FindBy(xpath = "//*[@class='kz-press-reader']")
	private WebElement vBookTier1Page;

	@FindBy(xpath = "//*[@id='thirdPartyCarousel_2']")
	private WebElement vBookTier1Carousel;

	@FindBy(xpath = "(//*[@title='Checkout'])[1]")
	private WebElement primaryCTA;

	@FindBy(xpath = "(//*[@class='ac-container ac-selectable'])[1]")
	private WebElement titleCardinTier1;

	@FindBy(xpath = "(//*[@class='third-party-card-details third-party-videos-detail'])")
	public static WebElement titleDetailPage;

	@FindBy(xpath = "(//button[@title='Checkout'])[1]")
	public static WebElement checkoutButton;

	@FindBy(xpath = "//h3[contains(text(),'Videos')]/following::div[text()='Checkout']")
	private List<WebElement> checkoutCTA_videocarousel;

	@FindBy(xpath = "(//*[contains(text(),'Videos')]//following::div[@class='ac-container ac-selectable'])")
	private List<WebElement> coverimg_videocarousel;

	@FindBy(xpath = "(//button[@title='Play'])[1]")
	public static WebElement playButton;

	@FindBy(xpath = "(//button[@title='Resume'])[1]")
	public static WebElement ResumeCta;

	@FindBy(xpath = "//*[@title='Return']")
	private WebElement returnButton;

	@FindBy(xpath = "//*[@title='Renew']")
	private WebElement renewButton;

	@FindBy(xpath = "(//*[contains(text(),'Videos')]//following::div[@class='ac-container ac-selectable'])[1]")
	public static WebElement Lib_videoCarousel_videotitleCoverimg;

	@FindBy(xpath = "(//button[@type='button']//div[text()='Checkout'])")
	private WebElement Lib_videoCarousel_PrimaryCTAasCheckout;

	@FindBy(xpath = "(//button[@type='button']//div[text()='Checkout'])")
	private List<WebElement> Lib_videoCarousel_PrimaryCTACheckout;

	@FindBy(xpath = "//div[@class='third-party-card-details third-party-videos-detail']")
	private WebElement Lib_videoCarousel_Nav_Tier3Detailspage;

	@FindBy(xpath = "(//button[@type='button']//div[text()='Play'])[1]")
	private WebElement Lib_videoCarousel_PrimaryCTAasPlay;

	@FindBy(id = "myVideo")
	private WebElement Lib_videoCarousel_Resume;

	@FindBy(xpath = "//*[contains(text(),'Resume')]")
	private WebElement Lib_videoCarousel_ResumeCTA;

	@FindBy(xpath = "(//h2[contains(text(),'Video')]/following::a[contains(text(),'See All ')])[2]")
	private WebElement Lib_videoCarousel_seeAllCTA;

	@FindBy(xpath = "(//div[@class='third-party-featured-banner'])[1]")
	private WebElement Lib_videoCarousel_tier1_Featuredcarousel;

	@FindBy(xpath = "//*[@id='thirdPartyCarousel_3']")
	private WebElement Lib_videoCarousel_tier1_othercarousel;

	@FindBy(xpath = "(//*[@id='thirdPartyCarousel_2'])[1]")
	private WebElement Lib_videoCarousel_tier1_titleCarousel;

	@FindBy(xpath = "(//div[@class='third-party-video-category'])[1]")
	public static WebElement Lib_videoCarousel_tier1_category;

	@FindBy(xpath = "//*[@class='carousel-categories']")
	public static WebElement Lib_videoCarousel_tier1_categoryCarouseformatl;

	@FindBy(xpath = "//div[contains(text(),'Mr. Billie')]")
	public static WebElement Lib_videoCarousel_tier1_categoryMrBillie;

	@FindBy(xpath = "//div[contains(text(),'Checkers')]")
	public static WebElement Lib_videoCarousel_tier1_categoryCheckersTV;
	
	@FindBy(xpath = "(//*[@class='video-widgets-category'])[1]")
	public static WebElement Lib_videoCarousel_category;
	
	@FindBy(xpath = "(//*[@class='kz-carousel kz-category-carousel ng-star-inserted'])[1]")
	public static WebElement Lib_videoCarousel_tier1_categoryCarousel;

	@FindBy(xpath = "(//img[@class='ac-image ac-selectable'])[1]")
	public static WebElement Lib_videoCarousel_tier1_categoryCarouselIcon;

	@FindBy(xpath = "(//*[@class='kz-carousel kz-third-party-carousel kz-video-carousel ng-star-inserted'])[2]")
	public static WebElement Lib_videoCarousel_tier1_seriesCarousel;

	@FindBy(xpath = "(//axis360-third-party-widgets-carousel)[1]")
	public static WebElement libPageVideoCategoryCarousel;

	@FindBy(xpath = "//*[@class='third-party-card third-party-card-checkout-videos third-party-card-common']")
	public static List<WebElement> libPageVideoTitleCard;

	@FindBy(xpath = "dummy")
	private List<WebElement> checkoutCTA_videocarousel_titleName;

	@FindBy(xpath = "//h3[text()='Videos']/following::div[@class='ac-container ac-adaptiveCard']")
	private List<WebElement> Lib_videoCarousel_titlecard;
	
	@FindBy(xpath = "(//div[@class='carousel-container']/following::a[@class='link see-all-text'])[3]")
	private WebElement Lib_videoWidgetSeeAll;
	
	@FindBy(id = "loc_btn_See all Checkers Library TV")
	private WebElement Lib_Afterformat_videoWidgetSeeAll;
	
	@FindBy(id = "loc_btn_See all Videobooks")
	private WebElement Lib_vbookWidgetSeeAll;
	
	@FindBy(xpath = "(//div[@class='ac-container ac-selectable'])[1]")
	public static WebElement Tier2_title;
	
	@FindBy(xpath = "(//div[@id='video-poster-bg'])[1]")
	public static WebElement lib_videoTitle;
	
	@FindBy(xpath = "//*[@aria-label='Titles in This Series']")
	public static WebElement titlesinseries_txt;
	
	@FindBy(xpath = "//div[@class='kz-carousel kz-third-party-carousel kz-video-carousel item-carousel-default ng-star-inserted']")
	public static WebElement titlesinseries_carousel;
	
	@FindBy(xpath = "//*[@aria-label='More Like This']")
	public static WebElement MoreLikethis_txt;
	
	@FindBy(xpath = "//div[@class='kz-carousel kz-third-party-carousel item-carousel-default ng-star-inserted']")
	public static WebElement MoreLikeThis_carousel;

	public WebElement getPlayButton() {
		return playButton;
	}

	public WebElement getLib_videoCarousel_seeAllCTA() {
		return Lib_videoCarousel_seeAllCTA;
	}

	public WebElement getLib_vBookCarousel_CardCarouselType() {
		return Lib_vBookCarousel_CardCarouselType;
	}

	public WebElement getLib_videoCarousel_tier1_categoryCarousel() {
		return Lib_videoCarousel_tier1_categoryCarousel;
	}

	public WebElement getLib_videoCarousel_tier1_titleCarousel() {
		return Lib_videoCarousel_tier1_titleCarousel;
	}

	public WebElement getLib_videoCarousel_tier1_Featuredcarousel() {
		return Lib_videoCarousel_tier1_Featuredcarousel;
	}

	public WebElement getLib_videoCarousel_tier1_othercarousel() {
		return Lib_videoCarousel_tier1_othercarousel;
	}

	public WebElement getLib_videoCarousel_ResumeCTA() {
		return Lib_videoCarousel_ResumeCTA;
	}

	public WebElement getLib_videoCarousel_PrimaryCTAasPlay() {
		return Lib_videoCarousel_PrimaryCTAasPlay;
	}

	public WebElement getLib_videoCarousel_PrimaryCTAasCheckout() {
		return Lib_videoCarousel_PrimaryCTAasCheckout;
	}

	public WebElement getLib_videoCarousel_Nav_Tier3Detailspage() {
		return Lib_videoCarousel_Nav_Tier3Detailspage;
	}

	public WebElement getLib_videoCarousel_videotitleCoverimg() {
		return Lib_videoCarousel_videotitleCoverimg;
	}

	@FindBy(xpath = "")
	private WebElement videoPage;

	@FindBy(xpath = "(//carousel[@class='carousel'])[1]")
	private WebElement tier1Carousel;

	@FindBy(xpath = "//*[@class='kz-carousel kz-category-carousel ng-star-inserted']")
	private WebElement categoryTier1;

	@FindBy(xpath = "//*[@class='kz-carousel kz-category-carousel ng-star-inserted']")
	private WebElement categoryCarousel;

	@FindBy(xpath = "(//*[@class='third-party-video-widgets-category'])[1]//*[@class='ac-textBlock']")
	private WebElement categoryName;

	@FindBy(xpath = "(//*[@class='third-party-video-widgets-category'])[1]//*[@class='ac-image']")
	private WebElement categoryIcon;

	@FindBy(xpath = "")
	private WebElement videoCarousel;

	@FindBy(xpath = "//*[@class='third-party-tier-two-container']")
	private WebElement videoTier2page;

	@FindBy(xpath = "(//*[contains(text(),'See All')])[1]")
	private WebElement videoTier1CarouselSeeAll;

	@FindBy(xpath = "(//*[@class='ac-container ac-selectable'])[1]")
	private WebElement videoCardTier2;

	@FindBy(xpath = "(//*[@class='ac-container ac-selectable'])[1]")
	private WebElement videoCardTier1;

	@FindBy(xpath = "(//img[@class='ac-image'])[1]")
	private WebElement titleImageTier3;

	@FindBy(xpath = "(//*[@class='ac-textBlock'])[1]")
	private WebElement titleHeadingTier3;

	@FindBy(xpath = "(//*[@class='ac-image'])[1]")
	public static WebElement videoIconTier3;

	@FindBy(xpath = "")
	private WebElement titleDescriptionTier3;

	@FindBy(xpath = "(//*[@type='button'])[1]")
	private WebElement primaryCTATier3;

	@FindBy(xpath = "(//*[@type='button'])[1]/*[contains(text(),'Checkout')]")
	private WebElement checkoutCTATier3;

	@FindBy(xpath = "(//*[@type='button'])[1]//*[contains(text(),'Renew')]")
	private WebElement secCTATier3;

	@FindBy(xpath = "//*[contains(text(),'Renew')]")
	public static WebElement renewCTA;

	@FindBy(xpath = "//*[contains(text(),'Return')]")
	public static WebElement returnCTA;

	@FindBy(xpath = "(//*[@class='ac-columnSet'])[3]")
	private WebElement titleDetailSection;

	@FindBy(xpath = "//*[@class='kz-carousel kz-third-party-carousel kz-video-carousel ng-star-inserted']")
	private WebElement relatedBooksTier3;

	@FindBy(xpath = "(//*[@class='third-party-card third-party-card-checkout-videos third-party-card-common'])")
	private List<WebElement> tier1_titleCard;

	@FindBy(xpath = "//*[contains(text(),'Vbook Carousel')]/following::*[@class='ac-container ac-adaptiveCard']")
	private List<WebElement> vBookTitleCard;
	
	@FindBy(xpath = "(//*[@id='list_id_VIDEOS']//following::*[@class='ac-container ac-selectable'])")
	public List<WebElement> videoTitleCard;

	@FindBy(xpath = "//*[contains(text(),'Vbook Carousel')]/following::*[@class='ac-container ac-selectable']")
	private List<WebElement> vBookTitleCoverImg;

	@FindBy(xpath = "dummy")
	public static WebElement mylib_videos_titles;

	@FindBy(xpath = "//*[contains(text(),'Resume')]//preceding::*[@class='ac-container ac-selectable']")
	public static WebElement libTitleWithResumeCTA;

	@FindBy(xpath = "//div[@class='kz-carousel']")
	public static List<WebElement> CurrentlyCheckout_CarouselContent;

	@FindBy(xpath = "//div[@class='ac-container ac-adaptiveCard']")
	public static List<WebElement> tier_titlecard_category;

	@FindBy(xpath = "alert-dialog-title")
	public static WebElement mylib_;

	@FindBy(xpath = "//h3[contains(text(),'Videos')]/following::div[@class='ac-container ac-adaptiveCard']")
	private List<WebElement> videoTitlecard_videocarousel;

	@FindBy(xpath = "//h3[contains(text(),'Videos')]/following::div[text()='Checkout']")
	public static List<WebElement> videoCheckout_CTA;

	@FindBy(xpath = "//h3[contains(text(),'Featured - 1')]/following::div[@class='ac-container ac-adaptiveCard']")
	public static List<WebElement> tier1_featured_titlecard;

	@FindBy(xpath = "(//button[@type='button']//div[text()='Checkout'])[1]")
	private WebElement tier1_checkoutCTA;

	@FindBy(xpath = "(//*[@aria-label='Popular Videos']//following::*[@class='carousel-arrow carousel-arrow-next'])[1]")
	private WebElement VideoCarousel_nextButton;

	@FindBy(xpath = "(//*[contains(text(),'Popular Videos ')]//following::*[@class='carousel-arrow carousel-arrow-prev'])[1]")
	private WebElement VideoCarousel_prevButton;

	@FindBy(xpath = "(//*[contains(text(),'Popular Videobooks ')]//following::*[@class='carousel-arrow carousel-arrow-next'])[1]")
	private WebElement vBookCarousel_nextButton;

	@FindBy(xpath = "(//*[contains(text(),'Popular Videobooks ')]//following::*[@class='carousel-arrow carousel-arrow-prev'])[1]")
	private WebElement vBookCarousel_prevButton;
	
	@FindBy(id = "breadcrumb-link-1")
	private WebElement Tier1_Breadcrumb;

	@FindBy(xpath = "(//div[contains(@style,' vertical; -webkit-line-clamp: 2; box-sizing: border-box; flex: 0 0 auto;')])[2]")
	private WebElement categoryName2;
	
	@FindBy(xpath = "//*[@type='button']")
	public WebElement primaryCTA_tier3;

	public WebElement getCategoryName2() {
		return categoryName2;
	}

	public WebElement getTier1_Breadcrumb() {
		return Tier1_Breadcrumb;
	}

	public WebElement getVideoCarousel_nextButton() {
		return VideoCarousel_nextButton;
	}

	public WebElement getRelatedBooksTier3() {
		return relatedBooksTier3;
	}

	public WebElement getTitleDetailSection() {
		return titleDetailSection;
	}

	public WebElement getPrimaryCTATier3() {
		return primaryCTATier3;
	}

	public WebElement getTitleDescriptionTier3() {
		return titleDescriptionTier3;
	}

	public WebElement getTitleImageTier3() {
		return titleImageTier3;
	}

	public WebElement getTitleHeadingTier3() {
		return titleHeadingTier3;
	}

	public WebElement getVideoIconTier3() {
		return videoIconTier3;
	}

	public WebElement getVideoTier1CarouselSeeAll() {
		return videoTier1CarouselSeeAll;
	}

	public WebElement getCategoryName() {
		return categoryName;
	}

	public WebElement getCategoryIcon() {
		return categoryIcon;
	}

	public WebElement getCategoryCarousel() {
		return categoryCarousel;
	}

	public WebElement getCategoryTier1() {
		return categoryTier1;
	}

	public WebElement getTier1Carousel() {
		return tier1Carousel;
	}

	public WebElement getVideoPage() {
		return videoPage;
	}

	public WebElement getTitleDetailPage() {
		return titleDetailPage;
	}

	public WebElement getPrimaryCTA() {
		return primaryCTA;
	}

	public WebElement getLib_videoCarousel_itemCarouselType() {
		return Lib_videoCarousel_itemCarouselType;
	}

	public WebElement getvBookTier1Carousel() {
		return vBookTier1Carousel;
	}

	public WebElement getLib_vBookCarousel_CardCarousel() {
		return Lib_vBookCarousel_CardCarousel;
	}

	public WebElement getLib_videoCarousel_CardCarouselType() {
		return Lib_videoCarousel_CardCarouselType;
	}

	public WebElement getLibraryPage() {
		return LibraryPage;
	}

	public WebElement getvBookTier1Page() {
		return vBookTier1Page;
	}

	/***********************************************************************************************************/

	
	public void verify_SuggestedCarousel() {
		javaScriptScrollToEnd();
		if (titlesinseries_txt.isDisplayed()) {
			Assert.assertTrue(titlesinseries_carousel.isDisplayed());
		}else if (MoreLikethis_txt.isDisplayed()) {
			Assert.assertTrue(MoreLikeThis_carousel.isDisplayed());
		}

	}
	public void videoCarouselArrow() {
		if (isElementPresent(VideoCarousel_nextButton)) {
			Logger.log("Carousel Next Arrow is displayed");
		} else {
			Logger.log("Carousel Next Arrow is not displayed");
		}
	}
	
	public void vBookCarouselArrow() {
		if (isElementPresent(vBookCarousel_nextButton)) {
			Logger.log("Carousel Next Arrow is displayed");
		} else {
			Logger.log("Carousel Next Arrow is not displayed");
		}
	}

	public void clickTitleDetail() {
		WaitForWebElement(vBookTier1Page);
		jsClick(titleCardinTier1);
		WaitForWebElement(titleDetailPage);
	}

	public boolean view_videoCarouselFormat() {
		javascriptScroll(Lib_videoCarouselFormat);
		boolean b = true;
		if (Lib_videoCarouselFormat.isDisplayed()) {
			b = true;
		} else {
			b = false;
		}
		return b;
	}

	public void clickVBookSeeAll() {
		visibilityWait(vBookSeeAll);
		javascriptScroll(vBookSeeAll);
		jsClick(vBookSeeAll);
		waitFor(2000);
		//visibilityWait(vBookTier1Page);
	}

	public void clickVideoSeeAll() {
		visibilityWait(Lib_videoCarousel_seeAllCTA);
		javascriptScroll(Lib_videoCarousel_seeAllCTA);
		jsClick(Lib_videoCarousel_seeAllCTA);
		visibilityWait(vBookTier1Page);
	}

	public void primaryActionValidation() {
		if (isElementPresent(checkoutButton)) {
			jsClick(checkoutButton);
			WaitForWebElement(playButton);
		} else if (isElementPresent(returnButton)) {
			jsClick(returnButton);
			WaitForWebElement(checkoutButton);
			Logger.log("User able to see the Checkout Button as Primary CTA if the title is not checked out");
			jsClick(checkoutButton);
			WaitForWebElement(playButton);
			Logger.log("User able to see the Play Button as Primary CTA Once the title is checked out");
		}
	}

	public void playAsprimaryCTA_AfterCheckedout() {
		if (isElementPresent(checkoutButton)) {
			javascriptScroll(checkoutButton);
			jsClick(checkoutButton);
			WaitForWebElement(playButton);
		} else {
			javascriptScroll(playButton);
			playButton.isDisplayed();
			System.out.println("play cta is displayed");
		}

	}

	public boolean view_PlaySecondaryCTA() {
		boolean b = true;
		visibilityWait(returnButton);
		javascriptScroll(returnButton);
		Assert.assertTrue(returnButton.isDisplayed());
		Assert.assertTrue(renewButton.isDisplayed());
		return b;
	}

	public void clickPlayButton() {
		waitFor(2000);
		ClickOnWebElement(playButton);
		waitFor(2000);
	}

	public void switchTabAndInspect() {
		ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
		waitFor(2000);
		DriverManager.getDriver().switchTo().window(tabs.get(1));
		waitFor(2000);
		// Assert.assertTrue(videoPage.isDisplayed());
		DriverManager.getDriver().close();
		DriverManager.getDriver().switchTo().window(tabs.get(0));
		waitFor(2000);
	}

	public boolean view_coverimgAndprimaryCTA() {
		boolean b = true;
		Assert.assertTrue(Lib_videoCarousel_videotitleCoverimg.isDisplayed());
		jsClick(Lib_videoCarousel_videotitleCoverimg);
		//Assert.assertTrue(Lib_videoCarousel_PrimaryCTAasCheckout.isDisplayed());
		return b;
	}

	public void click_videoTitleCard() {
		//visibilityWait(coverimg_videocarousel.get(1));
		javascriptScroll(coverimg_videocarousel.get(1));
		jsClick(coverimg_videocarousel.get(1));
//		for (int i = 0; i < checkoutCTA_videocarousel.size(); i++) {
//			if (Lib_videoCarousel_PrimaryCTACheckout.get(i).getText().equalsIgnoreCase("Checkout")) {
//				jsClick(coverimg_videocarousel.get(i));
//				break;
//			}
//		}
		WaitForWebElement(titleDetailPage);
	}

	public void click_videoTitleCardLibrary() {
		visibilityWait(coverimg_videocarousel.get(1));
		javascriptScroll(coverimg_videocarousel.get(1));
		jsClick(coverimg_videocarousel.get(1));
	}

	public void click_tier1Titlecard() {
		javascriptScroll(tier1_featured_titlecard.get(1));
		for (int i = 0; i < tier1_featured_titlecard.size(); i++) {
			if (tier1_checkoutCTA.getText().equalsIgnoreCase("Checkout")) {
				jsClick(tier1_featured_titlecard.get(i));
				break;
			}

		}

	}

	public void click_videoTitleCardPlayCTA() {
		WaitForWebElement(Lib_videoCarousel_videotitleCoverimg);
		for (int i = 0; i < checkoutCTA_videocarousel.size(); i++) {
			if (Lib_videoCarousel_PrimaryCTAasCheckout.getText().equalsIgnoreCase("Play")) {
				jsClick(coverimg_videocarousel.get(i));
				WaitForWebElement(Lib_videoCarousel_Nav_Tier3Detailspage);
			}
		}
	}

	public void click_vBookTitleCardPlayCTA() {
		WaitForWebElement(vBookTitleCard.get(0));
		for (int i = 0; i < vBookTitleCard.size(); i++) {
			if (vBookTitleCard.get(i).getText().equalsIgnoreCase("Play")) {
				jsClick(vBookTitleCoverImg.get(i));
				WaitForWebElement(Lib_videoCarousel_Nav_Tier3Detailspage);
			}
		}
	}

	public void click_CheckoutAsprimaryCTA() {
		if (isElementPresent(Lib_videoCarousel_PrimaryCTAasCheckout)) {
			visibilityWait(Lib_videoCarousel_PrimaryCTAasCheckout);
			javascriptScroll(Lib_videoCarousel_PrimaryCTAasCheckout);
			jsClick(Lib_videoCarousel_PrimaryCTAasCheckout);
			waitFor(2000);
			visibilityWait(getLib_videoCarousel_PrimaryCTAasPlay());
			// DriverManager.getDriver().navigate().refresh();
			// WaitForWebElement(getLib_videoCarousel_PrimaryCTAasPlay());
		} else {
			System.out.println("checkout is not primary cta");
		}

	}

	public void click_PlayCTA() {
		jsClick(Lib_videoCarousel_PrimaryCTAasPlay);
		waitFor(2000);
		ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
		DriverManager.getDriver().switchTo().window(tabs.get(1));
		waitFor(6000);
		// Assert.assertTrue(DriverManager.getDriver().getTitle().equalsIgnoreCase("axisnow"));
		jsClick(Lib_videoCarousel_Resume);
		waitFor(2000);
		DriverManager.getDriver().close();
		DriverManager.getDriver().switchTo().window(tabs.get(0));
		waitFor(2000);
//		WaitForWebElement(Lib_videoCarousel_ResumeCTA);
	}

	public void click_ResumeCTA() {
		visibilityWait(Lib_videoCarousel_Resume);
		waitFor(2000);
		ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
		DriverManager.getDriver().switchTo().window(tabs.get(1));
//		jsClick(Lib_videoCarousel_Resume);
		Assert.assertTrue(DriverManager.getDriver().getTitle().equalsIgnoreCase("axisnow"));
		waitFor(2000);
		DriverManager.getDriver().close();
		DriverManager.getDriver().switchTo().window(tabs.get(0));
		waitFor(2000);
//		WaitForWebElement(Lib_videoCarousel_ResumeCTA);
	}

	public void Click_level1page() {
		javascriptScroll(Lib_videoCarouselFormat);
		jsClick(Lib_videoCarousel_seeAllCTA);
		visibilityWait(vBookTier1Page);
	}
	
	public void click_videoWidgetSeeAll() {
		javascriptScroll(Lib_Afterformat_videoWidgetSeeAll);
		jsClick(Lib_Afterformat_videoWidgetSeeAll);
		visibilityWait(vBookTier1Page);

	}
	
	public void click_afterFormatSelected_videoWidgetSeeAll() {
	javascriptScroll(Lib_Afterformat_videoWidgetSeeAll);
	jsClick(Lib_Afterformat_videoWidgetSeeAll);
	visibilityWait(vBookTier1Page);

	}
	
	public void click_vbookWidgetSeeAll() {
		javascriptScroll(Lib_vbookWidgetSeeAll);
		jsClick(Lib_vbookWidgetSeeAll);
		visibilityWait(vBookTier1Page);

	}

	public void click_SeeAllTier1Video() {
		visibilityWait(videoTier1CarouselSeeAll);
		javascriptScroll(videoTier1CarouselSeeAll);
		jsClick(videoTier1CarouselSeeAll);
		visibilityWait(videoTier2page);
		// WaitForWebElement(videoTier2page);
	}

	public void click_TitleCard1Video() {
		javascriptScroll(videoCardTier2);
		jsClick(videoCardTier2);
		WaitForWebElement(titleDetailPage);
	}

	public void click_TitleCardTier2VBook() {
		javascriptScroll(videoCardTier2);
		jsClick(videoCardTier2);
		WaitForWebElement(titleDetailPage);
	}

	public void click_TitleCardTier1Video() {
		visibilityWait(videoCardTier1);
		javascriptScroll(videoCardTier1);
		jsClick(videoCardTier1);
		// jsClick(videoCardTier1);
		waitFor(3000);
		visibilityWait(titleDetailPage);
		// WaitForWebElement(titleDetailPage);
	}

	public void ClickonPlay_TitleCard() {
		visibilityWait(tier_titlecard_category.get(0));
		javascriptScroll(tier_titlecard_category.get(0));
		jsClick(tier_titlecard_category.get(0));
		waitFor(3000);
		visibilityWait(titleDetailPage);
		if (checkoutCTATier3.isDisplayed()) {
			jsClick(checkoutCTATier3);
			waitFor(2000);
			visibilityWait(playButton);
		} else {
			playButton.isDisplayed();
			System.out.println("user is able to view play cta");
		}

//		for (int i = 0; i < tier_titlecard_category.size(); i++) {
//			if (playButton.isDisplayed()) {
//				jsClick(tier1_titleCard.get(i));
//				break;
//			}else if (checkoutCTATier3.isDisplayed()) {
//				jsClick(checkoutCTATier3);
//				waitFor(2000);
//				playButton.isDisplayed();
//			}
//							
//		}
	}

	public void clickResume_Titlecard() {
		for (int i = 0; i < Lib_videoCarousel_titlecard.size(); i++) {
			if (ResumeCta.isDisplayed()) {
				jsClick(Lib_videoCarousel_titlecard.get(i));
				visibilityWait(titleDetailPage);
				break;
			}
		}

	}

	public void checkoutTitleTier3() {
		if (isElementPresent(checkoutCTATier3)) {
			ClickOnWebElement(checkoutCTATier3);
		} else {
			ClickOnWebElement(returnCTA);
			WaitForWebElement(checkoutCTATier3);
			ClickOnWebElement(checkoutCTATier3);
		}
	}

	public void click_checkoutCTALibpage() {
		javascriptScroll(checkoutCTA_videocarousel.get(1));
		for (int i = 0; i < checkoutCTA_videocarousel.size(); i++) {
			jsClick(checkoutCTA_videocarousel.get(i));
			break;
		}

//		visibilityWait(checkoutCTA_videocarousel.get(1));
//		javascriptScroll(checkoutCTA_videocarousel.get(1));
//		for (int i = 0; i < checkoutCTA_videocarousel.size(); i++) {
//			if (Lib_videoCarousel_PrimaryCTAasCheckout.getText().equalsIgnoreCase("Checkout")) {
//				//String checkout_titleName = checkoutCTA_videocarousel_titleName.get(i).getText();
//				jsClick(checkoutCTA_videocarousel.get(i));
//				waitFor(2000);
//				try {
//					if (vbook.Checkout_popup.isDisplayed()) {
//						visibilityWait(vbook.Checkout_popup);
//						jsClick(vbook.Checkout_popup);
//						waitFor(2000);
//						javascriptScroll(videoTitlecard_videocarousel.get(1));
//						jsClick(videoCheckout_CTA.get(2));
//					} else {
//						System.out.println("Checkout popup is not displayed");
//					}
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}	
//		}

	}

	public void click_ResumeCTALibpage() {
		WaitForWebElement(Lib_videoCarousel_videotitleCoverimg);
		jsClick(libTitleWithResumeCTA);
		WaitForWebElement(Lib_videoCarousel_Nav_Tier3Detailspage);
	}

	public void click_VideoCarouselLeftRightButton() {
		if (isElementPresent(VideoCarousel_nextButton)) {
			WaitForWebElement(VideoCarousel_nextButton);
			jsClick(VideoCarousel_nextButton);
			WaitForWebElement(VideoCarousel_prevButton);
			jsClick(VideoCarousel_prevButton);
		} else {
			Logger.log("Carousel Arrow is not displayed");
		}
	}
	
	public void click_vBookCarouselLeftRightButton() {
		if (isElementPresent(vBookCarousel_nextButton)) {
			WaitForWebElement(vBookCarousel_nextButton);
			jsClick(vBookCarousel_nextButton);
			WaitForWebElement(vBookCarousel_prevButton);
			jsClick(vBookCarousel_prevButton);
		} else {
			Logger.log("Carousel Arrow is not displayed");
		}
	}
	
	public void verify_ActionCTAs() {
		jsClick(Tier2_title);
		visibilityWait(titleDetailPage);
		if (Lib_videoCarousel_PrimaryCTAasCheckout.isDisplayed()) {
			jsClick(Lib_videoCarousel_PrimaryCTAasCheckout);
			waitFor(2000);
			Assert.assertTrue(playButton.isDisplayed());
		} else if (playButton.isDisplayed()) {
			Assert.assertTrue(playButton.isDisplayed());
		}else {
			ResumeCta.isDisplayed();
		} 

	}
}
