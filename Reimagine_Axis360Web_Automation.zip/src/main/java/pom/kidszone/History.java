package pom.kidszone;

import org.junit.Assert;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;

public class History extends CommonAction {

	static ExcelReader reader = new ExcelReader();
	Holds hold = new Holds(DriverManager.getDriver());
	Wishlist wish = new Wishlist(DriverManager.getDriver());

	public History(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "loc_labelCheckout History")
	private WebElement historyButton;

	@FindBy(id = "loc_txtCheckout History")
	private WebElement historyPage;
	
	@FindBy(xpath = "(//*[text()[normalize-space()='HISTORY']])[1]")
	private WebElement historyHamOldUi;
	
	@FindBy(xpath = "(//*[@data-val='wishlist'])[1]")
	private WebElement wishOldUi;
	
	@FindBy(xpath = "(//*[@class='mylib-heading'])[2]")
	private WebElement wishListPageOldUi;
	
	@FindBy(xpath = "(//*[@data-val='history'])[1]")
	private WebElement historyOldUi;
	
	@FindBy(xpath = "(//*[@class='mylib-heading'])[2]")
	private WebElement historyHamPageOldUi;
	
	@FindBy(xpath = "//*[@class='no-stuffs ng-star-inserted']")
	private WebElement noStuffText;
	
	@FindBy(xpath = "(//*[@class='mystuff-grids ng-star-inserted'])[1]")
	private WebElement historyTitles;
	
	@FindBy(xpath = "//*[@class='mat-menu-content ng-tns-c96-1']")
	private WebElement sortOptions;
	
	@FindBy(id = "loc_Recently Checkedout")
	private WebElement LatestCheckout;
	
	@FindBy(id = "loc_Ratings")
	private WebElement rating;
	
	@FindBy(id = "loc_A-Z")
	private WebElement aToZ;
	
	@FindBy(xpath = "(//*[@class='mat-ripple mat-menu-ripple'])[1]")
	private WebElement secCta1;

	public WebElement getSecCta1() {
		return secCta1;
	}

	public WebElement getHistoryPage() {
		return historyPage;
	}

	public WebElement getHistoryTitles() {
		return historyTitles;
	}

	public WebElement getNoStuffText() {
		return noStuffText;
	}

	public void clickHistory() {
		javascriptScroll(historyButton);
		jsClick(historyButton);
		WaitForWebElement(historyPage);
	}
	
	public void noHistoryCount() {
		Assert.assertTrue(historyButton.getText().contains("0"));
	}
	
	public void navigateBackCta() {
		DriverManager.getDriver().navigate().back();
		WaitForWebElement(hold.getHoldPage());
		waitFor(2000);
	}
	
	public void sortOptions() {
		WaitForWebElement(LatestCheckout);
		javascriptScroll(LatestCheckout);
		Assert.assertTrue(LatestCheckout.isDisplayed());
		Assert.assertTrue(rating.isDisplayed());
		Assert.assertTrue(aToZ.isDisplayed());
		jsClick(hold.sortButton);
	}
	
	public void secCtaActions() {
		javascriptScroll(hold.getMoreOptions());
		ClickOnWebElement(hold.getMoreOptions());
		WaitForWebElement(secCta1);
	}
	
	public void clickHistoryHamOldUi() {
		WaitForWebElement(historyHamOldUi);
		javascriptScroll(historyHamOldUi);
		ClickOnWebElement(historyHamOldUi);
		WaitForWebElement(historyHamPageOldUi);
	}
	
	public void quickCtaOldUi() {
		ClickOnWebElement(wishOldUi);
		WaitForWebElement(wishListPageOldUi);
		ClickOnWebElement(historyOldUi);
		WaitForWebElement(historyHamPageOldUi);
	}

	public void navigateBackCtaOldUi() {
		DriverManager.getDriver().navigate().back();
		WaitForWebElement(hold.getAdultLibraryPage());
	}
}
