package pom.kidszone;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Tier1_Videobooks extends CommonAction {
	MyLibrary_Videobooks video = new MyLibrary_Videobooks(DriverManager.getDriver());
	static ExcelReader reader = new ExcelReader();

	public Tier1_Videobooks(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='featured-magazine kz-video-featured-magazine ng-star-inserted']")
	public static WebElement Featuredbanner_tier1;

	@FindBy(xpath = "(//h2[contains(text(),'Videos')]/following::div[@class='kz-carousel kz-category-carousel'])[1]")
	public static WebElement mylibrary_categoryies_video;

	@FindBy(xpath = "(//div[@class='carousel-container'])[2]")
	public static WebElement Tier1_category_carousel;

	@FindBy(xpath = "(//a[contains(text(),'See All ')])[1]")
	public static WebElement Tier1_categorycarousel_SeeAllCTA;

	@FindBy(xpath = "(//h3[contains(text(),'Video Carousel')]/following::div[@class='carousel-arrow carousel-arrow-next'])[1]")
	public static WebElement mylibrary_categoryies_RightArrow;

	@FindBy(xpath = "(//*[@class='carousel-arrow carousel-arrow-next'])[1]")
	public static WebElement mylibrary_categoryies_RightArrowTier1;

	@FindBy(xpath = "//*[@class='third-party-tier-two-container']")
	public static WebElement videoTier2page;

	@FindBy(xpath = "(//div[@class='ac-input-container'])[1]")
	private WebElement tier2_publishinput;

	@FindBy(id = "Refiner_title_Language")
	private WebElement tier2_Language;

	@FindBy(xpath = "//*[contains(text(),'Relevance')]")
	private WebElement tier2_Relevence;

	@FindBy(xpath = "//label[contains(text(),'Popularity')]")
	private WebElement tier2_popularity;

	@FindBy(xpath = "//div[contains(text(),'Search')]")
	private WebElement tier2_searchCTA;

	@FindBy(xpath = "(//img[@class='ac-image'])[1]")
	public static WebElement tier1_vbooks_TitleIcon;

	@FindBy(xpath = "//*[contains(text(),' sort By ')]")
	public static WebElement tier2_sort;

	@FindBy(xpath = "//div[@class='kz-drawer-refiners-container thirdparty-tiertwoleftwrap ng-star-inserted']")
	public static WebElement tier2_RefinerSection;

	@FindBy(xpath = "//label[contains(text(),'Publication date')]")
	public static WebElement tier2_RefinerSection_publicationDate;

	@FindBy(xpath = "//label[contains(text(),'Popularity')]")
	public static WebElement tier2_RefinerSection_popularity;

	@FindBy(xpath = "//label[contains(text(),'Relevance')]")
	public static WebElement tier2_RefinerSection_Relevance;

	@FindBy(xpath = "(//div[@alt='undefined'])[3]")
	private WebElement tier2_vbooks_image;

	@FindBy(xpath = "(//img[@class='ac-image'])[8]")
	private WebElement tier2_vbooks_TitleIcon;

	@FindBy(xpath = "(//div[@class='ac-container ac-adaptiveCard']/following::img)[1]")
	public static WebElement tier2_videos_categoryIcon;

	@FindBy(xpath = "(//*[@class='carousel-container'])[3]")
	public static WebElement tier1_videos_carousel;

	@FindBy(xpath = "(//*[@class='carousel-categories'])")
	public static WebElement tier1_videos_Categorycarousel;

	@FindBy(xpath = "(//*[contains(text(),'Categories')]//following-sibling::*//*[@class='ac-container ac-selectable'])[1]")
	public static WebElement videoCategoryIconTier1;

	@FindBy(xpath = "(//div[@id='adp-category-text'])[1]")
	public static WebElement videoCategoryNameTier1;
	
	@FindBy(xpath = "(//*[contains(text(),'Categories')]//following-sibling::*//*[@class='ac-container ac-selectable'])[1]")
	public static WebElement vBooksCategoryIconTier1;

	@FindBy(xpath = "(//*[@class='third-party-video-category']//following-sibling::*[@class='ac-textBlock'])[1]")
	public static WebElement vBooksCategoryNameTier1;
	
	@FindBy(id = "Refiner_title_Age Level")
	public static WebElement tier2_Agelevel;

	public static WebElement getTier2_RefinerSection() {
		return tier2_RefinerSection;
	}

	public WebElement getTier2_vbooks_image() {
		return tier2_vbooks_image;
	}

	public WebElement getTier2_vbooks_TitleIcon() {
		return tier2_vbooks_TitleIcon;
	}

	public void verify_featuredBannerBackgroundColor() {
		String color = "rgba(0, 120, 71, 1)";
		String bckgclr = Featuredbanner_tier1.getCssValue("background-color");
		System.out.println(bckgclr);
		if (color.equalsIgnoreCase(bckgclr)) {
			System.out.println("user is able to view the feature hero banner background color");
		}
	}

	public void scrollUp() {

	}

	public void view_LeftAndRightArrowinVideoCarousel() {
		visibilityWait(mylibrary_categoryies_RightArrow);
		scrollingup(mylibrary_categoryies_RightArrow);
		waitFor(2000);
		// javascriptScroll(mylibrary_categoryies_RightArrow);
		jsClick(mylibrary_categoryies_RightArrow);
		waitFor(2000);
	}

	public void view_LeftAndRightArrowinVideoTier1Carousel() {
		visibilityWait(mylibrary_categoryies_RightArrowTier1);
		waitFor(2000);
		// javascriptScroll(mylibrary_categoryies_RightArrow);
		jsClick(mylibrary_categoryies_RightArrowTier1);
		waitFor(2000);
	}

	public void click_categoryCarousel_SeeAllCTA() {
		if (isElementPresent(Tier1_categorycarousel_SeeAllCTA)) {
			jsClick(Tier1_categorycarousel_SeeAllCTA);
			visibilityWait(videoTier2page);
		} else {
			Logger.log("User having only less number of titles");
		}

	}

	public void view_tier2RefinerSection() {
		visibilityWait(tier2_Agelevel);
		Assert.assertTrue(tier2_Agelevel.isDisplayed());
		Assert.assertTrue(tier2_Language.isDisplayed());
		// tier2_Audience.isDisplayed();

	}

	public void selectAnyRefineroption_Search() {
		visibilityWait(tier2_Relevence);
		jsClick(tier2_Relevence);
		javascriptScroll(tier2_searchCTA);
		jsClick(tier2_searchCTA);
	}

	public boolean verify_tier2_RefinerSuboptions() {
		visibilityWait(tier2_RefinerSection_publicationDate);
		boolean b = true;
		tier2_RefinerSection_publicationDate.isDisplayed();
		tier2_RefinerSection_popularity.isDisplayed();
		tier2_RefinerSection_Relevance.isDisplayed();
		return b;
	}


}
