package pom.kidszone;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;

public class PatronDashboardPage extends CommonAction {

	static ExcelReader reader = new ExcelReader();

	public PatronDashboardPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "loginBtn")
	private WebElement btn_Login;
	
	@FindBy(id = "LogOnModel_UserName")
	private WebElement txt_LogOnModel_UserName;
	
	@FindBy(id="LogOnModel_Password")
	private WebElement txt_LogOnModel_Password;
	
	@FindBy(xpath="//button[text()='login']")
	private WebElement btn_LoginSubmmit;

	
	public void patronLogin() throws InvalidFormatException, IOException
	{
		List<Map<String, String>> testData = reader.getData("./src/test/resources/Data/WebData.xlsx", "Login");
		WaitForWebElement(btn_Login);
		ClickOnWebElement(btn_Login);
		WaitForWebElement(txt_LogOnModel_UserName);
		ClickOnWebElement(txt_LogOnModel_UserName);
		SendKeysOnWebElement(txt_LogOnModel_UserName, testData.get(0).get("PatronLibraryid"));
		SendKeysOnWebElement(txt_LogOnModel_Password, testData.get(0).get("PatronPin"));
		ClickOnWebElement(btn_LoginSubmmit);
		
	}
}
