package pom.kidszone;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import api.searchTitlev8.SearchTitleResponse;
import api.searchTitlev8.Title;
import api.enums.*;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import api.enums.GenericEnum;
import api.enums.GenericEnum.Categories;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.Logger;

import api.APIClient;

public class LibrarySprint6B extends CommonAction {

	MyLibrary_Guest guest = new MyLibrary_Guest(DriverManager.getDriver());

	TitleAcrossProfile across = new TitleAcrossProfile(DriverManager.getDriver());
	Login login = new Login(DriverManager.getDriver());
	BrowseBySearch search = new BrowseBySearch(DriverManager.getDriver());
	private List<SearchTitleResponse> apiResponses;

	public LibrarySprint6B(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "searchText")
	private WebElement searchBar;

	@FindBy(xpath = "//*[@class='ui-radiobutton ui-widget']/following-sibling::*[contains(text(),'Keyword')]")
	private WebElement keyword;

	@FindBy(xpath = "//*[contains(text(),'Requests For Library Purchase')]")
	public static WebElement purchaseReq;

	@FindBy(xpath = "//button[text()= 'Search']")
	private WebElement searchButton;

	@FindBy(xpath = "//*[@class='spinner-loader advance-search-loader']")
	public static WebElement advanceSearchLoader;

	@FindBy(xpath = "//*[contains(text(),' Format ')]//following::*[@aria-labelledby='menubutton']//preceding-sibling::*//*")
	private List<WebElement> categorySection;

	@FindBy(xpath = "//*[@class='kz-carousel kz-third-party-carousel ng-star-inserted']")
	private WebElement newsMagCarousel;

	@FindBy(xpath = "//*[@class='kz-carousel kz-third-party-carousel ng-star-inserted']//following-sibling::*[contains(text(),'See All')]")
	private WebElement newsMagCarouselSeeAll;

	@FindBy(xpath = "//*[@class='carousel-title-group btn-group ng-star-inserted']//*[1][contains(text(),'eBOOKS')]")
	private WebElement ebooksCarousel;

	@FindBy(xpath = "//*[@class='carousel-title-group btn-group ng-star-inserted']//*[2][contains(text(),'See All')]")
	private WebElement ebooksCarouselSeeAll;

	@FindBy(xpath = "//*[@class='carousel-title-group btn-group']//*[1][contains(text(),' Web Resources ')]/following::a[1]")
	private WebElement webResCarousel;

	@FindBy(xpath = "//*[@class='carousel-title-group btn-group']//*[2][contains(text(),'See All')]")
	private WebElement webResCarouselSeeAll;

	@FindBy(xpath = "//*[@class='search-result-info']")
	private WebElement searchResultCategory;

	@FindBy(xpath = "//*[@class='thirdparty-titlewrap']")
	private WebElement searchResultCategoryThirdParty;

	@FindBy(xpath = "//*[@class='carousel-title heading-2']")
	private WebElement searchResultHeader;

	@FindBy(xpath = "//*[@class='thirdparty-title']/span")
	public WebElement searchResultHeaderThirdParty;

	@FindBy(xpath = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'availability')]/ancestor::mat-expansion-panel-header")
	public WebElement refinerOptionAvailability;

	@FindBy(xpath = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'sort by')]/ancestor::mat-expansion-panel-header")
	public WebElement refinerSortBy;

	@FindBy(id = "loc_refiners_Available Now")
	public WebElement availableNowAvailabilityRefinerOption;

	@FindBy(xpath = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'age level')]/ancestor::mat-expansion-panel-header")
	public WebElement refinerAgeLevel;

	@FindBy(xpath = "//*[contains(@id,'Refiner_title_Age Level')]/ancestor::div[contains(@id,'refine')]")
	public WebElement thirdPartyRefinerAgeLevel;

	@FindBy(xpath = "//*[contains(@id,'Refiner_title_Language')]/ancestor::div[contains(@id,'refine')]")
	public WebElement thirdPartyRefinerLanguage;

	@FindBy(id = "loc_refiners_Children's - Toddlers, Age 2-4")
	public WebElement ChildrenToddlerAge2To4AgeLevelRefinerOption;

	@FindBy(xpath = "//label[contains(text(), \"Children's - Toddlers, Age 2-4\")]/parent::div")
	public WebElement thirdPartyChildrenToddlerAge2To4AgeLevelRefinerOption;

	@FindBy(xpath = "//label[contains(text(), \"Children's - Kindergarten, Age 5-6\")]/parent::div")
	public WebElement thirdPartyChildrenToddlerAge5To6AgeLevelRefinerOption;

	@FindBy(xpath = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'language')]/ancestor::mat-expansion-panel-header")
	public WebElement refinerLanguage;

	@FindBy(id = "loc_refiners_English")
	public WebElement englishLanguageOption;

	@FindBy(xpath = "//label[contains(text(), 'English')]/parent::div")
	public WebElement thirdPartyEnglishLanguageOption;

	@FindBy(xpath = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'attributes')]/ancestor::mat-expansion-panel-header")
	public WebElement refinerAttributes;

	@FindBy(id = "loc_refiners_eRead-Along")
	public WebElement eReadAlongAttributeOption;

	@FindBy(id = "loc_refiners_Return date")
	public WebElement sortByReturnDate;

	@FindBy(xpath = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'popularity')]/ancestor::p-radiobutton/div")
	public WebElement sortByPopularity;

	@FindBy(xpath = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'publication date')]/following-sibling::div")
	public WebElement sortByPubDate;

	@FindBy(id = "loc_refiners_Added Date")
	public WebElement sortByAddedDate;

	@FindBy(id = "loc_refiners_Title")
	public WebElement sortByTitle;

	@FindBy(id = "loc_refiners_Author")
	public WebElement sortByAuthor;

	@FindBy(id = "loc_refiners_Relevancy")
	public WebElement sortByRelevancy;

	@FindBy(xpath = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'relevance')]/ancestor::p-radiobutton)")
	public WebElement sortByRelevance;

	@FindBy(xpath = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'titles a-z')]/ancestor::p-radiobutton")
	public WebElement sortByTitlesAZ;

	@FindBy(xpath = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'titles z-a')]/ancestor::p-radiobutton")
	public WebElement sortByTitlesZA;

//	@FindBy(xpath = "//*[@class='results-text ng-star-inserted']")
//	public WebElement resultResultAfterApplyingFilters;
	
	@FindBy(id = "carouselTitle")
	public WebElement resultsAfterApplyingFilters;
	
	@FindBy(xpath = "//div[text()='Search']")
	public WebElement refinerSearchBtn;

	public WebElement getSearchResultCategoryThirdParty() {
		return searchResultCategoryThirdParty;
	}

	public WebElement getSearchResultCategory() {
		return searchResultCategory;
	}

	public WebElement getSearchResultHeader() {
		return searchResultHeader;
	}

	public WebElement getWebResCarousel() {
		return webResCarousel;
	}

	public WebElement getWebResCarouselSeeAll() {
		return webResCarouselSeeAll;
	}

	public List<WebElement> getCategorySection() {
		return categorySection;
	}

	public WebElement getNewsMagCarousel() {
		return newsMagCarousel;
	}

	public WebElement getNewsMagCarouselSeeAll() {
		return newsMagCarouselSeeAll;
	}

	public WebElement getEbooksCarousel() {
		return ebooksCarousel;
	}

	public WebElement getEbooksCarouselSeeAll() {
		return ebooksCarouselSeeAll;
	}

	public void searchWithKeyword(String keyWord) {
		if (isElementPresent(advanceSearchLoader)) {
			inVisibilityWait(advanceSearchLoader);
			javascriptScroll(searchBar);
			SendKeysOnWebElement(searchBar, keyWord);
			waitFor(2000);

			jsClick(searchButton);
			WaitForWebElement(across.getSearchResult());
		} else {
			visibilityWait(searchBar);
			javascriptScroll(searchBar);
			SendKeysOnWebElement(searchBar, keyWord);
			javascriptScroll(searchButton);
			jsClick(searchButton);
			visibilityWait(across.getSearchResult());
		}
	}
	
	public void advanceSearchKeyword(String keyword) {
		
		javascriptScroll(searchBar);
		SendKeysOnWebElement(searchBar, keyword);
		jsClick(searchButton);
		WaitForWebElement(across.getSearchResult());
	}
	

	public void Enter_SearchKeyword(String keyWord) {
		visibilityWait(searchBar);
		javascriptScroll(searchBar);
		SendKeysOnWebElement(searchBar, keyWord);
		javascriptScroll(searchButton);
		jsClick(searchButton);
		visibilityWait(across.getSearchResult());

	}

	public void searchCategory(String category) {
		javascriptScroll(categorySection.get(1));
		for (int i = 0; i < categorySection.size(); i++) {
			javascriptScroll(categorySection.get(i));
			if (categorySection.get(i).getText().contains(category)) {
				Logger.log("User validates the refiner section with option " + category);
				waitFor(2000);
				break;
//			} else {
//				continue;
//			}
			}
		}
	}

	public void clickCategory(String category) {
		waitFor(2000);
		for (int i = 0; i < categorySection.size(); i++) {
			javascriptScroll(categorySection.get(i));
			if (categorySection.get(i).getText().equalsIgnoreCase(category)) {
				jsClick(categorySection.get(i));
				if (category.equalsIgnoreCase("eBooks") || category.equalsIgnoreCase("eAudios")) {
					WaitForWebElement(searchResultCategory);
					waitFor(2000);
					Assert.assertTrue(searchResultHeader.getText().contains(category));
					Logger.log("User able to see the results based on the selection");
					waitFor(2000);
					break;
				} else if (category.equalsIgnoreCase("videoBooks")
						|| category.equalsIgnoreCase("Checkers Library TV")) {
					WaitForWebElement(searchResultHeaderThirdParty);
					Logger.log("searchResultHeaderThirdParty " + searchResultHeaderThirdParty.getText());
					Assert.assertTrue(searchResultHeaderThirdParty.getText().contains(category));
					Logger.log("User able to see the results based on the selection");
					break;
				}
			}
//			} else {
//				continue;
//			}
		}
	}
	

	public void clickSeeAll(WebElement element) {
		javascriptScroll(element);
		jsClick(element);
		WaitForWebElement(searchResultCategory);
	}

	public void clickSeeAllNewsMag(WebElement element) {
		javascriptScroll(element);
		jsClick(element);
		WaitForWebElement(searchResultCategoryThirdParty);
	}

	@FindBy(xpath = "//label[text()='Newspapers & Magazines - 3rd party']")
	private WebElement advanceSearchpopup_newspaper_radiobtn;

	@FindBy(id = "searchText")
	private WebElement input_search;

	@FindBy(xpath = "//button[text()='Search']")
	private WebElement btn_search;

	@FindBy(xpath = "(//div[@class='third-party-card third-party-card-common'])[1]")
	private WebElement btn_searchContent;

	@FindBy(xpath = "(//div[@class='web-resources-container'])[1]")
	private WebElement btn_studysitecontent;

	@FindBy(id = "breadcrumb-link-1")
	private WebElement search_word;

	@FindBy(xpath = "(//div[text()='Read Now'])[1]")
	private WebElement readnow_cta;

	@FindBy(xpath = "//h2[text()='Log Into Your Library']")
	private WebElement login_popup;

	@FindBy(xpath = "//label[text()='Web Resources']")
	private WebElement radiobtn_webREsource;

	@FindBy(xpath = "//button[@class='advsearch-button']")
	private WebElement old_advansearchtxt;

	@FindBy(xpath = "//label[contains(text(),'Newspapers')]")
	private WebElement old_newspaperRadiobtn;

	@FindBy(id = "searchText")
	private WebElement old_inputSearch;

	@FindBy(xpath = "(//button[@type='submit'])[2]")
	private WebElement btn_oldsearch;

	@FindBy(xpath = "(//axis360-press-reader-card[@class='card-item ng-star-inserted'])[1]")
	private WebElement btn_oldsearchContent;

	@FindBy(xpath = "//p[@class='sub-title ng-star-inserted']")
	private WebElement search_oldword;

	@FindBy(xpath = "(//a[text()='Read Now'])[1]")
	private WebElement oldreadnow_cta;

	@FindBy(xpath = "//label[@for='Study-Sites']")
	private WebElement btn_Oldstudysites;

	@FindBy(xpath = "(//axis360-title-info-card[@class='search-card-item ng-star-inserted'])[1]")
	private WebElement btn_studysitessearchContent;

	@FindBy(id = "dialogHeading")
	private WebElement login_oldpopup;

	@FindBy(xpath = "//h2[normalize-space()='Always Available']")
	private WebElement lib_Alwaysavailable;

	@FindBy(id = "advancedSearchForm")
	private WebElement advanceSearch_popup;

	@FindBy(xpath = " //h2[contains(text(),'Category ')]")
	private WebElement view_category;

	@FindBy(xpath = "//a[@class='menuitem ng-star-inserted']")
	private List<WebElement> category_options;

	@FindBy(id = "loc_txtAvailability")
	private WebElement navigate_libscreen;

	@FindBy(id = "btnSearch")
	public static WebElement navigate_oldlibscreen;

	@FindBy(id = "advancedSearchForm")
	public static WebElement oldadvanceSearch_popup;

	@FindBy(id = "loc_Always Available")
	public static WebElement Oldalwaysavailable_radiobtn;

	@FindBy(xpath = "//div[@class='search-view-container']")
	public static WebElement Alwaysavailable_content;

	@FindBy(id = "refinerBtn")
	public static WebElement Refiner_old;

	@FindBy(xpath = "//div[@class='container kz-advanced-search']")
	public static WebElement AdvanceSearch_popupOverlay;

	public WebElement getNavigate_libscreen() {
		return navigate_libscreen;
	}

	public WebElement getAdvanceSearch_popup() {
		return advanceSearch_popup;
	}

	public WebElement getLib_Alwaysavailable() {
		return lib_Alwaysavailable;
	}

	public WebElement getLogin_oldpopup() {
		return login_oldpopup;
	}

	public WebElement getBtn_studysitecontent() {
		return btn_studysitecontent;
	}

	public WebElement getBtn_studysitessearchContent() {
		return btn_studysitessearchContent;
	}

	public WebElement getBtn_Oldstudysites() {
		return btn_Oldstudysites;
	}

	public WebElement getBtn_oldsearchContent() {
		return btn_oldsearchContent;
	}

	public WebElement getOld_newspaperRadiobtn() {
		return old_newspaperRadiobtn;
	}

	public WebElement getLogin_popup() {
		return login_popup;
	}

	public WebElement getRadiobtn_webREsource() {
		return radiobtn_webREsource;
	}

	public WebElement getBtn_searchContent() {
		return btn_searchContent;
	}

	public WebElement getAdvanceSearchpopup_newspaper_radiobtn() {
		return advanceSearchpopup_newspaper_radiobtn;
	}

	/****************************************
	 * * Action Methods
	 *****************************************************/

	public void click_newspaperRadiobtn() {
		javascriptScroll(advanceSearchpopup_newspaper_radiobtn);
		jsClick(advanceSearchpopup_newspaper_radiobtn);
		waitFor(3000);

	}

	public void enter_searchContent(String content) {
		ClickOnWebElement(input_search);
		SendKeysOnWebElement(input_search, content);
		waitFor(3000);

	}

	public void click_searchCTA() {
		javascriptScroll(btn_search);
		jsClick(btn_search);
		waitFor(2000);

	}

	public void verify_searchkeyword() {
		String content = "hello";
		String text = search_word.getText();
		if (content.equals(text)) {
			System.out.println("user is able to view the newpapers & magazines based on saerch keyword ");
		} else {
			System.out.println("user is  not able to view the newpapers & magazines based on saerch keyword ");
		}

	}

	public void click_ReadnowCTA() {
		javascriptScroll(readnow_cta);
		jsClick(readnow_cta);
		waitFor(3000);

	}

	public void select_webresourceRadiobtn() {
		javascriptScroll(radiobtn_webREsource);
		jsClick(radiobtn_webREsource);
		waitFor(2000);

	}

	public void click_oldAdvanceSearch() {
		visibilityWait(old_advansearchtxt);
		jsClick(old_advansearchtxt);
		visibilityWait(AdvanceSearch_popupOverlay);

	}

	public void enter_oldsearchContent(String content) {
		ClickOnWebElement(old_inputSearch);
		SendKeysOnWebElement(old_inputSearch, content);
		waitFor(2000);

	}

	public void click_oldnewspaperRadiobtn() {
		javascriptScroll(old_newspaperRadiobtn);
		jsClick(old_newspaperRadiobtn);
		waitFor(2000);

	}

	public void click_OldsearchCTA() {
		javascriptScroll(btn_oldsearch);
		jsClick(btn_oldsearch);
		waitFor(3000);

	}

	public void verify_oldsearchkeyword() {
		String content = "hello";
		String text = search_oldword.getText();
		if (content.contains("hello")) {
			System.out.println("user is able to view the newpapers & magazines based on saerch keyword ");
		} else {
			System.out.println("user is  not able to view the newpapers & magazines based on saerch keyword ");
		}

	}

	public void click_oldReadnowCTA() {
		javascriptScroll(oldreadnow_cta);
		jsClick(oldreadnow_cta);
		waitFor(3000);

	}

	public void select_studysitesRadiobtn() {
		javascriptScroll(btn_Oldstudysites);
		jsClick(btn_Oldstudysites);
		waitFor(2000);

	}

	public void categorySection_notshownAlwaysAvailable() {
		visibilityWait(view_category);
		for (int i = 0; i < category_options.size(); i++) {
			if (!category_options.get(i).getText().equals("Always Available")) {
				System.out.println("user is not able to view always available on category section");
			} else {
				System.out.println("user is able to view always available on category section");
			}
		}

	}

	public boolean view_AlwaysAvailableCarousel() {
		javascriptScroll(lib_Alwaysavailable);
		boolean b = true;
		isElementPresent(lib_Alwaysavailable);
		return b;
	}

	public void select_oldalwaysAvailable() {
		javascriptScroll(Oldalwaysavailable_radiobtn);
		jsClick(Oldalwaysavailable_radiobtn);
		waitFor(2000);
	}

	public void clickSortByRefinerOption(String sortByType) {

		if (refinerSortBy.getAttribute("aria-expanded").equalsIgnoreCase("false")) {
			jsClick(refinerSortBy);
		}

		String dynamicText = sortByType;
		String Id = "loc_refiners_" + dynamicText;

		try {
			clickById(Id);
		} catch (Exception e) {
			dynamicText = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '"
					+ sortByType.toLowerCase() + "')]/ancestor::p-radiobutton";
			clickByXPath(dynamicText);
		}

		jsClick(refinerSortBy);

	}

	public void clickAvailabilityRefinerOption(String availability) {
		String dynamicText = availability;
		String Id = "loc_refiners_" + dynamicText;
		jsClick(refinerOptionAvailability);
		javascriptScroll(availableNowAvailabilityRefinerOption);
		waitFor(4000);
		clickById(Id);
		jsClick(refinerOptionAvailability);
	}

	public void clickAgeLevelRefinerOption(String ageLevel) {

		String dynamicText = ageLevel;

		String Id = "loc_refiners_" + dynamicText;
		String xpath = "//label[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), \""
				+ dynamicText.toLowerCase() + "\")]/parent::div";

//		try {
		if (isElementPresent(refinerAgeLevel)
				&& (refinerAgeLevel.getAttribute("aria-expanded").equalsIgnoreCase("false"))) {
			jsClick(refinerAgeLevel);

		} else if (isElementPresent(thirdPartyRefinerAgeLevel)) {

			jsClick(thirdPartyRefinerAgeLevel);
		}

		try {
			if (!ageLevel.isEmpty()) {
				clickById(Id);
			}
		} catch (Exception e) {
			if (isElementPresent(thirdPartyRefinerAgeLevel)) {
				clickByXPath(xpath);
			}
		}

		if (isElementPresent(refinerAgeLevel)) {
			jsClick(refinerAgeLevel);
		} else if (isElementPresent(thirdPartyRefinerAgeLevel)) {
			jsClick(thirdPartyRefinerAgeLevel);
		}
	}

	public void clickLanguage(String language) {

		if (isElementPresent(refinerLanguage)
				&& (refinerLanguage.getAttribute("aria-expanded").equalsIgnoreCase("false"))) {
			System.out.println("came inside of normal refiners");
			jsClick(refinerLanguage);

		} else if (isElementPresent(thirdPartyRefinerLanguage)) {
			
			System.out.println("came inside of third party refiner");
			jsClick(thirdPartyRefinerLanguage);

		}
		String dynamicText = language;
		String xpath = "//label[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), \""
				+ dynamicText.toLowerCase() + "\")]";
		String Id = "loc_refiners_" + dynamicText;

		try {
			if (!language.isEmpty()) {
				clickById(Id);
			}
		} catch (Exception e) {
			if(isElementPresent(thirdPartyRefinerLanguage)) {
			clickByXPath(xpath);
			}
		}

		if (isElementPresent(refinerLanguage)) {
			jsClick(refinerLanguage);

		} else if (isElementPresent(thirdPartyRefinerLanguage)){
			
			jsClick(thirdPartyRefinerLanguage);
		}

	}

	public void clickAttributes() {
		
		String Id = "loc_refiners_eRead-Along";
		jsClick(refinerAttributes);
		javascriptScroll(eReadAlongAttributeOption);
		waitFor(4000);
		clickById(Id);
		jsClick(refinerAttributes);
	}
	
	public void clickSearchBtn() {
		
		javascriptScroll(refinerSearchBtn);
		jsClick(refinerSearchBtn);
	}

	public int getSearchResultAfterApplyingFilter() {
		
		javascriptScroll(resultsAfterApplyingFilters);
		visibilityWait(resultsAfterApplyingFilters);
		return Integer.parseInt(resultsAfterApplyingFilters.getText().replaceAll("[^0-9]", ""));
	}

//	public void selectBisacCodes(String category) {

//		String searchSort = "Popularity";
//
//		category = convertCategories(category);
//
//		apiResponses = APIClient.getBrowseSearchTitleResponse(category, searchSort);
//
//		HashMap<String, String> isbnAudienceMap = new HashMap<String, String>();
//
//		for (SearchTitleResponse apiResponse : apiResponses) {
//			int apiResultCount = Integer
//					.parseInt(apiResponse.getSearchTitleResponseData().getSearchTitleResult().getResultCount());
//
//			Assert.assertEquals("browse result count should match", search.searchResultCount(), apiResultCount);
//
//			List<Title> titles = apiResponse.getSearchTitleResponseData().getSearchTitleResult().getTitlesList()
//					.getTitle();
//			String audioCountResult = apiResponse.getSearchTitleResponseData().getSearchTitleResult()
//					.geteAudioBookCount();
//			String eBookCountResult = apiResponse.getSearchTitleResponseData().getSearchTitleResult().geteBookCount();
//			List<String> isbnListFromAPI = new ArrayList<String>();
//
//			for (Title title : titles) {
//				String audience = title.getAudience();
//				String isbn = title.getiSBN();
//				isbnAudienceMap.put(isbn, audience);
//				isbnListFromAPI.add(isbn);
//				System.out.println("extracted audience code for title : " + isbn + " is : " + audience);
//			}
//
//			List<String> isbListfromUI = new ArrayList<String>();
//
//			isbListfromUI = login.get_TitlesISBN();
//
//			for (String isbn : isbListfromUI) {
//				System.out.println("isbn from UI: " + isbn);
//				if (isbnAudienceMap.containsKey(isbn)) {
//					System.out.println("isbnAudienceMap.get(isbn): " + isbnAudienceMap.get(isbn));
////		    		Assert.assertTrue("Audience should be Teen or Children", isbnAudienceMap.get(isbn).contains("Teen") ||isbnAudienceMap.get(isbn).contains("Children"));
//					System.out
//							.println("HashMap contains the key: " + isbn + "Audience is: " + isbnAudienceMap.get(isbn));
//				} else {
//					System.out.println("HashMap does not contain the key: " + isbn);
//					System.out.println("isbnAudienceMap.get(isbn): " + isbnAudienceMap.get(isbn));
//				}
//			}
//		}
//
//	}

	public String convertCategories(String input) {

		String[] categories = input.split("#");
		System.out.println("categories" + categories.length);
		StringBuilder result = new StringBuilder();

		for (String category : categories) {
			Categories enumCategory = getCategory(category);

			System.out.println("enumvalues" + enumCategory);
			if (enumCategory != null) {
				result.append(enumCategory.getDescription());
				result.append("#");
				System.out.println("After splitting category " + result);
			}
		}

		if (result.length() > 0) {
			result.deleteCharAt(result.length() - 1); // Remove the trailing #
		}
		return result.toString();
	}

	public Categories getCategory(String categoryName) {

		for (Categories category : Categories.values()) {
			if (categoryName.contains(category.name())) {
				System.out.println("Enum values of categories " + category);
				return category;
			}
		}
		return null; // Category not found

	}

}
