package pom.kidszone;

import org.junit.Assert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.driverfactory.DriverManager;
import com.resuableMethods.CommonAction;
import com.utilities.ExcelReader;
import com.utilities.Logger;

public class Recommendations extends CommonAction {
	
	static ExcelReader reader = new ExcelReader();
	Holds hold = new Holds(DriverManager.getDriver());
	Wishlist wish = new Wishlist(DriverManager.getDriver());
	public Recommendations(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "loc_labelPurchase Requests")
	private WebElement purchaseReqButton;
	
	@FindBy(xpath = "(//*[text()[normalize-space()='RECOMMENDATIONS']])[1]")
	private WebElement purchaseReqHam;
	
	@FindBy(id = "loc_txtPurchase Requests")
	private WebElement purchaseReqPage;
	
	@FindBy(xpath = "//*[@class='no-stuffs ng-star-inserted']")
	private WebElement purchaseReqNoStuff;
	
	@FindBy(xpath = "(//*[contains(text(),'Recommendations')])[1]")
	private WebElement purchaseReqHamPage;
	
	@FindBy(xpath = "(//*[contains(text(),'WISHLIST')])[2]")
	private WebElement wishListDemo;
	
	@FindBy(xpath = "(//*[contains(text(),'Wish List')])[1]")
	private WebElement wishListDemoPage;
	
	@FindBy(xpath = "(//*[contains(text(),'RECOMMENDATIONS')])[2]")
	private WebElement recommendations;
	
	@FindBy(id = "breadcrumb-link-1")
	private WebElement breadCrumb;
	
	@FindBy(xpath = "//axis360-my-stuff-grid-card[@class='ng-star-inserted']")
	private WebElement recommendedTitle;
	
	@FindBy(xpath = "(//*[@class='kz-card-btn kz-card-btn-grid primary-action ng-star-inserted'])[1]")
	private WebElement primaryCta;
	
	@FindBy(xpath = "//*[contains(text(),'Cancel Request')]")
	private WebElement secCta;
	
	@FindBy(id = "loc_btnSort")
	private WebElement sortButton;
	
	@FindBy(xpath = "//*[@class='mat-menu-content ng-tns-c113-1']")
	private WebElement sortMenu;
	
	@FindBy(id = "loc_Recently Requested")
	private WebElement latesRecommend;
	
	@FindBy(id = "loc_Ratings")
	private WebElement rating;
	
	@FindBy(id = "loc_A-Z")
	private WebElement aToZ;
	
	@FindBy(id = "loc_btnSort")
	private WebElement btn_SortIcon;
	
	public WebElement getSecCta() {
		return secCta;
	}

	public WebElement getPrimaryCta() {
		return primaryCta;
	}

	public WebElement getRecommendedTitle() {
		return recommendedTitle;
	}

	public WebElement getBreadCrumb() {
		return breadCrumb;
	}

	public WebElement getPurchaseReqNoStuff() {
		return purchaseReqNoStuff;
	}

	public WebElement getPurchaseReqPage() {
		return purchaseReqPage;
	}

	public void clickPurchaseReq() {
		hold.myShelfClick();
		WaitForWebElement(purchaseReqButton);
		ClickOnWebElement(purchaseReqButton);
		WaitForWebElement(purchaseReqPage);
	}
	public void quickCtaPR() {
		ClickOnWebElement(wish.getWishlist());
		WaitForWebElement(wish.getWishlistPage());
		ClickOnWebElement(purchaseReqButton);
		WaitForWebElement(purchaseReqPage);
	}
	public void clickPurReqHam() {
		WaitForWebElement(purchaseReqHam);
		ClickOnWebElement(purchaseReqHam);
		WaitForWebElement(purchaseReqHamPage);
	}
	public void quickCtaPRDemo() {
		ClickOnWebElement(recommendations);
		WaitForWebElement(purchaseReqHamPage);
	}
	
	public void navigateBackCta() {
		DriverManager.getDriver().navigate().back();
		WaitForWebElement(wish.getWishlistPage());
		ClickOnWebElement(purchaseReqButton);
		WaitForWebElement(purchaseReqPage);
	}
	
	public void navigateBackCtaDemo() {
		DriverManager.getDriver().navigate().back();
		WaitForWebElement(hold.getAdultLibraryPage());
	}
	
	public void secCtaOptions() {
		WaitForWebElement(hold.getMoreOptions());
		jsClick(hold.getMoreOptions());
		WaitForWebElement(secCta);
	}
	
	public void sortOptions() {
		WaitForWebElement(latesRecommend);
		Assert.assertTrue(latesRecommend.isDisplayed());
		Assert.assertTrue(rating.isDisplayed());
		Assert.assertTrue(aToZ.isDisplayed());
		waitFor(2000);
	}
}
