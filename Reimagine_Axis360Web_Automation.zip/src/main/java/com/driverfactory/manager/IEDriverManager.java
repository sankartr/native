package com.driverfactory.manager;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.driverfactory.Factory;
import com.driverfactory.DriverFactory.Target;

import exceptions.BrowserNotSupportedException;

import static io.github.bonigarcia.wdm.config.DriverManagerType.IEXPLORER;
import static org.apache.commons.lang3.SystemUtils.*;

public class IEDriverManager implements Factory {

    @Override
    public WebDriver createDriver(Target target) {
        if (!IS_OS_WINDOWS) throw new
                BrowserNotSupportedException("IE is not supported on " + System.getProperty("os.name"));

        WebDriverManager.getInstance(IEXPLORER).setup();

        return new InternetExplorerDriver();
    }
}
