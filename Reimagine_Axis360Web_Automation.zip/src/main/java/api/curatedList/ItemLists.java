package api.curatedList;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ItemLists {
	

	private CuratedResponse[] curatedResponse;

	public CuratedResponse[] getCuratedResponse() {
		return curatedResponse;
	}

	public void setCuratedResponse(CuratedResponse[] curatedResponse) {
		this.curatedResponse = curatedResponse;
	}

}
