package api.curatedList;

import java.util.List;

public class CuratedResponse {
	private String listId;
	private String listName;
	private String description;
	private int totalItems;
	private int pageNum;
	private int pageSize;
	private String sortField;
	private int sortOrder;
	private CuratedResponseFilter filter;
	private List<CuratedResponseItem> items;

	public String getListId() {
		return listId;
	}

	public void setListId(String listId) {
		this.listId = listId;
	}

	public String getListName() {
		return listName;
	}

	public void setListName(String listName) {
		this.listName = listName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getTotalItems() {
		return totalItems;
	}

	public void setTotalItems(int totalItems) {
		this.totalItems = totalItems;
	}

	public int getPageNum() {
		return pageNum;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getSortField() {
		return sortField;
	}

	public void setSortField(String sortField) {
		this.sortField = sortField;
	}

	public int getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}

	public CuratedResponseFilter getFilter() {
		return filter;
	}

	public void setFilter(CuratedResponseFilter filter) {
		this.filter = filter;
	}

	public List<CuratedResponseItem> getItems() {
		return items;
	}

	public void setItems(List<CuratedResponseItem> items) {
		this.items = items;
	}

}
