package api.curatedList;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CuratedResponseFilter {
    @JsonProperty("available")
    private String available;

    @JsonProperty("format")
    private String format;

    @JsonProperty("audience")
    private String audience;

    @JsonProperty("language")
    private String language;

    @JsonProperty("releaseDate")
    private long releaseDate;

    @JsonProperty("addedDate")
    private long addedDate;

    @JsonProperty("rtv")
    private String rtv;

    @JsonProperty("axisAttribute")
    private List<String> axisAttribute;

    @JsonProperty("profileType")
    private int profileType;

	public String getAvailable() {
		return available;
	}

	public void setAvailable(String available) {
		this.available = available;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getAudience() {
		return audience;
	}

	public void setAudience(String audience) {
		this.audience = audience;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public long getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(long releaseDate) {
		this.releaseDate = releaseDate;
	}

	public long getAddedDate() {
		return addedDate;
	}

	public void setAddedDate(long addedDate) {
		this.addedDate = addedDate;
	}

	public String getRtv() {
		return rtv;
	}

	public void setRtv(String rtv) {
		this.rtv = rtv;
	}

	public List<String> getAxisAttribute() {
		return axisAttribute;
	}

	public void setAxisAttribute(List<String> axisAttribute) {
		this.axisAttribute = axisAttribute;
	}

	public int getProfileType() {
		return profileType;
	}

	public void setProfileType(int profileType) {
		this.profileType = profileType;
	}

}
