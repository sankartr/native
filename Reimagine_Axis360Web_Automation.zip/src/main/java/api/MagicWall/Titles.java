package api.MagicWall;

import java.util.List;

public class Titles {
	
	
	private List<Title> title;

	public List<Title> getTitle() {
		return title;
	}

	public void setTitle(List<Title> title) {
		this.title = title;
	}

}
