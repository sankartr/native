package api.MagicWall;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class SearchParameters {
	@JsonIgnoreProperties(ignoreUnknown = true)
	private String searchCatagory;
	private String searchFormat;
    private String searchLabel;
    private String searchSort;
    private Object searchType;
    private Object searchValue;
    
    
    public String getSearchCatagory() {
		return searchCatagory;
	}
	public void setSearchCatagory(String searchCatagory) {
		this.searchCatagory = searchCatagory;
	}
	public String getSearchFormat() {
		return searchFormat;
	}
	public void setSearchFormat(String searchFormat) {
		this.searchFormat = searchFormat;
	}
	public String getSearchLabel() {
		return searchLabel;
	}
	public void setSearchLabel(String searchLabel) {
		this.searchLabel = searchLabel;
	}
	public String getSearchSort() {
		return searchSort;
	}
	public void setSearchSort(String searchSort) {
		this.searchSort = searchSort;
	}
	public Object getSearchType() {
		return searchType;
	}
	public void setSearchType(Object searchType) {
		this.searchType = searchType;
	}
	public Object getSearchValue() {
		return searchValue;
	}
	public void setSearchValue(Object searchValue) {
		this.searchValue = searchValue;
	}

}
