package api.MagicWall;

import java.util.List;

public class Narrators {
	
	private Object author;
	private List<Narrator> narrator;
	
	public Object getAuthor() {
		return author;
	}
	public void setAuthor(Object author) {
		this.author = author;
	}
	public List<Narrator> getNarrator() {
		return narrator;
	}
	public void setNarrator(List<Narrator> narrator) {
		this.narrator = narrator;
	}

}
