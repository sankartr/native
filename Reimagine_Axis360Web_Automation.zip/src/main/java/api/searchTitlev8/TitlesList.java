package api.searchTitlev8;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TitlesList {
	    @JsonProperty("title")
	    @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	    private List<Title> titles;

	    public List<Title> getTitles() {
	        return titles;
	    }

	    public void setTitles(List<Title> titles) {
	        this.titles = titles;
	    }

}
