package api.searchTitlev8;

public class Narrator {
	
    private String narrator;

    public String getNarrator() {
        return narrator;
    }

    public void setNarrator(String narrator) {
        this.narrator = narrator;
    }

}
