package api.magicWallList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SearchParameters {
	
	
	@JsonProperty("@xmlns")
	private String xmlns;

	public String getXmlns() {
		return xmlns;
	}

	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}

}
