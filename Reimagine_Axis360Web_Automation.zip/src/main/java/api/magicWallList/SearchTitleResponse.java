package api.magicWallList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SearchTitleResponse {
	
	@JsonProperty("@xmlns")
	private String xmlns;
	@JsonProperty("@xmlns$xsi")
	private String xmlns$xsi;
	@JsonProperty("@xmlns$xsd")
	private String xmlns$xsd;
	@JsonProperty("searchTitleResult")
	private SearchTitleResult searchTitleResult;
	
	public String getXmlns() {
		return xmlns;
	}
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}
	public String getXmlns$xsi() {
		return xmlns$xsi;
	}
	public void setXmlns$xsi(String xmlns$xsi) {
		this.xmlns$xsi = xmlns$xsi;
	}
	public String getXmlns$xsd() {
		return xmlns$xsd;
	}
	public void setXmlns$xsd(String xmlns$xsd) {
		this.xmlns$xsd = xmlns$xsd;
	}
	public SearchTitleResult getSearchTitleResult() {
		return searchTitleResult;
	}
	public void setSearchTitleResult(SearchTitleResult searchTitleResult) {
		this.searchTitleResult = searchTitleResult;
	}

}
