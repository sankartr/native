package api.magicWallList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SearchTitleResult {
	
	@JsonProperty("status")
	private Status status;
	@JsonProperty("searchParameters")
	private SearchParameters searchParameters;
	@JsonProperty("resultCount")
	private String resultCount;
	@JsonProperty("paramCatagory")
	private String paramCatagory;
	@JsonProperty("searchSort")
	private String searchSort;
	@JsonProperty("searchSortOrder")
	private String searchSortOrder;
	@JsonProperty("pageNumber")
	private String pageNumber;
	@JsonProperty("titlesList")
	private TitlesList titlesList;
	
	
	
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public SearchParameters getSearchParameters() {
		return searchParameters;
	}
	public void setSearchParameters(SearchParameters searchParameters) {
		this.searchParameters = searchParameters;
	}
	public String getResultCount() {
		return resultCount;
	}
	public void setResultCount(String resultCount) {
		this.resultCount = resultCount;
	}
	public String getParamCatagory() {
		return paramCatagory;
	}
	public void setParamCatagory(String paramCatagory) {
		this.paramCatagory = paramCatagory;
	}
	public String getSearchSort() {
		return searchSort;
	}
	public void setSearchSort(String searchSort) {
		this.searchSort = searchSort;
	}
	public String getSearchSortOrder() {
		return searchSortOrder;
	}
	public void setSearchSortOrder(String searchSortOrder) {
		this.searchSortOrder = searchSortOrder;
	}
	public String getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(String pageNumber) {
		this.pageNumber = pageNumber;
	}
	public TitlesList getTitlesList() {
		return titlesList;
	}
	public void setTitlesList(TitlesList titlesList) {
		this.titlesList = titlesList;
	}

}
