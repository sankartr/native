package api.magicWallList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FeaturedList {
	
	
	@JsonProperty("version")
	private String version;
	@JsonProperty("encoding")
	private String encoding;
	@JsonProperty("searchTitleResponse")
	private SearchTitleResponse searchTitleResponse;
	
	
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getEncoding() {
		return encoding;
	}
	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}
	public SearchTitleResponse getSearchTitleResult() {
		return searchTitleResponse;
	}
	public void SearchTitleResponse(SearchTitleResponse SearchTitleResponse) {
		this.searchTitleResponse = SearchTitleResponse;
	}

}
