package api.magicWallList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Title {
	
	
	@JsonProperty("@xmlns")
	private String xmlns;
	@JsonProperty("bookTitle")
	private String bookTitle;
	@JsonProperty("authors")
	private Authors authors;
	@JsonProperty("titleID")
	private String titleID;
	@JsonProperty("formatType")
	private String formatType;
	@JsonProperty("iSBN")
	private String iSBN;
	@JsonProperty("imageURL")
	private String imageURL;
	@JsonProperty("narrators")
	private Object narrators;
	@JsonProperty("publicationDate")
	private String publicationDate;
	@JsonProperty("series")
	private Object series;
	@JsonProperty("synopsis")
	private Object synopsis;
	@JsonProperty("purchaseOption")
	private Object purchaseOption;
	@JsonProperty("publisher")
	private Object publisher;
	@JsonProperty("subject")
	private Object subject;
	@JsonProperty("edition")
	private Object edition;
	@JsonProperty("audience")
	private String audience;
	@JsonProperty("isAvailable")
	private String isAvailable;
	@JsonProperty("isBLIO")
	private String isBLIO;
	@JsonProperty("isAcoustik")
	private String isAcoustik;
	@JsonProperty("isPDF")
	private String isPDF;
	@JsonProperty("isEPub")
	private String isEPub;
	@JsonProperty("isHold")
	private String isHold;
	@JsonProperty("isCheckout")
	private String isCheckout;
	@JsonProperty("axisAttribute")
	private Object axisAttribute;
	@JsonProperty("runTime")
	private String runTime;
	@JsonProperty("createdDate")
	private String createdDate;
	@JsonProperty("OnOrderQuantity")
	private String onOrderQuantity;
	@JsonProperty("TotalQuantity")
	private String totalQuantity;
	@JsonProperty("PageLength")
	private String pageLength;
	
	
	
	public String getXmlns() {
		return xmlns;
	}
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public Authors getAuthors() {
		return authors;
	}
	public void setAuthors(Authors authors) {
		this.authors = authors;
	}
	public String getTitleID() {
		return titleID;
	}
	public void setTitleID(String titleID) {
		this.titleID = titleID;
	}
	public String getFormatType() {
		return formatType;
	}
	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}
	public String getiSBN() {
		return iSBN;
	}
	public void setiSBN(String iSBN) {
		this.iSBN = iSBN;
	}
	public String getImageURL() {
		return imageURL;
	}
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}
	public Object getNarrators() {
		return narrators;
	}
	public void setNarrators(Object narrators) {
		this.narrators = narrators;
	}
	public String getPublicationDate() {
		return publicationDate;
	}
	public void setPublicationDate(String publicationDate) {
		this.publicationDate = publicationDate;
	}
	public Object getSeries() {
		return series;
	}
	public void setSeries(Object series) {
		this.series = series;
	}
	public Object getSynopsis() {
		return synopsis;
	}
	public void setSynopsis(Object synopsis) {
		this.synopsis = synopsis;
	}
	public Object getPurchaseOption() {
		return purchaseOption;
	}
	public void setPurchaseOption(Object purchaseOption) {
		this.purchaseOption = purchaseOption;
	}
	public Object getPublisher() {
		return publisher;
	}
	public void setPublisher(Object publisher) {
		this.publisher = publisher;
	}
	public Object getSubject() {
		return subject;
	}
	public void setSubject(Object subject) {
		this.subject = subject;
	}
	public Object getEdition() {
		return edition;
	}
	public void setEdition(Object edition) {
		this.edition = edition;
	}
	public String getAudience() {
		return audience;
	}
	public void setAudience(String audience) {
		this.audience = audience;
	}
	public String getIsAvailable() {
		return isAvailable;
	}
	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}
	public String getIsBLIO() {
		return isBLIO;
	}
	public void setIsBLIO(String isBLIO) {
		this.isBLIO = isBLIO;
	}
	public String getIsAcoustik() {
		return isAcoustik;
	}
	public void setIsAcoustik(String isAcoustik) {
		this.isAcoustik = isAcoustik;
	}
	public String getIsPDF() {
		return isPDF;
	}
	public void setIsPDF(String isPDF) {
		this.isPDF = isPDF;
	}
	public String getIsEPub() {
		return isEPub;
	}
	public void setIsEPub(String isEPub) {
		this.isEPub = isEPub;
	}
	public String getIsHold() {
		return isHold;
	}
	public void setIsHold(String isHold) {
		this.isHold = isHold;
	}
	public String getIsCheckout() {
		return isCheckout;
	}
	public void setIsCheckout(String isCheckout) {
		this.isCheckout = isCheckout;
	}
	public Object getAxisAttribute() {
		return axisAttribute;
	}
	public void setAxisAttribute(Object axisAttribute) {
		this.axisAttribute = axisAttribute;
	}
	public String getRunTime() {
		return runTime;
	}
	public void setRunTime(String runTime) {
		this.runTime = runTime;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getOnOrderQuantity() {
		return onOrderQuantity;
	}
	public void setOnOrderQuantity(String onOrderQuantity) {
		this.onOrderQuantity = onOrderQuantity;
	}
	public String getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(String totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public String getPageLength() {
		return pageLength;
	}
	public void setPageLength(String pageLength) {
		this.pageLength = pageLength;
	}

}
