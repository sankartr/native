package api.libraryComponents;

import java.util.List;

public class Component {
	private String id;
	private String type;
	private int sequence;
	private String title;
	private String description;
	private String entityId;
	private String entityType;
	private boolean enabled;
	private boolean editable;
	private boolean mandatory;
	private boolean readOnly;
	private boolean hidden;
    private DataApi dataApi;
    private JsonTempl jsonTempl;
	private List<Component> components;
    
    public Component() {}

	public Component(String id, String type, int sequence, String title, String description, String entityId,
			String entityType, boolean enabled) {
		this.id = id;
		this.type = type;
		this.sequence = sequence;
		this.title = title;
		this.description = description;
		this.entityId = entityId;
		this.entityType = entityType;
		this.enabled = enabled;
	}

	public DataApi getDataApi() {
		return dataApi;
	}

	public void setDataApi(DataApi dataApi) {
		this.dataApi = dataApi;
	}

	public JsonTempl getJsonTempl() {
		return jsonTempl;
	}

	public void setJsonTempl(JsonTempl jsonTempl) {
		this.jsonTempl = jsonTempl;
	}

	// Getters and setters

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEntityId() {
		return entityId;
	}

	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}

	public boolean isMandatory() {
		return mandatory;
	}

	public void setMandatory(boolean mandatory) {
		this.mandatory = mandatory;
	}

	public boolean isReadOnly() {
		return readOnly;
	}

	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}

	public boolean isHidden() {
		return hidden;
	}

	public void setHidden(boolean hidden) {
		this.hidden = hidden;
	}

	public List<Component> getComponents() {
		return components;
	}

	public void setComponents(List<Component> components) {
		this.components = components;
	}

}
