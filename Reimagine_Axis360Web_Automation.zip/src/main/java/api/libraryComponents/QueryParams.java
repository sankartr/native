package api.libraryComponents;

class QueryParams {
    // Define query parameters properties
}