package api.libraryComponents;

class JsonTempl {
    // Define JSON template properties
}
