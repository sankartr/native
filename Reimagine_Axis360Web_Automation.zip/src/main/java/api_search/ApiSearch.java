package api_search;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.resuableMethods.CommonAction;
import com.utilities.Logger;

public class ApiSearch extends CommonAction {
	
	public ApiSearch(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	
	@FindBy(xpath = "//*[@id='loc_dropdwnBrowseBySubject']/following::div[@class='radio-group check-group ng-star-inserted']")
	private List<WebElement> browse_subjects;
	
	@FindBy(xpath = "//*[@id='loc_dropdwnFeaturedCategories']/following::div[@class='radio-group check-group']")
	public List<WebElement> browse_categories;
	
	@FindBy(xpath = "//*[contains(text(),' Availability')]")
	public static WebElement Refiner_Availability_dropdwn;
	
	@FindBy(xpath = "//*[contains(text(),' Availability')]/following::mat-checkbox")
	public static List<WebElement> Refiner_Availability_options;
	
	@FindBy(id = "loc_dropdwnFormat")
	public static WebElement Format_dropdwn;
	
	@FindBy(xpath = "//h2[@id='loc_dropdwnFormat']/following::div[@class='radio-group check-group ng-star-inserted']")
	public List<WebElement> Refiner_Format_options;

	@FindBy(id = "loc_dropdwnAge Level")
	public WebElement AgeLevel_dropdown;
	
	@FindBy(xpath = "//h2[@id='loc_dropdwnAge Level']/following::div[@class='radio-group check-group ng-star-inserted']")
	public List<WebElement> AgeLevel_options;
	
	@FindBy(xpath = "//*[contains(text(),' Language')]")
	public static WebElement Refiner_Language_dropdwn;
	
	@FindBy(xpath = "//*[contains(text(),' Language')]/following::mat-checkbox")
	public static List<WebElement> Refiner_Language_options;
	
	
	
	
	
	
	
	
	
	
	
	public void select_Subjects(String subjects) {
		for (int i = 0; i < browse_subjects.size(); i++) {
			if (browse_subjects.get(i).getText().contains(subjects)) {
				Logger.log("subjects : " + browse_subjects.get(i).getText());
				ClickOnWebElement(browse_subjects.get(i));
				break;
			}
			
		}

	}
	
	public void select_categories(String categories) {
		for (int i = 0; i < browse_categories.size(); i++) {
			if (browse_categories.get(i).getText().contains(categories)) {
				Logger.log("Categories : " + browse_categories.get(i).getText());
				ClickOnWebElement(browse_categories.get(i));
				break;
			}
			
		}

	}
	
	public void click_AvailabilityDropDown() {
		javascriptScroll(Refiner_Availability_dropdwn);
		jsClick(Refiner_Availability_dropdwn);

	}
	
	public void click_FormatDropDown() {
		javascriptScroll(Format_dropdwn);
		jsClick(Format_dropdwn);

	}
	
	public void click_AgeLevelDropDown() {
		javascriptScroll(AgeLevel_dropdown);
		jsClick(AgeLevel_dropdown);

	}
	
	public void click_LanguageDropDown() {
		javascriptScroll(Refiner_Language_dropdwn);
		jsClick(Refiner_Language_dropdwn);

	}
	
	public void select_AvailabilityOption(String availablity) {
		for (int i = 0; i < Refiner_Availability_options.size(); i++) {
			if (Refiner_Availability_options.get(i).getText().contains(availablity)) {
				Logger.log("AvailablityOption : " + Refiner_Availability_options.get(i).getText());
				ClickOnWebElement(Refiner_Availability_options.get(i));
				break;
			}
			
		}
		

	}
	
	public void select_FormatType(String format) {
		for (int i = 0; i < Refiner_Format_options.size(); i++) {
			if (Refiner_Format_options.get(i).getText().contains(format)) {
				Logger.log("FormatOption : " + Refiner_Format_options.get(i).getText());
				jsClick(Refiner_Format_options.get(i));
				break;
			}
			
		}

	}
	
	public void select_AgeLevelOptions(String AgeLevel) {
		for (int i = 0; i < AgeLevel_options.size(); i++) {
			if (AgeLevel_options.get(i).getText().contains(AgeLevel)) {
				Logger.log("AgeLevelOption : " + AgeLevel_options.get(i).getText());
				jsClick(AgeLevel_options.get(i));
				break;
			}
			
		}

	}
	
	public void select_LanguageOptions(String language) {
		for (int i = 0; i < Refiner_Language_options.size(); i++) {
			if (Refiner_Language_options.get(i).getText().contains(language)) {
				Logger.log("LanguageOption : " + Refiner_Language_options.get(i).getText());
				jsClick(Refiner_Language_options.get(i));
				break;
			}
			
		}

	}
	
	
	
	
	
	
	
}
